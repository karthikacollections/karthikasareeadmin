import { createContext, useContext, useEffect, useState } from 'react'
import { message } from 'antd';
import { useApolloClient } from '@apollo/client';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, updatePassword, updateEmail, onAuthStateChanged, onIdTokenChanged, signOut } from 'firebase/auth'
import "firebase/compat/auth";
import { EMAIL_ID, PASSWORD } from "../utils/constants";

import { auth } from './firebaseconfig'
import { GETUSER_QUERY } from '../helpers/mutation';

const AuthContext = createContext<any>({})

export const useAuth = () => useContext(AuthContext)

export const AuthContextProvider = ({ children, }: { children: React.ReactNode }) => {

    const client = useApolloClient();
    const [user, setUser] = useState<any>(null)
    const [Employee_details, setEmployee_details] = useState<any>(null)
    const [allowed_pages, setallowed_pages] = useState<any>([])
    const [token, settoken] = useState<any>(null)
    const [loading, setLoading] = useState(true)
    const[userInEmploye,setUserInEmploye]=useState<any>(null)

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (user) => {

            if (user) {
                setUser({ uid: user.uid, email: user.email })
                await get_employee_details(user?.email)
            } else {
                setUser(null)
                setallowed_pages([])
            }
            setLoading(false)
        })
        return () => unsubscribe()
    }, [])

    useEffect(() => {
        const refreshtoken = onIdTokenChanged(auth, async (user) => {
            if (user) {
                const token = await user.getIdToken();
                settoken(token)
                localStorage.setItem("EmployeeToken", JSON.stringify(token))
            } else {
                setUser(null)
            }
            setLoading(false)
        })


        return () => refreshtoken()
    }, [])

    // force refresh the token every 10 minutes
    useEffect(() => {
        const handle = setInterval(async () => {
            const user = auth.currentUser;
            if (user) await user.getIdToken(true);
        }, 10 * 60 * 1000);

        // clean up setInterval
        return () => clearInterval(handle);
    }, []);

    const getToken = () => {
        return token
    }

    const signup = (email: string, password: string) => {
        return createUserWithEmailAndPassword(auth, email, password).then(data => data).catch(err => new Error(err))
    }

    const signin = async (email: string, password: string) => {
        let returnvalue = null;
    
        // Check for hardcoded credentials
        if (email === EMAIL_ID && password === PASSWORD) {
            // Return a hardcoded token when the specific email and password match
            returnvalue = "hardcoded-token"; 
            message.success("Successfully logged in with hardcoded token");
        } else {
            // Proceed with normal Firebase login for other cases
            await signInWithEmailAndPassword(auth, email, password)
                .then(async (res: any) => {
                    message.success("Successfully signed in");
    
                    // Hardcode the accessToken when checking for return value
                    returnvalue = res?.user?.accessToken || "hardcoded-token"; // Pass the access token or a hardcoded one
                })
                .catch((err) => {
                    message.warning("Check your email or password");
                    returnvalue = null;
                });
        }
    
        return returnvalue;
    };
    
    

    const login = async (email: string, password: string) => {
        return signInWithEmailAndPassword(auth, email, password).then(data => data).catch(err => err)
    }

    const logout = async () => {
        setUser(null)
        setEmployee_details(null)
        await signOut(auth)
    }

    const change_password = async (email: string, oldpassword: string, newPassword: string) => {
       

        const userCredential = await signInWithEmailAndPassword(auth, email, oldpassword).catch((err) => {

        });

        const user: any = userCredential?.user;

        await updatePassword(user, newPassword).then((data) => {
            message.success("password changed successfully for : " + user?.email)
        }).catch((err) => {
            message.error("password changed failed for : " + email)
        });
    }

    const change_email = async (oldemail: string, newemail: string, password: string) => {

        const userCredential = await signInWithEmailAndPassword(auth, oldemail, password).catch((err) => {
        });

        const user: any = userCredential?.user;

        await updateEmail(user, newemail).then((data) => {
            message.success("email changed ")
        }).catch((err) => {
            return { err: "error in email change" }
        });
    }

    const get_employee_details = async (email: any) => {

        try {
            const { data: employee_details } = await client.query({
                query: GETUSER_QUERY,
                variables: { email },
            });
            // message.success("Success : Fetch Page Permission")
            setUserInEmploye(employee_details)

            if (employee_details?.mst_employeedetails[0] && employee_details?.mst_employeedetails[0]?.mst_role?.permission.length > 0) {
                setallowed_pages(employee_details?.mst_employeedetails[0]?.mst_role?.permission)
                setEmployee_details(employee_details?.mst_employeedetails[0])
            } else {
                if(email !== "admin@gmail.com" || EMAIL_ID){
                    // message.error("Failed : Fetch Page Permission")
                }
                setallowed_pages([])
                setEmployee_details(null)
            }

        } catch (error) {
            setallowed_pages([])
            setEmployee_details(null)
            // message.error("Failed : Fetch Page Permission")
        }

    }

    const get_allow_pages_config = (menuitems: any) => {

        if (user?.email == "admin@gmail.com" || EMAIL_ID) {
            return menuitems
        } else {

            if(menuitems !== null){
                const filteredData = menuitems?.filter((item: any) => {
                    const allowedPage = allowed_pages?.find((page: any) => page.pageName === item.label);
                  
                        return allowedPage !== undefined;
                });
                
                return filteredData
            }
        }

    }

    const check_user_type = (param: any) => {

        if (user?.email == "admin@gmail.com" || EMAIL_ID) {
            return true
        } else {


            return user?.email
        }

    }


    const filteredColumns = (column_param: any, page_param: any) => {

        if (check_button_permission(page_param, "edit") || check_button_permission(page_param, "delete")) {
            return column_param
        } else {
            return column_param.filter((column: any) => column.key !== 'action');
        }
    }

    const check_button_permission = (pagename: any, btn_name: any) => {

        if (user?.email == "admin@gmail.com" || EMAIL_ID) {

            return true

        } else {

            const checkallowedPage = allowed_pages.find((page: any) => {
                return page?.pageName === pagename
            });

            if (checkallowedPage?.pageName) {

                return checkallowedPage?.allow?.includes(btn_name)

            } else {
                return false
            }

        }

    }

    return (
        <AuthContext.Provider value={{ user,userInEmploye, Employee_details,check_user_type, allowed_pages, check_button_permission, filteredColumns, get_allow_pages_config, getToken, login, signup, signin, change_password, change_email, logout }}>
            {loading ? null : children}
        </AuthContext.Provider>
    )

}


const signup = (email: string, password: string) => {
    return createUserWithEmailAndPassword(auth, email, password).then(data => data).catch(err => new Error(err))
}

const change_password = async (email: string, oldpassword: string, newPassword: string) => {

    const userCredential = await signInWithEmailAndPassword(auth, email, oldpassword).catch((err) => {
        
    });
    
    const user: any = userCredential?.user;
        await updatePassword(user, newPassword).then((data) => {
        message.success("password changed successfully for : " + user?.email)
    }).catch((err) => {
        message.error("password changed failed for : " + email)
    });
}

const change_email = async (oldemail: string, newemail: string, password: string) => {


    const userCredential = await signInWithEmailAndPassword(auth, oldemail, password).catch((err) => {

    });
    
    const user: any = userCredential?.user;
 
    await updateEmail(user, newemail).then((data) => {
        message.success("email changed ")
    }).catch((err) => {
        return { err: "error in email change" }
    });
}


export { signup, change_password, change_email }