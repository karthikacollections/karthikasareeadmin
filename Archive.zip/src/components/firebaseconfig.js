import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
    apiKey: "AIzaSyAhD-T1b4WYLI0VWmetjGKgsXfREDpXf0Y",
    authDomain: "hysas-emp.firebaseapp.com",
    projectId: "hysas-emp",
    storageBucket: "hysas-emp.appspot.com",
    messagingSenderId: "858692775187",
    appId: "1:858692775187:web:357e95f45a66233738bee6",
    measurementId: "G-T81YQQLVYN"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth()