import Link from 'next/link'
import { useRouter } from 'next/router'
import { useAuth } from "../../components/auth";

import {
  UsergroupAddOutlined,
  HeatMapOutlined,
  IdcardOutlined,
  UnorderedListOutlined,
  PoweroffOutlined,
  AppstoreAddOutlined,
  DesktopOutlined,
  GoldOutlined,
  DollarOutlined,
  AccountBookOutlined,
  BankOutlined
} from '@ant-design/icons';

import { Group, MantineColor, Navbar, Text, ThemeIcon, UnstyledButton } from '@mantine/core'
import MenuItem from '@/custom_components/custom_menuItem_componentd';

interface MenuItemProps {
  icon: React.ReactNode
  color?: MantineColor
  label: string
  link?: string
  // action?: () => void
}

const data: MenuItemProps[] = [
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Leave Management', link: '/HRM/LeaveManagement' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Payroll', link: '/HRM/Payroll' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Holiday management', link: '/HRM/Holidaymanagement' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Announcement', link: '/HRM/Announcement' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Salary Management', link: '/HRM/SalaryManagement' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Sprint', link: '/HRM/Sprint' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Task', link: '/HRM/Task' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Board', link: '/HRM/Board' },

]

export default function HRMNav() {
  const authenticated = true
  // const { signOut } = useSignOut()
  const router = useRouter()
  const { get_allow_pages_config } = useAuth()

  const filteredData = get_allow_pages_config(data)

  const links = filteredData.map((link: any) => <MenuItem {...link} key={link.label} />); return (
    <Navbar width={{ sm: 110, lg: 110, base: 110, position: "fixed" }} className='settings'>
      <Navbar.Section grow mt="lg">
        {links}
      </Navbar.Section>
    </Navbar>
  )
}
