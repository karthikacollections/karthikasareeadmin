import Link from 'next/link'
import { useRouter } from 'next/router'
import { useAuth } from "../../components/auth";
import { IdcardOutlined } from '@ant-design/icons';
import { Group, MantineColor, Navbar, Text, ThemeIcon, UnstyledButton } from '@mantine/core'
import MenuItem from '@/custom_components/custom_menuItem_componentd';

interface MenuItemProps {
  icon: React.ReactNode
  color?: MantineColor
  label: string
  link?: string
}

const data: MenuItemProps[] = [

  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Employee', link: '/Employees/Employee' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Resume Creation', link: '/Employees/ResumeCreation' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Role', link: '/Employees/Role' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Manage Page', link: '/Employees/Managepage' },
]

export default function EmployeeNav() {

  const route = useRouter()
  

  const { get_allow_pages_config } = useAuth()

  const filteredData = get_allow_pages_config(data)

  const links = filteredData.map((link: any) => <MenuItem {...link} key={link.label} />); 
  
  return (
    <Navbar width={{ sm: 110, lg: 110, base: 110, position: "fixed" }} className='settings'>
      <Navbar.Section grow mt="lg">
        {links}
      </Navbar.Section>
    </Navbar>
  )
}
