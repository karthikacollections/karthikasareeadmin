import Link from 'next/link'
import { useRouter } from 'next/router'
import { useAuth } from "../../components/auth";

import {
  UsergroupAddOutlined,
  HeatMapOutlined,
  IdcardOutlined,
  UnorderedListOutlined,
  PoweroffOutlined,
  AppstoreAddOutlined,
  DesktopOutlined,
  GoldOutlined,
  DollarOutlined,
  AccountBookOutlined,
  BankOutlined
} from '@ant-design/icons';

import { Group, MantineColor, Navbar, Text, ThemeIcon, UnstyledButton } from '@mantine/core'
import MenuItem from '@/custom_components/custom_menuItem_componentd';

interface MenuItemProps {
  icon: React.ReactNode
  color?: MantineColor
  label: string
  link?: string
  // action?: () => void
}

const data: MenuItemProps[] = [
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Company Details', link: '/Settings/ReminderNotification' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'blue', label: 'hist', link: '/Settings/history' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Designation', link: '/Settings/Destination' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Assets', link: '/Settings/Assets' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Skills Manage', link: '/Settings/SkillsManage' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Holiday Management', link: '/Settings/Holidaymanagement' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Leave Type', link: '/Settings/LeaveType' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Category', link: '/Settings/Category' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Sub Category', link: '/Settings/SubCategory' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Organization', link: '/Settings/Organization' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Department', link: '/Settings/Deportment' },
 

]

export default function SettingsNav() {
  const authenticated = true
  // const { signOut } = useSignOut()
  const router = useRouter()
  const { get_allow_pages_config } = useAuth()

  const filteredData = get_allow_pages_config(data)

  const links = filteredData.map((link: any) => <MenuItem {...link} key={link.label} />);
   return (
    <Navbar width={{ sm: 110, lg: 110, base: 110, position: "fixed" }} className='settings'>
      <Navbar.Section grow mt="lg">
        {links}
      </Navbar.Section>
    </Navbar>
  )
}
