import Link from 'next/link'
import { useRouter } from 'next/router'
import { useAuth } from "../../components/auth";
import {
  UsergroupAddOutlined,
  HeatMapOutlined,
  IdcardOutlined,
  UnorderedListOutlined,
  PoweroffOutlined,
  AppstoreAddOutlined,
  DesktopOutlined,
  GoldOutlined,
  DollarOutlined,
  AccountBookOutlined,
  BankOutlined
} from '@ant-design/icons';

import { Group, MantineColor, Navbar, Text, ThemeIcon, UnstyledButton } from '@mantine/core'
import MenuItem from '@/custom_components/custom_menuItem_componentd';
interface MenuItemProps {
  icon: React.ReactNode
  color?: MantineColor
  label: string
  link?: string
  // action?: () => void
}


const data: MenuItemProps[] = [  
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Category', link: '/CRM/Category' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Sub Category', link: '/CRM/SubCategory' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Products', link: '/CRM/Products' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Attributes', link: '/CRM/Attributes' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Orders', link: '/CRM/OrderBookings' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Settings', link: '/CRM/Settings' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Clients', link: '/CRM/Clients' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Banner', link: '/CRM/Banner' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Coupons', link: '/CRM/Copouns' },
  { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Messages', link: '/CRM/Messages' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Bookings', link: '/CRM/Bookings' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Subscriptions', link: '/CRM/Orders' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Remainder', link: '/CRM/Remainder' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Client Management', link: '/CRM/ClientManagement' },
  { icon: <PoweroffOutlined className='settings_group-icon' />, color: 'red', label: 'Sign Out', link: '/login' },
 
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Attributes', link: '/CRM/Attributes' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'User', link: '/CRM/user' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'User Address', link: '/CRM/UserAddress' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Project', link: '/CRM/Project' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Client Management', link: '/CRM/ClientManagement' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Invoice', link: '/CRM/Invoice' },
  // { icon: <IdcardOutlined className='settings_group-icon' />, color: 'red', label: 'Shop', link: '/CRM/Shop' },
]

export default function HRMNav() {
  const authenticated = true
  // const { signOut } = useSignOut()
  const router = useRouter()
  const { get_allow_pages_config } = useAuth()

  const filteredData = get_allow_pages_config(data)

  const links = filteredData.map((link: any) => <MenuItem {...link} key={link.label} />); 
  
  return (
    <Navbar width={{ sm: 110, lg: 110, base: 110, position: "fixed" }} className='settings'>
      <Navbar.Section grow mt="lg">
        {links}
      </Navbar.Section>
    </Navbar>
  )
}
