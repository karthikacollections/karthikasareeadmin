import Link from 'next/link'
import { useRouter } from 'next/router'
import { UsergroupAddOutlined, HeatMapOutlined, IdcardOutlined, UnorderedListOutlined, ClockCircleOutlined, PoweroffOutlined, AppstoreAddOutlined, DesktopOutlined, GoldOutlined, DollarOutlined, AccountBookOutlined, BankOutlined } from '@ant-design/icons';
import { Modal } from 'antd';
import { Group, MantineColor, Navbar, Text, ThemeIcon, UnstyledButton } from '@mantine/core'
import menuData from './json/menu.json';
import { useAuth } from "../components/auth";
import { useEffect, useState } from 'react';
import MenuItem from '@/custom_components/custom_menuItem_componentd';
import SideMenuItem from '@/custom_components/custom_sidMenu';

interface MenuItemProps {
  icon: React.ReactNode
  color?: MantineColor
  label: string
  link?: string
  action?: () => void
}

// Logout menu Item
const MenuOut: React.FC<MenuItemProps> = ({ icon, color, label, link, action }) => {
  const { route } = useRouter()
  const active = route === link
  const Button = (
    <UnstyledButton
      className='navbar_UnstyledButton'
      onClick={action}
      sx={(theme) => ({
        display: 'block',
        width: '100%',
        padding: theme.spacing.xs,
        borderRadius: theme.radius.sm,

        color: active
          ? theme.colors[theme.primaryColor][theme.colorScheme === 'dark' ? 4 : 7]
          : theme.colorScheme === 'dark'
            ? theme.colors.dark[0]
            : theme.black,

        // '&:hover': {
        //   backgroundColor:
        //      theme.colorScheme === 'dark' ? theme.colors.dark[6] : theme.colors.gray[0],

        // }

      })}
    >
      <Group className='navbar_group' >
        {/* <ThemeIcon className='navbar_group-icons'>  */}
        {icon}
        {/* </ThemeIcon>  */}

        <Text size="sm" className='navbar_group-label'>{label}</Text>
      </Group>
    </UnstyledButton>
  )

  return link ? (
    <Link href={link} passHref className='navbar_group-label-link'>
      {Button}
    </Link>
  ) : (
    Button
  )
}

const iconMap: any = {
  GoldOutlined,
  UnorderedListOutlined,
  UsergroupAddOutlined,
  ClockCircleOutlined,
  IdcardOutlined
};

export default function NavBar() {
  const authenticated = true
  const { logout } = useAuth();
  const router = useRouter()
  const [sideMenu, setSidMenu] = useState<any>([])
  const [open, setOpen] = useState(false);
  const { get_allow_pages_config } = useAuth()


  // hanling Submenu
  const handleSubMenu = (address: string) => {
    let path = address?.split('/')
    let sidBarMenu = menuData?.filter((menu: any) => {
      if (menu?.label === path[1]) {
        return menu
      }
    })
    setSidMenu(sidBarMenu[0]?.children)
  };
  useEffect(() => {

    handleSubMenu(router.asPath)
  }, [router.asPath])

  // Side Menu 
  const filteredData = get_allow_pages_config(menuData)

  const links = filteredData.map((link: any) => {

    const IconComponent = iconMap[link.icon]
    const isActive = router.asPath === link.link

    return <MenuItem {...link} link={link?.link} index={link?.id} label={link?.label} icon={<IconComponent className='navbar_group-icon' />} key={link.id} active={isActive} />
  })

  // Side Children Menu

  const sibeMenuFilter = get_allow_pages_config(sideMenu)

  const sideMenuLink = sibeMenuFilter?.map((link: any) => {

    const IconComponent = iconMap[link.icon]
    const isActive = router.asPath === link.link
    if (link.visibility !== "hidden") {
      return <SideMenuItem {...link} link={link?.link} index={link?.id} label={link?.label} icon={<IconComponent className='navbar_group-icon' />} key={link.id} active={isActive} />

    }
  })

  const accModal = async () => {
    localStorage.removeItem("EmployeeToken")
    localStorage.removeItem("Employee")
    await logout();
    router.replace('/login')
    setOpen(false);
  };

  const hideModal = async () => {
    setOpen(false);
  };

  return (
    <div className='setting_nav'>
      <Navbar 
      // width={{ sm: 110, lg: 110, base: 110, position: "fixed" }} 
      className='navbar'>
        <Navbar.Section grow mt="lg">
          {/* {links} */}
          {authenticated &&  (
            <>
              <Modal
                title="Sign Out"
                open={open}
                onOk={accModal}
                onCancel={hideModal}
                okText="Sign Out"
                cancelText="Cancel"
              >
                <p>Are you sure you want to Sign Out ?</p>
              </Modal>

              {/* <MenuOut
                icon={<PoweroffOutlined className='navbar_group-icon' />}
                label={'Sign Out'}
                action={() => { setOpen(true) }}
              /> */}
            </>
          )}
        </Navbar.Section>
      </Navbar>
      {sideMenuLink?.length > 0
        &&
        <Navbar width={{ sm: 110, lg: 110, base: 110, position: "fixed" }} className='navbar'>
          <Navbar.Section grow mt="lg">
            {sideMenuLink}
          </Navbar.Section>
        </Navbar>
      }
    </div>

  )
}
