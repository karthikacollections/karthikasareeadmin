import { useRouter } from 'next/router'
import React, { useEffect, useState } from 'react'
import { useAuth } from './auth'

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, allowed_pages } = useAuth()
  const [check_page_validation, set_check_page_validation] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Check if the current page is excluded from protection
    const excludedPages = ['/CRM/Category'] // Add route path to exclude

    if (excludedPages.includes(router.pathname)) {
      return; // Skip protection for this page
    }

    if (!user) {
      router.push('/login')
    }

    if (Array.isArray(allowed_pages)) {
      const get_pages = allowed_pages?.map(param => param?.pageName)
      const router_name = router?.pathname?.split("/")?.filter(a => a)

      const hasAllValues = get_pages.every(value => router_name.includes(value))
      set_check_page_validation(hasAllValues)
    }
  }, [router, user, allowed_pages])

  return <>{user ? children : null}</>
}

export default ProtectedRoute
