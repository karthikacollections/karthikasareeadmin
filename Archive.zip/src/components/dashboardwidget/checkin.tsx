import React, { useEffect, useState } from "react";
import { useQuery, useMutation } from "@apollo/client";
import { GET_TIMESHEET, GET_EMPLOYDETAILS } from "../../helpers/queries";
import { CREATE_TIMESHEET, UPDATE_TIMESHEET } from "../../helpers/mutation";
import { Button, Card, message, Modal, Input } from "antd";
import { useAuth } from "../../components/auth";
import moment, { now } from "moment";

const { TextArea } = Input;

export const Checkin: React.FC<any> = () => {
  const [employeeStatus, setEmployeeStatus] = useState<any | null>(null);
  const [timeInSeconds, setTimeInSeconds] = useState(0);
  const [currentTime, setCurrentTime] = useState("");
  const [currentDate, setCurrentDate] = useState("");
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [timeStartedByButton, setTimeStartedByButton] = useState<Date | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalInputValue, setModalInputValue] = useState('');
  const [createCheckin] = useMutation(CREATE_TIMESHEET);
  const [updateCheckin] = useMutation(UPDATE_TIMESHEET);
  const { Employee_details } = useAuth();
  const data = { date: moment(new Date()).format("YYYY-MM-DD") };


  const { data: timeData, refetch } = useQuery(GET_TIMESHEET, {
    variables: { date: data.date, employee: Employee_details?.id },
  });

  const [location, setLocation] = useState<any>({
    latitude: null,
    longitude: null,
  });
  const companyGeoLocation = [8.8073923, 78.1337001];
  const [error, setError] = useState<any>(null);



  useEffect(() => {
    if (timeData) {
      const employeeCheckin = timeData?.mst_timesheet?.filter(
        (data: any) => data?.employee === Employee_details?.id
      );

      let latestCheckin = employeeCheckin[employeeCheckin.length - 1];
      let totalLoginTime = 0;


      employeeCheckin.forEach((time: any) => {
        totalLoginTime = totalLoginTime + time.seconds;
      });


      if (employeeCheckin.length > 0) {
        setTimeInSeconds(totalLoginTime);
        setEmployeeStatus(latestCheckin);
        setTimeStartedByButton(new Date(latestCheckin.in_time));

      }
      if (latestCheckin?.out_time === null) {
        let inTimeSplit = latestCheckin?.in_time.split(':')
        let currentTime = new Date().getTime()
        const specificTime = new Date();
        specificTime.setHours(inTimeSplit[0]);
        specificTime.setMinutes(inTimeSplit[1]);
        specificTime.setSeconds(inTimeSplit[2]);
        let prevTime = specificTime.getTime()
        let calculate = currentTime - prevTime
        let differentSec = calculate / 1000;
        let totale = totalLoginTime + differentSec

        setTimeInSeconds(totale);
      }
    }
  }, [timeData, Employee_details?.id]);

  useEffect(() => {
    let timerId: any;

    if (employeeStatus?.in_time && !employeeStatus?.out_time) {

      if (startTime === null) {

        setStartTime(new Date());
      }
      if (timeStartedByButton === null) {

        setTimeStartedByButton(new Date());
      }
      timerId = setInterval(() => {
        setTimeInSeconds((prevTime) => prevTime + 1);
      }, 1000);
    }
    return () => {
      clearInterval(timerId);
    };
  }, [startTime, timeStartedByButton]);

  useEffect(() => {
    const interval = setInterval(() => {
      const currentDateObj = new Date();
      const options = {
        hour12: true,
        timeZone: "Asia/Kolkata", // Use 'Asia/Kolkata' for Indian Standard Time
      };

      setCurrentTime(currentDateObj.toLocaleTimeString("en-IN", options));
      setCurrentDate(currentDateObj.toLocaleDateString("en-IN"));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    locationDiec();
  }, []);



  const reverseddate = (e: string) => {
    const currentDate: string = e;
    const parts: string[] = currentDate.split("/");
    const reversedDate: string = `${parts[2]}-${parts[1]}-${parts[0]}`;
    return reversedDate;
  };

  const formatTime = () => {

    const hours = Math.floor(timeInSeconds / 3600);
    const minutes = Math.floor((timeInSeconds % 3600) / 60);
    const seconds = timeInSeconds % 60;
    return `${hours.toString()}:${minutes.toString().padStart(2, "0")}:${seconds
      .toString()
      .padStart(2, "0")}`;
  };

  const calculateTimeDifferenceInSeconds = (time: any) => {
    let currentTime = new Date();
    const givenTimeString = time;
    const givenTimeArray = givenTimeString.split(":");
    const givenTime = new Date(currentTime);
    givenTime.setHours(
      parseInt(givenTimeArray[0]),
      parseInt(givenTimeArray[1]),
      parseInt(givenTimeArray[2])
    );

    const timeDiffInMilliseconds = givenTime.getTime() - currentTime.getTime();
    return Math.abs(Math.floor(timeDiffInMilliseconds / 1000));
  };


  const calculateDistance = (lat1: any, lon1: any, lat2: any, lon2: any) => {

    const R = 6371;
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;
    return distance;
  };

  const locationDiec = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        }),

          (error: any) => {
            setError(error.message);
          };
      });
    } else {
      alert("navgation not allowed");
      setError(null); // Clear any previous errors
    }
  };



  // Code to allow user to check in when location in on

  const handleCheckinClick = async () => {
    // Check if the browser supports geolocation
    if ("geolocation" in navigator) {
      // Request location permission from the user
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          // User granted location permission, now you can proceed with check-in logic
          if (
            (!employeeStatus?.in_time && !employeeStatus?.out_time) ||
            (employeeStatus?.in_time && employeeStatus?.out_time)
          ) {
            let dis = calculateDistance(
              Employee_details?.mst_organization?.latitude,
              Employee_details?.mst_organization?.longitude,
              position.coords.latitude,
              position.coords.longitude
            );

            if (dis <= 1) {
              message.success("Your in office");
            } else {
              message.warning(
                "Your not in the office. If you are connecting from home, please apply WFH in the portal and inform the team."
              );
            }

            setTimeStartedByButton(new Date());
            const employeeCheckin = timeData?.mst_timesheet?.filter(
              (data: any) =>
                data?.employee === Employee_details.id && data?.in_time
            );

            try {
              const result = await createCheckin({
                variables: {
                  employee: Employee_details.id,
                  date: reverseddate(currentDate),
                  in_time: currentTime,
                  checkin_location: {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                  },

                },
              });
            } catch (error) {
              // Handle the error here
            }
          }
          refetch();
        },
        (error) => {
          // User denied location permission, handle accordingly
          message.error("Please enable location services to check in.");
        }
      );
    } else {
      // Geolocation is not supported in this browser
      message.error("Geolocation is not supported in your browser.");
    }
  };

  const handleKeyDown = (e: any) => {
    if (e.key === 'Enter') {
      e.preventDefault(); // Prevents the default behavior of Enter key
      handleCloseModal();
    }
  };

  // Code that allows only when CheckedIn from Office

  // const handleCheckinClick = async () => {
  //   // Check if the browser supports geolocation
  //   if ("geolocation" in navigator) {
  //     // Request location permission from the user
  //     navigator.geolocation.getCurrentPosition(
  //       async (position) => {
  //         // User granted location permission, now you can proceed with check-in logic
  //         let dis = calculateDistance(
  //           Employee_details?.mst_organization?.latitude,
  //           Employee_details?.mst_organization?.longitude,
  //           position.coords.latitude,
  //           position.coords.longitude
  //         );

  //         if (dis <= 1) {
  //           // Allow check-in only when the distance is less than or equal to 1
  //           if (
  //             (!employeeStatus?.in_time && !employeeStatus?.out_time) ||
  //             (employeeStatus?.in_time && employeeStatus?.out_time)
  //           ) {
  //             message.success("You're in the office");

  //             setTimeStartedByButton(new Date());
  //             const employeeCheckin = timeData?.mst_timesheet?.filter(
  //               (data: any) =>
  //                 data?.employee === Employee_details.id && data?.in_time
  //             );

  //             try {
  //               const result = await createCheckin({
  //                 variables: {
  //                   employee: Employee_details.id,
  //                   date: reverseddate(currentDate),
  //                   in_time: currentTime,
  //                   checkin_location: {
  //                     latitude: position.coords.latitude,
  //                     longitude: position.coords.longitude,
  //                   },
  //                 },
  //               });
  //             
  //             } catch (error) {
  //               // Handle the error here
  //             }
  //           } else {
  //             message.warning("You can only check in if you have previously checked out.");
  //           }
  //         } else {
  //           message.warning(
  //             "You are not at the office location. If you are connecting from home, please apply WFH in the portal and inform the team."
  //           );
  //         }
  //         refetch();
  //       },
  //       (error) => {
  //         // User denied location permission, handle accordingly
  //         message.error("Please enable location services to check in.");
  //       }
  //     );
  //   } else {
  //     // Geolocation is not supported in this browser
  //     message.error("Geolocation is not supported in your browser.");
  //   }
  // };



  const openModal = () => {
    setIsModalOpen(true);
  };

  const handleInputChange = (e: any) => {
    setModalInputValue(e.target.value);
  };

  //  Code to allow user to checkOut when location in on

  const handleCloseModal = async () => {
   const trimModalInputValue=modalInputValue.trim()
    if (trimModalInputValue.length >= 10) {
      setIsModalOpen(false);

      // Check if the browser supports geolocation
      if ("geolocation" in navigator) {
        // Request location permission from the user
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            // User granted location permission, now you can proceed with check-out logic
            if (employeeStatus?.in_time && !employeeStatus?.out_time) {
              // Check if location services are available, if not, display a message
              if (position.coords.latitude && position.coords.longitude) {
                // Proceed with check-out
                message.success("You've successfully checked out.");

                // Calculate the time difference
                let totalseconds = calculateTimeDifferenceInSeconds(employeeStatus.in_time);

                try {
                  const result = await updateCheckin({
                    variables: {
                      id: employeeStatus?.id,
                      out_time: currentTime,
                      seconds: totalseconds,
                      task: modalInputValue,
                      checkout_location: {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                      },
                    },
                  }).then((res: any) => setModalInputValue(''))
                } catch (error) {
                  // Handle the error here
                }
              } else {
                // Location services are available, but the user's location is not determined
                message.warning("Your location is not available. Please check out from a location with better GPS signal.");
              }
            } else {
              message.warning("You can only check out if you have previously checked in.");
            }
            refetch();
          },
          (error) => {
            // User denied location permission, handle accordingly
            message.error("Please enable location services to check out.");
          }
        );
      } else {
        // Geolocation is not supported in this browser
        message.error("Geolocation is not supported in your browser.");
      }
    } else {
      message.error('Enter the your task')
    }
  };


  // Allows only when Location is equal to Organization

  // const handleCloseModal = async () => {
  //   setIsModalOpen(false);
  //   // Check if the browser supports geolocation
  //   if ("geolocation" in navigator) {
  //     // Request location permission from the user
  //     navigator.geolocation.getCurrentPosition(
  //       async (position) => {
  //         // User granted location permission, now you can proceed with check-out logic
  //         if (employeeStatus?.in_time && !employeeStatus?.out_time) {
  //           let dis = calculateDistance(
  //             Employee_details?.mst_organization?.latitude,
  //             Employee_details?.mst_organization?.longitude,
  //             position.coords.latitude,
  //             position.coords.longitude
  //           );

  //           if (dis <= 1) {
  //             // Allow check-out only when the distance is less than or equal to 1
  //             message.success("You've successfully checked out.");
  //             // Calculate the time difference
  //             let totalseconds = calculateTimeDifferenceInSeconds(employeeStatus.in_time);

  //             try {
  //               const result = await updateCheckin({
  //                 variables: {
  //                   id: employeeStatus?.id,
  //                   out_time: currentTime,
  //                   seconds: totalseconds,
  //                   task: modalInputValue,
  //                   checkout_location: {
  //                     latitude: position.coords.latitude,
  //                     longitude: position.coords.longitude,
  //                   },
  //                 },
  //               });



  //             } catch (error) {
  //               // Handle the error here
  //             }
  //           } else {
  //             message.warning(
  //               "You are not at the office location. Please check out from the correct location."
  //             );
  //           }
  //         } else {
  //           message.warning("You can only check out if you have previously checked in.");
  //         }
  //         refetch();
  //       },
  //       (error) => {
  //         // User denied location permission, handle accordingly
  //         message.error("Please enable location services to check out.");
  //       }
  //     );
  //   } else {
  //     // Geolocation is not supported in this browser
  //     message.error("Geolocation is not supported in your browser.");
  //   }
  // };



  return (
    <Card className="dashboard_card" title={<h2>Attendance</h2>}>
      <div>Time: {currentTime}</div>
      <div>Date: {currentDate}</div>
      <h1>{formatTime()} Hrs</h1>
      {(!employeeStatus?.in_time && !employeeStatus?.out_time) ||
        (employeeStatus?.in_time && employeeStatus?.out_time) ? (

        <Button className="dashboard_button_checkin-button" onClick={handleCheckinClick}>
          Check In
        </Button>
      ) : (
        <Button className="dashboard_button_checkout-button" onClick={openModal}>
          Check Out
        </Button>

      )}
      <Modal
        title="Today's Task"
        open={isModalOpen}
        onOk={handleCloseModal}
        onCancel={() => setIsModalOpen(false)}
      >
        <TextArea rows={4} placeholder="Enter Today's Tasks"
          style={{ resize: 'none' }}
          value={modalInputValue}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
        />
      </Modal>
      <p>
        Log In:{" "}
        {timeStartedByButton
          ? timeData?.mst_timesheet?.[0]?.in_time
          : "Yet to Log in"}
      </p>
    </Card>
  );
};
