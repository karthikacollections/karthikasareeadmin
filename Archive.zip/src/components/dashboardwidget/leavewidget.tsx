import { GET_LEAVE_EMP } from "@/helpers";
import { useQuery } from "@apollo/client";
import { Avatar, Button, Card, Col, Row } from "antd"
import { useRouter } from "next/router";
import { useAuth } from "../auth";
import { useEffect, useState } from "react";

export const LeaveWidget: React.FC<any> = () => {
    const router = useRouter();
    const [leaveData, setLeaveData] = useState([])
    const { userInEmploye } = useAuth()

    console.log(userInEmploye, 'userInEmployeuserInEmployeuserInEmployev');


    const {
        error: empError,
        loading: empLoading,
        data: empDatas,
        refetch
    } = useQuery(GET_LEAVE_EMP, {
        variables: { emp_name: userInEmploye?.mst_employeedetails[0]?.id },
    });

    const Apply_leave = () => {
        router.push('/HRM/LeaveManagement');
    }
    return (
        <Card className="dashboard_card" title={`Leave Management`} extra={<Button type="link" onClick={Apply_leave}>Apply Leave</Button>}>
            {

            }
        </Card>
    )
}

export default LeaveWidget