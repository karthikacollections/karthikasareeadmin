import { GET_ANNOUNCEMENT_WIDGET } from "@/helpers";
import { useQuery } from "@apollo/client";
import { Card, Table, Button } from "antd";
import { useEffect, useState } from "react";
import moment from "moment";

export const AnnounementWidget: React.FC<any> = () => {
  const { data: announceData, refetch } = useQuery(GET_ANNOUNCEMENT_WIDGET)
  const [filteredData, setFilteredData] = useState([]);
  
refetch()

 // useEffect(() => {
  //   const currentDate = new Date();
  //   const currentMonth = currentDate.getMonth() + 1;
  //   const currentWeek = currentDate.getDate(); // Use only the current day
  //   const filteredAnnouncements = announceData?.mst_announcement.filter((item: any) => {
  //     const announcementDate = new Date(item.date);
  //     const announcementMonth = announcementDate.getMonth() + 1;
  //     const announcementWeek = announcementDate.getDate();
  
  //     return (
  //       (announcementMonth === currentMonth && announcementWeek <= currentWeek) ||
  //       (announcementMonth > currentMonth)
  //     );
  //   });
  //   setFilteredData(filteredAnnouncements);
  // }, [announceData]);


  useEffect(() => {
    if (announceData) {
      const announcements = announceData.mst_announcement.map((item :any) => item);
      setFilteredData(announcements);
    }
  }, [announceData]);


const dataSource = filteredData?.map((item: any) => ({
    key: item.id,
    date:new Date(item.date),
    id: item.id,
    message: item.message,
    file:item.file,
  })).sort((a: any, b: any) => b.date - a.date);

  const columns = [
    {
      render: (value: any) => {
        let dateFormat = moment(value?.date).format("DD MMM");
        return (
          <>
            <p>{dateFormat}</p>
          </>
        );
      },
    },
      {
        dataIndex: 'message',
        key: 'message',
      },
    {
      dataIndex: 'actions',
      key: 'actions',
      render: (_text: any, record: any) => (
        record.file ? (
          <a  href={record.file} target='_blank'>
            <Button type="primary">
              View
            </Button>
          </a>
        ) : null
      ),
    }
  ];

  return (
    <>
      <Card className="dashboard_card" title={<h2>Announcement</h2>}>
        {dataSource?.length > 0 ? (
          <div className="dashboard_announcement">
            <Table dataSource={dataSource} columns={columns} pagination={false} showHeader={false} />
          </div>
        ) : (
          <p>No Announcement</p>
        )}
      </Card>
    </>
  );
};
export default AnnounementWidget;
