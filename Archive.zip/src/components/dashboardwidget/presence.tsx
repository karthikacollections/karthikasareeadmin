import { Card } from "antd";
import React from "react";
import { useQuery } from "@apollo/client";
import { useAuth } from "../auth";
import { GET_HOLIDAYMANAGEMENT, GET_PRESENCE } from "../../helpers/queries";

const PresenceWidget: React.FC<any> = () => {
  const { loading: holidayLoading, error: holidayError, data: holidayData } = useQuery(GET_HOLIDAYMANAGEMENT);
  const { user, userInEmploye } = useAuth();
  const isAdmin = user?.email === "admin@gmail.com";
  const employeeId = isAdmin ? "admin" : userInEmploye?.mst_employeedetails[0]?.id;

  const { error: presenceError, loading: presenceLoading, data: presenceData } = useQuery(GET_PRESENCE, {
    variables: { employee: employeeId },
  });



  if (holidayLoading || presenceLoading) return <p>Loading...</p>;
  if (holidayError || presenceError) {
    const errorMessage = holidayError ? holidayError.message : presenceError?.message;
    return <p>Error: {errorMessage}</p>;
  }

  const timesheets = presenceData?.mst_timesheet || [];
  const uniqueDates = Array.from(new Set(timesheets.map((item: { date: any }) => item.date)));
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth();
  
  const getCurrentMonthWorkingDays = (data: any, currentMonth: number) => {
    const currentYear = currentDate.getFullYear();
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    let workingDays = 0;
  
    for (let date = new Date(firstDay); date <= lastDay; date.setDate(date.getDate() + 1)) {
      if (date.getDay() !== 0 && date.getDay() !== 6) {
        workingDays++;
      }
    }
  
    const holidaysInCurrentMonth = data.mst_holidaymanagement.filter((item: { date: string }) => {
      const holidayDate = new Date(item.date);
      return holidayDate.getMonth() === currentMonth;
    });
  
    workingDays -= holidaysInCurrentMonth.length;
  
    return workingDays;
  };

  const workingDaysForCurrentMonth = getCurrentMonthWorkingDays(holidayData, currentMonth);
  const dateCount = isAdmin ? "00" : uniqueDates.length;

  return (
    <Card className="presence_card">
      <div className="presence_body">
        <div className="presence_presencecontent">
          <p>Presence</p>
        </div>
        <div className="presence_date">
          <div className= "presence_presence">
            <p>{dateCount}/{workingDaysForCurrentMonth}</p>
          </div>
          <div className="presence_date_month"></div>
        </div>
      </div>
    </Card>
  );
};

export default PresenceWidget;
