import { Card } from "antd"
import moment from "moment"
import { useEffect, useState } from "react";
import { useAuth } from "../auth";
import dayjs from 'dayjs';

export const WelcomeWidget: React.FC<any> = () =>{
    const [currentTime, setCurrentTime] = useState("");
    const{user,userInEmploye}=useAuth()
    const [greeting, setGreeting] = useState<string>('');

    let name=user?.email==="admin@gmail.com" ? "Admin" :userInEmploye?.mst_employeedetails[0]?.name
    let date=moment().format("DD")
    let month=dayjs().format("MMM")
    let day=dayjs().format("dddd")
    
  useEffect(() => {
    const interval = setInterval(() => {
      const currentDateObj = new Date();
      const options:any = {
        hour12: true,
        timeZone: "Asia/Kolkata", // Use 'Asia/Kolkata' for Indian Standard Time
        hour: "numeric",
        minute: "numeric",
      };

      setCurrentTime(currentDateObj.toLocaleTimeString("en-IN", options));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Function to update the greeting based on the time
    const updateGreeting = () => {
      const now = new Date();
      const hours = now.getUTCHours() + 5.5; // IST is UTC+5.5

      if (hours >= 4 && hours < 12) {
        setGreeting('Good Morning');
      } else if (hours >= 12 && hours < 16) {
        setGreeting('Good Afternoon');
      } else {
        setGreeting('Good Evening');
      }
    };
    updateGreeting();
    const intervalId = setInterval(updateGreeting, 60000); // Update every minute

    return () => {
      clearInterval(intervalId);
    };
  }, []);


    return(
        <Card className="welcome_card">
           <div className="welcome_body">
            <div className="welcome_content">
                <p> {greeting}</p>
                <p>{name?.split(' ')[0]}</p>
            </div>
            <div className="welcome_date">
                <div className="welcome_weather">
                    <p>{date}</p>
                </div>
                <div className="welcome_date_month">
                    <p>{day} | {month}</p>
                </div>
            </div>
           </div>
        </Card>
    )
}


export default WelcomeWidget 