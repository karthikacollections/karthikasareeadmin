import { Card, Table } from "antd";
import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { useAuth } from "../../components/auth";
import { GET_CHECK_IN_DETAILS } from "../../helpers/queries";
import moment from 'moment';
import { log } from "console";

export const ProgressWidget: React.FC<any> = () => {

  const [userDetail, setUserDetail] = useState<any[]>([]);
  const { check_button_permission, filteredColumns, userInEmploye, user, check_user_type } = useAuth()
  const employeequery = { employee: userInEmploye?.mst_employeedetails[0]?.id }

  const { error, loading, data, refetch } = useQuery(GET_CHECK_IN_DETAILS, { variables: employeequery });

  useEffect(() => {
    console.log(data);

    if (data) {
      let res = data?.mst_timesheet;
      console.log('Data from GraphQL', res);
      setUserDetail(res);
    }
  }, [data]);


  // const convertTimestampToIndianTime = (timestamp: string) => {
  //   if (!timestamp) return '00:00 AM';

  //   const utcTime = new Date(timestamp);
  //   const options: Intl.DateTimeFormatOptions = {
  //     timeZone: 'Asia/Kolkata',
  //     hour: 'numeric',
  //     minute: '2-digit',
  //     hour12: true,
  //   };
  //       // Convert the UTC time to Indian time
  //       return utcTime.toLocaleTimeString('en-IN', options);
  //     };

    function formatTime(time: { split: (arg0: string) =>
      [any, any]; }) {
 
     if (!time) return null;
 
     const [hours, minutes] = time?.split(':');
     const ampm = parseInt(hours) >= 12 ? 'PM' : 'AM';
     const formattedHours = parseInt(hours) % 12 === 0 ? 12 : parseInt(hours) % 12; // Convert 24-hour format to 12-hour format
     return `${formattedHours}:${minutes} ${ampm}`;
   }
 
  console.log(userDetail, "userDetail")

  const columns = [
    {
      title: 'Date',
      dataIndex: "date",
      key: 'date'
    },
    {
      title: 'In Time',
      render: (value: any) => {
        const recorded = value?.in_time;
        const intime = formatTime(recorded);
        return (
          <>
            <p>{intime !== 'Invalid Time' ? intime : "00:00"}</p>
          </>
        )
      },
    },
    {
      title: 'Out Time',
      render: (value: any) => {
        const recorded = value?.out_time;
        const outtime = formatTime(recorded);
        return (
          <>
            <p>{outtime !== 'Invalid Time' ? outtime : "00:00"}</p>
          </>
        )
      },
    },
];

  return (
    <>
      <Card className="dashboard_card" title={<h2>Last Week's Progress</h2>}>
        {userDetail.length === 0 ? (
          <p>No Data</p>
        ) : (
          <div className="dashboard_onleave">
            <Table
              columns={filteredColumns(columns, 'Attendance')}
              dataSource={userDetail}
              pagination={{ pageSize: 10 }}
              className="attendance_table"
            />
          </div>
        )}
      </Card>
    </>
  );
};

export default ProgressWidget