import { GET_HOLIDAYMANAGEMENT } from "@/helpers"
import { useQuery } from "@apollo/client"
import { Card, Table } from "antd"
import React, { useEffect, useState } from 'react';
import moment from "moment";

export const HolidayWidget: React.FC<any> = () => {
  const { data: holidayData } = useQuery(GET_HOLIDAYMANAGEMENT)
  const [data,setData]=useState([])

  useEffect(()=>{
    if(holidayData){
      let res=holidayData?.mst_holidaymanagement
      setData(res)
    }
  },[holidayData])

  const columns = [
    {
        
      render: (value: any) => {
        let dateFormat = moment(value?.date).format("DD MMM YYYY");

        return (
          <>
            <p>{dateFormat}</p>
          </>
        );
      },
    },
    {
      dataIndex: 'reason',
      key: 'reason',
    },
  ];
  
  const Filter = (param: any) => {
  let currentDate = new Date();

  let upcomingEvents = param.filter((data: any) => {
    let eventDate = new Date(data?.date);
    
    return eventDate > currentDate;
  });

  return upcomingEvents;
};


  const dataSource:any=Filter(data)

    return(
        <>
        <Card className="dashboard_card" title={<h2>Holiday</h2>} >
          {dataSource.length==0 ?<p>No Holiday</p>:
          <div className="dashboard_holiday">
            <Table dataSource={dataSource} columns={columns} pagination={false}  showHeader={false}/>
          </div>
          }
        </Card>
        </>
    )
}
export default HolidayWidget