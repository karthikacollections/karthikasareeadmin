import { GET_EMPLOYDETAILS_DOB } from "@/helpers"
import { useQuery } from "@apollo/client"
import { Card, Table } from "antd"
import moment from "moment"
import { useEffect, useState } from "react"


export const DobAnnounementWidget: React.FC<any> = () =>{
    const[dobData,setDobData]=useState<any>([])
    const {data}=useQuery(GET_EMPLOYDETAILS_DOB)
    const currentDate = new Date();

    useEffect(()=>{
        if(data){
            let res=data?.mst_employeedetails?.filter((param:any)=>filter_emp_DOB(param))
            setDobData([...res])
        }
    },[data])

    const filter_emp_DOB=(param:any)=>{
        const currentDate = new Date();
        const month = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Months are zero-indexed
        const day = currentDate.getDate().toString().padStart(2, '0');
        const empDate=param?.dob!==undefined ? param?.dob?.split('-') : undefined
        if(empDate!==undefined){
        if(empDate[1]===month&&empDate[2]===day){
            return param
        }else{
            return ''
        }
        }
    }
    
    const columns:any=[
        {
            render: (urlList: any) => {
              return (
                <img
                  src={urlList?.image}
                  alt="Image"
                  style={{ width: "100px" }}
                  className="employee-details_table-profile"
                />
              );
            },
        },
        {
            render:(value:any)=>{
                return(
                    <p>It's {value?.name}'s day!</p>
                )
            }
        }
    ]



    return(
        // <Card className="dashboard_card" title={`Birthday ( ${moment(currentDate).format('DD-MM-YYYY')} ) `} >
        <Card className="dashboard_card" title={<h2>Birthday's</h2>} >
          {dobData?.length > 0 ? (
            <div className="dashboard_birthday">
                <Table dataSource={dobData} columns={columns} pagination={false} showHeader={false} />
            </div>
        ) : (
          <p>No Birthday</p>
        )}
        </Card>
    )
}

export default DobAnnounementWidget