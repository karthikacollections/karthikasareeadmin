import { GET_TODAY_LEAVE } from "@/helpers";
import { useQuery } from "@apollo/client"
import { Card, Table } from "antd"
import moment from "moment";
import React, { useEffect, useState } from 'react';
import { useAuth } from '../../components/auth'

export const Leavewidget: React.FC<any> = () => {

    const [res, setData] = useState([])
    const { check_button_permission, filteredColumns, userInEmploye, user, check_user_type } = useAuth()
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
    const day = String(currentDate.getDate()).padStart(2, '0');
    // const formattedDate = `${year}-${month}-${day}`;

    const formattedDate = moment(currentDate).format('YYYY-MM-DD')


    const today = { from_date: formattedDate }

    const {
        error,
        loading,
        data: leaveData,
        refetch,
    } = useQuery(GET_TODAY_LEAVE, {
        variables: today,
    });

    useEffect(() => {
        if (leaveData) {
            let res = leaveData?.mst_leave_management
            setData(res)
        }
    })



    var count = 0

    const columns = [
        {
            title: 'S.no',
            dataIndex: 's.no',
            render: () => ++count,
        },
        {
            title: 'Employee Name',
            render: (value: any) => {
                let name = value?.mst_employeedetails_mst_leave?.name
                return (
                    <>
                        <p>{name}</p>
                    </>
                )
            }
        },
        {
            title: 'Reason',
            render: (value: any) => {
                let Reason = value?.mst_leavemanage_mst_leavetype?.reason
                return (
                    <>
                        <p>{Reason}</p>
                    </>
                )
            }
        },
    ];
    // const dataSource: any = leaveData

    const isAdmin = user?.email === "admin@gmail.com";

    return (
        <>
            <Card className="dashboard_card" title={<h2>Who's Off</h2>}  >
                {isAdmin ? (
                    res.length === 0 ? (
                        <p>No Absentees</p>
                    ) : (
                        <div className="dashboard_onleave">
                            <Table dataSource={res} columns={columns} pagination={false} showHeader={false} />
                        </div>
                    )
                ) : (
                    <p>No Absentees</p>
                )}
            </Card>
        </>
    )
}
export default Leavewidget