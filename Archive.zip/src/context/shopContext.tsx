// shopContext.tsx

import React, { createContext, useContext, useState, ReactNode } from 'react';

type ShopContextProps = {
  selectedShop: string | undefined;
  setSelectedShop: React.Dispatch<React.SetStateAction<string | undefined>>;
  selectedOrgValue: string | undefined; // Add selectedOrgValue
  setSelectedOrgValue: React.Dispatch<React.SetStateAction<string | undefined>>; // Add setSelectedOrgValue
};

type ShopProviderProps = {
  children: ReactNode; // Explicitly type children prop
};

const ShopContext = createContext<ShopContextProps | undefined>(undefined);

export const ShopProvider: React.FC<ShopProviderProps> = ({ children }) => {
  const [selectedShop, setSelectedShop] = useState<string | undefined>(undefined);
  const [selectedOrgValue, setSelectedOrgValue] = useState<string | undefined>(undefined);

  const value: ShopContextProps = {
    selectedShop,
    setSelectedShop,
    selectedOrgValue,
    setSelectedOrgValue,
  };

  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
};

export const useShopContext = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShopContext must be used within a ShopProvider');
  }
  return context;
};
