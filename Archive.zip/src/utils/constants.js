

export const SHOP_ID = process.env.NEXT_PUBLIC_SHOP_ID;
export const EMAIL_ID=process.env.NEXT_PUBLIC_EMAIL_ID
export const PASSWORD =process.env.NEXT_PUBLIC_PASSWORD_ID


