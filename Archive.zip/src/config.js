import withApollo from "next-with-apollo";
import { ApolloClient, ApolloProvider, InMemoryCache, createHttpLink } from "@apollo/client";
import { setContext } from '@apollo/client/link/context';
// Learn more about `@apollo/client` here - https://www.apollographql.com/docs/react/why-apollo
// Learn more about `next-with-apollo` here - https://github.com/lfades/next-with-apollo
// creating the Apollo Client

const authLink = setContext((_, { headers }) => {
  return {
  headers: {
       ...headers, 'x-hasura-admin-secret': 'admin_secret'
     }
   }
 });


 const httpLink = createHttpLink({
  uri: 'https://employeeapp.vinsoftconnected.com/v1/graphql',
 });
const client = new ApolloClient({
  link: authLink.concat(httpLink),
 cache: new InMemoryCache()
});

export default withApollo(
  () => {
    return client;
  },
  {
    // providing the Apollo Client access to the pages
    render: ({ Page, props }) => {
      return (
        <ApolloProvider client={client}>
          <Page {...props} />
        </ApolloProvider>
      );
    }
  }
);