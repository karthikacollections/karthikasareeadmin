import { Group, MantineColor, Text, UnstyledButton } from "@mantine/core"
import Link from "next/link"
import { useRouter } from "next/router"

interface MenuItemProps {
    icon: React.ReactNode
    color?: MantineColor
    label: string
    link?: string
    index?: number
    active?:boolean
  }

const MenuItem: React.FC<MenuItemProps> = ({ index, icon, color, label, link, active}) => {
    const { route } = useRouter()
    
    // const active = route === link
    const Button = (
      <UnstyledButton
        className='settings_UnstyledButton'
        // onClick={action}
        sx={(theme) => ({
          display: 'block',
          width: '100%',
          padding: theme.spacing.xs,
          borderRadius: theme.radius.sm,
  
          color: active
            ? theme.colors[theme.primaryColor][theme.colorScheme === 'dark' ? 4 : 7]
            : theme.colorScheme === 'dark'
              ? theme.colors.dark[0]
              : theme.black,
  
// Styles in the MenuItem component
'&:hover': {
  backgroundColor: theme.colorScheme === 'dark' ? theme.colors.dark[6] : theme.colors.gray[0],
},
  
        })}
      >
        <Group className='settings_group' >
          {/* <ThemeIcon className='settings_group-icons'>  */}
          {icon}
          {/* </ThemeIcon>  */}
  
          <Text size="sm" className='settings_group-label'>{label}</Text>
        </Group>
      </UnstyledButton>
    )
  


    return link ? (
      <Link href={link} passHref className='settings_group-label-link'>
        {Button}
      </Link>
    ) : (
      Button
    )
  }

export default MenuItem;
