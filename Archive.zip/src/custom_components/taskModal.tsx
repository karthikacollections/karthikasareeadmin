import React, { useEffect, useState } from 'react'
import { Button, Avatar } from "antd";
import { RichTextEditor } from '../components/ritchTextBox';
import { useMutation, useQuery } from '@apollo/client';
import { CREATE_COMMENT, GET_COMMENTS, GET_TASK_MODAL, UPDATE_TASK_DESCRIPTION, DELETE_COMMENT } from '@/helpers';
import { useAuth } from '@/components/auth';
import { UUID } from 'crypto';

const TaskModal: React.FC<any> = ({ id }) => {

    const [editorValue, setEditorValue] = useState<string>('');
    const [editorCommentValue, setEditorCommentValue] = useState<string>('');
    const [task, setTask] = useState<any>([]);
    const [commentDataSet, setCommentDataSet] = useState<any>([]);
    const [openEditor, setOpenEditor] = useState<boolean>(false);
    const [openCommentEditor, setOpenCommentEditor] = useState<boolean>(false);
    const { user, Employee_details } = useAuth();
    const { loading, error, data, refetch } = useQuery(GET_TASK_MODAL, { variables: { id: id } })
    const [udateDescription] = useMutation(UPDATE_TASK_DESCRIPTION)
    const [deleteComment, { data: dataDelete }] = useMutation(DELETE_COMMENT)
    const [commentTask] = useMutation(CREATE_COMMENT);
    const { loading: commentLoading, error: commentError, data: commentData, refetch: commentRefetch } = useQuery(GET_COMMENTS, { variables: { task_id: id } });

    useEffect(() => {
        if (!loading) {
            getTaskData()
        }
    }, [loading, refetch, udateDescription])

    useEffect(() => {
        if (!commentLoading) {
            getCommentData()
        }
    }, [commentLoading, commentRefetch, commentTask])

    const getTaskData = async () => {
        const res = await data?.mst_task[0]
        setTask(res)
    }

    const getCommentData = async () => {
        const res = await commentData?.mst_comments
        setCommentDataSet(res)
        refetch();
    }

    const handleEditorChange = (value: string) => {
        setEditorValue(value);
    };

    const handleCommentEditorChange = (value: string) => {
        setEditorCommentValue(value);
    };

    // Submit the description
    const handleDescription = () => {
        if (editorValue?.length > 0) {
            udateDescription({
                variables: { id: id, description: editorValue }
            }).then((res: any) => {
                refetch()
                setOpenEditor(!openEditor)
            }).catch((err: any) => {
                console.log(err);
            })
        }
    }

    const handleDeleteComment = async (commentId: UUID) => {
        try {
            await deleteComment({ variables: { id: commentId } });
            await commentRefetch();
            await refetch();
        } catch (error) {
            console.error('Error deleting comment:', error);

        }
    };

    const handleEditComment = async (commentId: UUID) => {
        try {
            await deleteComment({ variables: { id: commentId } });
            await commentRefetch();
            await refetch();
        } catch (error) {
            console.error('Error deleting comment:', error);

        }
    };

    // Submit the Comment
    const handleComment = () => {
        commentTask({
            variables: {
                comments: editorCommentValue,
                employee: Employee_details?.id,
                task_id: id,
            },
        }).then((res: any) => {
            setOpenCommentEditor(!openCommentEditor)
            commentRefetch()
            refetch()
        })
    }

    return (
        <div>
            <div>
                <div style={{ fontSize: "18px", fontWeight: "normal" }}>
                    <p>
                        <span style={{ fontSize: "24px", fontWeight: "bold" }}>
                            {task?.issue_type}
                        </span>{" "}
                        : {task?.title}
                    </p>
                </div>
                <div className='description'>
                    <div className='description-title'>
                        <p>
                            <span>
                                Description
                            </span>
                        </p>
                        {task?.description?.length > 0 && <Button type='primary'>Edit</Button>}
                    </div>
                    <div className='description-box'>
                        {openEditor ? <div className='description-box-textEditor'>
                            <div className='description-box-textEditor-textArea'>
                                <RichTextEditor value={editorValue} onChange={handleEditorChange} className='description-textBox' placeholder='Write your Description' />
                            </div>
                            <div className='description-box-textEditor-control'>
                                <Button type='primary' onClick={handleDescription}>Save</Button>
                                <Button onClick={() => setOpenEditor(!openEditor)} >Cancel</Button>
                            </div>
                        </div>
                            :
                            task?.description ?
                                <div className='description-box-desText' onClick={() => { setOpenEditor(!openEditor); setEditorValue(task?.description) }}>
                                    <div dangerouslySetInnerHTML={{ __html: task?.description }} />
                                </div>
                                :
                                <div className='description-box-desText'>
                                    <div>
                                        <p>Write your Description</p>
                                    </div>
                                </div>
                        }
                    </div>
                </div>
            </div>
            <p className='row3'
                style={{ display: "flex" }}>
                <span className='HeaderPriority'>
                    Priority
                </span>
                <span className='HeaderPriority' >
                    Status
                </span>
            </p>
            <p style={{ display: "flex" }}>
                <span
                    className='Priority'
                >
                    {task?.priority === "Low" && (
                        <span
                            style={{
                                position: "absolute",
                                top: "50%",
                                left: "0", // Adjust this value to position the line
                                width: "4px",
                                height: "25px",
                                backgroundColor: "green",
                                borderRadius: "2px",
                                transform: "translateY(-50%)",
                            }}
                        ></span>
                    )}
                    {task?.priority === "Medium" && (
                        <span
                            style={{
                                position: "absolute",
                                top: "50%",
                                left: "0px", // Adjust this value to position the line
                                width: "4px",
                                height: "25px",
                                backgroundColor: "orange",
                                borderRadius: "2px",
                                transform: "translateY(-50%)",
                            }}
                        ></span>
                    )}
                    {task?.priority === "High" && (
                        <span
                            style={{
                                position: "absolute",
                                top: "50%",
                                left: "0px", // Adjust this value to position the line
                                width: "4px",
                                height: "25px",
                                backgroundColor: "red",
                                borderRadius: "2px",
                                transform: "translateY(-50%)",
                            }}
                        ></span>
                    )}
                    <span
                        className='taskPriority'
                    >
                        {task?.priority}
                    </span>
                </span>

                <span
                    className='rowStatus'
                >
                    {task?.status}
                </span>
            </p>
            <p style={{ display: "flex" }}>
                <span className='HeaderPriority'>
                    Project
                </span>
                <span className='HeaderPriority'>
                    Sprint
                </span>
            </p>
            <p style={{ display: "flex" }}>
                <span
                    className='rowStatus'
                >
                    {task?.mst_task_mst_sprints?.mst_sprint_mst_project?.project_name}
                </span>
                <span
                    className='rowStatus'
                >
                    {task?.mst_task_mst_sprints?.sprint_name}
                </span>
            </p>
            <p style={{ display: "flex" }}>
                <span className='HeaderPriority'>
                    Reporter
                </span>
                <span className='HeaderPriority'>
                    Assigned to
                </span>
            </p>
            <p style={{ display: "flex" }}>
                <span
                    className='rowStatus'
                >
                    {task?.reporterrelation?.name}
                </span>
                <span
                    className='rowStatus'
                >
                    {task?.mast_employee_assign?.name}
                </span>
            </p>
            <p style={{ display: "flex" }}>
                <span className='HeaderPriority'>
                    Start Date
                </span>
                <span className='HeaderPriority'>
                    End Date
                </span>
            </p>
            <p style={{ display: "flex" }}>
                <span
                    className='rowStatus'
                >
                    {task?.start_date}
                </span>
                <span
                    className='rowStatus'
                >
                    {task?.target_date}
                </span>
            </p>
            {/* Comment Session */}
            <div className='comment'>
                <div className='comment-session'>
                    {user.email == "admin@gmail.com" && commentDataSet?.length > 0 && (
                        <div>
                            <h3>Comments</h3>
                        </div>
                    )}

                    {user.email !== "admin@gmail.com" &&
                        <div className="comment-session-textEditor">
                            <div className="comment-session-textEditor-logo">
                                <Avatar size='large' src={Employee_details?.image} />
                            </div>
                            <div className="comment-session-textEditor-box">
                                {openCommentEditor ?
                                    <div className="comment-session-textEditor-box-ative">
                                        <div className="comment-session-textEditor-box-ativeEditor">
                                            <RichTextEditor value={editorCommentValue} onChange={handleCommentEditorChange} className='comment-textBox' placeholder='Write a Comment...' />
                                        </div>
                                        <div className="comment-session-textEditor-box-ativeEditor-control">
                                            <Button type='primary' onClick={handleComment}>Save</Button>
                                            <Button onClick={() => setOpenCommentEditor(!openCommentEditor)}>Cancel</Button>
                                        </div>
                                    </div>
                                    :
                                    <div className="comment-session-textEditor-box-disAtiveEditor" onClick={() => setOpenCommentEditor(!openCommentEditor)}>
                                        <p>Write a Comment</p>
                                    </div>
                                }
                            </div>
                        </div>
                    }
                    {/* Comment Display */}
                    {commentDataSet?.length > 0 &&
                        <div className={commentDataSet.length > 3 ? 'comment-session-card scroll' : 'comment-session-card'}>
                            <div className="comment-session-card-body">
                                {commentDataSet?.map((message: any, index: any) => {
                                    console.log(message, "daaa");

                                    return (
                                        <div className="comment-session-card-messagebox " key={index}>
                                            <div>
                                                <div className='comment-session-card-messagebox-topContent'>
                                                    <div className="comment-session-card-messagebox-logo">
                                                        <Avatar src={message?.mst_comments_mst_empolyee?.image} />
                                                    </div>
                                                    <div className="comment-session-card-messagebox-name">
                                                        <p>{message?.mst_comments_mst_empolyee?.name}</p>
                                                    </div>
                                                </div>

                                                <div className="comment-session-card-messagebox-messageContent">
                                                    <div className="comment-session-card-messagebox-messageContent-message">
                                                        <div dangerouslySetInnerHTML={{ __html: message?.comments }} />
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <a href="#" onClick={() => handleDeleteComment(message?.id)}>Delete</a>
                                                <span> <a href="#" onClick={() => handleEditComment(message?.id)}>Edit</a></span>
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                        </div>
                    }
                </div>
            </div>
        </div>
    )
}

export default TaskModal