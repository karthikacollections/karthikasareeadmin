import React, { useEffect, useState } from 'react';
import { Button } from 'antd';

const StatusButton = ({ currentStatus, setStatus, id, changestatus }: any) => {



    const statusOptions = ['NO', 'YES'];

    const handleStatusChange = (event: any, btn_name: any) => {
        const currentIndex = statusOptions?.indexOf(currentStatus);
        const newIndex = (currentIndex + 1) % statusOptions?.length;
        setStatus(statusOptions[newIndex]);
        const id = event
        changestatus(id + "_=_" + btn_name)
    };


    return (
        <>
            {
                currentStatus === "YES"
                    ?
                    <Button onClick={() => handleStatusChange(id, "NO")} size="small" style={{ backgroundColor: "green", color: "white" }} >
                        {currentStatus}
                    </Button>
                    :
                    <Button onClick={() => handleStatusChange(id, "YES")} size="small" style={{ backgroundColor: "red", color: "white" }} >
                        {currentStatus}
                    </Button>
            }
        </>
    );
};

const Custom_Btn = ({ pre_status, id, changestatus }: any) => {

    const [status1, setStatus1] = useState('NO');

    useEffect(() => {
        setStatus1(pre_status == true ? "YES" : "NO")
    }, [pre_status, id])

    return (
        <div >
            <StatusButton currentStatus={status1} setStatus={setStatus1} id={id} changestatus={(param: any) => changestatus(param)} />
        </div>
    );
};

export default Custom_Btn;
