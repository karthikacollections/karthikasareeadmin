import { useEffect, useState } from "react";
import React from "react";
import { useRouter } from "next/router";
import type { AppProps } from "next/app";
import NavBar from '../components/Navbar'
import { AuthContextProvider } from "../components/auth";
import ProtectedRoute from "../components/protectedroute";
import withApollo from "../config";
import '../assets/scss/main.scss'
import { ShopProvider } from "../context/shopContext";


const noAuthRequired = ["/", "/login", "/login/forgotpassword","/CRM/Category","/CRM/SubCategory","/CRM/Products","/CRM/Attributes","/CRM/Clients","/CRM/OrderBookings","/CRM/Copouns",
  // "/login/loginResetpassword",
  // "/login/loginOTP",
  // "/login/otpsignin",
  "/CRM/Banner",
  "/CRM/Messages"
];

function MyApp({ Component, pageProps }: AppProps) {

  const router = useRouter();

  return (
    <div>
      <ShopProvider>
              <AuthContextProvider>
              {
                noAuthRequired.includes(router.pathname) ?
                  <Component {...pageProps} />
                  :
                  <ProtectedRoute>
                    <div className="pockets_container">
                      
                      <NavBar />
                      <div className="mainContent">
                        <div className="mainContent_bg">
                          <Component {...pageProps} />
                        </div>
                      </div>
                    </div>
                    
                   
                    
                  </ProtectedRoute>
              }
            </AuthContextProvider>
            </ShopProvider>
            </div>
   
  );
}

export default withApollo(MyApp);

