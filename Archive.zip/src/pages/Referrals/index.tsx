import { ColorInput } from '@mantine/core'
import { Button, DatePicker, DatePickerProps, Table } from 'antd'
import React, { useEffect, useState } from 'react'
import withApollo from '../../config'
import { useQuery } from '@apollo/client'
import { GET_EMPLOYDETAILS } from '@/helpers'
import moment from 'moment'
import {useAuth} from '../../components/auth'

export const Employee: React.FC<any> = ({ urlList }) => {
    const [user, setUser] = useState([]);
    const [filterreferral, setFilterReferral] = useState([])
    const [filter, setFilter] = useState(false)
    const { check_button_permission,filteredColumns } = useAuth()


    const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetEmployDetails,
    } = useQuery(GET_EMPLOYDETAILS, {
        variables: {},
    });

    useEffect(() => {
        if (dataUser) {
            let user = dataUser?.mst_employeedetails
            setUser(user)
        }
    }, [dataUser])

    let Refferel = user?.filter((val: any) => val.referral != null)

    const onChange: DatePickerProps['onChange'] = (date, dateString) => {
        setFilter(true)
        const filteredReferrals = Refferel.filter((val: any) => moment(val?.createdat).format("MMMM YYYY") === moment(dateString).format("MMMM YYYY"));
        setFilterReferral(filteredReferrals)
    };

    const columns = [
        {
            title: 'S.No',
            dataIndex: 'sno',
            key: 'sno',
            render: (text: any, record: any, index: number) => index + 1,
        },

        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: 'Referral',
            render: (value: any) =>
                <>
                    <p>{value?.referral}</p>
                </>
        },
        {
            title: 'DOJ',
            render: (value: any) => {
                let passWordFormat = moment(value?.doj).format("DD MMMM YYYY");

                return (
                    <>
                        <p>{passWordFormat}</p>
                    </>
                )
            }
        },
    ];
    return (
        <div className="employee-details">
            <div className="employee-details_head">
                <h2 className="employee-details_head-text">Employee Referral</h2>
                <DatePicker onChange={onChange} picker="month" placeholder='Filter Month' style={{ padding: "10px 20px;" }} />
            </div>
            {filter ? <Table columns={columns} dataSource={filterreferral} pagination={false} className="employee-details_table" /> :
                <Table columns={columns} dataSource={Refferel} pagination={false} className="employee-details_table" />}
        </div>

    )
}

export default Employee