import React, { useEffect, useState, useRef } from "react";
import {
  Select,
  Table,
  Button,
  Form,
  Tag,
  DatePicker,
  Modal,
  Spin,
} from "antd";
import type { ColumnsType } from "antd/es/table";
import { useQuery } from "@apollo/client";
import { useAuth } from "../../components/auth";
import { FilterOutlined } from "@ant-design/icons";
import {
  GET_ATTENDANCE,
  GET_EMPLOYDETAILS_DATA,
  GET_ORGANIZATION,
} from "../../helpers/queries";
import { CaretUpOutlined, CaretDownOutlined } from "@ant-design/icons";
import moment from "moment";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

const { Option } = Select;

interface DataType {
  key: string;
  loginTime: number;
  logoutTime: number;
  date: string;
  employee: string;
}

export const Employee: React.FC<any> = () => {
  const {
    check_button_permission,
    filteredColumns,
    userInEmploye,
    user,
    check_user_type,
  } = useAuth();
  const [count, setCount] = useState([]);
  const [userlist, setUser] = useState([]);
  const [form] = Form.useForm();
  const formRef = useRef(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [taskData, setTaskData] = useState<any>([]);

  const [editdraw, setEditdraw] = useState("");
  // const [currentDate, setCurrentDate] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [filterData, setFilterData] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [filterAsset, setFilterAsset] = useState([]);
  const [selectedValue, setSelectedValue] = useState("");
  const [selectedOrgValue, setSelectedOrgValue] = useState("");
  const [searchVal, setSearchVal] = useState("");
  const [userDetail, setUserDetail] = useState([]);
  const tableRef = useRef<HTMLDivElement>(null);
  const [pagination, setPagination] = useState({ pageSize: 10, current: 1 });
  const [showAllData, setShowAllData] = useState(false);

 const handleSelectChangeOrganization = (value: any) => {
    if (value === undefined) {
      sessionStorage.removeItem("searchAttendance");
    } else {
      sessionStorage.setItem("searchAttendance", value);
    }
    setSelectedOrgValue(value);
  };

  const handleSelectChange = (value: any) => {
    setSelectedValue(value);
  };

  const search_user = (data: any) => {
    return selectedValue
      ? data.filter((u: any) =>
          u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
        )
      : data;
  };

  let a = check_user_type();

  const search = (data: any) => {
    let searchOrg = sessionStorage.getItem("searchAttendance");

    if (selectedValue && selectedOrgValue) {
      return data.filter(
        (u: any) =>
          u.name?.toLowerCase().includes(selectedValue?.toLowerCase()) &&
          u.mst_organization?.name
            ?.toLowerCase()
            .includes(selectedOrgValue?.toLowerCase())
      );
    } else if (selectedValue) {
      return data.filter((u: any) =>
        u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
      );
    } else if (selectedOrgValue) {
      return data?.filter((u: any) =>
        u?.mst_organization?.name
          ?.toLowerCase()
          .includes(selectedOrgValue?.toLowerCase())
      );
    } else if (searchOrg) {
      return data?.filter((u: any) =>
        u?.mst_organization?.name
          ?.toLowerCase()
          .includes(searchOrg?.toLowerCase())
      );
    } else {
      return data;
    }
  };

  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, "0");
  const day = String(currentDate.getDate()).padStart(2, "0");
  const formattedDate = `${year}-${month}-${day}`;

  const queryVariables = selectedDate
    ? { date: selectedDate, id: userInEmploye?.mst_employeedetails[0]?.id }
    : { date: formattedDate, id: userInEmploye?.mst_employeedetails[0]?.id };

  const employeequery = selectedDate
    ? { date: selectedDate, id: userInEmploye?.mst_employeedetails[0]?.id }
    : { date: formattedDate, id: userInEmploye?.mst_employeedetails[0]?.id };

  const { error, loading, data, refetch } = useQuery(GET_EMPLOYDETAILS_DATA, {
    variables: employeequery,
  });

  useEffect(() => {
    if (data) {
      let userlist = data?.mst_employeedetails;
      setUserDetail(userlist);
    }
  }, [data]);

  const {
    error: userError,
    loading: userLoading,
    data: dataUser,
    refetch: refetEmployDetails,
  } = useQuery(GET_ATTENDANCE, {
    variables: queryVariables,
  });

  useEffect(() => {
    if (dataUser) {
   let userlist: [] = dataUser?.mst_employeedetails;
      let userlistFiltered = userlist.filter((data: any) => {
        return  data.status === true && data.isdeleteat==false ;
      });
      setUser(userlistFiltered);
    }
  }, [dataUser]);

  const {
    error: orgError,
    loading: orgLoading,
    data: orgData,
    refetch: refetOrganizationDetails,
  } = useQuery(GET_ORGANIZATION);
  const handleDateChange = (date: any, dateString: string) => {
    setSelectedDate(dateString);
  };

  // if (userLoading) return <p>Loading...</p>;
  // if (userError) return <p>Error: {userError.message}</p>;

  const totalTimeHour = (timeSheet: any[]): boolean => {
    const totalTimeInSeconds = timeSheet.reduce((sum, obj) => {
      const timeInSeconds = parseInt(obj.seconds, 10) || 0;
      return sum + timeInSeconds;
    }, 0);

    const hours = Math.floor(totalTimeInSeconds / 3600);
    return hours <= 8;
  };

  const totalTimeInHour = (timeSheet: any[]): string => {
    const totalTimeInSeconds = timeSheet.reduce((sum, obj) => {
      const timeInSeconds = parseInt(obj.seconds, 10) || 0;
      return sum + timeInSeconds;
    }, 0);

    const hours = Math.floor(totalTimeInSeconds / 3600);
    const minutes = Math.floor((totalTimeInSeconds % 3600) / 60);
    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}`;
  };

  function convertRailwayTimeToNormalTime(railwayTime: any) {
    const [hours, minutes] =
      railwayTime !== undefined &&
      railwayTime !== null &&
      railwayTime?.length !== 0
        ? railwayTime?.split(":").map(Number)
        : "0";
    const date = new Date(0, 0, 0, hours, minutes);
    const normalTime = date.toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    });
    return normalTime;
  }

  let empData = [...(dataUser?.mst_employeedetails || [])];
  let sort = empData?.sort((a: any, b: any) => a?.name.localeCompare(b?.name));

  function formatTime(time: { split: (arg0: string) => [any, any] }) {
    if (!time) return null;

    const [hours, minutes] = time?.split(":");
    const ampm = parseInt(hours) >= 12 ? "PM" : "AM";
    const formattedHours =
      parseInt(hours) % 12 === 0 ? 12 : parseInt(hours) % 12; // Convert 24-hour format to 12-hour format
    return `${formattedHours}:${minutes} ${ampm}`;
  }

  // const convertTimestampToIndianTime = (timestamp: string) => {
  //     if (!timestamp) return '00:00'; // Default to 00:00 AM if the timestamp is empty.

  //     // Assuming the input timestamp is in UTC
  //     const utcTime = new Date(timestamp);

  //     // Define the options for formatting
  //     const options: Intl.DateTimeFormatOptions = {
  //         timeZone: 'Asia/Kolkata',
  //         hour: 'numeric',
  //         minute: '2-digit',
  //         hour12: true,  // This will format the time in AM/PM
  //     };

  //     // Convert the UTC time to Indian time
  //     return utcTime.toLocaleTimeString('en-IN', options);
  // };

  const showModal = (param: any) => {
    setModalVisible(true);
    setTaskData(param);
  };

  const modalColumns: ColumnsType<DataType> = [
    {
      title: "Task",
      key: "task",
      dataIndex: "task",
      render: (value: any) => {
        return <>{value?.task}</>;
      },
    },
  ];

  const columns: ColumnsType<DataType> = [
    {
      title: "S.No",
      dataIndex: "sno",
      key: "sno",
      render: (text, record, index) => index + 1,
    },
    {
      title: "Employee",
      render: (value) => {
        return (
          <>
            <p>{value?.name}</p>
          </>
        );
      },
    },
    {
      title: "Organizaton",
      render: (value: any) => {
        let organization = value?.mst_organization?.name;
        return <p>{organization}</p>;
      },
      filters: [
        {
          text: "Hysas",
          value: "Hysas",
        },
        {
          text: "Vinsoft",
          value: "Vinsoft",
        },
        {
          text: "Kitez",
          value: "Kitez",
        },
      ],
      onFilter: (value: any, record: any) =>
        record?.mst_organization?.name?.indexOf(value) === 0,
      filterIcon: () =>
        user.email === "admin@gmail.com" && (
          <FilterOutlined style={{ color: "white", fontSize: "18px" }} />
        ),
    },
    {
      title: "Date",
      render: (value: any) => {
        const currentDate = new Date();
        const dateToDisplay = value?.mstTimesheetsByEmployee[0]?.date;
        return (
          <>
            <p>{dateToDisplay ? dateToDisplay : queryVariables?.date}</p>
          </>
        );
      },
    },

    {
      title: "In Time",
      render: (value) => {
        const recorded = value?.mstTimesheetsByEmployee;
        const intime = formatTime(recorded[0]?.in_time);
        return (
          <>
            <p>{intime !== "Invalid Date" ? intime : "00:00"}</p>
          </>
        );
      },
      sorter: (a: any, b: any) => {
        const aInTime = a?.mstTimesheetsByEmployee[0]?.in_time;
        const bInTime = b?.mstTimesheetsByEmployee[0]?.in_time;
        if (!aInTime && bInTime) return 1;
        if (aInTime && !bInTime) return -1;

        if (aInTime && bInTime) {
          if (aInTime < bInTime) return -1;
          if (aInTime > bInTime) return 1;
        }

        return 0;
      },
      showSorterTooltip: false,
      sortIcon: (sort: any) => {
        if (sort?.sortOrder === "ascend") {
          return (
            <div className="attendance_sort_box">
              <CaretUpOutlined className="attendance_sort_activeIcon" />
              <CaretDownOutlined className="attendance_sort_icon" />
            </div>
          );
        }
        if (sort?.sortOrder === "descend") {
          return (
            <div className="attendance_sort_box">
              <CaretUpOutlined className="attendance_sort_icon" />
              <CaretDownOutlined className="attendance_sort_activeIcon" />
            </div>
          );
        }
        return (
          <div className="attendance_sort_box">
            <CaretUpOutlined className="attendance_sort_icon" />
            <CaretDownOutlined className="attendance_sort_icon" />
          </div>
        );
      },
    },

    {
      title: "Out Time",
      render: (value) => {
        const recorded = value?.mstTimesheetsByEmployee;
        const outtime = formatTime(recorded[recorded?.length - 1]?.out_time);

        return (
          <>
            <p>{outtime !== null ? outtime : "00:00"}</p>
          </>
        );
      },
      sorter: (a: any, b: any) => {
        const aOutTime =
          a?.mstTimesheetsByEmployee[a?.mstTimesheetsByEmployee.length - 1]
            ?.out_time;
        const bOutTime =
          b?.mstTimesheetsByEmployee[b?.mstTimesheetsByEmployee.length - 1]
            ?.out_time;
        if (aOutTime < bOutTime) return -1;
        if (aOutTime > bOutTime) return 1;
        return 0;
      },
      showSorterTooltip: false,
      sortIcon: (sort: any) => {
        if (sort?.sortOrder === "ascend") {
          return (
            <div className="attendance_sort_box">
              <CaretUpOutlined className="attendance_sort_activeIcon" />
              <CaretDownOutlined className="attendance_sort_icon" />
            </div>
          );
        }
        if (sort?.sortOrder === "descend") {
          return (
            <div className="attendance_sort_box">
              <CaretUpOutlined className="attendance_sort_icon" />
              <CaretDownOutlined className="attendance_sort_activeIcon" />
            </div>
          );
        }
        return (
          <div className="attendance_sort_box">
            <CaretUpOutlined className="attendance_sort_icon" />
            <CaretDownOutlined className="attendance_sort_icon" />
          </div>
        );
      },
    },
    {
      title: "Hours",
      render: (value) => {
        let recorded = value?.mstTimesheetsByEmployee;
        let totalHours = totalTimeInHour(recorded);
        let color = totalTimeHour(recorded);

        return (
          <>
            <p style={{ color: color ? "red" : "green" }}>{totalHours}</p>
          </>
        );
      },
    },
    {
      title: "Task",
      render: (value) => {
        let recorded = value?.mstTimesheetsByEmployee;
        let lastTask = recorded[recorded?.length - 1];

        return (
          <>
            <Button type="primary" onClick={() => showModal(lastTask)}>
              View
            </Button>
          </>
        );
      },
    },
    {
      title: "Status",
      key: "status",

      filters: [
        {
          text: "Present",
          value: "Present",
        },
        {
          text: "Absent",
          value: "Absent",
        },
      ],
      onFilter: (value, record: any) => {
        let recorded = record?.mstTimesheetsByEmployee;
        let in_time = convertRailwayTimeToNormalTime(recorded[0]?.in_time);
        let out_time = convertRailwayTimeToNormalTime(
          recorded[recorded.length - 1]?.out_time
        );

        if (value === "Present") {
          return in_time !== "Invalid Date";
        } else if (value === "Absent") {
          return in_time === "Invalid Date";
        }

        // If value is neither 'Present' nor 'Absent', show all records.
        return true;
      },

      filterIcon: (filtered) =>
        // Use the FilterOutlined icon, or replace it with your custom icon/component

        user.email === "admin@gmail.com" && (
          <FilterOutlined style={{ color: "white", fontSize: "18px" }} />
        ),
      render: (value: any) => {
        let recorded = value?.mstTimesheetsByEmployee;
        let in_time = convertRailwayTimeToNormalTime(recorded[0]?.in_time);
        let out_time = convertRailwayTimeToNormalTime(
          recorded[recorded.length - 1]?.out_time
        );

        return (
          <Tag color={in_time !== "Invalid Date" ? "green" : "red"}>
            {in_time !== "Invalid Date" ? "Present" : "Absent"}
          </Tag>
        );
      },
    },
  ];

  const handleChangePagination = (pagination: any) => {
    setPagination(pagination);
  };

  const exportPdfFile = () => {
    setShowAllData(true);

    setTimeout(() => {
      const input = tableRef.current;
      if (input) {
        const table = input.querySelector(".ant-table") as HTMLElement | null;
        const lastHeader = table?.querySelector(
          ".ant-table-thead th:last-child"
        ) as HTMLElement | null;
        const lastCells = table?.querySelectorAll(
          ".ant-table-tbody td:last-child"
        ) as NodeListOf<HTMLElement> | null;

        if (lastHeader) lastHeader.style.display = "none";
        lastCells?.forEach((cell) => (cell.style.display = "none"));

        html2canvas(input, { scale: 2 }).then((canvas) => {
          const imgData = canvas.toDataURL("image/png");
          const pdf = new jsPDF("p", "mm", "a4");
          const pdfWidth = pdf.internal.pageSize.getWidth();
          const pdfHeight = pdf.internal.pageSize.getHeight();
          const imgWidth = canvas.width;
          const imgHeight = canvas.height;
          const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);

          pdf.addImage(
            imgData,
            "PNG",
            0,
            0,
            imgWidth * ratio,
            imgHeight * ratio
          );
          pdf.save("table.pdf");

          if (lastHeader) lastHeader.style.display = "";
          lastCells?.forEach((cell) => (cell.style.display = ""));

          setShowAllData(false);
        });
      }
    }, 500);
  };

  return (
    <>
      <div className="attendance">
        <div className="attendance_head">
          <h2 className="attendance_head-text">Attendance</h2>

          {user.email === "admin@gmail.com" && (
            <Select
              size={"large"}
              onChange={handleSelectChangeOrganization}
              allowClear
              showSearch // Enable search functionality
              filterOption={(input, option: any) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
              placeholder={"Select Organization"}
              className="Asset_selecter"
              defaultValue={sessionStorage.getItem("searchAttendance")}
              style={{ width: "220px" }}
            >
              {orgData?.mst_organization?.map((org: any, index: any) => {
                return (
                  <Select.Option value={org.name} key={index}>
                    {org?.name}
                  </Select.Option>
                );
              })}
            </Select>
          )}
          {user.email === "admin@gmail.com" && (
            <Select
              size={"large"}
              onChange={handleSelectChange}
              allowClear
              showSearch // Enable search functionality
              filterOption={(input, option: any) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
              placeholder={"Select Employee"}
              className="Asset_selecter"
              style={{ width: "220px" }}
            >
              {sort?.map((emp: any, index: any) => {
                if (emp.status === true && emp.isdeleteat == false) {
                  return (
                    <Select.Option value={emp.name} key={index}>
                      {emp?.name}
                    </Select.Option>
                  );
                }
              })}
            </Select>
          )}

          <div>
            <Button
              className="employee-details_head-create"
              onClick={exportPdfFile}
            >
              Export PDF
            </Button>
          </div>
          <div>
            <DatePicker onChange={handleDateChange} picker="date" />
          </div>
        </div>
        {user.email === "admin@gmail.com" ? (
          <div ref={tableRef}>
            <Spin spinning={userLoading}>
              <Table
                columns={filteredColumns(columns, "Attendance")}
                dataSource={search(userlist)}
                pagination={showAllData ? false : { pageSize: 10 }}
                onChange={handleChangePagination}
                className="attendance_table"
              />
            </Spin>
          </div>
        ) : (
          <Spin spinning={userLoading}>
            <Table
              columns={filteredColumns(columns, "Attendance")}
              dataSource={search_user(userDetail)}
              pagination={showAllData ? false : { pageSize: 10 }}
              onChange={handleChangePagination}
              className="attendance_table"
            />
          </Spin>
        )}
      </div>

      <Modal
        title={
          <React.Fragment>
            <div className="task">
              <div className="task_header">
                <div className="task_header_body">
                  <p className="task_header_title">
                    {moment(taskData?.date).format("DD-MMM")}
                  </p>
                  <p className="task_header_title">Task</p>
                </div>
              </div>
            </div>
          </React.Fragment>
        }
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={500}
      >
        {taskData?.task === null ||
        taskData === undefined ||
        taskData?.task?.length === 0 ? (
          <div className="task_body">
            <p className="task_noData">No Task</p>
          </div>
        ) : (
          <div className="task_body">
            {taskData?.task?.split("\n").map((point: any, index: any) => (
              <div className="task_page">
                <p className="task_data">{point.trim()} </p>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </>
  );
};

export default Employee;
