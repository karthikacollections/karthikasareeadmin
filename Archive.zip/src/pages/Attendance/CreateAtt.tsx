import { Button, Form, Select, message, DatePickerProps, TimePickerProps, DatePicker, TimePicker, Space } from 'antd';
import React, { useEffect, useState, useRef } from 'react';
import { GET_LOGIN } from '../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import { CREATE_ATTENDANCE, UPDATE_ATTENDANCE } from "../../helpers/mutation"
import { GET_EMPLOYDETAILS } from '../../helpers/queries'
import dayjs from "dayjs";
import moment from 'moment';

export const Employee: React.FC<any> = ({ ModalClose, editdraw, login }) => {
    const [form] = Form.useForm();
    const formRef = useRef(null);
    const [user, setUser] = useState([])

    // const [open, setOpen] = useState(false);
    const [date, setDate] = useState(null)
    const [logintime, setLogintime] = useState(null)
    const [logouttime, setLogouttime] = useState(null)

    //   create Attendance
    const [createAttendance, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_ATTENDANCE, {
        errorPolicy: 'all',
    });

    const [updateAttendance, { loading: updateLoading, error: updateError, data: updateDataAddress }] = useMutation(UPDATE_ATTENDANCE, {
        errorPolicy: 'all',
    });

    const {
        error: countError,
        loading: countLoading,
        data: dataCount,
        refetch: refetAttendance,
    } = useQuery(GET_LOGIN, {
        variables: {},
    });

    const onChangedate: DatePickerProps["onChange"] = (dateString: any) => {
        setDate(dateString);
    };

    const onChangetime: TimePickerProps["onChange"] = (timeString: any) => {
        setLogintime(timeString);
    };
    const onChangingtime: TimePickerProps["onChange"] = (timeString: any) => {
        setLogouttime(timeString);
    };

    function disabledHours() {
        const hours = Array.from({ length: 24 }, (_, hour) => hour);
        const loginHour = moment(editdraw?.logintime)?.hour(); // Extract the login hour

        // Remove hours after the login hour
        hours.splice(loginHour + 1);

        return hours;
    }



    // get employDetails

    const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetEmployDetails,
    } = useQuery(GET_EMPLOYDETAILS, {
        variables: {},
    });


    useEffect(() => {
        if (dataUser) {
            let user = dataUser?.mst_employeedetails
            setUser(user)
        }
    }, [dataUser])

    useEffect(() => {
        if (editdraw) {
            let data = JSON.parse(JSON.stringify(editdraw))
            data.logintime = dayjs(editdraw.logintime)
            data.logouttime = dayjs(editdraw.logouttime)
            data.date = dayjs(editdraw.date)
            form.setFieldsValue(data)
        }

    }, [editdraw])


    const onFinish = (values: any,) => {

        if (editdraw) {
            values.id = editdraw?.id
            updateAttendance({
                variables: values,
            }).then((response) => {
                refetAttendance()
                ModalClose(null)
            });
        }
        else {
            values.date = date
            values.logintime = logintime
            values.logouttime = logouttime
            createAttendance({
                variables: values,
            }).then((response) => {
                refetAttendance()
                ModalClose(null)
            });
        };
    }


    const onFinishFailed = (errorInfo: any) => {
    };


    return (
        <>
            <div>
                <Form
                    name="basic"
                    layout="vertical"
                    initialValues={{ remember: true }}
                    onFinish={onFinish}
                    onFinishFailed={onFinishFailed}
                    autoComplete="off"
                    form={form}
                    ref={formRef}
                    className="attendance_form"
                >
                    <Form.Item label="Employee"
                        name="employee"
                        required={false}
                        rules={[{ required: true, message: 'Please select your name!' }]}
                        className="attendance_form_item"
                    >
                        <Select className="attendance_form_item-input">
                            {
                                user.map((val: any) => {
                                    return (
                                        <Select.Option value={val.id} key={val.id}>{val?.name}</Select.Option>
                                    )
                                })
                            }
                        </Select>

                    </Form.Item>

                    <Form.Item name="logintime"
                        label="Login Time"
                        required={false}
                        rules={[{ required: true, message: 'Please select correct time!' }]}
                        className="attendance_form_item"
                    >
                        <TimePicker className="attendance_form-timepic" onChange={onChangetime} />
                    </Form.Item>

                    <Form.Item name="logouttime"
                        label="Logout Time"
                        required={false}
                        rules={[{ required: true, message: 'Please select correct time!' }]}
                        className="attendance_form_item"
                    >
                        <TimePicker className="attendance_form-timepic" onChange={onChangingtime}
                            disabledHours={() => disabledHours()}
                        />
                    </Form.Item>

                    <Form.Item label="Date" name="date"
                        required={false}
                        rules={[{ required: true, message: 'Please select correct date!' }]}
                        className="attendance_form_item"
                    >
                        <DatePicker className="attendance_form-datepic" onChange={onChangedate} />
                    </Form.Item>


                    <Form.Item >
                        <div className="attendance_submit">
                            <Space>
                                <Button htmlType="button" className="attendance_cancel-btn" onClick={() => ModalClose(null)}>
                                    Cancel
                                </Button>
                                <Button htmlType="submit" className="attendance_submit-btn">
                                    Submit
                                </Button>
                            </Space>
                        </div>
                    </Form.Item>
                </Form>

            </div>

        </>

    )
}

export default Employee