
import type { NextPage } from 'next'
import Image from 'next/image';
import { useRouter } from 'next/router'
import { Button, Form, Input, message } from 'antd';
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../../components/firebaseconfig";
import { LockOutlined, UserOutlined } from '@ant-design/icons';
import Login_logo from '../../assets/photos/emp_background-logo.svg' 
import { EMAIL_ID, PASSWORD } from "../../../src/utils/constants";

const Login: NextPage = () => {

    const router = useRouter();

    const onFinish = async ({ email, password }: any) => {
        // Hardcoded email and password
        const hardcodedEmail = EMAIL_ID;
        const hardcodedPassword = PASSWORD;
    
        console.log(email, password); // Log values
    
        // Check if the entered email and password match the hardcoded credentials
        if (email === hardcodedEmail && password === hardcodedPassword) {
            message.success("Successfully Signed in");
            console.log("Navigating to /CRM/Category");
            window.location.href = "/CRM/Category";
        } else {
            message.error("Check your email or password");
        }
    };
    
    

    return (
        <>
        {/* <div className="welcome_message"><p>Kindly Login via Laptop</p></div> */}
            <div className="login">
                <div className="login-box">
                    <div className="login-loginSession">
                        <div style={{display:'flex'}}>
                            
                            <div className="login-form">
                                <h1>Login</h1>
                                <Form onFinish={onFinish} layout="vertical" autoComplete="off">
                                    <div className='login-inputBox'>
                                        <Form.Item  name="email" rules={[{ type: "email", required: false, message: "Please input your Email ID", },]}>
                                            <Input size="large"prefix={<UserOutlined className='inputLogo' />} placeholder="Email ID" className="login-input" />
                                        </Form.Item>

                                        <Form.Item name="password" rules={[{ required: false, message: "Please input your password!" },]} >
                                            <Input.Password placeholder="Password" prefix = {<LockOutlined className='inputLogo'/>} className="login-input" />
                                        </Form.Item>
                                    </div>
                                    <div className='login-action'>
                                        
                                        {/* <h3 className="pockets-forgot">
                                            <span >Forgot Password?</span>
                                        </h3> */}

                                        <Button htmlType="submit" className="login-button">sign in</Button>

                                    </div>

                                </Form>
                            </div>
                        </div>
                    </div>

                    {/* <div className="login-welcomeSession">
                        <div className="login-welcomeSession-box">
                            <div className='login-welcomeSession-title'>
                                <h2>welcome to</h2>
                            </div>
                            <div className='login-welcomeSession-logoBox'>
                                <Image src={Login_logo} width={300} alt="Image Description" />
                            </div>
                            <div className='login-welcomeSession-quoteBox'>
                                <p>A company's success is measured by the dedication and performance of its employees, tracked and optimized through a reliable database</p>
                            </div>
                        </div>
                    </div> */}
                    
                </div>
            </div>
        </>
    );
};

export default Login;