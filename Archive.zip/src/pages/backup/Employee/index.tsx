import withApollo from '../../../config'
import { Space, Table, Button, Modal, InputNumber, Form, Input,Popconfirm } from 'antd';
import React, { useEffect, useState } from 'react';
import type { ColumnsType } from 'antd/es/table';
import { GET_USERS } from '../../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import { CREATE_EMPLOYEE, UPDATE_EMPLOYEE,DELETE_EMPLOYEE } from "../../../helpers/mutation";
import type { PaginationProps } from 'antd';

export const Home: React.FC = () => {

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [pageType, setPageType] = useState("create")
    const [editEmployee, setEditEmployee] = useState<any>()
    const [user, setUser] = useState([])
    const [page, setPage] = useState(1);


    const [form] = Form.useForm();
    interface DataType {
        key: string;
        name: string;
        sno: number;
        age: number;
        experience: number;
    }

    const itemRender: PaginationProps["itemRender"] = (
        _,
        type,
        originalElement
    ) => {
        if (type === "prev") {
            return <a>Prev</a>;
        }
        if (type === "next") {
            return <a>Next</a>;
        }
        return originalElement;
    };


    const columns: ColumnsType<DataType> = [
        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: "S.no",

            render: (text, object, index: number) => { return ((page - 1) * 10 + index) + 1 },

        },
        {
            title: 'Age',
            dataIndex: 'age',
            key: 'age',
        },
        {
            title: 'Experience',
            dataIndex: 'experience',
            key: 'experience',
        },

        {
            title: 'Action',
            key: 'action',
            render: (_, record) => (
                <Space size='large'>
                    <Button
                        type="primary"
                        // icon={<EditOutlined />}
                        size="large"
                        onClick={() => showModal(record)}
                    >Edit</Button>

                    <Popconfirm
                        title="Delete the task"
                        description="Are you sure to delete this task?"
                        okText="Yes"
                        cancelText="No"
                        onConfirm={() => handleDelete(record)}
                    >
                        <Button type="primary" danger
                            // icon={<DeleteOutlined />} 
                            size="large" >Delete</Button>
                    </Popconfirm>



                </Space>
            ),
        },
    ];

    // modal
    const showModal = (record: any) => {
        if (record) {
            setPageType('edit')
            setEditEmployee(record)
            form.setFieldsValue(record)
        }
        else {
            setPageType('create')
            setEditEmployee(null)
            form.setFieldsValue(null)
        }

        setIsModalOpen(true);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
        setEditEmployee(null)
        form.resetFields()
    };

    // get employee

    const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetUser,
    } = useQuery(GET_USERS, {
        variables: {},
    });



    useEffect(() => {
        if (dataUser) {
            let user = dataUser?.mst_employee
            setUser(user)
        }
    }, [dataUser])



    const [createEmployee, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_EMPLOYEE, {
        errorPolicy: 'all',
    });


    const [
        updateEmployee,
        { loading: updateloading, error: updateerror, data: updatedataAddress },
    ] = useMutation(UPDATE_EMPLOYEE, {
        errorPolicy: "all",
    });

    const [deleteEmployee, { loading, error, data }] = useMutation(DELETE_EMPLOYEE);
    const handleDelete = (id: any) => {
        deleteEmployee({
            variables: id,

            update: (cache) => {
                refetUser()
            },
        });
    };


    const onFinish = (values: any) => {

        if (pageType === 'edit') {
            values.id = editEmployee?.id
            updateEmployee({
                variables: values,
            }).then((response) => {
                refetUser()
                setIsModalOpen(false)
            });
        }
        else {
            createEmployee({
                variables: values,
            }).then((response) => {
                refetUser()
                setIsModalOpen(false)
            });
        };
    }

    const onFinishFailed = (errorInfo: any) => {
    };

    return (
        <>
            <div>
                <div className="employee_home_div_createbtn">
                    <Button type="primary" size="large" className="employee_home_createbtn" onClick={() => showModal(null)}>Create +</Button>
                </div>
                <Table columns={columns} dataSource={user} pagination={{
                    pageSize: 10,
                    itemRender: itemRender,
                    onChange(current) {
                        setPage(current);
                    }
                }} className="employedetails_Home_table" />
                <Modal title={`${pageType}employee`} open={isModalOpen} footer={false} onCancel={handleCancel}>
                    <Form
                        name="basic"
                        labelCol={{ span: 8 }}

                        style={{ maxWidth: 400 }}
                        initialValues={{ remember: true }}
                        onFinish={onFinish}
                        onFinishFailed={onFinishFailed}
                        autoComplete="off"
                        form={form}
                    >
                        <Form.Item
                            label="Name"
                            name="name"
                            rules={[{ required: true, message: 'Please input your Name!' }]}
                        >
                            <Input />
                        </Form.Item>

                        {/* <Form.Item
                            label="S.No"
                            name="sno"
                            rules={[{ required: true, message: 'Please input your S.No!' }]}
                        >
                            <InputNumber />
                        </Form.Item> */}

                        <Form.Item
                            name="age"
                            label="Age"
                            rules={[{ required: true, message: 'Please input your age!' }]}
                        >
                            <InputNumber />
                        </Form.Item>

                        <Form.Item
                            label="Experience"
                            name="experience"
                            rules={[{ required: true, message: 'Please input your Experience!' }]}
                        >
                            <InputNumber />
                        </Form.Item>

                        <Form.Item >
                            <div className="employee_form_btndiv">
                                <Button type="primary" htmlType="submit" className="employee_form_btndiv_btn">
                                    Submit
                                </Button>
                            </div>
                        </Form.Item>
                    </Form>
                </Modal>
            </div>
        </>
    )
}
export default Home