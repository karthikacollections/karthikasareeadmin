import type { NextPage } from 'next'

import { useAuth } from '../components/auth'
import Login from '../pages/login/index'

import NavBar from '../components/Navbar'
import Dashboard from './Dashboard'
import CRM from './CRM'

const Home: NextPage = () => {
  const { user } = useAuth()
  return (
    user ?
      <div className="pockets_container">
        <NavBar />
        <div className="mainContent">
          <div className="mainContent_bg">
          <Login />
          </div>
        </div>
      </div>
      :
      <Login />
  )
}

export default Home