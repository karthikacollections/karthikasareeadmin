import { Button, Form, Select, Space, Input, } from 'antd';
import React, { useEffect, useState, useRef } from 'react';
import {GET_ASSET} from '../../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import { CREATE_ASSTMANAGE, UPDATE_ASSTMANAGE } from "../../../helpers/mutation"
 import { GET_EMPLOYDETAILS } from '../../../helpers/queries'


export const Employee: React.FC<any> = ({ ModalClose, editdraw, login }) => {

    const [form] = Form.useForm();
    const formRef = useRef(null);
    const [user, setUser] = useState([])
    const [asset, setAsset] = useState([])
    const [manage, setManage] = useState([])

    // Employee names

    const [createManage, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_ASSTMANAGE, {
        errorPolicy: 'all',
    });

    const [updateManage, { loading: updateLoading, error: updateError, data: updateDataAddress }] = useMutation(UPDATE_ASSTMANAGE, {
        errorPolicy: 'all',
    });

     const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetEmployDetails,
    } = useQuery(GET_EMPLOYDETAILS, {
        variables: {},
    });


    useEffect(() => {
        if (dataUser) {
            let user = dataUser?.mst_employeedetails
            setUser(user)
        }
    }, [dataUser])

    // Assets

    const {
        error: assetError,
        loading: assetLoading,
        data: dataAsset,
        refetch: refetasset,
    } = useQuery(GET_ASSET, {
        variables: {},
    });


    useEffect(() => {
        if (dataAsset) {
            let asset = dataAsset?.mst_assets
            setAsset(asset)
        }
    }, [dataAsset])

    const {
        error: manageError,
        loading: manageLoading,
        data: dataManage,
        refetch: refetAsstManage,
    } = useQuery(GET_ASSET, {
        variables: {},
    });

    useEffect(() => {
        if (dataManage) {
            let manage = dataManage?.mst_asstmanage
            setManage(manage)
        }
    }, [dataManage])

    const onFinish = (values: any,) => {
        if (editdraw) {
            values.id = editdraw?.id
        

            updateManage({
                variables: values,
            }).then((response) => {
                refetasset()
                ModalClose(null)
            });
        }
        else {
            
            createManage({
                variables: values,
            }).then((response) => {
                refetasset()
                ModalClose(null)
            });
        };
    }
    useEffect(() => {
        form.setFieldsValue(editdraw)
    }, [editdraw])

    const onFinishFailed = (errorInfo: any) => {
    };


    return (
        <div>
            <Form
                name="basic"
                layout="vertical"
                initialValues={{ remember: true }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                ref={formRef}
                className="assets_form"

            >
                <Form.Item label="Employee"
                    name="employee"
                    required={false}
                    rules={[{ required: true, message: 'Please select your name!' }]}
                    className="attendance_form_item"
                >
                    <Select className="attendance_form_item-input">
                        {
                            user?.map((val: any) => {
                                if(val.status == true){
                                       return (
                                        <Select.Option value={val.id} key={val.id}>{val?.name}</Select.Option>
                                    )
                                }
                                
                            })
                        }
                    </Select>

                </Form.Item>



                <Form.Item label="Property Type"
                    name="property_type"
                    required={false}
                    rules={[{ required: true, message: 'Please select type' }]}
                    className="attendance_form_item"
                >
                    <Select className="attendance_form_item-input">
                        {
                            asset.map((val: any) => {
                                return (
                                    <Select.Option value={val.id} key={val.id}>{val?.property_type}</Select.Option>
                                )
                            })
                        }
                    </Select>
                </Form.Item> 

                
                

                <Form.Item >
                    <div className="assets_submit">
                        <Space>
                            <Button htmlType="button" className="assets_cancel-btn" onClick={() => ModalClose(null)}>
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="assets_submit-btn">
                                Submit
                            </Button>
                        </Space>
                    </div>
                </Form.Item>

            </Form>

        </div>
    )
}

export default Employee
