import withApollo from '../../../config'
import React, { useEffect, useState, useRef } from 'react';
import { Space, Table, Button, Form, Popconfirm, Drawer, Select } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { GET_ASSTMANAGE, GET_EMPLOYDETAILS } from '../../../helpers/queries'
import {DELETE_ASSTMANAGE} from '../../../helpers/mutation'
import { useQuery, useMutation } from "@apollo/client";
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import CreateAssetManagement from "./CreateManagement";
import Compnaynav from "../company"
import { useAuth } from '../../../components/auth'

export const AssetManage: React.FC = () => {

    // const [count, setCount] = useState([])

    const [open, setOpen] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("")
    const { check_button_permission,filteredColumns } = useAuth()
    const [user, setUser] = useState([])
    const [filterData, setFilterData] = useState(false)
    const [filterAsset, setFilterAsset] = useState([])
    const ModalClose = () => {
        setOpen(false)
        refetAssetManage()

    }

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("edit")
    }

    const [deleteAsstManage, { loading, error, data }] = useMutation(DELETE_ASSTMANAGE);
    const handleDelete = (id: any) => {
        deleteAsstManage({
            variables: id,

            update: (cache) => {
                refetAssetManage()
            },
        });
    };

    
    const {
        error: assetError,
        loading: assetLoading,
        data: dataAsset,
        refetch: refetAssetManage,
    } = useQuery(GET_ASSTMANAGE, {
        variables: {},
    });

    const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetEmployDetails,
    } = useQuery(GET_EMPLOYDETAILS, {
        variables: {},
    });

    

useEffect(() => {
        if (dataAsset) {
            let user = dataAsset?.mst_asstmanage
            setUser(user)
        }
    }, [dataAsset])
    
   

    interface DataType {
        // key: string;
        // loginTime: number;
        // logoutTime: number;
        // date: string;
        employee: string;
    }
    

    const columns: ColumnsType<DataType> = [
        {
            title: 'Employee',
            
            render: (value) => {
                
                return (
                    <>
                        <p>{value?.mst_asstmanage_mst_employee?.name}</p>
                    </>
                )
            }
        },
        {
            title:'Serial Number',
            render:(value)=>{
                return(
                    <p>{value?.mst_asstmanage_mst_assets?.serialno}</p>
                )
            }
        },
        {
            title: 'Property',
            render: (value) => {
                return (
                    <>
                        <p>{value?.mst_asstmanage_mst_assets?.property_type}</p>
                    </>
                )
               
            }
        },
       
        {
            title: 'Action',
            key: 'action',
            render: (
                record: any) => (
                <Space size='large'>
                    {
                        check_button_permission("Assetsmanagement", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="assets_edit"
                            />:<></>
                    }

                     {
                        check_button_permission("Assetsmanagement", "delete")
                            ?
                            <Popconfirm
                                title="Delete the task"
                                description="Are you sure to delete this task?"
                                okText="Yes"
                                onConfirm={() => handleDelete(record)}
                                cancelText="No"
                            >
                                <DeleteOutlined className="assets_delete" />
                            </Popconfirm>:<></>
                    }

                </Space>
            ),
        },
    ];
    
    const handleSelectChange = (value:any) => {
        setFilterData(true)
        const filter_Asset = user?.filter((param:any)=>param?.employee==value)
        setFilterAsset(filter_Asset)
        if(value===undefined){
            setFilterData(false)
        }
        
      };
      

    return (
      <Compnaynav>
        <div className="assets">
          <div className="assets_head">
            <h2 className="assets_head-text">Assets Management</h2>
            <div className='expense_action'>
                <Select
                size={'large'}
                onChange={handleSelectChange}
                allowClear
                placeholder={'Select Employee'}
                className='Asset_selecter'
                style={{width:'220px'}}
                >
                    {dataUser?.mst_employeedetails?.map((emp:any,index:any)=>{
                         if(emp.status===true){
                                    
                             return (
                                 <Select.Option value={emp.id} key={index}>{emp?.name}</Select.Option>
                             )
                         }
                    })}
                </Select>
                {check_button_permission("Assetsmanagement", "create") ? (
                <Button
                    className="assets_head-create"
                    onClick={() => setOpen("Create")}>
                    Add New
                </Button>
                ) : (
                <></>
                )}
            </div>
          </div>
          {filterData ? <Table
            columns={filteredColumns(columns, "Assetsmanagement")}
            dataSource={filterAsset}
            pagination={false}
            className="assets_table"
          />:<Table
          columns={filteredColumns(columns, "Assetsmanagement")}
          dataSource={user}
          pagination={false}
          className="assets_table"
        />}
          
          <Drawer
            title={`${open} Assetsmanagement `}
            width={570}
            placement="right"
            onClose={() => setOpen(false)}
            open={open?.length > 1 ? true : false}>
            {open == "edit" ? (
              <CreateAssetManagement
                ModalClose={ModalClose}
                editdraw={editdraw}
              />
            ) : (
              <></>
            )}
            {open == "Create" ? (
              <CreateAssetManagement ModalClose={ModalClose} editdraw={null} />
            ) : (
              <></>
            )}
          </Drawer>
        </div>
      </Compnaynav>
    );
}

export default AssetManage
