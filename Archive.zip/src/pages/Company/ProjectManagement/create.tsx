import { Button, DatePicker, DatePickerProps, Form, Input, InputNumber, Select, Space, message } from "antd";
import React, { useEffect, useRef, useState } from "react";
import dayjs from "dayjs";
import { GET_CLIENT, GET_PROJECT } from "../../../helpers/queries"
import { useMutation, useQuery } from "@apollo/client";
import { CREATE_PROJECT_DATA, UPDATE_PROJECT_DATA } from "@/helpers";

const CreateProject: React.FC<any> = ({ ModalClose, editdraw, showModal }) => {

    const [form] = Form.useForm()
    const formRef = useRef(null)
    const [formDate, setFormDate] = useState<any>('')
    const [toDate, setToDate] = useState<any>('')
    const [client, setClient] = useState([]);

    const onChangeFormDate: DatePickerProps["onChange"] = (dateString: any) => {
        setFormDate(dateString)

    }
    const onChangeToDate: DatePickerProps["onChange"] = (dateString: any) => {
        setToDate(dateString)
    }

    // get Client Data
    const {
        error: userError,
        loading: userLoading,
        data: clientData,
        refetch: refetClientData
    } = useQuery(GET_CLIENT)

    useEffect(() => {
        if (clientData) {
            console.log(clientData ,'clientData');
            
            let data = clientData?.mst_clientmanagement
            setClient(data)
        }

    }, [clientData])

    useEffect(() => {
        if (editdraw) {
            let data = JSON.parse(JSON.stringify(editdraw))
            data.duration_from = dayjs(editdraw.duration_from)
            data.duration_to = dayjs(editdraw.duration_to)
            form.setFieldsValue(data)
        }
    }, [editdraw])

    // Get the Project Data
    const {
        error: projectError,
        loading: projectLoading,
        data: projectData,
        refetch: refetProjectData
    } = useQuery(GET_PROJECT)


    // POST the Project
    const [createProjectData, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_PROJECT_DATA, {
        errorPolicy: 'all',
    });

    //  Update the Project
    const [updateProjectData, { loading, error, data }] = useMutation(UPDATE_PROJECT_DATA, {
        errorPolicy: 'all'
    })


    //  Cheak the Date,Month and Year
    const dayCal = (day: any) => {
        let now = new Date()
        let currentDate = now.toLocaleDateString().split('/')
        let date = +day[1] - Number(currentDate[1])
        return Math.sign(date)
    }
    const monthCal = (day: any) => {
        let now = new Date()
        let currentDate = now.toLocaleDateString().split('/')
        let month = +day[0] - Number(currentDate[0])
        return Math.sign(month)
    }
    const yearCal = (day: any) => {
        let now = new Date()
        let currentDate = now.toLocaleDateString().split('/')
        let date = +day[2] - Number(currentDate[2])
        return Math.sign(date)
    }

    //  Cheak the Date weather it was Perviwes date or Not
    const CheakDate = (form: any, to: any) => {
        let formDay = form.split('-')
        let toDay = to.split('-')
        if (dayCal(formDay) == -1 || monthCal(formDay) == -1 || yearCal(formDay) == -1 || dayCal(toDay) == -1 || monthCal(toDay) == -1 || yearCal(toDay) == -1) {
            return true
        } else {
            return false
        }
    }

    // Passing the Data form Form
    const onFinish = async (values: any) => {
        console.log(values);
        let formDay = dayjs(formDate).format('MM-DD-YYYY')
        let toDay = dayjs(toDate).format('MM-DD-YYYY')

        if (CheakDate(formDay, toDay)) {
            message.error('Cheak the Date')
        }

        if (editdraw) {
            console.log(editdraw , 'editdraw');
            
            values.id = editdraw.id
            await updateProjectData({ variables: values }).then((res: any) => {
                refetProjectData()
                ModalClose(null)
                message.success('Update the Project')
                form.resetFields()
                showModal("Updated")
            }).catch((err: any) => {
                message.error('error')
            })
        } else {
            // values.duration_from = formDate
            // values.duration_to = toDate
            await createProjectData({ variables: values }).then((res: any) => {
                refetProjectData()
                ModalClose(null)
                showModal("Created")
                message.success(`Inserting new Data`)
                form.resetFields()
            }).catch((err: any) => {
                message.error('error')
            })
        }
    }
    const onFinishFailed = async (errorInfo: any) => {

    }


    return <>
        <Form
            name="Project"
            layout="vertical"
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
            form={form}
            ref={formRef}
            className="employee-details_form"
        >
            <Form.Item
                label="Project Name"
                name="project_name"
                required={false}
                rules={[{ required: true, message: 'Please Enter Project Name' }]}
            >
                <Input />
            </Form.Item>

            <Form.Item
                label="Company Name"
                name="company_name"
                required={false}
                rules={[{ required: true, message: 'Please Select the company name' }]}
            >
                <Select className="employee-details_form_item-input">
                    {client.map((data: any) => (
                        <Select.Option value={data.id} key={data.id}>{data.company_name}</Select.Option>
                    ))}
                </Select>
            </Form.Item>

            <Space>
                <Form.Item
                    label="Form"
                    name="duration_from"
                    required={false}
                    rules={[{ required: true, message: 'Please Select the From Date' }]}
                >

                    <DatePicker style={{ width: 230 }} onChange={onChangeFormDate} />
                </Form.Item>

                <Form.Item
                    label="To"
                    name="duration_to"
                    required={false}
                    rules={[{ required: true, message: 'Please Select the  Date' }]}
                >
                    <DatePicker style={{ width: 230 }} onChange={onChangeToDate} />
                </Form.Item>
            </Space>

            <Form.Item
                label="Budget"
                name="budget"
                required={false}
                rules={[{ required: true, message: 'Please Enter budget of the Projecot' }]}
            >
                <Input />
            </Form.Item>

            <Form.Item>
                <div className="employee-details_submit">
                    <Space>
                        <Button htmlType="button" className="employee-details_cancel-btn" onClick={() => ModalClose(null)}>
                            Cancel
                        </Button>
                        <Button htmlType="submit" className="employee-details_submit-btn">
                            Submit
                        </Button>
                    </Space>
                </div>
            </Form.Item>

        </Form>
    </>
}

export default CreateProject