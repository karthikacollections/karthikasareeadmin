// import { authProtected } from "@/components/protectedroute"
import { Button, Drawer, Popconfirm, Space, Table, Modal } from "antd"
import { useEffect, useState } from "react";
import  CreateProject  from "./create";
import { useMutation, useQuery } from "@apollo/client";
import { DELECT_PPROJECT, GET_PROJECT ,GET_CLIENT } from "@/helpers";
import moment from "moment";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import Compnaynav from "../company"
import {useAuth} from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";

export const ProjectManagement:React.FC<any>=()=>{

    const[project,setProject]=useState([]);
    const [open, setOpen] = useState<any>(false);
    const [heading, setHeading] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("");
    const {check_button_permission,filteredColumns}=useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
      };
      
      const handleOk = () => {
        refetProjectData();
        setPopOpen(false);
      };
    
      const handleCancel = () => {
        setPopOpen(false);
      };
    

    const OnOpen=()=>{
        setOpen(true)
        setHeading('Create')
    }

    const ModalClose = () => {
        setOpen(false)
    }

    // Getting Project Data
    const {
        error:projectError,
        loading:projectLoading,
        data:projectData,
        refetch: refetProjectData
    }=useQuery(GET_PROJECT)

// Delect the Project Date
    const[delectProject,{loading,error,data}]=useMutation(DELECT_PPROJECT);


    useEffect(()=>{
        if(projectData){
            console.log(projectData ,'projectData');
            
            let res=projectData?.mst_project
            setProject(res)
        }
    },[projectData])

    // Update Function
    const handleChange = (record: any) => {
        console.log(record);
        
        setEditdraw(record)
        setOpen("Edit")
        setHeading("Edit")
    }

    // Delete Function
    const handleDelete=(res:any)=>{
        delectProject({
            variables:res,
            update:(cache:any)=>{
                refetProjectData()
            }
        })
    }

    var count=0
    const columns=[
        {
            title:'S.no',
            dataIndex: 's.no',
            render: () =>++count,
        },
        {
            title:'Project Name',
            dataIndex:'project_name',
            key:'project_name'
        },
        {
            title:'Company Name',
           
          render: (value:any)=>{
            return(
                <p>{value?.mst_client_company?.company_name}</p>
            )
          }
     
        },
                {
                    title:'From',
                    render:(value:any)=>{
                        return(<>
                        <p>{moment(value?.duration_from).format('DD MMMM YYYY')}</p>
                     
                        </>)
                    }
                },
                {
                    title:'TO',
                    render:(value:any)=>{
                        return(<>
                     
                        <p>{moment(value?.duration_to).format('DD MMMM YYYY')}</p>
                        </>)
                    }
                },
        {
            title:'Budget',
            dataIndex:'budget',
            key:'budget'
        },
        
        {
            title: 'Action',
            key: 'action',
            render: (record: any) => (
                <Space  size='large'>
                    {
                        check_button_permission("ProjectManagement", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="employee-details_edit"
                            />
                        :<></>
                    }

                    {
                        check_button_permission("ProjectManagement", "delete")
                            ?
                            <Popconfirm
                                title="Delete the task"
                                description="Are you sure to delete this task?"
                                okText="Yes"
                                cancelText="No"
                                onConfirm={() => handleDelete(record)}
                            >
                                <DeleteOutlined className="employee-details_delete" />
                            </Popconfirm>:<></>
                    }
                </Space>
            ),
        },
    ]

    return (
        <Compnaynav>
        <div className="employee-details">
            <div className="employee-details_head">
                <h2 className="employee-details_head-text">Project Management</h2>
                {
                        check_button_permission("ProjectManagement", "create")
                            ?
                        <Button className="employee-details_head-create" onClick={() => setOpen("Create")}>Add Project</Button>
                        :<></>
                }
            </div>
            <Table columns={filteredColumns(columns,'ProjectManagement')} dataSource={project} pagination={false} className="employee-details_table" />

            <Drawer title={`${open} Project`} width={570} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false} className="employee-details_drawer">
                {
                    open == "Edit" ? (<CreateProject ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                }
                {
                    open == "Create" ? (<CreateProject ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                }
            </Drawer>
        </div>
        <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{display: "flex", justifyContent: "center"}}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
        </Compnaynav>
    )
}

export default ProjectManagement