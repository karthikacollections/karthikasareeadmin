import React, { useEffect, useState } from 'react';
import { Space, Table, Button, Popconfirm, Drawer,Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { GET_PROJECT } from '../../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import { DELETE_PROJECT } from "../../../helpers/mutation"
import CreateAsset from "./create";
import Compnaynav from "../company"
import {useAuth} from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";

export const Employee: React.FC = () => {

    const [count, setCount] = useState([])
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");
    const [open, setOpen] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("")
    const { check_button_permission,filteredColumns } = useAuth()

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
      };
      
      const handleOk = () => {
        refetchProject();
        setPopOpen(false);
      };
    
      const handleCancel = () => {
        setPopOpen(false);
      };

    interface DataType {
        key: string;
        employee: string;
    }
    
    const ModalClose = () => {
        setOpen(false)

    }

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("edit")
    }

    const {
        error: countError,
        loading: countLoading,
        data: dataCount,
        refetch: refetchProject,
    } = useQuery(GET_PROJECT, {
        variables: {},
    });

    useEffect(() => {
        if (dataCount) {
            let count = dataCount?.mst_project
            setCount(count)
        }
    }, [dataCount])

    const [deleteProject, { loading, error, data }] = useMutation(DELETE_PROJECT);
    const handleDelete = (id: any) => {
        deleteProject({
            variables: id,
            update: (cache) => {
                showModal("Deleted")
                refetchProject()
            },
        });
    };

    var count_serial=0

    const columns: ColumnsType<DataType> = [
        {
            title: 'S.no',
            key: 'property',
            render:()=>++count_serial
        },
        {
            title: 'Project Name',
            dataIndex: 'project_name',
            key: 'project_name',
        },
        {
            title: 'Description',
            dataIndex: 'description',
            key: 'description',
        },
        {
            title: 'Action',
            key: 'action',
            render: (
                record: any) => (
                <Space size='large'>
                    {
                        check_button_permission("Projects", "edit")
                            ?
                        <EditOutlined
                            onClick={() => handleChange(record)}
                            className="assets_edit"
                        />:<></>
                    }

                    {
                        check_button_permission("Projects", "delete")
                            ?
                        <Popconfirm
                            title="Delete the task"
                            description="Are you sure to delete this task?"
                            okText="Yes"
                            onConfirm={() => handleDelete(record)}
                            cancelText="No"
                        >
                            <DeleteOutlined className="assets_delete" />
                        </Popconfirm>:<></>
                    }

                </Space>
            ),
        },
    ];

    return (
        <Compnaynav>
            <div className="assets">
                <div className="assets_head">
                    <h2 className="assets_head-text">Projects</h2>
                    {/* <Button className="assets_head-create" onClick={() => setOpen("create")}>+ Add New Login</Button> */}
                    {
                        check_button_permission("Projects", "create")
                            ?
                            <Button className="assets_head-create" onClick={() => setOpen("Create")} >+ Add New</Button>
                            :<></>
                    }
                </div>
                <Table columns={columns} dataSource={count} pagination={false} className="assets_table" />

                <Drawer title={`${open} Projects`} width={570} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}>
                    {
                        open == "edit" ? (<CreateAsset ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        open == "Create" ? (<CreateAsset ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                    }
                </Drawer>

            </div>
            <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{display: "flex", justifyContent: "center"}}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
      </Compnaynav>
    )
}

export default Employee