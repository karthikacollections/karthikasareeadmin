import { Button, Form, Select, message, DatePickerProps, TimePickerProps, DatePicker, TimePicker, Space, Input, } from 'antd';
import React, { useEffect, useState, useRef } from 'react';
import { GET_PROJECT } from '../../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import { CREATE_PROJECT, UPDATE_PROJECT } from "../../../helpers/mutation"

export const Employee: React.FC<any> = ({ ModalClose, editdraw, login, showModal }) => {
    const [form] = Form.useForm();
    const formRef = useRef(null);
    const { TextArea } = Input;

    const [createProject, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_PROJECT, { errorPolicy: 'all', });

    const [updateProject, { loading: updateLoading, error: updateError, data: updateDataAddress }] = useMutation(UPDATE_PROJECT, { errorPolicy: 'all', });

    const { error: countError, loading: countLoading, data: dataCount, refetch: refetProject, } = useQuery(GET_PROJECT, { variables: {}, });

    const onFinish = (values: any,) => {
        if (editdraw) {
            values.id = editdraw?.id
            updateProject({
                variables: values,
            }).then((response) => {
                showModal("Updated")
                refetProject()
                ModalClose(null)
            });
        }
        else {
            createProject({
                variables: values,
            }).then((response) => {
                showModal("Created")
                refetProject()
                ModalClose(null)
            });
        };
    }

    useEffect(() => {
        form.setFieldsValue(editdraw)
    }, [editdraw])

    const onFinishFailed = (errorInfo: any) => {
    };

    return (
        <div>
            <Form
                name="basic"
                layout="vertical"
                initialValues={{ remember: true }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                ref={formRef}
                className="assets_form"

            >
                <Form.Item label="Project Name"
                    name="project_name"
                    required={false}
                    rules={[{ required: true, message: 'Please select type' }]}
                    className="assets_form_item"
                >
                    <Input className="assets_form_item-input" />
                </Form.Item>

                <Form.Item label="Description"
                    name="description"
                    required={false}
                    rules={[{ required: true, message: 'Please enter description' }]}
                    className="assets_form_item">
                    <TextArea rows={4}
                        style={{ height: 130, resize: 'none' }}
                        className="assets_form_item-input"
                    />
                </Form.Item>

                <Form.Item >
                    <div className="assets_submit">
                        <Space>
                            <Button htmlType="button" className="assets_cancel-btn" onClick={() => ModalClose(null)}>
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="assets_submit-btn">
                                Submit
                            </Button>
                        </Space>
                    </div>
                </Form.Item>

            </Form>
        </div>
    )
}

export default Employee