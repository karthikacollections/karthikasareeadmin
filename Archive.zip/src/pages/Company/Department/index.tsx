import { ColorInput } from '@mantine/core'
import { Button, DatePicker, DatePickerProps, Drawer, Popconfirm, Space, Table, Modal } from 'antd'
import React, { useEffect, useState } from 'react'

import withApollo from '../../../config'
import { useMutation, useQuery } from '@apollo/client'
import { DELETE_DEPARTMENT, GET_DEPARTMENT } from '@/helpers'
import moment from 'moment'
import CreateEmp from './createDep'
import { DeleteOutlined, EditOutlined } from '@ant-design/icons'
import Compnaynav from "../company"
import {useAuth} from '../../../components/auth'
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";


export const Department: React.FC<any> = ({ urlList }) => {
    const [user, setUser] = useState([]);
    const [filterreferral, setFilterReferral] = useState([])
    const [filter, setFilter] = useState(false)
    const [open, setOpen] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("")
    const { check_button_permission,filteredColumns } = useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");
    
    const ModalClose = () => {
        setOpen(false)
        // refetEmployDetails()
    }
    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
    } 
    const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetEmployDetails,
    } = useQuery(GET_DEPARTMENT, {
        variables: {},
    });
    useEffect(() => {
        if (dataUser) {
            let user = dataUser?.mst_department
            setUser(user)
        }
    }, [dataUser])
    
    const [deleteEmployee, { loading, error, data }] = useMutation(DELETE_DEPARTMENT);
    const handleDelete = (req: any) => {
        
        deleteEmployee({
            variables: req,
            update: (cache: any) => {
                showModal("Deleted")
                refetEmployDetails()
            },
        });
    };
    


    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
    };

    const handleOk = () => {
        refetEmployDetails();
        setPopOpen(false);
    };

    const handleCancel = () => {
        setPopOpen(false);
    };


    const columns = [
        {
            title: 'S.No',
            dataIndex: 'sno',
            key: 'sno',
            render: (text: any, record: any, index: number) => index + 1,
        },

        {
            title: 'Name',
            dataIndex: 'department_name',
            key: 'department_name',
        },
        {
            title: 'description',
            render: (value: any) =>
                <>
                    <p>{value?.description}</p>
                </>
        },
        {
            title: 'Action',
            key: 'action',
            render: (record: any) => (
                <Space size='large'>
                    {
                        check_button_permission("Department", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="employee-details_edit"
                            />
                            :<></>
                    }

                    {
                        check_button_permission("Department", "delete")
                            ?
                                <Popconfirm
                                    title="Delete the task"
                                    description="Are you sure to delete this task?"
                                    okText="Yes"
                                    cancelText="No"
                                    onConfirm={() => handleDelete(record)}
                                >
                                    <DeleteOutlined className="employee-details_delete" />
                                </Popconfirm>
                                :<></>
                    }
                </Space>
            ),
        },
    ];
    return (
        <Compnaynav>
        <div className="employee-details">
            <div className="employee-details_head">
                <h2 className="employee-details_head-text">Department</h2>
                {
                        check_button_permission("Department", "create")
                            ?
                            <Button className="employee-details_head-create" onClick={() => setOpen("Create")}>+ Add New Department</Button>
                            :<></>
                }
            </div>
            <Table columns={filteredColumns(columns,"Department")} dataSource={user} pagination={false} className="employee-details_table" />

            <Drawer title={`${open} Department`} width={570} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false} className="employee-details_drawer">
                {
                    open == "Edit" ? (<CreateEmp ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                }
                {
                    open == "Create" ? (<CreateEmp ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                }
            </Drawer>
        </div>
        <Modal
                open={Popopen}
                title=""
                onOk={handleOk}
                onCancel={handleCancel}
                footer={[
                    <div style={{ display: "flex", justifyContent: "center" }}>
                        <Button
                            key="submit"
                            type="primary"
                            loading={userLoading}
                            onClick={handleOk}
                            style={{
                                display: "flex",
                                width: "206px",
                                padding: "15px 30px",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "10px",
                                borderRadius: "8px",
                                background: "#252947",
                            }}>
                            OK
                        </Button>
                    </div>,
                ]}
                width={"386px"}>
                <Space
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                    }}>
                    <Image
                        src={PopImage}
                        alt="image"
                        style={{
                            width: "150px",
                            height: "150px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    />
                    <p
                        style={{
                            color: "#101010",
                            textAlign: "center",
                            fontFamily: "revert",
                            fontSize: "32px",
                            fontStyle: "normal",
                            fontWeight: "700",
                            lineHeight: "normal",
                        }}>
                        {`${title}`} Successfully
                    </p>
                </Space>
            </Modal>
        </Compnaynav>
    )
}

export default Department
