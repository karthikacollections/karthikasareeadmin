import { CREATE_DEPARTMENT, GET_DEPARTMENT, UPDATE_DEPARTMENT } from '@/helpers';
import { useMutation, useQuery } from '@apollo/client';
import { Form, Modal, Input, Button, Popconfirm, Select, Space, DatePickerProps, Drawer, DatePicker, message, Upload } from 'antd';

import React, { useEffect, useRef } from 'react'

const createDep: React.FC<any> = ({ ModalClose, editdraw, showModal}) => {
  const formRef = useRef(null);
  const [form] = Form.useForm();
  useEffect(() => {
    if (editdraw) {
      let data = JSON.parse(JSON.stringify(editdraw))
      form.setFieldsValue(data)
    }
  }, [editdraw])

  const [
    updateEmployee,
    { loading: updateloading, error: updateerror, data: updatedataAddress },
  ] = useMutation(UPDATE_DEPARTMENT, {
    errorPolicy: "all",
  });
  const [createEmployee, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_DEPARTMENT, {
    errorPolicy: 'all',
  });

  const {
    error: userError,
    loading: userLoading,
    data: dataUser,
    refetch: refetEmployDetails,
  } = useQuery(GET_DEPARTMENT, {
    variables: {},
  });

  useEffect(() => {
    if (dataUser) {
      let user = dataUser?.mst_department
      // setUser(user)
    }
  }, [dataUser])


  const onFinish = async (values: any) => {

    if (editdraw) {
      values.id = editdraw?.id
      updateEmployee({
        variables: values,
      }).then((response) => {
       
        showModal("Updated")
        refetEmployDetails()
        ModalClose(null)
      });

    }
    else {
      createEmployee({ variables: values, }).then((response: any) => {
        showModal("Created")
        
        refetEmployDetails();
        ModalClose(null)
      }).catch((err) => {
        
        message.error(`Hasura Signup Failed`);
      });

    }
  }

  const onFinishFailed = (errorInfo: any) => {
  };


  return (
    <div>
      <Form
        name="basic"
        initialValues={{ remember: true }}
        layout="vertical"
        onFinish={onFinish}
        ref={formRef}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        form={form}
        className="employee-details_form"
      >
        <Form.Item
          label="Department Name"
          name="department_name"
          required={false}
          rules={[{ required: true, message: 'Please enter Department Name' }]}
          className="employee-details_form_item"
        >
          <Input className="employee-details_form_item-input" />
        </Form.Item>

        <Form.Item label="Description" name="description" required={false} rules={[{ required: true, message: 'Please enter Description' }]} className="employee-details_form_item">
          <Input className="employee-details_form_item-input" />
        </Form.Item>

        <Form.Item >
          <div className="employee-details_submit">
            <Space>
              <Button htmlType="button" className="employee-details_cancel-btn" onClick={() => ModalClose(null)}>
                Cancel
              </Button>
              <Button htmlType="submit" className="employee-details_submit-btn">
                Submit
              </Button>
            </Space>

          </div>
        </Form.Item>



      </Form>    </div >
  )
}

export default createDep
