import React, { ReactNode } from 'react';
import Compnaynav from '../../components/Side_Nav/Companynav';
import withApollo from '../../config'

type CompanyLayoutProps = {
  children: ReactNode;
};

const CompanyLayout: React.FC<CompanyLayoutProps> = ({ children }) => {
  return (
    <div className='setting_nav'>
      {/* <div>
        <Compnaynav />
      </div> */}
      <div className='settings_style'>
        {children}
      </div>
    </div>
  );
};

export default CompanyLayout
