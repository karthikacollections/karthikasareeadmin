import { ColorInput } from '@mantine/core'
import { Button, DatePicker, DatePickerProps, Drawer, Popconfirm, Space, Table, Modal } from 'antd'
import React, { useEffect, useState } from 'react'
import withApollo from '../../../config'
import { useMutation, useQuery } from '@apollo/client'
import { DELETE_ORGANIZATION,GET_ORGANIZATION } from '@/helpers'
import moment from 'moment'
import CreateOrg from './createOrg'
import { DeleteOutlined, EditOutlined } from '@ant-design/icons'
import Compnaynav from "../company"
import {useAuth} from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";


export const Organization: React.FC<any> = ({ urlList }) => {
    const [user, setUser] = useState([]);
    const [open, setOpen] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("")
    const { check_button_permission,filteredColumns } = useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");


    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
      };
      
      const handleOk = () => {
        refetEmployDetails();
        setPopOpen(false);
      };
    
      const handleCancel = () => {
        setPopOpen(false);
      };

      
    const ModalClose = () => {
        setOpen(false)
    }
    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
    }

    const [deleteEmployee, { loading, error, data }] = useMutation(DELETE_ORGANIZATION);
    const handleDelete = (req: any) => {

        deleteEmployee({
            variables: req,
            update: (cache: any) => {
                showModal("Deleted");
                refetEmployDetails()
            },
        });
    };

    const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetEmployDetails,
    } = useQuery(GET_ORGANIZATION, {
        variables: {},
    });


    useEffect(() => {
        if (dataUser) {
            let user = dataUser?.mst_organization
            setUser(user)
        }
    }, [dataUser])


    const columns = [
        {
            title: 'S.No',
            dataIndex: 'sno',
            key: 'sno',
            render: (text: any, record: any, index: number) => index + 1,
        },

        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: 'Description',
            dataIndex: 'description',
            key: 'description',
        },
        {
            title: 'Latitude',
            dataIndex: 'latitude',
            key: 'latitude',
        },
        {
            title: 'Longitude',
            dataIndex: 'longitude',
            key: 'longitude',
        },
        {
            title: 'Action',
            key: 'action',
            render: (record: any) => (
                <Space size='large'>
                    {
                        check_button_permission("Organization", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="employee-details_edit"
                            />:<></>
                    }

                    {
                        check_button_permission("Organization", "delete")
                            ?
                            <Popconfirm
                                title="Delete the task"
                                description="Are you sure to delete this task?"
                                okText="Yes"
                                cancelText="No"
                                onConfirm={() => handleDelete(record)}
                            >
                                <DeleteOutlined className="employee-details_delete" />
                            </Popconfirm>
                            :<></>
                    }
                </Space>
            ),
        },
    ];
    return (
        <Compnaynav>
        <div className="employee-details">
            <div className="employee-details_head">
                <h2 className="employee-details_head-text">Organization</h2>
                {
                        check_button_permission("Organization", "create")
                            ?
                        <Button className="employee-details_head-create" onClick={() => setOpen("Create")}>+ Add New Organization</Button>
                        :<></>
                }
            </div>
            <Table columns={filteredColumns(columns,"Organization")} dataSource={user} pagination={false} className="employee-details_table" />

            <Drawer title={`${open} Organization`} width={570} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false} className="employee-details_drawer">
                {
                    open == "Edit" ? (<CreateOrg ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                }
                {
                    open == "Create" ? (<CreateOrg ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                }
            </Drawer>
        </div>
        <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{display: "flex", justifyContent: "center"}}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
        </Compnaynav>
    )
}

export default Organization
