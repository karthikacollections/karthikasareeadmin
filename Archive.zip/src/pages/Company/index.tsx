import React, { ReactNode } from 'react';
import EmployeeNav from '../../components/Side_Nav/Employeenav';
import CompanyLayout from './company';

import withApollo from '../../config'



const CompanyPage: React.FC = () => {
  return (
    <CompanyLayout>
      {/* <h1>Settings Page</h1> */}
      {/* Add your Settings page content here */}
    </CompanyLayout>
  );
};

export default CompanyPage;

 