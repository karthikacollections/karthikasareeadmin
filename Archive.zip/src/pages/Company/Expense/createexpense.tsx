import React, { useRef, useEffect, useState } from 'react'
import dayjs from "dayjs";
import moment from 'moment';
import { Form, Modal, Input, Button, Popconfirm, Select, Space, DatePickerProps, Drawer, DatePicker, message, Upload } from 'antd';
import { UPDATE_EXPENSE, CREATE_EXPENSE } from '../../../helpers/mutation';
import { GET_EXPENSE } from '../../../helpers/queries';
import { useMutation, useQuery } from "@apollo/client";

const createexpense: React.FC<any> = ({ ModalClose, editdraw, showModal}) => {

    const [form] = Form.useForm();
    const formRef = useRef(null);
    const [date, setEdate] = useState(null)
    const [editforminitaldata, seteditforminitaldata]: any = useState(false);
    const [formtype, setformtype] = useState("create")
    const onChangedoe: DatePickerProps["onChange"] = (dateString: any) => {
        setEdate(dateString);
    };



    
    const [createExpense, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_EXPENSE, {
        errorPolicy: 'all',
    });

    const [
        updateExpense,
        { loading: updateloading, error: updateerror, data: updatedataAddress },
    ] = useMutation(UPDATE_EXPENSE, {
        errorPolicy: "all",
    });

    const {
        error: userError,
        loading: userLoading,
        data: dataExpense,
        refetch: refetExpense,
    } = useQuery(GET_EXPENSE
        , {
            variables: {},
        });

    const onFinish = (values: any) => {
        
        if (editdraw) {
            values.id = editdraw?.id
            updateExpense({
                variables: values,
            }).then((response) => {
                refetExpense()
                showModal("Updated");
                ModalClose(null)
                // setOpen(false)
            });
        }
        else {
            createExpense({
                variables: values,
            }).then((response) => {
                ModalClose(null)
                refetExpense()
                showModal("Created");
            });
        };
    }
    useEffect(() => {
        if (editdraw) {
            let data = JSON.parse(JSON.stringify(editdraw))
            data.date = dayjs(editdraw.date)
            data.dor = dayjs(editdraw.dor)
            data.date = dayjs(editdraw.date)
            // setUrlList(data?.image?.split(','));
            form.setFieldsValue(data)
            setformtype("edit")
            seteditforminitaldata(data)
        }
    }, [editdraw])

    const onFinishFailed = (errorInfo: any) => {
    };

    return (
        <>
            <Form
                name="basic"
                initialValues={{ remember: true }}
                layout="vertical"
                onFinish={onFinish}
                ref={formRef}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                // onValuesChange={handleValuesChange}
                className="employee-details_form"
            >

                <Form.Item
                    label="Date"
                    name="date"
                    required={false}
                    rules={[{ required: true, message: 'Please select date' }]}
                    className="employee-details_form_item"
                >
                    <DatePicker className="employee-details_form-datepic" onChange={onChangedoe} />
                </Form.Item>

                <Form.Item
                    label="Reason"
                    name="reason"
                    required={false}
                    rules={[{ required: true, message: 'Please enter reason' }]}
                    className="employee-details_form_item"
                >
                    <Input className="employee-details_form_item-input" />
                </Form.Item>

               

                <Form.Item
                    label="Expense"
                    name="expense"
                    required={false}
                    rules={[{ required: true, message: 'Please enter expense' }]}
                    className="employee-details_form_item"
                >
                    <Input className="employee-details_form_item-input" />
                </Form.Item>


                <Form.Item >
                    <div className="employee-details_submit">
                        <Space>
                            <Button htmlType="button" className="employee-details_cancel-btn" onClick={() => ModalClose(null)}>
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="employee-details_submit-btn">
                                Submit
                            </Button>
                        </Space>

                    </div>
                </Form.Item>
            </Form>
        </>
    )
}

export default createexpense