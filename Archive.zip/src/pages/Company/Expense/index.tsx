
import withApollo from '../../../config'
import React, { useEffect, useState, useRef } from 'react';
import { Space, Table, Button, Form, Popconfirm, Drawer, DatePicker,Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useQuery, useMutation } from "@apollo/client";
import moment from "moment";
import { GET_EXPENSE } from '../../../helpers/queries'
import CreateExpense from "./createexpense";
import { CloseCircleOutlined, DeleteOutlined, EditOutlined } from '@ant-design/icons';
import { UPDATE_DELETE_EXPENSE } from '../../../helpers/mutation'
import Compnaynav from "../company"
import {useAuth} from '../../../components/auth'
import type { DatePickerProps } from 'antd';
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";


interface DataType {
    // expense: any;
    // key: string;
    // reason: string;
    // date: string;
    // income: string;
}

export const Expense: React.FC<any> = () => {


    const [expense, setExpense] = useState([])

    const [editdraw, setEditdraw] = useState("")
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");
    const [open, setOpen] = useState<any>(null);
    const [filterData, setFilterData] = useState(false)
    const [filterPayroll, setFilterPayroll] = useState([])

    const { check_button_permission,filteredColumns } = useAuth()

    const ModalClose = () => {
        setOpen(false)
        // refetExpense()
    }

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
    }

  
    

    const {
        error: userError,
        loading: userLoading,
        data: dataExpense,
        refetch: refectExpence,
    } = useQuery(GET_EXPENSE, {
        variables: {},
    });

    const [deleteExpense, { loading, error, data }] = useMutation(UPDATE_DELETE_EXPENSE, {
        errorPolicy: "all",
    });

    useEffect(() => {
        if (dataExpense) {
            let expense = dataExpense?.mst_expense?.filter((Param: any) => !Param?.isdeleteat)
            setExpense(expense)
        }
    },[dataExpense])

    const handleDelete = (param: any) => {
        let deleteValue = {id:'',isdeleteat:true}
        deleteValue.id=param.id
        
        deleteExpense({variables:deleteValue}).then((res:any)=>{
            showModal("Delete")
            refectExpence()
        })
    }

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
      };
      
      const handleOk = () => {
        refectExpence();
        setPopOpen(false);
      };
    
      const handleCancel = () => {
        setPopOpen(false);
      };

    const columns: ColumnsType<DataType> = [
        {
            title: 'S.No',
            dataIndex: 'sno',
            key: 'sno',
            render: (text, record, index) => index + 1,
        },
        {

            title: 'Date',
            render: (value) => {
                let dateFormat = moment(value?.date).format("DD MMMM YYYY");
                return (
                    <>
                        <p>{dateFormat}</p>
                    </>
                )
            }
        },
        {
            title: 'Reason',
            render: (value) => {
                return (
                    <>
                        <p>{value?.reason}</p>
                    </>
                )
            }
        },

        {
            title: 'Expense',
            render: (value) => {
                return (
                    <>
                        <p>{value?.expense ? value?.expense : "--"}</p>
                    </>
                )
            }
        },
        {
            title: 'Action',
            key: 'action',
            render: (
                record: any) => (
                <Space size='large'>
                    {
                        check_button_permission("Expense", "edit")
                            ?
                        <EditOutlined
                            onClick={() => handleChange(record)}
                            className="assets_edit"
                        />:<></>
                    }       

                    {
                        check_button_permission("Expense", "delete")
                            ?
                            <Popconfirm
                                title="Delete the task"
                                description="Are you sure to delete this task?"
                                okText="Yes"
                                onConfirm={() => handleDelete(record)}
                                cancelText="No"
                            >
                                <DeleteOutlined className="assets_delete" />
                            </Popconfirm>
                    :<></>
                    }

                </Space>
            ),
        },
    ]

    const onChange: DatePickerProps['onChange'] = (date, dateString) => {
        setFilterData(true)
        const filterPayroll = expense.filter((val: any) => moment(val?.date).format("MMMM YYYY") === moment(dateString).format("MMMM YYYY"));
        setFilterPayroll(filterPayroll)
        if(date===null){
            setFilterData(false)
        }
      
    };
    
    const handleDateClear=()=>{
        setFilterData(false)
        setFilterPayroll(expense)
        refectExpence()
    }


    return (
        <Compnaynav>
            <div className="attendance">
                <div className="attendance_head">
                    <h2 className="attendance_head-text">Expense</h2>
                    <div className="expense_action">
                    <DatePicker
                        className="payroll_head-create"
                        onChange={onChange}
                        picker="month" />
                    {
                        check_button_permission("Expense", "create")
                            ?
                            <Button className="attendance_head-create"
                                onClick={() => setOpen("Create")}
                            >
                                Add New</Button>
                                :<></>
                    }
                    </div>

                </div>
                {filterData ? <Table columns={filteredColumns(columns,"Expense")} dataSource={filterPayroll}  pagination={false} className="attendance_table" />:
                                <Table columns={filteredColumns(columns,"Expense")} dataSource={expense} pagination={false} className="attendance_table" />}

                <Drawer
                    title=
                    {`${open} Expense`}
                    width={570} placement="right"
                    onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}
                >
                    {
                        open == "Edit" ? (<CreateExpense ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        open == "Create" ? (<CreateExpense ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                    }
                </Drawer>
            </div>
            <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{display: "flex", justifyContent: "center"}}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
        </Compnaynav>
    )
}

export default Expense