import React from 'react'; 
import CompanyLayout from './company';

const HistoryPage = () => {
  return (
    <CompanyLayout>
      {/* <h1>History Page</h1> */}
      {/* Add your History page content here */}
    </CompanyLayout>
  );
};

export default HistoryPage;