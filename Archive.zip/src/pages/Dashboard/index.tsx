import React, { useEffect, useState } from 'react';
import { useQuery } from "@apollo/client";
import { GET_ANNOUNCEMENT } from '../../helpers/queries'
import { Table, Card } from 'antd';
import { Checkin } from '@/components/dashboardwidget/checkin';
import HolidayWidget from '@/components/dashboardwidget/holidayWidget';
import AnnounementWidget from '@/components/dashboardwidget/announcement';
import Leavewidget from '@/components/dashboardwidget/onLeaveToday';
import DobAnnounementWidget from '@/components/dashboardwidget/dobAnnouncement';
import ProgressWidget from '@/components/dashboardwidget/checkInOut';
import PresenceWidget from '@/components/dashboardwidget/presence';
import LeaveWidget from '@/components/dashboardwidget/leavewidget';
import { useAuth } from '@/components/auth';
import WelcomeWidget from '@/components/dashboardwidget/welcomewidget';

export const Dashboard: React.FC<any> = () => {

  const { data: announceData } = useQuery(GET_ANNOUNCEMENT)
  const [filteredData, setFilteredData] = useState([]);
  const { user } = useAuth()


  useEffect(() => {
    const currentMonth = new Date().getMonth() + 1;
    const filteredAnnouncements = announceData?.mst_announcement.filter((item: any) => {
      const announcementMonth = new Date(item.date).getMonth() + 1;
      return announcementMonth === currentMonth;
    });
    setFilteredData(filteredAnnouncements);
  }, [announceData]);

  const dataSource = filteredData?.map((item: any) => ({
    key: item.id,
    date: item.date,
    id: item.id,
    message: item.message,
  }));


  return (
    <>

      <h1>Dashboard</h1>
      <div className="dashboard_attendance" style={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap', gap: '20px' }}>
        <div className='widgetsstyle'>
          <div>
            <WelcomeWidget />
          </div>
          {/* <div>
            <PresenceWidget />
          </div> */}
        </div>
        <Checkin />
        {user?.email !== "admin@gmail.com" && <ProgressWidget />}
        <AnnounementWidget />
        <HolidayWidget />
        {user?.email == "admin@gmail.com" && <Leavewidget />}
        <DobAnnounementWidget />
        {user?.email !== "admin@gmail.com" && <LeaveWidget />}

      </div>
    </>
  );
};

export default Dashboard


