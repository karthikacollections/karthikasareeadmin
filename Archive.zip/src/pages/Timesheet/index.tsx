import React, { useEffect, useState } from "react";
import { useLazyQuery, useMutation, useQuery } from "@apollo/client";
import { Table, Select, DatePicker, Button, Modal, Space, Image, Row, Col, message ,Popconfirm } from "antd";
import { GET_EMPLOYDETAILS, GET_EMPLOYDETAILS_DOB, GET_PROJECT, GET_WORK_TIMESHEET, GET_WORK_TIMESHEET_USER } from "@/helpers/queries";
import { useAuth } from "../../components/auth";
import CreateTimesheet from "./createTimeSheet";
import moment from "moment";
import EditTimesheet from "./editTimeSheet";
import { EditOutlined ,DeleteOutlined } from "@ant-design/icons";
import { INSERT_WEEKDATA_TIMESHEET, UPDATE_WORK_TIMESHEET_STATES } from "@/helpers/mutation";
import { DELETE_TIME_SHEET } from '@/helpers'
import PopImage from "../../assets/photos/tick-circle.jpg";
import { log } from "console";

const { Option } = Select;

const Timesheet: React.FC = () => {
  const { check_button_permission, userInEmploye, user } = useAuth();
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [timeSheet, setTimeSheet] = useState<any>([]); //timeSheet Data
  const [timeSheetID, setTimeSheetID] = useState<any>(null)
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [modalTimeView, setModalTimeView] = useState<boolean>(false);
  const [modalTimeViewData, setModalTimeViewData] = useState<any>([])
  const [modalTimeEditView, setModalTimeEditView] = useState<boolean>(false);
  const [modalTimeEditData, setModalTimeEditData] = useState<any>([])
  const [total, setTotal] = useState<number>(0)
  const [selectWeekDate, setSelectWeekDate] = useState<any>([])
  const [modifyWeekDate, setModifyWeekDate] = useState<any>(null)
  const [selectModifyWeekDate, setSelectModifyWeekDate] = useState<any>([])
  const [reloadCreateTimesheet, setReloadCreateTimesheet] = useState(false);
  const [count, setCount] = useState<any>([]);
  const [approveData, setApproveData] = useState<any>([])
  const [monthSelector, setMonthSelector] = useState<any>(null)
  const [weekDates, setWeekDates] = useState<any>([])
  const [selectedValue, setSelectedValue] = useState("");

  const { loading, error, data, refetch } = useQuery(GET_WORK_TIMESHEET, {
    variables: {},
  });

  const { loading: userLoading, error: userError, data: userData, refetch: userRefetch } = useQuery(GET_WORK_TIMESHEET_USER, {
    variables: { employee: userInEmploye?.mst_employeedetails[0]?.id },
  });

  const [updateEmployee, { loading: updateloading, error: updateError, data: updateData }] = useMutation(UPDATE_WORK_TIMESHEET_STATES,
    {
      errorPolicy: "all",
    }
  );

  const [insertWeekDataTimesheet] = useMutation(INSERT_WEEKDATA_TIMESHEET);

  const {
    error: countError,
    loading: countLoading,
    data: dataCount,
    refetch: refetchProject,
  } = useQuery(GET_PROJECT, {
    variables: {},
  });

  const { loading: loadingUser, error: Error, data: dataUser, refetch: refetEmp } = useQuery(GET_EMPLOYDETAILS_DOB);
  const [deleteEmployee, { loading: timeLoading, error :errorTimeSheet, data :dataDelete, }] = useMutation(DELETE_TIME_SHEET);

  const handleDelete =(value :any)=>{
    console.log(value.id);
    
    deleteEmployee({
      variables: value
      
  });
  refetch()

}


let empData = [...(dataUser?.mst_employeedetails || [])]
  let sort = empData?.sort((a: any, b: any) => a?.name.localeCompare(b?.name));
  let FliterEmpData = sort.filter((val)=>{
    return val.status ===true

  }) 

  
  // console.log(modalTimeViewData ,"modalTimeViewData");

  useEffect(() => {
    if (data) {
      let timeSheetList = data?.mst_work_timesheet;
      let timeSheetSort = timeSheetSorting(timeSheetList)
      setTimeSheet(timeSheetSort);
    }
  }, [data]);

  useEffect(() => {
    getWeeksInMonth()
  }, [])

  useEffect(() => {
    if (dataCount) {
      let count = dataCount?.mst_project;
      setCount(count);
    }
  }, [dataCount]);


 const onChangeModifyWeekDate = (value: any) => {
    setModifyWeekDate(value)
  }
  const ModalClose = (param: any) => {
    setIsModalVisible(false);
    if (user?.email === "admin@gmail.com") {
      refetch()
      setModifyWeekDate(null)
      setReloadCreateTimesheet(prevState => !prevState);
    } else {
      userRefetch()
      setModifyWeekDate(null)
      setReloadCreateTimesheet(prevState => !prevState);
    }

    if (typeof param === "string") {
      setPopOpen(true)
      setTitle(param)
    }
  };

  const ModalEditViewClose = (param: any) => {
    setModalTimeEditData([])
    setModalTimeEditView(false)
    if (user?.email === "admin@gmail.com") {
      refetch()
    } else {
      userRefetch()
    }

    if (typeof param === "string") {
      setPopOpen(true)
      setTitle(param)
    }
  };

  const handleEditModalClose = () => {
    setModalTimeEditData([])
    setModalTimeEditView(false)
    setReloadCreateTimesheet(prevState => !prevState);
  }

  const ModalViewClose = () => {
    setModalTimeViewData([])
    setModalTimeView(!modalTimeView)
  }

  const ModalViewOpen = (record: any) => {
    console.log(record ,"record");
     approveDataStructure(record)
    setModalTimeViewData(record)
    setTimeSheetID(record)
    setModalTimeView(true)
    totalHoursCount(record?.timesheet)
    let weekStartDate: any = moment(record?.startDate).format('DD-MM-YYYY')
    console.log(weekStartDate ,"weekStartDate");
    const [day, month, year] = weekStartDate.split('-');
    const dateObject = new Date(year, month - 1, day);
    const timestamp = dateObject.getTime();
    const currentDate = new Date(timestamp)
    const weekDate = getWeekdayTimestamps(currentDate);
    setWeekDates(weekDate)
  }

  const handleEdit = (record: any) => {
    setModalTimeEditData(record)
    setModalTimeEditView(true)
  }

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleOk = () => {
    setPopOpen(false);
  };

  const handleCancel = () => {
    setPopOpen(false);
  };

  const handleDatePicker = (date: any, dateString: any) => {
    setMonthSelector(dateString)
  }


  const handleSelectChange = (value: any) => {
    setSelectedValue(value);
  };

  const getWeekdayTimestamps = (date: Date): number[] => {
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1); // Adjust to Monday if the current day is Sunday
    const startDate = new Date(date.setDate(diff));

    const timestamps: number[] = [];

    // Calculate timestamps for each day of the week
    for (let i = 0; i < 7; i++) {
      const currentDay = new Date(startDate);
      currentDay.setDate(startDate.getDate() + i);
      timestamps.push(currentDay.getTime());
    }

    return timestamps;
  };


  const getWeeksInMonth = () => {
    let currentYear = Number(moment().format('YYYY'));
    let currentMonth = Number(moment().format('M'));

    const weeks: { startDate: string, endDate: string }[] = [];

    // Iterate through current month's 4 weeks
    for (let weekNumber = 1; weekNumber <= 4; weekNumber++) {
      const firstDayOfMonth = new Date(currentYear, currentMonth - 1, 1);

      // Calculate the first day of the current week
      const firstDayOfWeek = new Date(
        firstDayOfMonth.getTime() +
        ((weekNumber - 1) * 7 - firstDayOfMonth.getDay() + 1) * 24 * 60 * 60 * 1000
      );

      // Calculate the last day of the current week
      const lastDayOfWeek = new Date(firstDayOfWeek.getTime() + 6 * 24 * 60 * 60 * 1000);

      // Store the results
      weeks.push({
        startDate: moment(firstDayOfWeek).format('DD-MM-YYYY'),
        endDate: moment(lastDayOfWeek).format('DD-MM-YYYY')
      });
    }

    // Iterate through next month's 2 weeks
    const nextMonth = currentMonth === 12 ? 1 : currentMonth + 1;
    const nextMonthYear = currentMonth === 12 ? currentYear + 1 : currentYear;

    for (let weekNumber = 1; weekNumber <= 2; weekNumber++) {
      const firstDayOfNextMonth = new Date(nextMonthYear, nextMonth - 1, 1);

      // Calculate the first day of the current week
      const firstDayOfWeek = new Date(
        firstDayOfNextMonth.getTime() +
        ((weekNumber - 1) * 7 - firstDayOfNextMonth.getDay() + 1) * 24 * 60 * 60 * 1000
      );

      // Calculate the last day of the current week
      const lastDayOfWeek = new Date(firstDayOfWeek.getTime() + 6 * 24 * 60 * 60 * 1000);

      // Store the results
      weeks.push({
        startDate: moment(firstDayOfWeek).format('DD-MM-YYYY'),
        endDate: moment(lastDayOfWeek).format('DD-MM-YYYY')
      });
    }

    // Assuming you want to store the date ranges in state
    setSelectModifyWeekDate([...weeks]);
  };

  const approveDataStructure = (record: any) => {
    const { timesheet, employee, id } = record
    let dataStructure = timesheet?.map((param: any, index: any) => {
      let arrayaData: any = []
      Object.values(param)?.map((paramItem: any) => {
        paramItem?.map((list: any) => {
          let date = new Date(list.date);
          let timestamp = date.toISOString()
          if (list?.hours > 0) {
            let dataArray = { ...list, project_name: Object.keys(param)[0], date: timestamp, employee_name: employee, timesheet: id }
            arrayaData?.push(dataArray)
          }
        }
        )

      }
      )
      return arrayaData
    })

    setApproveData(dataStructure?.flat())
  }

  const UpdateState = (record: any) => {

    let values = {
      id: record?.id,
      status: true
    }

    try {
      updateEmployee({
        variables: values
      })
      if (user?.email === "admin@gmail.com") {
        refetch()
      } else {
        userRefetch()
      }
      insertWeekDataTimesheet({
        variables: {
          objects: approveData
        },
      })
      ModalViewClose()
      setPopOpen(true)
      setTitle('Approved Successfully')
    }
    catch (err: any) {
      message.error(err)
    }
  }

  const filterTimeSheet = (timeSheetParam: any) => {
    let filterTime = timeSheetParam?.filter((param: any) => {
      let startDate = new Date(weekDates[0]);
      let endDate = new Date(weekDates[weekDates?.length - 1]);
      let timeStartDate = new Date(param?.startDate);
      let timeEndDate = new Date(param?.endDate);

      let startDateComponents = [startDate.getDate(), startDate.getMonth(), startDate.getFullYear()];
      let endDateComponents = [endDate.getDate(), endDate.getMonth(), endDate.getFullYear()];
      let timeStartDateComponents = [timeStartDate.getDate(), timeStartDate.getMonth(), timeStartDate.getFullYear()];
      let timeEndDateComponents = [timeEndDate.getDate(), timeEndDate.getMonth(), timeEndDate.getFullYear()];

      return (
        startDateComponents.join() === timeStartDateComponents.join() &&
        endDateComponents.join() === timeEndDateComponents.join()
      );
    });

    if (selectedValue) {
      return timeSheetParam.filter((u: any) =>
        u.mst_employee.name?.toLowerCase().includes(selectedValue?.toLowerCase()))
    } else if (monthSelector) {
      let month = moment(monthSelector).format('MMMM')
      let year = moment(monthSelector).format('YYYY')
      let filterLeaveData = timeSheetParam?.filter((param: any) => (moment(param?.startDate).format('YYYY') === year) && (moment(param?.startDate).format('MMMM') === month))
      return filterLeaveData
    } else if (user?.email === "admin@gmail.com") {
      return timeSheetParam
    }
    else {
      let timeSheetData = filterMonth(timeSheetParam)
      return timeSheetData;
    }
  };

  const totalHoursCount = (paramTime: any) => {

    let totalSum = paramTime?.map((param: any) => {
      let key: any = Object.keys(param)
      let sum = param[key]?.reduce((accumulator: any, currentValue: any) => accumulator + currentValue?.hours, 0)
      return sum
    })?.reduce((accumulator: any, currentValue: any) => accumulator + currentValue, 0)

    setTotal(totalSum)

  }


  // Filter the Month

  const filterMonth = (param: any) => {
    let date = new Date()
    let filterCurrentMonth = param?.filter((arr: any) => {
      let fromDate: any = new Date(arr?.startDate)
      let toDate: any = new Date(arr?.endDate)

      return fromDate.getMonth() === date.getMonth() || toDate.getMonth() === date.getMonth()
    })
    // let sortSheet = timeSheetSorting(filterCurrentMonth)

    return filterCurrentMonth
  }
  // Sorting the TimeSheet Data

  const timeSheetSorting = (param: any) => {
    let approvedArray: any = []
    let pendingArray: any = []
    let sortingArray: any = []
    for (let sheet of param) {
      if (sheet?.status === true) {
        approvedArray.push(sheet)
      } else {
        pendingArray.push(sheet)
      }
    }

    sortingArray = [...pendingArray, ...approvedArray]

    return sortingArray
  }

  const columns = [
    {
      title: "Name",
      render: (record: any) => <p>{record?.mst_employee?.name}</p>,
    },
    {
      title: "Designation",
      render: (record: any) => (
        <p>{record?.mst_employee?.mst_organization?.name}</p>
      ),
    },
    {
      title: 'View',
      key: 'View',
      render: (record: any) => {
        return (
          <div>
            <Button type="primary" onClick={() => ModalViewOpen(record)}>View</Button>
          </div>
        )
      }
    },
    {
      title: "Action",
      key: "action",
      render: (record: any) => (
        <Space size='large'>
                    {
                        check_button_permission("Timesheet", "edit")
                            ?
                            <EditOutlined
                            onClick={() => handleEdit(record)}
                            className="employee-details_edit"
                          />:<></>
                    }

                    {
                        check_button_permission("Timesheet", "delete")
                            ?
                            <Popconfirm
                                title="Delete the task"
                                description="Are you sure to delete this task?"
                                okText="Yes"
                                cancelText="No"
                                onConfirm={() => handleDelete(record)}
                            >
                                <DeleteOutlined className="employee-details_delete" />
                            </Popconfirm>
                            :<></>
                    }
                </Space>
      )
    },

    {
      title: "Status",
      key: "status",
      render: (record: any) => {
        return (
          <div>
            {user?.email === "admin@gmail.com" ?
              <p style={{ fontWeight: 'bold', color: !record?.status ? 'orange' : 'green' }}>{!record?.status ? 'Pending' : 'Approved'}</p>
              :
              <p style={{ fontWeight: 'bold', color: !record?.status ? 'orange' : 'green' }}>{!record?.status ? 'Pending' : 'Approved'}</p>
            }
          </div>
        )
      }
    },
  ];

  return (
    <div className="attendance">
      <div className="attendance_head">
        <h2 className="attendance_head-text">Timesheet</h2>
        <Row gutter={[40, 16]} >

          <Col span={8}>
            {user.email === "admin@gmail.com" &&
              <Select
                onChange={handleSelectChange}
                allowClear
                showSearch
                filterOption={(input, option: any) =>
                  option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
                placeholder={' Select Employee'}
                style={{ width: "210px" }}
              >

                {FliterEmpData?.map((emp: any, index: any) => {

                  return (
                    <Select.Option value={emp.name} key={index}>{emp?.name}</Select.Option>
                  )
                })}

              </Select>
            }

          </Col>

          <Col span={8}>
            <Select
              style={{ width: "210px" }}
              placeholder="Select an Week"
              value={modifyWeekDate}
              allowClear
              onChange={onChangeModifyWeekDate}>
              {selectModifyWeekDate?.map((weekData: any, index: any) =>
              (
                <Option key={index} value={weekData?.startDate}>
                  {`${weekData?.startDate} to ${weekData?.endDate}`}
                </Option>
              )
              )}
            </Select>

          </Col>

          <Col span={8}>
            <DatePicker onChange={handleDatePicker} picker="month" />
          </Col>

        </Row>

        {check_button_permission("Timesheet", "create") ? (
          <Button className="assets_head-create" onClick={showModal}>
            Create Timesheet
          </Button>
        ) : (
          <></>
        )}
      </div>
      {user?.email === "admin@gmail.com" ?
        <Table columns={columns} dataSource={filterTimeSheet(timeSheet)} />
        :
        <Table columns={columns} dataSource={filterTimeSheet(userData?.mst_work_timesheet)} />
      }

      <Modal
        title="Create Timesheet"
        open={isModalVisible}
        onCancel={ModalClose}
        closable={false}
        footer={null}
        width={1200}>
        <CreateTimesheet
          key={reloadCreateTimesheet}
          ModalClose={ModalClose}
          modifyDate={modifyWeekDate}
        />
      </Modal>

      <Modal
        title="Timesheet"
        open={modalTimeView}
        onCancel={ModalViewClose}
        footer={null}
        width={1200}>
        <Table
          columns={[
            {
              title: "Project",
              render: (record: any) => {
                let projects = count?.filter((param: any) => Object.keys(record)[0] === param?.id);

                // Map over the projects array and render the project names
                const projectNames = projects.map((project: any) => project.project_name);
                return (
                  <>
                    {projectNames}
                  </>
                )
              }
            },
            ...weekDates.map((date: any, columnIndex: any) => ({
              title: moment(date).format("ddd, DD MMM"),
              render: (text: any, record: any, rowIndex: any) => {
                let key: any = Object.keys(record)
                let hours = record[key][columnIndex]?.hours
                return (
                  <p>{hours}</p>
                )
              },
            })),
          ]}
          dataSource={modalTimeViewData?.timesheet}
        />
        <div style={{ display: 'flex' }}>
          <div style={{ width: '100%' }}>
            <p>Total Hours : {total}</p>
          </div>
          {user?.email === "admin@gmail.com"

            &&

            <div style={{ width: '100%', display: 'flex', justifyContent: 'flex-end', columnGap: '10px' }}>
              <Button type='primary' style={{ backgroundColor: 'red', width: '120px' }} onClick={ModalViewClose}>Cancel</Button>
              <Button type='primary' style={{ width: '120px' }} disabled={modalTimeViewData?.status ? true : false} onClick={() => UpdateState(timeSheetID)}>Approve</Button>
            </div>}
        </div>
      </Modal>

      <Modal
        title="Edit Timesheet"
        open={modalTimeEditView}
        onCancel={handleEditModalClose}
        closable={false}
        footer={null}
        width={1200}>
        <EditTimesheet
          key={reloadCreateTimesheet}
          ModalClose={ModalEditViewClose}
          editData={modalTimeEditData}
        />
      </Modal>

      <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{ display: "flex", justifyContent: "center" }}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage?.src}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "28px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`}
          </p>
        </Space>
      </Modal>
    </div>
  );
};

export default Timesheet;
