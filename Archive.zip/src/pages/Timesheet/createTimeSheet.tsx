import React, { useEffect, useState } from "react";
import { useMutation, useQuery } from "@apollo/client";
import {
  Table,
  Select,
  DatePicker,
  Button,
  Row,
  Col,
  Input,
  Space,
  message,
} from "antd";
import { GET_EMPLOYEE_TIMESHEET, GET_PROJECT } from "@/helpers/queries";
import { CREATE_WORK_TIMESHEET } from "@/helpers/mutation";
import moment from "moment";
import { useAuth } from "@/components/auth";

const { Option } = Select;

const CreateTimesheet: React.FC<any> = ({ ModalClose, modifyDate }) => {
  const { check_button_permission, userInEmploye, user } = useAuth();
  const [timeValue, setTimeValues] = useState<any>([]); //timeSheet
  let [timeValueDelete, setTimeValuesDelete] = useState<boolean>(true);
  const [userlist, setUser] = useState([]);
  const [selectedProjects, setSelectedProjects] = useState<string[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<string>(""); //employee
  const [count, setCount] = useState([]);
  const [totalCount, setTotalCount] = useState(0); //total_hours
  const [weekDates, setWeekDates] = useState<any>([])

  const { loading, error, data, refetch } = useQuery(GET_EMPLOYEE_TIMESHEET);
  const {
    error: countError,
    loading: countLoading,
    data: dataCount,
    refetch: refetchProject,
  } = useQuery(GET_PROJECT, {
    variables: {},
  });

  const [
    createTimeSheet,
    { loading: timeSheetLoading, error: timeSheetError, data: timeSheetData },
  ] = useMutation(CREATE_WORK_TIMESHEET, {
    errorPolicy: "all",
  });

  useEffect(() => {
    if (user?.email !== "admin@gmail.com") {
      setSelectedEmployee(userInEmploye?.mst_employeedetails[0]?.id)
    }

  }, [])

  useEffect(() => {
    if (data) {
  let userlist:[] = data?.mst_employeedetails
            let userlistFiltered = userlist.filter((data: any)=>{
               return data.status === true
            })
            let sort =userlistFiltered.sort((a:any,b:any)=>{
              return a.name.localeCompare(b.name)
            })
            setUser(sort)
    }
  }, [data]);

  useEffect(() => {
    if (dataCount) {
      let count = dataCount?.mst_project;
      setCount(count);
    }
  }, [dataCount]);

  useEffect(() => {
    totalHoursCount();
  }, [timeValue]);

  useEffect(() => {
    if (modifyDate !== null && modifyDate !== undefined) {
      const [day, month, year] = modifyDate.split('-');


      // Create a Date object with the parsed values (month is 0-indexed in JavaScript)
      const dateObject = new Date(year, month - 1, day);

      // Get the timestamp in milliseconds
      const timestamp = dateObject.getTime();
      const currentDate = new Date(timestamp)
      const weekDate = getWeekdayTimestamps(currentDate);
      setWeekDates(weekDate)
    } else {
      const currentDate = new Date(); // Use your desired date
      const weekDate = getWeekdayTimestamps(currentDate);
      setWeekDates(weekDate)
    }
  }, [selectedProjects])

  const getWeekdayTimestamps = (date: Date): number[] => {
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1); // Adjust to Monday if the current day is Sunday
    const startDate = new Date(date.setDate(diff));

    const timestamps: number[] = [];

    // Calculate timestamps for each day of the week
    for (let i = 0; i < 7; i++) {
      const currentDay = new Date(startDate);
      currentDay.setDate(startDate.getDate() + i);
      timestamps.push(currentDay.getTime());
    }

    return timestamps;
  };
  
  console.log(timeValue, 'fgfgh');


  const createProjectTimeLine = (projectName: any) => {

    if (projectName?.length > timeValue?.length) {
      let data = weekDates.map((weekDay: any, index: any) => ({
        date: weekDay,
        hours: 0,
      }));
      let newdata = [
        ...timeValue,
        { [projectName[projectName?.length - 1]]: data },
      ];
      setTimeValues(newdata);
    } else {
      const missingProjectIndices: any = [];
      for (let i = 0; i < projectName.length; i++) {
        const name = projectName[i];
        let found = false;
        for (let j = 0; j < data.length; j++) {
          if (data[j].hasOwnProperty(name)) {
            found = true;
            break;
          }
        }
        if (!found) {
          missingProjectIndices.push(i);
        }
      }

      let timeFilter: any = []
      missingProjectIndices?.map((param: any, index: any) => {
        let filter = timeValue?.filter(
          (time: any, timeIndex: any) => index === timeIndex
        );

        timeFilter.push(...filter)

      });

      setTimeValues(timeFilter);
    }
  };

  const handleSelectChangeProject = (values: string[]) => {
    setSelectedProjects(values);

    createProjectTimeLine(values);
  };

  const handleSelectChangeEmployee = (value: any) => {
    setSelectedEmployee(value);
  };

  const OnSubmit = () => {
    let startDate = new Date(weekDates[0]);
    let endDate = new Date(weekDates[weekDates?.length - 1]);
    let submitValue = {
      employee: selectedEmployee,
      timesheet: timeValue,
      startDate,
      endDate,
    };

    if (timeValue.length > 0 && selectedEmployee?.length > 0) {
      createTimeSheet({ variables: submitValue })
        .then((res: any) => {
          refetchProject();
          refetch();
          ModalClose('Create Successfully');
          setTimeValues([]);
          setTotalCount(0);
          setSelectedProjects([]);
          setSelectedEmployee("");
        })
        .catch((error: any) => {
        });
    } else {
      message.error('Cheak the filed')
    }
  };

  const handleInputValueChange = (
    value: any,
    data: any,
    rowIndex: any,
    columnIndex: any) => {

       if (value === "" || isNaN(value)) {
      setTimeValues((prevData: any) => {
        return prevData.map((row: any, index: any) => {
          if (index === rowIndex && row[data?.project_name]) {
            return {
              ...row,
              [data?.project_name]: row[data?.project_name].map(
                (entry: any, entryIndex: any) => {
                  if (entryIndex === columnIndex) {
                    return {
                      ...entry,
                      hours: 0,
                    };
                  }
                  return entry;
                }
              ),
            };
          }
          console.log(row)
          return row;
        });
      });
    } else {
      setTimeValues((prevData: any) => {
        return prevData.map((row: any, index: any) => {
          if (index === rowIndex && row[data?.project_name]) {
            return {
              ...row,
              [data?.project_name]: row[data?.project_name].map(
                (entry: any, entryIndex: any) => {
                  if (entryIndex === columnIndex) {
                    return {
                      ...entry,
                      hours: parseInt(value),
                    };
                  }
                  return entry;
                }
              ),
            };
          }
          return row;
        });
      });
    }
  };

  const totalHoursCount = () => {

    let totalSum = timeValue
      ?.map((param: any) => {
        let key: any = Object.keys(param);
        let sum = param[key]?.reduce(
          (accumulator: any, currentValue: any) =>
            accumulator + currentValue?.hours,
          0
        );
        return sum;
      })
      ?.reduce(
        (accumulator: any, currentValue: any) => accumulator + currentValue,
        0
      );

    setTotalCount(totalSum);
  };

  const handleClose = () => {
    ModalClose();
    setTimeValues([]);
    setTotalCount(0);
    setSelectedProjects([]);
    setSelectedEmployee("");
  };

  return (
    <>
      <Row gutter={16}>
        <Col span={12}>
          <Select
            style={{ width: "70%" }}
            placeholder="Select an Employee"
            value={selectedEmployee}
            disabled={user?.email !== "admin@gmail.com" ? true : false}
            onChange={handleSelectChangeEmployee}>
            {userlist.map((user: any) => 
            (
           
              <Option key={user.id} value={user.id}>
                {user.name}
              </Option>
            ))}
          </Select>
        </Col>
        <Col span={12}>
          <Select
            style={{ width: "70%" }}
            mode="multiple"
            showArrow={true} 
            placeholder="Select Project"
            value={selectedProjects}
            onChange={handleSelectChangeProject}
          >
            {count.map((project: any) => (
              <Select.Option key={project.id} value={project.id}>
                {project.project_name}
              </Select.Option>
            ))}
          </Select>
        </Col>
      </Row>
      {selectedProjects.length > 0 && (
        <div>
          <h2>Projects</h2>
          <Table
            columns={[
              {
                title: "Project",
                render: (record: any) => {
                  let projects = count?.filter((param: any) => record?.project_name === param?.id);

                  // Map over the projects array and render the project names
                  const projectNames = projects.map((project: any) => project.project_name);

                  return (
                    <p>{projectNames}</p>
                  )
                }
              },
              ...weekDates.map((date: any, columnIndex: any) => ({
                title: moment(date).format("ddd, DD MMM"),
                dataIndex: `input_${columnIndex}`,
                render: (text: any, record: any, rowIndex: any) => {
                  return (
                    <Input
                      style={{ width: "70%" }}
                      onChange={(e) =>
                        handleInputValueChange(
                          e.target.value,
                          record,
                          rowIndex,
                          columnIndex
                        )
                      }
                    />
                  );
                },
              })),
            ]}
            dataSource={selectedProjects.map((selectedProject) => ({
              project_name: selectedProject,
            }))}
          />
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}>
            <p>Total Hours : {totalCount}</p>
            <Space>
              <Button
                htmlType="button"
                className="employee-details_cancel-btn"
                onClick={handleClose}>
                Cancel
              </Button>
              <Button
                htmlType="submit"
                className="employee-details_submit-btn"
                onClick={OnSubmit}>
                Submit
              </Button>
            </Space>
          </div>
        </div>
      )}
    </>
  );
};

export default CreateTimesheet;
