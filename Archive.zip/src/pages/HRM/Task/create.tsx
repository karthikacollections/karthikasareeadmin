import React, { useState, useRef, useEffect } from "react";
import {
  Button,
  DatePicker,
  Form,
  Input,
  Space,
  message,
  Select,
  Row,
  DatePickerProps,
  Col,
} from "antd";
import { useMutation, useQuery } from "@apollo/client";
import {
  GETTASK,
  INSERT_MYTASK,
  UPDATE_MYTASK,
  GET_EMPLOYEE_TASK,
  GET_SPRINT_TASK
} from "@/helpers";
import moment from 'moment';

import dayjs from "dayjs";

const createTaskadd: React.FC<any> = ({ ModalClose, editdraw, showModal }) => {
  const [user, setUser] = useState([]);
  const [sprint ,setSprint] = useState([]);
  const formRef = useRef(null);
  const [form] = Form.useForm();
  const [title, setTitle] = useState("");
  const { TextArea } = Input;
  const [date, setEdate] = useState(null);
  const [datee, setAdate] = useState(null);
  const [editforminitaldata, seteditforminitaldata]: any = useState(false);
  const [formtype, setformtype] = useState("create")

  //start date
  const onChangedoe: DatePickerProps["onChange"] = (dateString: any) => {
    setEdate(dateString);
  };
  //Target Date
  const onChangedoa: DatePickerProps["onChange"] = (dateString: any) => {
    setAdate(dateString);
  };
  const [isAssigneeLinkClicked, setIsAssigneeLinkClicked] = useState("");

  const handleAssigneeLinkClick = () => {
    if (isAssigneeLinkClicked === 'Admin') {
      setIsAssigneeLinkClicked("");
    } else {
      setIsAssigneeLinkClicked('Admin');
    }
  }


  // to get employee name in drop down
  //use query
  const {
    error: userError,
    loading: userLoading,
    data: userData,
    refetch: dataRefetcg,
  } = useQuery(GET_EMPLOYEE_TASK);

  //use Effect

  useEffect(() => {
    if (userData) {
      let add = userData?.mst_employeedetails;
      setUser(add);
    }
  }, [userData]);
// ----------------------------------------------------
// to get Sprint Name in dropdown
 //use query
 const {
  error: sprintError,
  loading: sprintLoading,
  data: sprintData,
  refetch: dataRefethg,
} = useQuery(GET_SPRINT_TASK);

//use Effect

useEffect(() => {
  if (sprintData) {
    let add = sprintData?.mst_sprints;
    setSprint(add);
  }
}, [sprintData]);

//-----------------------------------------------
  //update
  const [
    updateTask,
    { loading: updateloade, error: updateError, data: updateData },
  ] = useMutation(UPDATE_MYTASK, {
    errorPolicy: "all",
  });

  //Get
  const {
    error,
    loading,
    data: announData,
    refetch: refetchTask,
  } = useQuery(GETTASK);

  //create
  const [
    createTask,
    { loading: AnnounceLoading, error: AnnounceError, data: AnnounceData,},
  ] = useMutation(INSERT_MYTASK, {
    errorPolicy: "all",
  });

  const onFinishFailed = (error: any) => {
  };

  useEffect(() => {
    if (editdraw) {
        let data = JSON.parse(JSON.stringify(editdraw))
        data.date = dayjs(editdraw.date)
        data.start_date = dayjs(editdraw.date)
        data.target_date = dayjs(editdraw.date)
        
        form.setFieldsValue(data)
        setformtype("edit")
        seteditforminitaldata(data)
    }
}, [editdraw])


  const onFinish = (value: any) => {
    const startDate = value.start_date;
  const targetDate = value.target_date;

  if (startDate && targetDate && targetDate < startDate) {
    message.error("Target Date should be greater than the Start Date");
    return; // Do not proceed with form submission
  }
    if (editdraw) {
      value.id = editdraw.id;
      updateTask({ variables: value })
        .then((res: any) => {
          showModal('Updated')
          ModalClose(null);
          refetchTask();
          message.success(`Update Task`);
        })
        .catch((error) => {
          message.error(error);
          message.error("Check the Fileds");
        });
    } else {
      createTask({ variables: value })
        .then((res: any) => {
          showModal('Created')
          ModalClose(null);
          refetchTask();
          
          message.success(`Add New Task`);
        })
        .catch((error) => {
          message.error("Check the Fileds");
        });
    }
    
  };
  
  
  return (
    <div>
      <Form
        name="basic"
        layout="vertical"
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        form={form}
        ref={formRef}
        className="assets_form"
      >
        <Form.Item
          label="Title"
          name="title"
          required={false}
          rules={[{ required: true, message: "Please enter Title" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>

        <Form.Item
          label="Issue Type"
          name="issue_type"
          required={false}
          rules={[{ required: true, message: "Please Enter Issue Type" }]}
          className="assets_form_item"
        >
          <Select className="assets_form_item-input">
            <Select.Option value="Bug">Bug</Select.Option>
            <Select.Option value="User Story">User Story</Select.Option>
            <Select.Option value="Task">Task</Select.Option>
          </Select>
        </Form.Item>
        <Form.Item
          label="Description"
          name="description"
          required={false}
          // rules={[{ required: true, message: "Please enter description" }]}
          className="assets_form_item"
        >
          <TextArea rows={4} className="assets_form_item-input" />
        </Form.Item>
        <Form.Item
          label="Assigned to"
          name="assignee_userid"
          required={false}
          rules={[{ required: true, message: "Please Enter Asignee Name!" }]}
          className="employee-details_form_item"
          
        >
          <Select className="employee-details_form_item-input"
           showSearch
           filterOption={(input, option: any) =>
             option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
           >
            {user.map((val: any) => {
              if(val.status === true){return (
                <Select.Option value={val.id} key={val.id}>
                  {val?.name}
                </Select.Option>
              );}
              
            })}
          </Select>
        </Form.Item>
        
        <Form.Item
          label="Reporter"
          name="reporter_userid"
          required={false}
          rules={[{ required: true, message: "Please Enter Reporter Name!" }]}
          className="employee-details_form_item" 
        >
          <Select className="employee-details_form_item-input"
    
          >
            {user.map((val: any) => {
              if(val.status === true){
                  return (
                <Select.Option value={val.id} key={val.id}>
                  {val?.name}
                </Select.Option>
              );
              }
            
            })}
          </Select>
        </Form.Item>

        <Form.Item
          label="Status"
          name="status"
          required={false}
          rules={[{ required: true, message: "Please select Status" }]}
          className="assets_form_item"
        >
          <Select className="assets_form_item-input">
            <Select.Option value="To-do">To-do</Select.Option>
            <Select.Option value="In Progress">In Progress</Select.Option>
            <Select.Option value="Done">Done</Select.Option>
           
            
          </Select>
        </Form.Item>
        <Form.Item
          label="Priority"
          name="priority"
          required={false}
          rules={[{ required: true, message: "Please select Priority" }]}
          className="assets_form_item"
        >
          <Select className="assets_form_item-input">
            <Select.Option value="High">High</Select.Option>
            <Select.Option value="Medium">Medium</Select.Option>
            <Select.Option value="Low">Low</Select.Option>
            
          </Select>
        </Form.Item>
        <Form.Item
          label="Start Date"
          name="start_date"
          required={false}
          rules={[{ required: true, message: 'Please select date' }]}
          className="employee-details_form_item"
        >
          <DatePicker className="employee-details_form-datepic"
            onChange={onChangedoe}
          />
        </Form.Item>
        <Form.Item
          label="Target Date"
          name="target_date"
          required={false}
          rules={[{ required: true, message: 'Please select date' }]}
          className="employee-details_form_item"
        >
          <DatePicker className="employee-details_form-datepic"
            onChange={onChangedoa}
          />
        </Form.Item>
        <Form.Item
          label="Sprint Name"
          name="sprint_associationid"
          required={false}
          rules={[{ required: true, message: "Please Select Sprint Name!" }]}
          className="employee-details_form_item"
        >
          <Select className="employee-details_form_item-input"
          >
            {sprint.map((val: any) => {
              return (
                <Select.Option value={val.id} key={val.id}>
                  {val?.sprint_name}
                </Select.Option>
              );
            })}
          </Select>
        </Form.Item>
        <Form.Item>
          <div className="assets_submit">
            <Space>
              <Button
                htmlType="button"
                className="assets_cancel-btn"
                onClick={() => ModalClose(null)}
              >
                Cancel
              </Button>
              <Button htmlType="submit" className="assets_submit-btn">
                Submit
              </Button>
              
            </Space>
          </div>
        </Form.Item>
      </Form>
    </div>
  );
};

export default createTaskadd;
