import React from "react";
import HRMLayout from "../hrmlayout";
import { useEffect, useState } from "react";
import { useMutation, useQuery } from "@apollo/client";
import { GETTASK, DELETE_MYTASK,CREATE_COMMENT,GET_COMMENTS } from "@/helpers";
import { useAuth } from "../../../components/auth";
import { Button, Drawer, Popconfirm, Space, Table, Select, Upload } from "antd";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import moment from "moment";
import TaskModal from "@/custom_components/taskModal";
import CreateTaskadd from "./create";
import { Modal } from "antd";
import { Input } from 'antd';
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";
import { UploadOutlined } from '@ant-design/icons';
import { UploadChangeParam } from 'antd/lib/upload/interface';

export const TaskManagement: React.FC<any> = () => {
  const [isCreatingTask, setCreatingTask] = useState(false);
  const [heading, setHeading] = useState("");
  const [editdraw, setEditdraw] = useState("");
  const [task, setTask] = useState<any>([]);
  const [comment, setComment] = useState<any>([]);
  const [reloadCreateTimesheet, setReloadCreateTimesheet] = useState(false);
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [viewModalVisible, setViewModalVisible] = useState(false);
  const [viewModalData, setViewModalData] = useState<any | null>(null);
  const [selectedOrgValue, setSelectedOrgValue] = useState("");
  const { check_button_permission, filteredColumns } = useAuth(); // Use a more descriptive variable name
  const { TextArea } = Input;
  const [inputValue, setInputValue] = useState('');
  const [fileList, setFileList] = useState<any[]>([]);

  const onChange = ({ fileList: newFileList }: UploadChangeParam) => {
    setFileList(newFileList);
  };

  const onPreview = async (file: any) => {
    // Implement logic to preview the image, e.g., open a modal with the image
  };

  const onRemove = (file: any) => {
    // Implement logic to remove the image from the list
    setFileList((prevList) => prevList.filter((item) => item.uid !== file.uid));
  };

  //------------------comment-----------
  const handleInputChange = (event: any) => {
    setInputValue(event.target.value);
  };

  // const handledelete = (id: any) => {
  //   deleteTask({
  //     variables: id,
  //     update: (cache: any) => {
  //       refetchTask();
  //     },
  //   });
  // };

  const handleSubmit = () => {
    const taskId = task.length > 0 ? task[0].id : null;
   commentTask({
    variables: {
      comments: inputValue,
      // employee: inputValue,
      task_id:taskId,
    },
   })
    setInputValue(''); 
  };

  const handleSelectChangeOrganization = (value: any) => {
    if (value === undefined) {
      sessionStorage.removeItem('search')
    } else {
      sessionStorage.setItem('search', value)
    }
    setSelectedOrgValue(value);
  };
  const search = (data: any) => {
    let searchOrg = sessionStorage.getItem('search');
    let filteredData;

    if (selectedOrgValue) {
      filteredData = data.filter((u: any) => {
        const name = u?.mast_employee_assign?.name; // Update the property access
        const match = name && name.toLowerCase() === selectedOrgValue.toLowerCase();
        return match;
      });
    } else if (searchOrg) {
      filteredData = data?.filter((u: any) => {
        const name = u?.mast_employee_assign?.name; // Update the property access
        const match = name && name.toLowerCase().includes(searchOrg?.toLowerCase());
        return match;
      });
    } else {
      filteredData = data;
    }
    return filteredData;
  };

  const OnTask = () => {
    setCreatingTask(true); // Set it to true when creating a task
    setHeading("Create");
  };

  const ModalClose = () => {
    setCreatingTask(false);
    // refetClientData()
  };
  
  const {error, loading, data: GetTaskData,refetch: refetchTask,} = useQuery(GETTASK);

  const {data: comments,refetch: refetchComments,} = useQuery(GET_COMMENTS);
  
  const [deleteTask, { error: delectError, loading: delectLoading, data }] = useMutation(DELETE_MYTASK);

  const [commentTask, { error: commentError, loading: commentLoading, data:commentCreate }] = useMutation(CREATE_COMMENT);
 
  useEffect(() => {
   
    if (GetTaskData) {
      
      let res = GetTaskData?.mst_task;
      console.log(res , 'res');
      
      setTask(res);
    }
  }, [GetTaskData]);

  useEffect(() => {
    if (comments) {
      let res = comments?.mst_comments;
      setComment(res);
    }
  }, [comments]);
 
  const handledelete = (id: any) => {
    deleteTask({
      variables: id,
      update: (cache: any) => {
        refetchTask();
      },
    });
  };
  const handleChange = (record: any) => {
    setEditdraw(record);
    setCreatingTask(true);
    setHeading("Edit");
  };
  const handleViewModalOpen = (data: any) => {
    setViewModalData(data);
    setViewModalVisible(true);
  };
  const handleViewModalClose = () => {
    setViewModalData(null);
    setViewModalVisible(false);
    setReloadCreateTimesheet(prevState => !prevState);
  };
  const showModal = (param: any) => {
    setPopOpen(true);
    setTitle(param);
  };

  const handleOk = () => {
    refetchTask();
    setPopOpen(false);
  };

  const handleCancel = () => {
    setPopOpen(false);
  };


  var count = 0;
  const colums = [
    {
      title: "S.no",
      dataIndex: "s.no",
      render: () => ++count,
    },
    {
      title: "Issue Type",
      dataIndex: "issue_type",
      key: "issue_type",
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
    },

    {
      title: "Assigned To",
      render: (value: any) => {
        let name = value?.mast_employee_assign?.name;
        
        return <p>{name}</p>;
      },
    },

    {
      title: "View",
      render: (value: any) => (
        <>
          <Button
            type="primary"
            onClick={() => {
              setViewModalData(value?.id); // Set the data to be displayed in the modal
              setViewModalVisible(true); // Open the modal
            }}
          >
            View
          </Button>
        </>
      ),
    },
    {
      title: "Action",
      key: "action",
      render: (record: any) => (
        <Space size="large">
          {check_button_permission("Task", "edit") ? (
            <EditOutlined
              onClick={() => handleChange(record)}
              className="employee-details_edit"
            />
          ) : (
            <></>
          )}

          {check_button_permission("Task", "delete") ? (
            <Popconfirm
              title="Delete the Task"
              description="Are you sure to delete this Task?"
              okText="Yes"
              cancelText="No"
              onConfirm={() => handledelete(record)}
            >
              <DeleteOutlined className="employee-details_delete" />
            </Popconfirm>
          ) : (
            <></>
          )}
        </Space>
      ),
    },
  ];
  return (
    <HRMLayout>
      <div className="employee-details">
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Task</h2>
          <Select
            size={'large'}
            onChange={handleSelectChangeOrganization}
            allowClear
            showSearch
            filterOption={(input, option: any) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
            placeholder={'Assigned To'}
            defaultValue={sessionStorage.getItem('search')}
            className='Asset_selecter'
            style={{ width: '220px', marginRight: '10px' }}
          >
            {Array.from(
              new Set(
                GetTaskData?.mst_task?.map((task: any) => task.mast_employee_assign?.name)
              )
            ).map((name: any, index: number) => (
              <Select.Option value={name} key={index}>
                {name}
              </Select.Option>
            ))}
          </Select>


          {check_button_permission("Task", "create") ? (
            <Button className="employee-details_head-create" onClick={OnTask}>
              + Add New Task
            </Button>
          ) : (
            <></>
          )}
        </div>

        <Table
          columns={filteredColumns(colums, "Task")}
          dataSource={search(GetTaskData?.mst_task || [])}  // Use the filtered data directly
          pagination={{ pageSize: 10 }}
          className="employee-details_table"
        />

        <Drawer
          title={`${heading} Task`}
          width={570}
          placement="right"
          onClose={() => setCreatingTask(false)}
          open={isCreatingTask}
          className="employee-details_drawer"
        >
          {heading == "Edit" ? (
            <CreateTaskadd ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />
          ) : (
            <></>
          )}
          {heading == "Create" ? (
            <CreateTaskadd ModalClose={ModalClose} showModal={showModal} editdraw={null} />
          ) : (
            <></>
          )}
        </Drawer>

        <Modal
          open={viewModalVisible}
          onCancel={handleViewModalClose}
          footer={null}
          width={"50%"}
        >
          <TaskModal id = {viewModalData} key = {reloadCreateTimesheet} />
        </Modal>

        <Modal
          open={Popopen}
          title=""
          onOk={handleOk}
          onCancel={handleCancel}
          footer={[
            <div style={{ display: "flex", justifyContent: "center" }}>
              <Button
                key="submit"
                type="primary"
                loading={loading}
                onClick={handleOk}
                style={{
                  display: "flex",
                  width: "206px",
                  padding: "15px 30px",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: "10px",
                  borderRadius: "8px",
                  background: "#252947",
                }}>
                OK
              </Button>
            </div>,
          ]}
          width={"386px"}>
          <Space
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            }}>
            <Image
              src={PopImage}
              alt="image"
              style={{
                width: "150px",
                height: "150px",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            />
            <p
              style={{
                color: "#101010",
                textAlign: "center",
                fontFamily: "revert",
                fontSize: "32px",
                fontStyle: "normal",
                fontWeight: "700",
                lineHeight: "normal",
              }}>
              {`${title}`} Successfully
            </p>
          </Space>
        </Modal>

      </div>
    </HRMLayout>
  );
};

export default TaskManagement;
