import React, { useEffect, useState, useRef } from "react";
import { Space, Table, Button, Popconfirm, DatePicker, Modal, Select, } from "antd";
import type { ColumnsType } from "antd/es/table";
import { useQuery, useMutation } from "@apollo/client";
import moment from "moment";
import { DeleteOutlined, FilterOutlined } from "@ant-design/icons";
import { GET_ORGANIZATION, GET_PAYROLL } from "../../../helpers/queries";
import type { DatePickerProps } from "antd";
import { GET_PAYROLL_DATA, GET_HOLIDAYMANAGEMENT, } from "../../../helpers/queries";
import { CREATE_SALARY_PAYMENT, UPDATE_SALARY_PAYMENT, DELETE_SALARY_PAYMENT, } from "../../../helpers/mutation";
import HRMLayout from "../hrmlayout";
import { useAuth } from "../../../components/auth";
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";

interface DataType {
  project: string;
}

export const Payroll: React.FC<any> = () => {
  const [userlist, setUser] = useState([]);
  const [userPay, setPay] = useState([]);
  const [payMent, setPayment] = useState("Pending");
  const [filter, setFilter] = useState(false);
  const [filterPayroll, setFilterPayroll] = useState<string | null>(null);
  const { check_button_permission, userInEmploye, filteredColumns, user } = useAuth();
  const [holiDays, setHoliDays] = useState<number>(0);
  const { loading: holidayLoading, data: holidayData } = useQuery(GET_HOLIDAYMANAGEMENT);
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [selectedValue, setSelectedValue] = useState("");
  const [selectedOrgValue, setSelectedOrgValue] = useState("");


  const handleSelectChange = (value: any) => { setSelectedValue(value); };
  const showModal = (param: any) => {
    setPopOpen(true);
    setTitle(param);
  };

  const handleOk = () => {
    refetEmployDetails();
    setPopOpen(false);
  };

  const search_user = (data: any) => {
    return selectedValue
      ? data.filter((u: any) =>
        u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
      )
      : data;
  };

  const search = (data: any) => {
    let searchOrg = sessionStorage.getItem("searchPayRoll");

    const orgSearchData = data?.filter((u: any) =>
      u?.mst_organization?.name
        ?.toLowerCase()
        .includes(searchOrg?.toLowerCase())
    );

    if (selectedValue && selectedOrgValue) {
      return data.filter(
        (u: any) =>
          u.name?.toLowerCase().includes(selectedValue?.toLowerCase()) &&
          u.mst_organization?.name
            ?.toLowerCase()
            .includes(selectedOrgValue?.toLowerCase())
      );
    } else if (selectedValue) {
      return data.filter((u: any) =>
        u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
      );
    } else if (selectedOrgValue) {
      return data?.filter((u: any) =>
        u?.mst_organization?.name
          ?.toLowerCase()
          .includes(selectedOrgValue?.toLowerCase())
      );
    } else if (searchOrg) {
      return data?.filter((u: any) =>
        u?.mst_organization?.name
          ?.toLowerCase()
          .includes(searchOrg?.toLowerCase())
      );
    } else {
      return data;
    }
  };

  const month_of_leave_filters = (prv: any) => {

    let from_date: any = new Date(prv.from_date);
    let to_date: any = new Date(prv.to_date);

    if (
      to_date.getMonth() > from_date.getMonth() ||
      (to_date.getMonth() === 0 && from_date.getMonth() === 11)
    ) {
      let dayDifference = (to_date - from_date) / (24 * 60 * 60 * 1000);

    } else {
      return prv?.count;
    }
  }

  const handleCancel = () => {
    setPopOpen(false);
  };

  const ModalClose = () => {
    refetPayRoll();
  };

  const [updateStatus, { loading: updateLoad, error: updateError, data: updateData },] = useMutation(UPDATE_SALARY_PAYMENT);

  const { error: assetError, loading: assetLoading, data: dataPayRoll, refetch: refetPayRoll, } = useQuery(GET_PAYROLL, { variables: {}, });

  const { error: userError, loading: userLoading, data: dataUser, refetch: refetEmployDetails, } = useQuery(GET_PAYROLL_DATA, { variables: {}, });


  const {
    error: orgError,
    loading: orgLoading,
    data: orgData,
    refetch: refetOrganizationDetails,
  } = useQuery(GET_ORGANIZATION);

  useEffect(() => {
    if (dataUser && !filterPayroll) {
      let userlist = dataUser?.mst_employeedetails;
      const filterData = userlist.filter((value: any) => {
        return value.isdeleteat == false
      })
      setUser(filterData);
    }
  }, [dataUser, filterPayroll]);


  const onChange: DatePickerProps["onChange"] = (date, dateString) => {
    setFilter(true);
    // const filterPayroll = userlist.filter((val: any) => {
    //   moment(val?.mst_employeedetails_mst_salary_payments?.paid_on).format(
    //       "MMMM YYYY"
    //     ) === moment(dateString).format("MMMM YYYY")
    //   });
    setFilterPayroll(dateString);
  };


  interface Holiday {
    date: string;
    reason: string;
    id: number;
  }

  useEffect(() => {
    if (holidayData) {
      const currentDate = new Date();
      const currentMonth = currentDate.getMonth(); // 0-indexed month
      const holidaysForCurrentMonth =
        holidayData?.mst_holidaymanagement?.filter((holiday: Holiday) => {
          const holidayDate = new Date(holiday.date);
          return holidayDate.getMonth() === currentMonth;
        });

      setHoliDays(holidaysForCurrentMonth?.length || 0);
    }
    if (holidayData && filterPayroll) {

      let month = moment(filterPayroll).format("M");
      const holidaysForCurrentMonth =
        holidayData.mst_holidaymanagement?.filter((holiday: any) => {
          const holidayMonth = moment(holiday.date).format("M");
          return holidayMonth === month;
        });

      setHoliDays(holidaysForCurrentMonth?.length || 0);
    }

  }, [holidayData, filterPayroll]);


  const [
    createPayment,
    { loading: payLoading, error: payError, data: payDataAddress },
  ] = useMutation(CREATE_SALARY_PAYMENT, {
    errorPolicy: "all",
  });

  const handlePayClick = (values: any, perMonth: any) => {

   let currentDate = new Date()
    let targetDate = perMonth ? new Date(perMonth) : currentDate;

    let year = targetDate.getFullYear();
    let month = (targetDate.getMonth() + 1).toString().padStart(2, '0');
    let day = targetDate.getDate().toString().padStart(2, '0');


    let formattedDate = `${year}-${month}-${day}`;
    setPayment("Paid");

    let perDay = Math.round(
      values?.mst_employeedetails_mst_salarymanagements?.final_pay /
      (workingDaysInCurrentMonth - holiDays)
    );

    let payment = calculate_payment(perDay, values, filterPayroll);

    createPayment({
      variables: {
        emp: values?.id,
        paid_on: "now()",
        status: "true",
        paid_for: formattedDate,
        payment,
        working_days: workingDaysInCurrentMonth - holiDays,
        emp_working_days: totalAttendance(values),
      },
    }).then((response) => {
      refetEmployDetails();
    });
  };

  const [deleteRole, { loading, error, data }] = useMutation(
    DELETE_SALARY_PAYMENT
  );

  const handleDelete = (id: any) => {
    let getDeleteId = id.mst_employeedetails_mst_salary_payments

    let empId = getDeleteId.map((ID: any) => {
      return ID.id
    })
    deleteRole({
      variables: { id: empId[0] },
      update: (cache) => {
        refetEmployDetails();
      },
    });
  };

  const getNumberOfWorkingDaysInCurrentMonth = () => {
    const date = new Date();
    const year = date.getFullYear();
    const month = date.getMonth();

    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    let count = 0;
    let currentDay = new Date(firstDayOfMonth);

    while (currentDay <= lastDayOfMonth) {
      const dayOfWeek = currentDay.getDay();

      if (dayOfWeek !== 0 && dayOfWeek !== 6) {       // Exclude Sunday (0) and weekdays (Monday to Friday)
        count++;
      } else if (dayOfWeek === 6) {
        // For Saturdays, check if it's the first or third Saturday
        const weekOfMonth = Math.ceil((currentDay.getDate() - 1) / 7);
        if (weekOfMonth === 1 || weekOfMonth === 3) {
          count++;
        }
      }

      currentDay.setDate(currentDay.getDate() + 1);
    }

    return count;
  };

  const second_to_hours = (data: any) => {
    let seconds = data?.seconds / 3600;
    return seconds;
  };

  const workingDaysInCurrentMonth = getNumberOfWorkingDaysInCurrentMonth();

  const filterData = (param: any) => {
    const filteredData: any = {};
    let count = 0;

    param.forEach((item: any) => {
      const { date } = item;

      if (!filteredData[date]) {
        filteredData[date] = [];
      }

      filteredData[date].push(item);
    });

    for (const date in filteredData) {
      const items = filteredData[date];
      const length = items.length;
      const hours = second_to_hours(items[items.length - 1]); //Hours
      if (length != 0) {
        count++;
      }
    }
    return count;
  };

  const getAllDatesInMonth = () => {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);

    const datesArray = [];
    for (let day = firstDay; day <= lastDay; day.setDate(day.getDate() + 1)) {
      datesArray.push(moment(day).format('DD-MM-YYYY'));
    }
    return datesArray;
  };

  // Get all dates in the current month

  const totalAttendance = (param: any) => {

    let filterTimeSheet = param?.mstTimesheetsByEmployee?.filter((item: any) => {
      return moment(item.date).format("MM") === moment().format("MM")
    });

    const allDatesInMonth = getAllDatesInMonth();

    let arrayTime: any = []

    for (let currentMonth in allDatesInMonth) {
      let arraySession: any = []
      for (let filterTime in filterTimeSheet) {
        if (allDatesInMonth[currentMonth] === moment(filterTimeSheet[filterTime]?.date).format('DD-MM-YYYY')) {
          arraySession.push(filterTimeSheet[filterTime])
        }
      }
      if (arraySession?.length > 0) {
        let totalSum = arraySession?.reduce((accumulator: any, currentValue: any) => accumulator + currentValue?.seconds
          , 0)
        if (totalSum >= 8) {
          arrayTime.push(1)
        } else if (totalSum >= 4) {
          arrayTime.push(0.)
        } else {
          arrayTime.push(0)
        }
      }
    }

    let totalCountData = arrayTime?.reduce((accumulator: any, currentValue: any) => accumulator + currentValue, 0)

    return totalCountData;
  };

  const calculate_payment = (day: any, value: any, filterPayroll: any) => {

    if (!filterPayroll) {
      const currentDate = new Date();

      let check = value?.mst_leave_employee
        ?.filter((data: any) => {
          const from_date = new Date(data.from_date);
          const to_date = new Date(data.to_date);

          // Check if the leave falls within the current month
          const isCurrentMonth =
            from_date.getMonth() === currentDate.getMonth() &&
            from_date.getFullYear() === currentDate.getFullYear();

          return (
            isCurrentMonth
          );

        }).reduce((total: any, per: any) => {

          return total + month_of_leave_filter(per)
        }, 0);

      let check_in = totalAttendance(value) + check;
      let payment = (workingDaysInCurrentMonth - check) * day;
      return payment;
    }

    else {

      const currentDate = new Date(filterPayroll);

      let check = value?.mst_leave_employee
        ?.filter((data: any) => {
          const from_date = new Date(data.from_date);
          const to_date = new Date(data.to_date);

          // Check if the leave falls within the current month
          const isCurrentMonth =
            from_date.getMonth() === currentDate.getMonth() &&
            from_date.getFullYear() === currentDate.getFullYear();
          return (
            isCurrentMonth
          );

        }).reduce((total: any, per: any) => {
          return total + month_of_leave_filter(per)
        }, 0);
      let check_in = totalAttendance(value) + check;

      let holidayCount = (workingDaysInCurrentMonth - holiDays);

      let payment = (holidayCount - check) * day

      return payment;

    }

  };

  const month_of_leave_filter = (param: any) => {

    let from_date: any = new Date(param.from_date);
    let to_date: any = new Date(param.to_date);

    if (
      to_date.getMonth() > from_date.getMonth() ||
      (to_date.getMonth() === 0 && from_date.getMonth() === 11)
    ) {
      let dayDifference = (to_date - from_date) / (24 * 60 * 60 * 1000);
      // if (param?.mst_leavemanage_mst_leavetype?.reason === "Work From Home") {
      //   return 0;
      // } else {
      // }
    } else {
      // if (param?.mst_leavemanage_mst_leavetype?.reason === "Work From Home") {
      //   return 0;
      // } else {
      return param?.count;
      // }
    }
  };

  const month_leave_applied = (param: any, selectedMonth: any) => {

    if (!selectedMonth) {
      let currentMonth = new Date().getMonth() + 1;

      let monthLeave = param?.mst_leave_employee?.filter(
        (data: any) => {

          let fromMonth = new Date(data?.from_date).getMonth() + 1;
          let toMonth = new Date(data?.to_date).getMonth() + 1;
          return fromMonth === currentMonth || toMonth === currentMonth;
        }
      );
      let leaveCounts = monthLeave?.reduce(
        (total: any, prv: any) => total + month_of_leave_filter(prv),
        0
      );

      return leaveCounts;
    } else {
      let month: any = moment(selectedMonth).format("M");

      let monthLeave = param?.mst_leave_employee?.filter(
        (data: any) => {

          let fromMonth = new Date(data?.from_date).getMonth() + 1;
          let toMonth = new Date(data?.to_date).getMonth() + 1;
          return fromMonth === Number(month) || toMonth === Number(month);
        }
      );
      let leaveCounts = monthLeave?.reduce(
        (total: any, prv: any) => total + month_of_leave_filter(prv),
        0
      );

      return leaveCounts;
    }
  };


  const checkPaymentStatus = (value: any, previousMonth: any) => {
    const date = new Date();
    const currentMonth = date.getMonth();
    const filterPayment = value.mst_employeedetails_mst_salary_payments;

    let targetMonth = previousMonth ? new Date(previousMonth).getMonth() : currentMonth;

    const filteredPayments = filterPayment.filter((status: any) => {

      return status?.status === true && new Date(status?.paid_for).getMonth() === targetMonth;
    });

    return filteredPayments.length > 0;
  };

  const columns: ColumnsType<DataType> = [
    {
      title: "S.No",
      dataIndex: "sno",
      key: "sno",
      render: (text, record, index) => index + 1,
    },

    {
      title: "Emp Name",
      render: (value) => {
        return (
          <>
            <p>{value?.name}</p>
          </>
        );
      },
    },
    {
      title: "Org",
      render: (value: any) => {
        let organization = value?.mst_organization?.name;
        return <p>{organization}</p>;
      },
      filters: [
        {
          text: "Hysas",
          value: "Hysas",
        },
        {
          text: "Vinsoft",
          value: "Vinsoft",
        },
        {
          text: "Kitez",
          value: "Kitez",
        },
      ],
      onFilter: (value: any, record: any) =>
        record?.mst_organization?.name?.indexOf(value) === 0,
      filterIcon: () =>
        user.email === "admin@gmail.com" && (
          <FilterOutlined style={{ color: "white", fontSize: "18px" }} />
        ),
    },
    {
      title: "Days",
      render: (value) => {

        return (
          <>
            <p>{workingDaysInCurrentMonth - holiDays}</p>
          </>
        );
      },
    },
    // {
    //   title: "Present",
    //   render: (value) => {
    //     console.log(value?.mstTimesheetsByEmployee?.length);
    //     return (
    //       <>
    //         <p>{totalAttendance(value)}</p>
    //       </>
    //     );
    //   },
    // },
    {
      title: "Salary",
      render: (value) => {
        const salary = value?.mst_employeedetails_mst_salarymanagements?.salary;
        return (
          <>
            <p>{salary}</p>
          </>
        );
      },
    },
    {
      title: "Leave",
      render: (value) => {

        let LeaveCount = month_leave_applied(value, filterPayroll);
        return (
          <>
            <p>{LeaveCount}</p>
          </>
        );
      },
    },
    {
      title: "Payment",
      render: (value) => {
        let perDay = Math.round(
          value?.mst_employeedetails_mst_salarymanagements?.final_pay /
          (workingDaysInCurrentMonth - holiDays)
        );

        let payment = calculate_payment(perDay, value, filterPayroll);

        return (
          <>
            <p>{!payment ? "0" : payment}</p>
          </>
        );
      },
    },
    {
      title: "Status",
      render: (value) => {
        const statusText = ""
        return <p>{statusText}</p>;
      },
      filters: [
        { text: "Paid", value: true },
        { text: "Pending", value: false },
      ],
      onFilter: (value: any, record: any) => {
        const status =
          record?.mst_employeedetails_mst_salary_payments[
            record?.mst_employeedetails_mst_salary_payments?.length - 1
          ]?.status;

        return status === value;
      },
      filterIcon: (filtered) =>
        user.email === "admin@gmail.com" && (
          <FilterOutlined style={{ color: "white", fontSize: "18px" }} />
        ),
    },
    {
      title: "Actions",
      key: "action",
      render: (value: any) => {
        const isPaid = checkPaymentStatus(value, filterPayroll);
        return (
          <>
            <Popconfirm
              title="Save the PayRoll"
              description="Are you sure to save this payment?"
              okText="Yes"
              cancelText="No"
              onConfirm={() => { handlePayClick(value, filterPayroll) }}
            >
              <Button className="payroll_submit-btn"
                type="default"
                disabled={isPaid}
                style={
                  isPaid
                    ? { backgroundColor: '#1890ff', color: '#ffffff', borderColor: '#1890ff' }
                    : {}
                }
              >
                {isPaid ? 'Paid' : 'Pay'}
              </Button>
            </Popconfirm>

          </>
        );
      },
    },

    // {
    //     title: 'Action',
    //     key: 'action',
    //     render: (record) =>
    //     (
    //         <Space size='large'>

    //             {
    //                 check_button_permission("Payroll", "delete")
    //                     ?

    //                     <Popconfirm
    //                         title="Delete the task"
    //                         description="Are you sure to delete this task?"
    //                         okText="Yes"
    //                         cancelText="No"
    //                         // onConfirm={() => handleDelete(record)}
    //                         onConfirm={() => handleDelete(record?.mst_employeedetails_mst_salary_payments[record?.mst_employeedetails_mst_salary_payments?.length - 1]?.id)}
    //                         disabled={record?.mst_employeedetails_mst_salary_payments[record?.mst_employeedetails_mst_salary_payments?.length - 1]?.status ? false : true}

    //                     >

    //                         <DeleteOutlined className="role_delete"

    //                         />

    //                     </Popconfirm>
    //                     : <></>
    //             }

    //         </Space>
    //     ),
    // },
    {
      title: "Action",
      key: "action",
      render: (value) => {
        const isPaid = checkPaymentStatus(value, filterPayroll);
        return (

          <>
            <Space size="large">
              {check_button_permission("Payroll", "delete") ? (
                <Popconfirm
                  title="Delete the task"
                  description="Are you sure to delete this task?"
                  okText="Yes"
                  cancelText="No"
                  onConfirm={() =>
                    handleDelete(
                      value
                    )
                  }
                  disabled={!isPaid}
                >
                  <span

                  ></span>
                  <DeleteOutlined className="role_delete" style={{
                    opacity: !isPaid ? 0.5 : 1,
                    pointerEvents: !isPaid ? 'none' : 'auto',
                    cursor: !isPaid ? 'not-allowed' : 'pointer',
                  }} />
                </Popconfirm>
              ) : (
                <></>
              )}
            </Space>
          </>
        )
      }
    },
  ];

  let fit = filteredColumns(columns, "Payroll");
  let userDetail = userInEmploye?.mst_employeedetails.map((data: any) => data);

  const seartch = (data: any) => {
    return selectedValue
      ? data.filter((u: any) =>
        u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
      )
      : data;
  };

  let empData = [...(dataUser?.mst_employeedetails || [])];
  let sort = empData?.sort((a: any, b: any) => a?.name.localeCompare(b?.name));

  const onChangeSelectMul = (option: any) => {
    const filteredB = userlist.filter((item: any) =>
      option.includes(item?.name?.toString())
    );

    return "";
  };

  const handleSelectChangeOrganization = (value: any) => {
    if (value === undefined) {
      sessionStorage.removeItem("searchPayRoll");
    } else {
      sessionStorage.setItem("searchPayRoll", value);
    }
    setSelectedOrgValue(value);
  };

  return (
    <HRMLayout>
      <div className="payroll">
        <div className="payroll_head">
          <h2 className="payroll_head-text">Payroll</h2>
          <div style={{ marginRight: "10px" }}>

            {user.email === "admin@gmail.com" && (
              <Select
                size={"large"}
                onChange={handleSelectChangeOrganization}
                allowClear
                showSearch // Enable search functionality
                filterOption={(input, option: any) =>
                  option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
                placeholder={"Select Organization"}
                className="Asset_selecter"
                defaultValue={sessionStorage.getItem("searchPayRoll")}
                style={{ width: "220px", marginRight: "10px" }}
              >
                {orgData?.mst_organization?.map((org: any, index: any) => {
                  return (
                    <Select.Option value={org.name} key={index}>
                      {org?.name}
                    </Select.Option>
                  );
                })}
              </Select>
            )}

            {user.email === "admin@gmail.com" && (
              <Select
                size={"large"}
                onChange={handleSelectChange}
                allowClear
                showSearch // Enable search functionality
                filterOption={(input, option: any) =>
                  option.children.toLowerCase().indexOf(input.toLowerCase()) >=
                  0
                }
                placeholder={"Select Employee"}
                className="Asset_selecter"
                style={{ width: "220px", marginRight: "10px" }}>
                {sort?.map((emp: any, index: any) => {
                  if (emp.isdeleteat == false) {
                    return (
                      <Select.Option value={emp.name} key={index}>
                        {emp?.name}
                      </Select.Option>
                    );
                  }

                })}
              </Select>
            )}
            <DatePicker
              className="payroll_head-create"
              onChange={onChange}
              picker="month"
            />
          </div>
        </div>

        {user.email === "admin@gmail.com" ? (
          <Table
            columns={filteredColumns(columns, "Payroll")}
            dataSource={search(userlist)}
            pagination={{ pageSize: 10 }}
            className="attendance_table"
          />
        ) : (
          <Table
            columns={filteredColumns(columns, "Payroll")}
            dataSource={search_user(userDetail)}
            pagination={{ pageSize: 10 }}
            className="attendance_table"
          />
        )}
      </div>
      <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{ display: "flex", justifyContent: "center" }}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
    </HRMLayout>
  );
};

export default Payroll;
