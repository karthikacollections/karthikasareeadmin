import { useDrop } from "react-dnd";
import BoardTask from "./boardTask"
import { STATUS_UPDATE } from "@/helpers";
import { useMutation } from "@apollo/client";

export const BoardSection:React.FC<any>= ({tasks, refetch, handleClick, columnIndex, rowIndex, selectedNames, name, status}) => {

  const [updateStatusMutation,{loading, error, data}] = useMutation(STATUS_UPDATE);

    const [ { isOver }, drop ] = useDrop(() => ({
        accept: "task",
        drop: (item: any) => updateDrop(item),
        collect: (monitor: any) => ({
            isOver: !!monitor.isOver,
        })
    }))

    const updateDrop = (data: any) =>{
        updateStatusMutation({
            variables: {
              status: status,
              id: data.id,
            }
          }).then((res: any) => refetch())
    }
    
    return(
        <td
            className={`backgroundtable cardSection`}
            key={columnIndex}
            ref={drop}
        >
            {selectedNames[rowIndex] === name &&
                tasks?.filter((task: any) =>
                        task.mast_employee_assign?.name === name &&
                        task.status === status &&
                        (task.title ||
                        task.description ||
                        task.mast_employee_assign.image ||
                        task.issue_type ||
                        task.priority ||
                        task.status)
                    ).map((task: any, index: any) => (
                    <BoardTask taskData = {task} handleModleOpen = {handleClick} status = {status} name = {name}/>
                ))
            }
            
        </td>
    )
}

export default BoardSection
