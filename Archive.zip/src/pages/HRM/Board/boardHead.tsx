
export const BoardHead:React.FC<any>= ({title}) => {

    return(
        <th>
            {title}
        </th>
    )
}

export default BoardHead
