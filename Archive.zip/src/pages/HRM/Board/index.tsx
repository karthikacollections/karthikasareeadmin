import HRMLayout from "../hrmlayout";
import React, {useState} from "react";
import {useQuery, useMutation} from "@apollo/client";
import {DownOutlined, RightOutlined} from "@ant-design/icons";
import {GET_ASSIGN_TONAME, STATUS_UPDATE, GETTASK} from "@/helpers";
import {UUID} from "crypto";
import {Modal} from "antd";
import {DndProvider} from 'react-dnd';
import {HTML5Backend} from 'react-dnd-html5-backend';
import BoardSection from "./boardSection";
import BoardHead from "./boardHead";
import TaskModal from "@/custom_components/taskModal";

interface Task {
  id: UUID;
  issue_type: string;
  title: string;
  description: string;
  reporter_userid: string;
  assignee_userid: string;
  status: string;
  priority: string;
  start_date: string; // Adjust the actual type based on your data
  target_date: string; // Adjust the actual type based on your data
  sprint_associationid: string; // Adjust the actual type based on your data
  mast_employee_assign: {
    id: string;
    name: string;
    image: string;
  } | null;
  reporterrelation: {
    id: string;
    name: string;
  } | null;
  mst_tasksprintid: {
    sprint_name: string;
    id: string;
    getprojectname: {
      project_name: string;
    } | null;
  } | null;
}

const BoardTo: React.FC = () => {
  const {loading, error, data} = useQuery(GET_ASSIGN_TONAME);
  const {data: taskData,refetch} = useQuery(GETTASK);
  const tasks: Task[] = taskData?.mst_task || [];
  const [isCardModalOpen, setIsCardModalOpen] = useState<boolean>(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const nameCountMap = new Map<string, number>();
  const [updateStatusMutation] = useMutation(STATUS_UPDATE);
  const [comment, setComment] = useState<any>([]);

  const showModal = (task: Task) => {
    setSelectedTask(task);
    setIsCardModalOpen(true);
  };

  const handleCancel = () => {
    setSelectedTask(null);
    setIsCardModalOpen(false);
  };

  tasks.forEach((task) => {
    const name = task.mast_employee_assign?.name;
    if (name) {
      nameCountMap.set(name, (nameCountMap.get(name) || 0) + 1);
    }
  });

  const uniqueNamesArray: [string, number][] = Array.from(
    nameCountMap.entries()
  );

  // State to store the selected name for each row and whether the card is open for each name
  const [selectedNames, setSelectedNames] = useState<
    Record<string, string | null>
  >({});
  const [isCardOpen, setIsCardOpen] = useState<Record<string, boolean>>({});
  const [selectedRows, setSelectedRows] = useState<
    Record<string, number | null>
  >({});

  const handleNameClick = (rowIndex: number, name: string) => {
    setSelectedNames((prevSelectedNames) => {
      // Open or close the card for the clicked name in TODO column
      const todoSelectedName =
        prevSelectedNames[rowIndex] === name ? null : name;

      // Toggle the open/closed state for each name individually
      setIsCardOpen((prevIsCardOpen) => ({
        ...prevIsCardOpen,
        [name]: !prevIsCardOpen[name],
      }));

      setSelectedRows((prevSelectedRows) => ({
        ...prevSelectedRows,
        [name]: rowIndex,
      }));

      return {
        ...prevSelectedNames,
        [rowIndex]: todoSelectedName,
        [rowIndex + "inProgress"]: todoSelectedName,
        [rowIndex + "done"]: todoSelectedName,
      };
    });
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  const handleClick = (name: string, status: string, id: any) => {
    
    const rowIndex = selectedRows[name];
    if (rowIndex !== undefined && rowIndex !== null) {
      const taskForCard = tasks.find((task) => task.id === id);

      if (taskForCard !== undefined) {
        showModal(taskForCard);
      }
    }
  };

  // Define the order of statuses
  const statusOrder = ["To-do", "In Progress", "Done"];

  return (
    <HRMLayout>
    <DndProvider backend={HTML5Backend}>
      <h1>Board</h1>
      <table className="status-table">
        <thead className="headtable">
          <tr>
            {statusOrder.map((status, columnIndex) => (
              <BoardHead title = {status}/>
            ))}
          </tr>
        </thead>
        <tbody>
          {uniqueNamesArray.map(([name, count], rowIndex) => (
            <React.Fragment key={rowIndex}>
              <tr>
                <td className={`backgroundtable boldNameSection`}>
                  <div>
                    <span
                      className="boldName"
                      onClick={() => handleNameClick(rowIndex, name)}
                      style={{cursor: "pointer"}}>
                      <span className="togglebutton">
                        {isCardOpen[name] ? (
                          <DownOutlined />
                        ) : (
                          <RightOutlined />
                        )}
                      </span>{" "}
                      {name}
                    </span>{" "}
                    has {count} issue{count > 1 ? "s" : ""}
                  </div>
                </td>
              </tr>
              
              {isCardOpen[name] && (
                <tr>
                  {statusOrder.map((status, columnIndex) => (
                    <BoardSection refetch = {refetch} tasks = {tasks} handleClick = {handleClick} rowIndex = {rowIndex} columnIndex = {columnIndex} selectedNames = {selectedNames} name = {name} status = { status }/>
                  ))}
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
      <Modal
          open={isCardModalOpen} // "open" is changed to "visible" for Modal
          onCancel={handleCancel}
          footer={null}
          maskClosable={true}
          width={"50%"}
        >
          {selectedTask && (
            <TaskModal task={selectedTask} comment={comment} />
          )}
        </Modal>
    </DndProvider>
    </HRMLayout>
  );
};

export default BoardTo;
