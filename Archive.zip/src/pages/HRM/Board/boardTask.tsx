import { useDrag } from "react-dnd";
import BUG from "../../../assets/photos/issue_type/Bug.png";
import task from "../../../assets/photos/issue_type/Task.png";
import userStory from "../../../assets/photos/issue_type/UserStory.png";
import Image, {StaticImageData} from "next/image";

const issueTypeImages: {[key: string]: StaticImageData} = {
  Bug: BUG,
  Task: task,
  UserStory: userStory,
  // Add more mappings as needed
};

export const BoardTask: React.FC<any> = ({taskData, handleModleOpen, name, status}) => {

  const [ { isDragging }, drag ] = useDrag (() => ({
    type: 'task',
    item: {id: taskData?.id},
    collect: (monitor: any) => ({
      isDragging: !!monitor.isDragging()
    })
  }))
   
  return (
    <div
      ref={drag}
      key={taskData.title}
      className="card"
      onClick={() => handleModleOpen(name, status, taskData.id)}
    >
      {taskData.title && (
        <p
          style={{
            fontFamily: "Roboto, sans-serif",
            fontSize: "14px",
            width: "230px", // Set your desired width
            height: "auto",
            //  margin: "10px 0",
          }}>
          {taskData.title}
        </p>
      )}
      <div
        className="custom-container" // Set your desired class name
        style={{
          width: "300px", // Set your desired width
          height: "auto", // Set your desired height
        }}>
        {taskData.description && (
          <p
            style={{
              fontFamily: "Roboto, sans-serif",
              fontSize: "14px",
              margin: "10px 0",
              overflow: "hidden",
              textOverflow: "ellipsis",
              display: "-webkit-box",
              WebkitLineClamp: 2, // Number of lines to show
              WebkitBoxOrient: "vertical",
            }}>
            {taskData.description}
          </p>
        )}
      </div>

      {taskData.assigneerelation?.image && (
        <img
          src={taskData.assigneerelation.image}
          alt={`Image`}
          style={{
            position: "absolute",
            top: 0,
            right: 0,
            width: 100,
            height: 100,
            padding: 5,

            maxWidth: "40px", // Adjust the size as needed
            maxHeight: "50px", // Adjust the size as needed
          }}
        />
      )}
      {taskData.issue_type && (
        <div className="issuetype">
          <Image
            src={issueTypeImages[taskData.issue_type]}
            alt={taskData.issue_type}
            width={22} // Set the width as needed
            height={18} // Set the height as needed
          />
        </div>
      )}
    </div>
  );
};

export default BoardTask;
