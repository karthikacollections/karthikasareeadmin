import { Button, DatePicker, DatePickerProps, Form, Input, Space, message, Upload } from "antd";
import React, { useEffect, useRef, useState } from "react";
import dayjs from "dayjs";
import { useMutation, useQuery } from "@apollo/client";
import { CREATE_ANNOUNCEMENT, DELECT_ANNOUNCEMENT, GET_ANNOUNCEMENT, UPDATE_ANNOUNCEMENT } from "@/helpers";
import { UploadOutlined, ExclamationCircleOutlined, DeleteOutlined } from '@ant-design/icons';

const CreateAnnocement: React.FC<any> = ({ ModalClose, editdraw }) => {
    const [form] = Form.useForm()
    const formRef = useRef(null)
    const [date, setDate] = useState<any>()
    const [currentIST, setCurrentIST] = useState<any>()
    const [loadingMP, setLoading] = useState(false);
    const [urlList, setUrlList] = useState([] as any[]);
    const { Dragger } = Upload;

    const onChangedate: DatePickerProps["onChange"] = (dateString: any) => {
        setDate(dayjs(dateString).add(+1, 'day'))
    };

    useEffect(() => {
        const interval = setInterval(() => {
            const currentDate = new Date();
            const options = {
                hour12: false,
                timeZone: 'Asia/Kolkata' // Use 'Asia/Kolkata' for Indian Standard Time
            };
            setCurrentIST(currentDate.toLocaleString('en-IN', options));
        }, 1000);

        return () => {
            clearInterval(interval);
        };
    }, []);

    // CREATE 
    const [createAnnounce,
        {
            loading: AnnounceLoading,
            error: AnnounceError,
            data: AnnounceData
        }
    ] = useMutation(CREATE_ANNOUNCEMENT, {
        errorPolicy: 'all',
    });

    // GET
    const {
        error,
        loading,
        data: announData,
        refetch: refetchAnnoun
    } = useQuery(GET_ANNOUNCEMENT)

    // UPDATE
    const [updateAnnounce,
        {
            loading: updateloade,
            error: updateError,
            data: updateData
        }
    ] = useMutation(UPDATE_ANNOUNCEMENT, {
        errorPolicy: 'all',
    });

    useEffect(() => {
        if (editdraw) {
            let data = JSON.parse(JSON.stringify(editdraw))
            setUrlList(data?.file?.split(','));
            data.date = dayjs(editdraw.date)
            setDate(editdraw.date)
            form.setFieldsValue(data)
        }
    }, [editdraw])

    const ImageUploaderProp: any = {
        name: "file",
        multiple: true,
        action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
        onChange(info: any) {
            const { status } = info.file;
            if (status !== "uploading") {
            }
            if (status === "done") {
                message.success(`${info.file.name} file uploaded successfully.`);
            } else if (status === "error") {
                message.error(`${info.file.name} file upload failed.`);
            }
        },
    };

    const uploadImages = async (options: any) => {
        const { onSuccess, onError, file } = options;
        try {
            {
                setLoading(true);
                const data = new FormData();
                data.append("upload_preset", "Employee");
                data.append("file", file);

                data.append("cloud_name", "dgcgmcaxb");


                // fetch(`https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload`, {
                    fetch(`https://api.cloudinary.com/v1_1/hysas-tech/image/upload`, {
                    method: "post",
                    body: data,
                })
                    .then((resp) => resp.json())
                    .then((data) => {
                        setUrlList((urlList) => [...urlList, data.url]);
                        setLoading(false);
                    })
                    .catch((err) => {
                        setLoading(false);
                    });
                onSuccess("Ok");
            }
        } catch (err) {
            const error = new Error("Some error");
            onError({ err });
        }
    };

    const handleBeforeUpload = (file: any) => {
        const fileSizeInMB = file.size / 1024 / 1024; // Convert bytes to megabytes
        const maxFileSizeInMB = 2;
        if (fileSizeInMB > maxFileSizeInMB) {
            message.error(`File size must be within ${maxFileSizeInMB}MB!`);
            return false;
        }
        return true;
    };

    const handleRemove = async (images: any) => {
        let filteredImage = urlList?.filter(e => e !== images);
        setUrlList(filteredImage);

    };

   

    const onFinishFailed = (error: any) => {
    }

    const onFinish = (value: any) => {
        if (editdraw) {
            value.id = editdraw.id
            value.date = date
            value.file = urlList.toString()
            updateAnnounce({ variables: value }).then((res: any) => {
                ModalClose(null)
                refetchAnnoun()
                message.success(`Update Announcement`)
            }).catch((error) => {
                message.error(error)
                message.error('Check the Fileds')
            })
        } else {
            value.file = urlList.toString()
            createAnnounce({ variables: value }).then((res: any) => {
                ModalClose(null)
                refetchAnnoun()
                message.success(`Add new Announcement`)
            }).catch((error) => {
                message.error('Check the Fileds')
            })
        }
    }
    return <>
        <Form
            name="newAnnouncement"
            layout="vertical"
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
            form={form}
            ref={formRef}
            className="employee-details_form"
        >
            <Form.Item
                label="Date"
                name="date"
                required={false}
                rules={[{ required: true, message: 'Please select the Date!' }]}
            >
                <DatePicker onChange={onChangedate}></DatePicker>
            </Form.Item>

            <Form.Item
                label="Message"
                name="message"
                required={false}
                rules={[{ required: true, message: 'Please Enter Message!' }]}
            >
                <Input />
            </Form.Item>
            <Form.Item
                className="image_dragger"
                required={false} rules={[{ required: false, message: "Please Upload your Photos / videos" }]}
                label={<p className="create_post_lable">Upload Image</p>}
            >
                <Dragger
                    {...ImageUploaderProp}
                    name="file"
                    beforeUpload={handleBeforeUpload}
                    showUploadList={false}
                    customRequest={uploadImages}
                    className="dragger"
                    style={{ width: "100%", border: "2px dashed #7FACD6" }}
                >
                    <UploadOutlined className="employee-details_uploade-photo" />
                    <p>Drag & drop or Browse</p>
                    <p className="ant-upload-text">
                        Photo formates: JPEG, PNG, (maximum image size 2 mb).
                    </p>
                </Dragger>

                <div className="danger_alert">
                    <p> <ExclamationCircleOutlined className="employee-details_uploade-icon" /> maximum 10 slides</p>
                </div>

                {
                    urlList?.map((value) => {
                        const filename = value?.split('/').pop();

                        return <>
                            <div className='employee-details_photodelete'>
                                <img src={value} alt="profile" width={45} height={45} />
                                <p className='employee-details_photodelete-para' >{filename}</p>
                                <DeleteOutlined onClick={() => handleRemove(value)} className='employee-details_delete_icon' />
                            </div>
                        </>
                    })
                }
            </Form.Item>

            <Form.Item>
                <div className="employee-details_submit">
                    <Space>
                        <Button htmlType="button" onClick={() => ModalClose(null)} className="employee-details_cancel-btn">
                            Cancel
                        </Button>
                        <Button htmlType="submit" className="employee-details_submit-btn">
                            Submit
                        </Button>
                    </Space>
                </div>
            </Form.Item>
        </Form>
    </>
}

export default CreateAnnocement;