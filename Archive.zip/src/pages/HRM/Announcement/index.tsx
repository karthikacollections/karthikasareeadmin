import { DeleteOutlined, EditOutlined } from "@ant-design/icons"
import { Button, Drawer, Popconfirm, Space, Table } from "antd"
import { useEffect, useState } from "react";
// import { authProtected } from "@/components/protectedroute";
import { useMutation, useQuery } from "@apollo/client";
import { DELECT_ANNOUNCEMENT, GET_ANNOUNCEMENT, UPDATE_ANNOUNCEMENT, UPDATE_ANNOUNCEMENT_VIEW } from "@/helpers";
import moment from "moment";
import  CreateAnnocement  from "./createLeave";
import HRMLayout from '../hrmlayout'
import {useAuth} from '../../../components/auth'

export const AnnouncementManagement:React.FC<any>=()=>{

    const [open, setOpen] = useState<any>(false);
    const [heading, setHeading] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("");
    const [announcement, setAnnouncement] = useState <any>([]);
    const { check_button_permission,filteredColumns } = useAuth()

    // Opening Side Drawer
        const OnOpen=()=>{
            setOpen(true)
            setHeading('Create')
        }

    // Closinging Side Drawer

        const ModalClose = () => {
            setOpen(false)
            // refetClientData()
        }

    // Quary(GET,POST & DELECT)

    // GET
    const{
        error,
        loading,
        data:announData,
        refetch:refetchAnnoun
    }=useQuery(GET_ANNOUNCEMENT)

    // DELETE
       const[delectAnnoun,{
        error:delectError,
        loading:delectLoading,
        data
    }]=useMutation(DELECT_ANNOUNCEMENT); 

    // UPDATE
    const [updateAnnounce,
        {
            loading: updateloade,
            error: updateError,
            data: updateData,
        }
    ] = useMutation(UPDATE_ANNOUNCEMENT_VIEW, {
        errorPolicy: 'all',
    });

    // GET Annocsment Data
    useEffect(()=>{
        if(announData){
            let res=announData?.mst_announcement;
            setAnnouncement(res)
        }
    },[announData])
    
    // Delect Announcement
    const handleDelect=(id:any)=>{
        delectAnnoun({
            variables:id,
            update: (cache: any) => {
                refetchAnnoun()
            },
        })
    }

    // Update Announcement

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen(true)
        setHeading("Edit")
    }
    
    const updateViewChange = (recode: any) => {
        
        let state: boolean
        if(!recode?.isdelete){
            state = true
        }else{
            state = false
        }
        updateAnnounce({ variables:{id: recode?.id, isdelete: state} }).then((res: any) => {
            console.log(res ,'recode');
            refetchAnnoun()  
        })
        
    }
    var count=0
    const colums=[
        {
            title:'S.no',
            dataIndex:'s.no',
            render:()=>++count
        },
        {
            title:'Message',
            dataIndex:'message',
            key:'message'
        },
        {
            title:'Date',
            render:(value:any)=>{
                let dateMessage=moment(value?.date).format("DD-MM-YYYY")
                return(
                    <>
                        <p>{dateMessage}</p>
                    </>
                )
            }
        },
        {
            title:'Action',
            key:'action',
            render:(record:any)=>(
                <Space size='large'>
                    {
                        check_button_permission("Announcement", "edit")
                            ?
                        <EditOutlined
                            onClick={() => handleChange(record)}
                            className="employee-details_edit"
                        />
                        :<></>
                    }

                    {
                        !record?.isdelete ? <Button style={{color:'white', backgroundColor:'red', fontWeight:'bold', fontFamily:'Poppins'}} onClick={() => updateViewChange(record)}>Hide</Button> : <Button type='primary' style={{color:'white', fontWeight:'bold', fontFamily:'Poppins'}} onClick={() => updateViewChange(record)}>Show</Button>
                    }

                    {
                        check_button_permission("Announcement", "delete")
                            ?
                            <Popconfirm
                                title="Delete the Client"
                                description="Are you sure to delete?"
                                okText="Yes"
                                cancelText="No"
                                onConfirm={()=>handleDelect(record)}
                            >
                                <DeleteOutlined className="employee-details_delete" />
                            </Popconfirm>:<></>
                    }
            </Space>
            )
        }
    ]

    return<HRMLayout>
    <div className="employee-details">
                <div className="employee-details_head">
                    <h2 className="employee-details_head-text">Announcement Mangement</h2>
                    {
                        check_button_permission("Announcement", "create")
                            ?
                        <Button className="employee-details_head-create" onClick={OnOpen}>+ Add New Announcement</Button>
                        :<></>
                    }
                </div>

                <Table columns={filteredColumns(colums,"Announcement")}  dataSource={announcement} pagination={false} className="employee-details_table" />

                <Drawer title={`${heading} Announcement`} width={570} placement="right" onClose={() => setOpen(false)} open={open} className="employee-details_drawer">
                    {
                        heading == "Edit" ? (<CreateAnnocement ModalClose={ModalClose} editdraw={editdraw} />) : <></>
                    }
                    {
                        heading == "Create" ? (<CreateAnnocement ModalClose={ModalClose} editdraw={null} />) : <></>
                    }
                </Drawer>

            </div>
    </HRMLayout>
}

export default AnnouncementManagement