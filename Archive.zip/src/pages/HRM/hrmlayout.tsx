import React, { ReactNode } from 'react';
import HRMnav from '../../components/Side_Nav/HRMnav';
import withApollo from '../../config'

type HRMLayoutProps = {
    children: ReactNode;
};

const HRMLayout: React.FC<HRMLayoutProps> = ({ children }) => {
    return (
      <div className='setting_nav'>
      {/* <div>
      <HRMnav />
      </div> */}
      <div className='settings_style'>
        {children}
      </div>
    </div>
    );
  };

export default HRMLayout
