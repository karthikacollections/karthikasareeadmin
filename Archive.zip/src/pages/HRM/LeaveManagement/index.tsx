import {
  Button,
  Drawer,
  Popconfirm,
  Space,
  Table,
  Modal,
  Select,
  DatePicker,
} from "antd";
import React, { useEffect, useRef, useState } from "react";
import CreateLeaveManagement from "./create";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@apollo/client";
import {
  DELETE_LEAVE,
  GET_LEAVE,
  GET_LEAVE_EMP,
  UPDATE_YEARLY_LEAVE,
  GET_YEARLY_LEAVE,
  GET_YEARLY_LEAVE_ADMIN,
} from "@/helpers";
import moment from "moment";
import HRMLayout from "../hrmlayout";
import { useAuth } from "../../../components/auth";
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";
import { valueFromAST } from "graphql";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

export const LeaveManagemant: React.FC<any> = () => {
  const [open, setOpen] = useState<any>(false);
  const [heading, setHeading] = useState<any>(null);
  const [editdraw, setEditdraw] = useState("");
  const [Popopen, setPopOpen] = useState(false);
  const [reloadCreateTimesheet, setReloadCreateTimesheet] = useState(false);
  const [title, setTitle] = useState("");
  const [leaveData, setLeaveData] = useState([]);
  const [userData, setUser] = useState<any>();
  const [yearly, setYearly] = useState<any>([]);
  const [yearlyAdmin, setYearlyAdmin] = useState([]);
  const [empleaveData, setEmpLeaveData] = useState([]);
  const [reload, setReload] = useState(false);
  const { check_button_permission, filteredColumns, userInEmploye, user } =
    useAuth();
  const [selectedValue, setSelectedValue] = useState("");
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const { data: yearlyAdminData, refetch: reAdminYearlyData } = useQuery(
    GET_YEARLY_LEAVE_ADMIN
  );
  const { data: yearlyData, refetch: reYearlyData } = useQuery(
    GET_YEARLY_LEAVE,
    {
      variables: {
        employee_id:
          user.email === "admin@gmail.com"
            ? userData
            : userInEmploye?.mst_employeedetails[0]?.id,
      },
    }
  );
  const tableRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (yearlyAdminData) {
      let datum = yearlyAdminData?.mst_yearly_leave;
      setYearlyAdmin(datum);
    }
  }, [yearlyAdminData]);

  useEffect(() => {
    if (yearlyData) {
      let data = yearlyData?.mst_yearly_leave;
      setYearly(data);
    }
  }, [yearlyData]);
  const handleSelectChange = (value: any) => {
    setSelectedValue(value);
  };

  const check_leaveDate = (param: any) => {
    let from_Date = new Date(param?.from_date);
    let convert_fromDate = moment(param?.from_date).format("DD-MM-YYYY");
    let currentDate = new Date();
    let convert_ToDate = moment(currentDate).format("DD-MM-YYYY");
    const isAdmin = user.email === "admin@gmail.com";
    if (isAdmin) {
      return false; // Admins can edit and delete any data
    } else {
      if (
        convert_fromDate === convert_ToDate ||
        from_Date.getTime() > currentDate.getTime()
      ) {
        return false;
      } else {
        return true;
      }
    }
  };
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, "0");
  const day = String(currentDate.getDate()).padStart(2, "0");
  const formattedDate = `${year}-${month}-${day}`;
  const handleDateChange = (date: any, dateString: string) => {
    setSelectedDate(dateString);
  };
  const formattedDateStr = formattedDate.toString().split("T")[0];
  const {
    error: empError,
    loading: empLoading,
    data: empDatas,
    refetch,
  } = useQuery(GET_LEAVE_EMP, {
    variables: { id: userInEmploye?.mst_employeedetails[0]?.id },
  });
  const {
    error,
    loading,
    data: LeaveData,
    refetch: refetLeaveData,
  } = useQuery(GET_LEAVE);
  const [deleteLeave] = useMutation(DELETE_LEAVE);
  const [updateYearly] = useMutation(UPDATE_YEARLY_LEAVE);

  useEffect(() => {
    refetLeaveData();
  }, [userInEmploye]);

  useEffect(() => {
    if (LeaveData) {
      let data = LeaveData?.mst_leave_management;
      setLeaveData(data);
      refetLeaveData();
    }
  }, [LeaveData]);

  useEffect(() => {
    if (empDatas) {
      let data = empDatas?.mst_leave_management;
      setEmpLeaveData(data);
      refetch();
    }
  }, [empDatas]);

  const OnOpen = () => {
    setOpen(true);
    refetch();
    refetLeaveData();
    reYearlyData();
    setHeading("Create");
  };

  const handleChange = (record: any) => {
    setEditdraw(record);
    setOpen(true);
    refetch();
    refetLeaveData();
    setHeading("Edit");
    setReload(!reload);
  };

  useEffect(() => {
    reYearlyData();
  }, [userData]);

  const ref_yearly_leave = (id: string) => {
    setUser(id);
    reYearlyData();
  };

  const handleDelete = (id: any) => {
    const leaveType = id?.mst_leavemanage_mst_leavetype?.reason;
    const employeeName = id?.emp_name;
    const adminLeave = id?.count;
    const adminCount = yearly?.[0]?.casual_leave;

    deleteLeave({
      variables: id,
      update: (cache: any) => {
        refetch();
        refetLeaveData();
        showModal("Deleted");
      },
    });

    let empId;
    let casualLeave;

    if (leaveType !== "Un Paid Leave") {
      if (user?.email === "admin@gmail.com") {
        empId = employeeName;
        casualLeave = adminLeave + adminCount;
      } else {
        empId = userInEmploye?.mst_employeedetails[0]?.id;
        casualLeave =
          empDatas?.mst_leave_management[
            empDatas?.mst_leave_management.length - 1
          ]?.count + yearlyData?.mst_yearly_leave[0]?.casual_leave;
      }

      updateYearly({
        variables: {
          employee_id: empId,
          casual_leave: casualLeave,
        },
      });
    }
    setReload(!reload);
  };

  const search_user = (data: any) => {
    return selectedValue
      ? data.filter((u: any) =>
          u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
        )
      : data;
  };

  const search = (data: any) => {
    return selectedValue
      ? data.filter((u: any) =>
          u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
        )
      : data;
  };

  var count = 0;

  const columns = [
    {
      title: "S.no",
      dataIndex: "s.no",
      render: () => ++count,
    },
    {
      title: "Employee Name",
      render: (value: any) => {
        let name = value?.mst_employee_leave?.name;
        return (
          <>
            <p>{name}</p>
          </>
        );
      },
    },
    {
      title: "Reason",
      render: (value: any) => {
        let reason = value?.mst_leave_type?.reason;
        let textColor = reason === "Work From Home" ? "green" : "black";

        return (
          <>
            <p style={{ color: textColor }}>{reason}</p>
          </>
        );
      },
    },
    {
      title: "From",
      render: (recod: any) => {
        let formDate = moment(recod?.from_date).format("DD MMMM YYYY");

        return <p>{formDate}</p>;
      },
    },
    {
      title: "To",
      render: (recod: any) => {
   let toDate = moment(recod?.to_date).format("DD MMMM YYYY");
 return <p>{toDate}</p>;
      },
    },
    {
      title: "Count",
      dataIndex: "count",
      key: "count",
    },
    {
      title: "Comments",
      dataIndex: "comments",
      key: "comments",
    },
    {
      title: "Action",
      key: "action",
      render: (record: any) => {
        let check_Leave_date = check_leaveDate(record);
        return check_Leave_date ? (
          <></>
        ) : (
          <Space size="large">
            {check_button_permission("Leave Management", "edit") ? (
              <EditOutlined
                onClick={() => handleChange(record)}
                className="employee-details_edit"
              />
            ) : (
              <></>
            )}
            {check_button_permission("Leave Management", "delete") ? (
              <Popconfirm
                title="Delete Leave Details"
                description="Are you sure to delete this Leave details?"
                okText="Yes"
                cancelText="No"
                onConfirm={() => handleDelete(record)}
              >
                <DeleteOutlined
                  className="employee-details_delete"
                  onClick={() => ref_yearly_leave(record?.emp_name)}
                />
              </Popconfirm>
            ) : (
              <></>
            )}
          </Space>
        );
      },
    },
  ];

  let check = check_button_permission("Leave Management", "create");

  const showModal = (param: any) => {
    setPopOpen(true);
    refetch();
    refetLeaveData();
    setTitle(param);
  };

  const handleOk = () => {
    setPopOpen(false);
  };

  const handleCancel = () => {
    setPopOpen(false);
  };

  const ModalClose = () => {
    setOpen(false);
    setReloadCreateTimesheet((prevState) => !prevState);
  };

  const seartch = (data: any) => {
    return selectedValue
      ? data.filter((u: any) =>
          u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
        )
      : data;
  };

  let empData = [...(LeaveData?.mst_leave_management || [])];
  let sort = empData?.sort((a: any, b: any) => a?.name?.localeCompare(b?.name));

  const search_leave = (param: any) => {
    let currentMonth = moment().format("MMMM");
    let currentYear = moment().format("YYYY");

    let leave_Data = param
      ?.filter(
        (param: any) =>
          moment(param?.from_date).format("YYYY") === currentYear &&
          moment(param?.from_date).format("MMMM") === currentMonth
      )
      ?.sort((a: any, b: any) => {
        let aDate: any = new Date(a?.from_date);

        let bDate: any = new Date(b?.from_date);

        return aDate - bDate;
      });
    if (selectedDate) {
 

      let month = moment(selectedDate).format("MMMM");
      let year = moment(selectedDate).format("YYYY");
      let filterLeaveData = param
        ?.filter(
          (param: any) =>
            moment(param?.from_date).format("YYYY") === year &&
            moment(param?.from_date).format("MMMM") === month
        )
        ?.sort((a: any, b: any) => {
          let aDate: any = new Date(a?.from_date);
          let bDate: any = new Date(b?.from_date);
          return aDate - bDate;
        });
      return filterLeaveData;
    }
    return leave_Data;
  };

  const exportPdfFile = () => {
    const input = tableRef.current;
    if (input) {

      const table = input.querySelector('.ant-table') as HTMLElement | null;
      const lastHeader = table?.querySelector('.ant-table-thead th:last-child') as HTMLElement | null;
      const lastCells = table?.querySelectorAll('.ant-table-tbody td:last-child') as NodeListOf<HTMLElement> | null;

      if (lastHeader) lastHeader.style.display = 'none';
      lastCells?.forEach(cell => cell.style.display = 'none');
      html2canvas(input).then((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF();
        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
        pdf.save("table.pdf");

        if (lastHeader) lastHeader.style.display = '';
        lastCells?.forEach(cell => cell.style.display = '');


      });
    }
  };

  return (
    <HRMLayout>
      <div className="employee-details">
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Leave Management</h2>
          <div>
            <DatePicker onChange={handleDateChange} picker="month" />
          </div>
          <div className="employee-details_head-btn">
          <div>
            <Button
              className="employee-details_head-create"
              onClick={exportPdfFile}
            >
              Export PDF
            </Button>
          </div>

          {check_button_permission("Leave Management", "create") ? (
            <Button className="employee-details_head-create" onClick={OnOpen}>
              + Add Leave
            </Button>
          ) : (
            <></>
          )}
          </div>
        </div>
        {user?.email === "admin@gmail.com" ? (
          <div ref={tableRef}>
            <Table
              columns={filteredColumns(columns, "Leave Management")}
              dataSource={search_leave(leaveData)}
              pagination={false}
              className="employee-details_table"
            />
          </div>
        ) : (
          <Table
            columns={filteredColumns(columns, "Leave Management")}
            dataSource={search_leave(empleaveData)}
            pagination={false}
            className="employee-details_table"
          />
        )}
        <Drawer
          title={`${heading} Leave`}
          width={570}
          placement="right"
          onClose={ModalClose}
          open={open}
          className="employee-details_drawer"
        >
          {heading == "Edit" ? (
            <CreateLeaveManagement
              ModalClose={ModalClose}
              editdraw={editdraw}
              key={reloadCreateTimesheet}
              showModal={showModal}
              reload={reload}
            />
          ) : (
            <></>
          )}
          {heading == "Create" ? (
            <CreateLeaveManagement
              ModalClose={ModalClose}
              editdraw={null}
              key={reloadCreateTimesheet}
              showModal={showModal}
              reload={reload}
            />
          ) : (
            <></>
          )}
        </Drawer>
      </div>
      <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{ display: "flex", justifyContent: "center" }}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}
            >
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}
      >
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}
          >
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
    </HRMLayout>
  );
};
export default LeaveManagemant;
