import {
  CREATE_LEAVE,
  GET_EMPLOYDETAILS,
  GET_LEAVE,
  GET_LEAVE_LIST,
  UPDATE_LEAVE,
  GET_EMPLOYDETAILS_LEAVE,
  GET_YEARLY_LEAVE,
  UPDATE_YEARLY_LEAVE,
  COUNT_LEAVE,
} from "@/helpers";
import { useMutation, useQuery } from "@apollo/client";
import {
  Button,
  DatePicker,
  DatePickerProps,
  Form,
  Select,
  Space,
  message,
  Input,
  Table,
} from "antd";
import dayjs from "dayjs";
import moment, { months } from "moment";
import React, { useEffect, useRef, useState } from "react";
import { useAuth } from "../../../components/auth";

const CreateLeaveManagement: React.FC<any> = ({
  ModalClose,
  editdraw,
  showModal,
  reload
}) => {
  const [form] = Form.useForm();
  // const [formClear, setFromClear] = useSa
  const formRef = useRef(null);
  const [formDate, setFormDate] = useState<any>("");
  const [toDate, setToDate] = useState<any>("");
  const [leaveDateList, setLeaveDateList] = useState<any>(null);
  const [emp, setEmp] = useState<any>([]);
  const [peremp, setPerEmp] = useState([]);
  const [yearly, setYearly] = useState([]);
  const [leaveList, setLeaveList] = useState([]);
  const { TextArea } = Input;
  const [reasonSelected, setReasonSelected] = useState(false);
  const { user, userInEmploye } = useAuth();
  const [userData, setUser] = useState<any>();
  const [leaveTypeID, setLeaveType] = useState("");
  const [sickLeave, setSickLeave] = useState<any>();
  const [casualLeave, setCasualLeave] = useState<any>();
  const [paidLeave, setPaidLeave] = useState<any>();
  const [leaveLeft, setLeaveLeft] = useState<any>();
  const [leaveLimite, setLeaveLimite] = useState(0);
  const [alertLeave, setAlertLeave] = useState("");
  const [LeaveReason, setLeaveReason] = useState("");
  const [editLeaveLeft, setEditLeaveLeft] = useState(0);
  const [leaveCount, setLeaveCount] = useState(0);
  const [updateLeave] = useMutation(UPDATE_LEAVE, { errorPolicy: "all" });
  const [updateYearly] = useMutation(UPDATE_YEARLY_LEAVE, {
    errorPolicy: "all",
  });
  const [updateCount] = useMutation(COUNT_LEAVE, { errorPolicy: "all" });
  const [
    createLeave,
    { loading: leaveLoad, error: leaveError, data: leaveData },
  ] = useMutation(CREATE_LEAVE, { errorPolicy: "all" });
  const {
    error,
    loading,
    data: empData,
    refetch: reloadEmpData,
  } = useQuery(GET_EMPLOYDETAILS);


  useEffect(() => {
    if (empData) {
      let data = [...(empData?.mst_employeedetails || [])];
      let sort = data?.sort((a: any, b: any) => a?.name.localeCompare(b?.name));
      setEmp(sort);
      reloadEmpData();
    }
  }, [empData , reload]);

  const {
    error: empError,
    loading: empLoading,
    data: empDatas,
    refetch,
  } = useQuery(GET_EMPLOYDETAILS_LEAVE, {
    variables: {
      id:
        user.email === "admin@gmail.com"
          ? userData
          : userInEmploye?.mst_employeedetails[0]?.id,
    },
  });

  useEffect(() => {
    if (empDatas) {
      let data = empData?.mst_employeedetails;
      setPerEmp(data);
      refetch();
    }
  }, [userData]);

  const { data: yearlyData, refetch: reYearlyData } = useQuery(
    GET_YEARLY_LEAVE,
    {
      variables: {
        employee_id:
          user.email === "admin@gmail.com"
            ? userData
            : userInEmploye?.mst_employeedetails[0]?.id,
      },
    }
  );

  useEffect(() => {
    if (yearlyData) {
      let data = yearlyData?.mst_yearly_leave;
      setYearly(data);
      reYearlyData();
    }
  }, [yearlyData]);

  const {
    error: listError,
    loading: listLoad,
    data: leaveListData,
    refetch: refetLeaveList,
  } = useQuery(GET_LEAVE_LIST);

  useEffect(() => {
    if (leaveListData) {
      let data = leaveListData?.mst_leave_type;
      setLeaveList(data);
      refetLeaveList();
    }
  }, [leaveListData]);

  const Calculate_Inbetween_date = (param: any) => {
    let data: any = [];
    let currentDate = new Date(param?.disabledDateTo?.from_date);
    let to_date = new Date(param?.disabledDateTo?.to_date);
    while (currentDate <= to_date) {
      let get_date = new Date(currentDate);
      let convent_date = moment(get_date).format("YYYY-MM-DD");
      data.push(convent_date);
      currentDate.setDate(currentDate.getDate() + 1);
    }

    let leaveList_user: any = [...data];

    return leaveList_user;
  };

  const disabledDate = (current: any) => {
    if (current.day() === 0) {
      return true;
    }
    const weekOfMonth = Math.ceil(current.date() / 7);
    if ([2, 4, 5].includes(weekOfMonth) && current.day() === 6) {
      return true;
    }
    return false;
  };

  const disabledDateForm = (current: any) => {
    let leave_date_user = empDatas?.mst_employeedetails?.map((param: any) =>
      Calculate_Inbetween_date(param)
    );
    if (leave_date_user?.length > 0) {
      let final: any = []?.concat(...leave_date_user);
      const isDateAlreadyAppliedForLeave = final.includes(
        current.format("YYYY-MM-DD")
      );
      if (isDateAlreadyAppliedForLeave) {
        return true;
      }
    }
    let filterLeaveList: any = leaveList.filter(
      (param: any) => param?.id === leaveTypeID
    );
    let piror: any =
      filterLeaveList[0]?.piror_permission !== null
        ? filterLeaveList[0]?.piror_permission
        : 0;
    let startDate = moment(current).startOf("day").add(piror, "days");
    return (current && current < startDate) || !reasonSelected;
  };

  const disabledDateTo = (current: any) => {
    let leave_date_user = empDatas?.mst_employeedetails?.map((param: any) =>
      Calculate_Inbetween_date(param)
    );

    if (leave_date_user?.length > 0) {
      let final: any = []?.concat(...leave_date_user);
      const isDateAlreadyAppliedForLeave = final.includes(
        current.format("YYYY-MM-DD")
      );
      if (isDateAlreadyAppliedForLeave) {
        return true;
      }
    }
    return current < dayjs(formDate).add(0, "day") || !reasonSelected;
  };

  const handleReasonChange = (value: React.SetStateAction<string>) => {
    setLeaveType(value);

    const selecteLeaveType = leaveList?.filter((val: any) => {
      val;
      return val.id == value;
    });

    const getLeaveType = selecteLeaveType.map((leave: any) => {
      setLeaveReason(leave.reason);
    });

    setReasonSelected(!!value); // Set reasonSelected to true if a reason is selected
  };

  const onFinishFailed = (error: any) => {
    message.error("error");
  };

  const onCancel = () => {
    ModalClose(null);
    setFormDate(null);
    form.resetFields();
    setToDate(null);
    setUser("");
  };

  function generateDateList(fromDate: any, toDate: any) {
    const dateList = [];
    let currentDate = new Date(fromDate);
    while (currentDate <= toDate) {
      // Check if the current day is Sunday or the second, fourth, or fifth Saturday
      if (!(currentDate.getDay() === 0)) {
        let week: number = getWeekOfMonth(currentDate);
        let day = currentDate.getDay();
        if (day === 6 && [2, 4, 5].includes(week)) {
          // dateList.push(new Date(currentDate))
        } else {
          let date = new Date(currentDate);
          dateList.push(moment(date).format("DD-MM-YYYY"));
        }
      }

      currentDate.setDate(currentDate.getDate() + 1);
    }
    return dateList;
  }

  function getWeekOfMonth(date: any) {
    const firstDay = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    return Math.ceil((date.getDate() + firstDay) / 7);
  }

  const fetchUserLimiteLeave = (value: any) => {
    
    const date = new Date();
    const month = date.getMonth() + 1;
    const selectedEmployee = empData?.mst_employeedetails?.find(
      (emp: any) => {
        return emp.id === value
      });
    if (!selectedEmployee) {
      setEditLeaveLeft(month);
      return;
    }
    const getEmpLeave = selectedEmployee.mst_leave_employee;
    const addLeaveCount = getEmpLeave?.reduce((total: number, leave: any) => {
      return total + (leave.count || 0);
    }, 0);
    const showLeave = month - addLeaveCount;
    setEditLeaveLeft(showLeave);
  };

  useEffect(() => {
    if (editdraw && emp)  {
      

      fetchUserLimiteLeave(editdraw.emp_name);
      let { from_date, to_date, emp_name, reason } = editdraw;
      let data = { ...editdraw, editLeaveLeft };

      setUser(emp_name);
      data.from_date = dayjs(from_date);
      data.to_date = dayjs(to_date);
      data.reason = reason;

      setFormDate(dayjs(from_date));
      setToDate(dayjs(to_date));
      setLeaveLeft(data.editLeaveLeft)
      form.setFieldsValue(data);

    } else {
      form.resetFields();
      setUser("");
      setFormDate("");
      setToDate("");
    }
  }, [editdraw, editLeaveLeft , emp]);

  const onChangeFormDate: DatePickerProps["onChange"] = (dateString: any) => {
    setFormDate(dateString);

    if (dateString === null) {
      setLeaveDateList([]);
    }
  };

  const onChangeToDate: DatePickerProps["onChange"] = (dateString: any) => {
    setToDate(dateString);
    if (dateString === null) {
      setLeaveDateList([]);
    }
  };

  const calculateDaysDifference = (fromDat: any, toDate: any) => {
    const date1 = new Date(fromDat);
    const date2 = new Date(toDate);

    const timeDifferenceInMilliseconds = date2.getTime() - date1.getTime();
    const timeDifferenceInSeconds = Math.ceil(
      timeDifferenceInMilliseconds / (1000 * 60 * 60 * 24)
    );
    if (editdraw) {
      return timeDifferenceInSeconds + 1;
    } else {
      return timeDifferenceInSeconds;
    }
  };

  useEffect(() => {
    if (formDate && toDate && !editdraw) {
      const daysDifference = calculateDaysDifference(
        formDate.toISOString(),
        toDate.toISOString()
      );
      setLeaveCount(daysDifference);

      setLeaveLeft(() => leaveLimite - daysDifference);

      if (leaveLeft < 0) {
        setAlertLeave(`You can only apply the limited Leave`);
      }
    }
  }, [formDate, toDate, leaveCount]);

  useEffect(() => {
    if (formDate && toDate && editdraw && reload) {
      const daysDifference = calculateDaysDifference(
        formDate.toISOString(),
        toDate.toISOString()
      );
      setLeaveCount(daysDifference);
    }
  }, [formDate, toDate, editdraw]);

  const onFinish = async (value: any) => {
    const fromDates = new Date(formDate);
    const toDates = new Date(toDate);

    if (leaveLeft < 0 && LeaveReason !== "Un Paid Leave") {
      message.error("You Can't apply the leave , please apply the paid Leave");
      return;
    }

    if (editdraw) {

      if (leaveCount <= leaveLeft) {
        value.id = editdraw.id;
        const date1 = new Date(value.from_date);
        const date2 = new Date(value.to_date);
        const past_To_date = new Date(editdraw.to_date);
        const past_From_date = new Date(editdraw.from_date);
        const timeDifferenceInMilliseconds = date2.getTime() - date1.getTime();
        const past_timeDifferenceInMilliseconds =
          past_To_date.getTime() - past_From_date.getTime();
        let present_date = calculateDaysDifference(
          formDate.toISOString(),
          toDate.toISOString()
        );
        let past_date = calculateDaysDifference(
          dayjs(editdraw.from_date).toISOString(),
          dayjs(editdraw.to_date).toISOString()
        );
        let validate = present_date - past_date;
        const timeDifferenceInSeconds = Math.ceil(
          timeDifferenceInMilliseconds / (1000 * 60 * 60 * 24)
        );
        const timeDifferenceInSeconds_past = Math.ceil(
          past_timeDifferenceInMilliseconds / (1000 * 60 * 60 * 24)
        );
        value.count = calculateDaysDifference(
          formDate.toISOString(),
          toDate.toISOString()
        );
        value.leave_period = leaveDateList;

        let filterValueType = leaveList?.filter((data: any) => {
          return data.id === value.reason;
        });

        let limitedDate = filterValueType.map((data: any) => {
          let availableLeaveCount = 0;

          if (data.reason === "Casual Leave") {
            availableLeaveCount =
              yearlyData?.mst_yearly_leave[0]?.casual_leave || 0;
          } else if (data.reason === "Sick Leave") {
            availableLeaveCount =
              yearlyData?.mst_yearly_leave[0]?.casual_leave || 0;
          }

          return data.days - availableLeaveCount;
        });
        value.leave_period = generateDateList(date1, date2);

        let checkYealyLeave =
          validate - yearlyData?.mst_yearly_leave[0]?.casual_leave;

        // limitedDate[0] >= timeDifferenceInSeconds ?

        // checkYealyLeave >= 0 ?
        await updateLeave({ variables: value })
          .then((res) => {
            ModalClose(null);
            form.resetFields();
            showModal("Updated");
            message.success("Update");
          })
          .catch((error) => {
            message.error("error");
          });
      }
      else {
        message.error("You Can't Update the leave , please apply the paid Leave");
      }

      // :alert("Please select your limited leaves");
    } else {
      if (user?.email !== "admin@gmail.com") {
        value.emp_name = userInEmploye?.mst_employeedetails[0]?.id;
      }
      const date1 = new Date(value.from_date);
      const date2 = new Date(value.to_date);
      const timeDifferenceInMilliseconds = date2.getTime() - date1.getTime();
      const timeDifferenceInSeconds = Math.ceil(
        timeDifferenceInMilliseconds / (1000 * 60 * 60 * 24)
      );
      value.count = calculateDaysDifference(
        formDate.toISOString(),
        toDate.toISOString()
      );

      let availableLeaveCount =
        yearlyData?.mst_yearly_leave[0]?.casual_leave || 0;

      let leaveType = "";
      let limitedDate = leaveList?.map((data: any) => {
        let filterLeaveList: any = leaveList.filter(
          (param: any) => param?.id === leaveTypeID
        );

        filterLeaveList.map((datas: any) => (leaveType = datas.reason));
        if (leaveType === "Un Paid Leave") {
          return data.days * 24 * 60 * 60;
        } else {
          return availableLeaveCount;
        }
      });

      let form_date = value?.from_date;
      let to_date = value?.to_date;
      value.from_date = dayjs(form_date).format("YYYY-MM-DD");
      value.to_date = dayjs(to_date).format("YYYY-MM-DD");
      value.leave_period = generateDateList(form_date, to_date);
      if (leaveType !== "Un Paid Leave") {
        value.casual_leave = value?.count;
      }
      await createLeave({ variables: value })
        .then(async (res) => {
          if (res) {
            await refetch();
            ModalClose(null);
            form.resetFields();
            setFormDate("");
            setToDate("");
            setUser("");
            showModal("Created");

            if (leaveType !== "Un Paid Leave") {
              await updateYearly({
                variables: {
                  employee_id:
                    user?.email === "admin@gmail.com"
                      ? userData
                      : userInEmploye?.mst_employeedetails[0]?.id,
                  casual_leave: availableLeaveCount - value.count,
                },
              });
            }
          } else {
            message.error("error");
          }
        })
        .catch((error) => {
          message.error("error");
        });
    }
  };


  const selectEmpolyeeName = (value: any) => {
    setUser(value);
    const date = new Date();
    const month = date.getMonth() + 1;
    const selectedEmployee = empData?.mst_employeedetails?.find((emp: any) => {
      return emp.id === value
    }
    );

    if (!selectedEmployee) {
      // setLeaveLeft(month);
      setLeaveLimite(month);
      return;
    }
    const getEmpLeave = selectedEmployee.mst_leave_employee;
    const sumLeaveCount = getEmpLeave?.reduce((total: number, leave: any) => {
      return total + (leave.count || 0);
    }, 0);
    const showLeave = month - sumLeaveCount;

    setLeaveLeft(showLeave);
    setLeaveLimite(showLeave);



  };


  return (
    <>
      <Form
        name="LeaveManagement"
        layout="vertical"
        onFinish={onFinish}
        autoComplete="off"
        form={form}
        ref={formRef}
        className="employee-details_form"
      >
        <Form.Item
          label="Employee Name"
          name="emp_name"
          required={false}
          rules={[
            {
              required: user?.email === "admin@gmail.com" ? true : false,
              message: "Please Select the Employee Name!",
            },
          ]}
        >
          {user?.email === "admin@gmail.com" ? (
            <Select
              className="employee-details_form_item-input"
              showSearch
              allowClear
              filterOption={(input, option: any) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
              onChange={selectEmpolyeeName}
            >
              {emp?.map((data: any) => {
                return (
                  <>
                    {data.status ? (
                      <Select.Option value={data.id} key={data.id}>
                        {data.name}
                      </Select.Option>
                    ) : (
                      <></>
                    )}
                  </>
                );
              })}
            </Select>
          ) : (
            <Select
              className="employee-details_form_item-input"
              disabled
              defaultValue={userInEmploye?.mst_employeedetails[0]?.name}
              value={userInEmploye?.mst_employeedetails[0]?.name}
              onChange={(value: string[]) => setUser(value)}
            >
              {userInEmploye?.mst_employeedetails.map((data: any) => (
                <Select.Option value={data.id} key={data.id}>
                  {data.name}
                </Select.Option>
              ))}
            </Select>
          )}
        </Form.Item>
        <Form.Item
          label="Reason"
          name="reason"
          required={false}
          rules={[{ required: true, message: "Please Select the Reason!" }]}
        >
          <Select
            className="employee-details_form_item-input"
            allowClear
            onChange={handleReasonChange}
          >
            {leaveList.map((data: any) => {
              if (
                (data.reason === "Casual Leave" ||
                  data.reason === "Sick Leave") &&
                empDatas?.mst_employeedetails[0]?.mst_destination?.name ===
                "Contract"
              ) {
                return null;
              }
              return data.reason === "Casual Leave" &&
                casualLeave >= data.days ? (
                <Select.Option value={data.id} key={data.id} disabled>
                  {data.reason}
                </Select.Option>
              ) : data.reason === "Sick Leave" && sickLeave >= data.days ? (
                <Select.Option value={data.id} key={data.id} disabled>
                  {data.reason}
                </Select.Option>
              ) : data.reason === "Un Paid Leave" && paidLeave >= data.days ? (
                <Select.Option value={data.id} key={data.id} disabled>
                  {data.reason}
                </Select.Option>
              ) : (
                <Select.Option
                  value={data?.id}
                  key={data?.id}
                  disabled={
                    (leaveLeft <= 0 && data?.reason !== "Un Paid Leave") ||
                    (leaveLeft > 0 && data?.reason === "Un Paid Leave")
                  }
                >
                  {data?.reason}
                </Select.Option>
              );
            })}
          </Select>
        </Form.Item>

        <Form.Item label="Comments" name="comments" required={false}>
          <TextArea rows={4} placeholder="Comments" autoSize={false} />
        </Form.Item>

        {user?.email === "admin@gmail.com" ? (
          <Space>
            <Form.Item
              label="From"
              name="from_date"
              required={false}
              rules={[
                { required: true, message: "Please Select the From Date" },
              ]}
            >
              <DatePicker
                style={{ width: 230 }}
                // disabledDate={disabledDateForm}
                disabledDate={disabledDate}
                onChange={onChangeFormDate}
              />
            </Form.Item>

            <Form.Item
              label="To"
              name="to_date"
              required={false}
              rules={[{ required: true, message: "Please Select the To Date" }]}
            >
              <DatePicker
                style={{ width: 230 }}
                // disabledDate={disabledDateTo}
                disabledDate={disabledDate}
                onChange={onChangeToDate}
              />
            </Form.Item>
          </Space>
        ) : (
          <Space>
            <Form.Item
              label="Form"
              name="from_date"
              required={false}
              rules={[
                { required: true, message: "Please Select the From Date" },
              ]}
            >
              <DatePicker
                style={{ width: 230 }}
                disabled={
                  user?.email === "admin@gmail.com" ? false : !reasonSelected
                }
                disabledDate={disabledDateForm}
                onChange={onChangeFormDate}
              />
            </Form.Item>

            <Form.Item
              label="To"
              name="to_date"
              required={false}
              rules={[{ required: true, message: "Please Select the Date" }]}
            >
              <DatePicker
                style={{ width: 230 }}
                disabled={
                  user?.email === "admin@gmail.com" ? false : !reasonSelected
                }
                disabledDate={disabledDateTo}
                onChange={onChangeToDate}
              />
            </Form.Item>
          </Space>
        )}

        <Form.Item label="Total Leave" name="count" required={false}>
          {formDate && toDate ? <>{leaveCount}</> : null}
        </Form.Item>
        {/* <Form.Item label="Total Leave" name="leave_left" required={false}>
          {formDate && toDate ? <>{leaveCount}</> : null}
        </Form.Item> */}

        <Form.Item>
          <div className="employee-details_submit">
            <Space>
              <Button
                htmlType="button"
                className="employee-details_cancel-btn"
                onClick={onCancel}
              >
                Cancel
              </Button>

              <Button htmlType="submit" className="employee-details_submit-btn">
                Submit
              </Button>
            </Space>
          </div>
        </Form.Item>
      </Form>

      <div>
        {empDatas?.mst_employeedetails[0]?.mst_destination?.name ===
          "Contract" ? null : (
          // editdraw ? <h3>Leaves Left:{editLimitData}</h3>
          // :
          <h3>
            Leaves Left:{" "}
            {leaveLeft < 0 && LeaveReason !== "Un Paid Leave"
              ? alertLeave
              : LeaveReason == "Un Paid Leave"
                ? 0
                : leaveLeft}
          </h3>
        )}
      </div>
    </>
  );
};
export default CreateLeaveManagement;
