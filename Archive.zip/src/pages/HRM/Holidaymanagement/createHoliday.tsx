import React, { useRef, useEffect, useState } from 'react'
import dayjs from "dayjs";
import moment from 'moment';
import { Form, Input, Button, Select, Space, DatePickerProps, Drawer, DatePicker, } from 'antd';
import { UPDATE_HOLIDAY, CREATE_HOLIDAY } from '../../../helpers/mutation';
import { GET_HOLIDAYMANAGEMENT } from '../../../helpers/queries';
import { useMutation, useQuery } from "@apollo/client";

const createHoliday: React.FC<any> = ({ ModalClose, editdraw,showModal }) => {

  const [form] = Form.useForm();
  const formRef = useRef(null);
  const [date, setEdate] = useState(null)
  const [editforminitaldata, seteditforminitaldata]: any = useState(false);
  const [formtype, setformtype] = useState("create")
  
  const onChangedoe: DatePickerProps["onChange"] = (dateString: any) => {
    setEdate(dateString);
  };

  const [createHoliday, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_HOLIDAY, {
    errorPolicy: 'all',
  });

  const [
    updateHoliday,
    { loading: updateloading, error: updateerror, data: updatedataAddress },
  ] = useMutation(UPDATE_HOLIDAY, {
    errorPolicy: "all",
  });

  const {
    error: userError,
    loading: userLoading,
    data: dataHoliday,
    refetch: refetHoliday,
  } = useQuery(GET_HOLIDAYMANAGEMENT
    , {
      variables: {},
    });

    useEffect(() => {
      if (editdraw) {
          let data = JSON.parse(JSON.stringify(editdraw))
          data.date = dayjs(editdraw.date)
          
          form.setFieldsValue(data)
          setformtype("edit")
          seteditforminitaldata(data)
      }
  }, [editdraw])

  

  const onFinish = (values: any) => {
  
    if (editdraw) {
      values.id = editdraw?.id
      values.date=dayjs(date).format("YYYY-MM-DD")
      updateHoliday({
        variables: values,
      }).then((response) => {
        refetHoliday()
        ModalClose(null)
        showModal('Updated')
        // setOpen(false)
      });
    }
    else {
      values.date=dayjs(date).format("YYYY-MM-DD")
      createHoliday({
        variables: values,
        
      }).then((response) => {
        ModalClose(null)
        refetHoliday()
        showModal('Created')
        // setOpen(false)
      });
    };
  }

  useEffect(() => {
    if (editdraw) {
        let data = JSON.parse(JSON.stringify(editdraw))
        data.date = dayjs(editdraw.date)
        data.dor = dayjs(editdraw.dor)
        data.date = dayjs(editdraw.date)
        
        form.setFieldsValue(data)
        setformtype("edit")
        seteditforminitaldata(data)
    }
}, [editdraw])

  const onFinishFailed = (errorInfo: any) => {
  };

  return (
    <>
      <Form
        name="basic"
        initialValues={{ remember: true }}
        layout="vertical"
        onFinish={onFinish}

        ref={formRef}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        form={form}
        // onValuesChange={handleValuesChange}
        className="employee-details_form"
      >

        <Form.Item
          label="Date"
          name="date"
          required={false}
          rules={[{ required: true, message: 'Please select date' }]}
          className="employee-details_form_item"
        >
          <DatePicker className="employee-details_form-datepic"
            onChange={onChangedoe}
          />
        </Form.Item>

        <Form.Item
          label="Reason"
          name="reason"
          required={false}
          rules={[{ required: true, message: 'Please enter reason' }]}
          className="employee-details_form_item"
        >
          <Input className="employee-details_form_item-input" />
        </Form.Item>

        <Form.Item >
          <div className="employee-details_submit">
            <Space>
              <Button htmlType="button" className="employee-details_cancel-btn" onClick={() => ModalClose(null)}>
                Cancel
              </Button>
              <Button htmlType="submit" className="employee-details_submit-btn">
                Submit
              </Button>
            </Space>

          </div>
        </Form.Item>
      </Form>
    </>
  )
}
export default createHoliday