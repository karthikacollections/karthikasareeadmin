
import withApollo from '../../../config'
import React, { useEffect, useState, useRef } from 'react';
import { Space, Table, Button, Form, Popconfirm, Drawer, Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { useQuery, useMutation } from "@apollo/client";
import moment from "moment";
import { GET_HOLIDAYMANAGEMENT } from '../../../helpers/queries';
import Create from "./createHoliday";
import { DeleteOutlined, EditOutlined, } from '@ant-design/icons';
import { DELETE_HOLIDAY } from '../../../helpers/mutation'
import HRMLayout from '../hrmlayout'
import { useAuth } from '../../../components/auth'
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";

export const Holiday: React.FC<any> = () => {

    const [holiday, setHoliday] = useState([])
    const [Popopen, setPopOpen] = useState(false);
    const [editdraw, setEditdraw] = useState("")
    const [title, setTitle] = useState("");

    const [open, setOpen] = useState<any>(null);

    const { check_button_permission, filteredColumns } = useAuth()

    const ModalClose = () => {
        setOpen(false)
        refetHoliday()
    }

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
    }
    const {
        error: userError,
        loading: userLoading,
        data: dataHoliday,
        refetch: refetHoliday,
    } = useQuery(GET_HOLIDAYMANAGEMENT, {
        variables: {},
    });

    useEffect(() => {
        if (dataHoliday) {
            let holiday = dataHoliday?.mst_holidaymanagement
            setHoliday(holiday)
        }
    },)

    const [deleteHoliday, { loading, error, data }] = useMutation(DELETE_HOLIDAY);

    const handleDelete = (id: any) => {
        deleteHoliday({
            variables: id,

            update: (cache) => {
                showModal("Deleted");
            },
        });
    }

    interface DataType {
        holiday: any;
        // key: string;
        // reason: string;
        // date: string;
        // income: string;
    }

    const columns: ColumnsType<DataType> = [
        {
            title: 'S.No',
            dataIndex: 'sno',
            key: 'sno',
            render: (text, record, index) => index + 1,
        },
        {

            title: 'Date',
            render: (value) => {
                let dateFormat = moment(value?.date).format("DD MMMM YYYY");
                return (
                    <>
                        <p>{dateFormat}</p>
                    </>
                )
            }
        },
        {
            title: 'Reason',
            render: (value) => {
                return (
                    <>
                        <p>{value?.reason}</p>
                    </>
                )
            }
        },
        {
            title: 'Action',
            key: 'action',
            render: (
                record: any) => (
                <Space size='large'>
                    {
                        check_button_permission("Holidaymanagement", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="employee-details_edit"
                            /> : <></>
                    }

                    {
                        check_button_permission("Holidaymanagement", "delete")
                            ?
                            <Popconfirm
                                title="Delete the task"
                                description="Are you sure to delete ?"
                                okText="Yes"
                                onConfirm={() => handleDelete(record)}
                                cancelText="No"
                            >
                                <DeleteOutlined className="employee-details_delete" />
                            </Popconfirm>
                            : <></>
                    }

                </Space>
            ),
        },
    ]

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
    };

    const handleOk = () => {
        refetHoliday();
        setPopOpen(false);
    };

    const handleCancel = () => {
        setPopOpen(false);
    };

    return (
        <HRMLayout>
            <div className="employee-details">
                <div className="attendance_head">
                    <h2 className="attendance_head-text">Holiday Management</h2>
                    {
                        check_button_permission("Holidaymanagement", "create")
                            ?
                            <Button className="attendance_head-create"
                                onClick={() => setOpen("Create")}
                            >
                                Add New</Button>
                            : <></>
                    }

                </div>

                <Table
                    columns={filteredColumns(columns, "Holidaymanagement")}
                    dataSource={holiday}
                    pagination={false} className="attendance_table" />

                <Drawer
                    title=
                    {`${open} Holiday`}
                    width={570} placement="right"
                    onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}
                >
                    {
                        open == "Edit" ? (<Create ModalClose={ModalClose}
                            showModal={showModal}
                            editdraw={editdraw} />) : <></>
                    }
                    {
                        open == "Create" ? (<Create ModalClose={ModalClose} showModal={showModal}
                            editdraw={null} />) : <></>
                    }
                </Drawer>

            </div>
            <Modal
                open={Popopen}
                title=""
                onOk={handleOk}
                onCancel={handleCancel}
                footer={[
                    <div style={{ display: "flex", justifyContent: "center" }}>
                        <Button
                            key="submit"
                            type="primary"
                            loading={loading}
                            onClick={handleOk}
                            style={{
                                display: "flex",
                                width: "206px",
                                padding: "15px 30px",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "10px",
                                borderRadius: "8px",
                                background: "#252947",
                            }}>
                            OK
                        </Button>
                    </div>,
                ]}
                width={"386px"}>
                <Space
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                    }}>
                    <Image
                        src={PopImage}
                        alt="image"
                        style={{
                            width: "150px",
                            height: "150px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    />
                    <p
                        style={{
                            color: "#101010",
                            textAlign: "center",
                            fontFamily: "revert",
                            fontSize: "32px",
                            fontStyle: "normal",
                            fontWeight: "700",
                            lineHeight: "normal",
                        }}>
                        {`${title}`} Successfully
                    </p>
                </Space>
            </Modal>
        </HRMLayout>
    )



}
export default Holiday