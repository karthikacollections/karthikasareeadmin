import React from 'react'
import HRMLayout from '../hrmlayout'
import { useEffect, useState } from "react";
import { useMutation, useQuery } from "@apollo/client";
import {GET_SPRINT_QUERY,DELETE_SPRINT} from "@/helpers";
import {useAuth} from '../../../components/auth'
import { Button, Drawer, Modal, Popconfirm, Space, Table } from "antd"
import { DeleteOutlined, EditOutlined } from "@ant-design/icons"
import moment from "moment";
import CreateSprintadd from "./create";
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";


export const SprintManagement:React.FC<any>=()=>{
    const [isCreatingSprint, setCreatingSprint] = useState(false);
    const [task, setSprint] = useState <any>([]);
    const [heading, setHeading] = useState('');
    const [editdraw, setEditdraw] = useState("");
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");

    
    
    const { check_button_permission,filteredColumns } = useAuth() // Use a more descriptive variable name

    const OnSprint = () => {
      setCreatingSprint(true); // Set it to true when creating a sprint
      setHeading('Create');
    }
  
    const ModalClose = () => {
      setCreatingSprint(false)
        // refetClientData()
    }
    //for the last 2 icons

    const handleChange = (record: any) => {
      setEditdraw(record)
      setCreatingSprint(true)
      setHeading("Edit")
  }


//get data
    const{
        error,
        loading,
        data:GetSprintData,
        refetch:refetchTask
    }=useQuery(GET_SPRINT_QUERY)

    //Getting Data
    useEffect(()=>{
     if(GetSprintData){
          let res=GetSprintData?.mst_sprints;
           setSprint(res)
      }
  },[GetSprintData])

//Delete Data
    const[deleteSprint,{
        error:delectError,
        loading:delectLoading,
        data
    }]=useMutation(DELETE_SPRINT); 

    //deleting Data
    const handledelete=(id:any)=>{
      deleteSprint({
            variables:id,
            update: (cache: any) => {
                showModal("Deleted");
                refetchTask()
            },
        })
    }
    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
    };

    const handleOk = () => {
        refetchTask();
        setPopOpen(false);
    };

    const handleCancel = () => {
        setPopOpen(false);
    };

   
    var count=0
    const colums=[
        {
            title:'S.no',
            dataIndex:'s.no',
            render:()=>++count
        },
        {
            title:'Sprint Name',
            dataIndex:'sprint_name',
            key:'sprint_name'
        },
        {
            title:'Start Date',
            dataIndex:'start_date',
            key:'start_date'
        },
        {
            title:'End Date',
            dataIndex:'end_date',
            key:'end_date'
          },
          {
     title: 'Project Name',
    render: (value: any) => {
        let project_name = value?.
        mst_sprint_mst_project?.project_name
        return (    
            <p>{project_name}</p>
        )
    }
          },
        
       
          {
            title:'Goal',
            dataIndex:'goal',
            key:'goal'
          },
          {
            title:'Status',
            dataIndex:'status',
            key:'status'
          },
        
   {
            title:'action',
            key:'action',
            render:(record:any)=>(
                <Space size='large'>
                    {
                        check_button_permission("Sprint", "edit")
                            ?
                        <EditOutlined
                            onClick={() => handleChange(record)}
                            className="employee-details_edit"
                        />
                        :<></>
                    }

                    {
                        check_button_permission("Sprint", "delete")
                            ?
                            <Popconfirm
                                title="Delete the Sprint"
                                description="Are you sure to delete this Sprint?"
                                okText="Yes"
                                cancelText="No"
                                onConfirm={()=>handledelete(record)}
                            >
                                <DeleteOutlined className="employee-details_delete" />
                            </Popconfirm>:<></>
                    }
            </Space>
            )
        }
    ]
  return <HRMLayout>
  <div className="employee-details">
                <div className="employee-details_head">
                    <h2 className="employee-details_head-text">Sprint</h2>
                    {
                        check_button_permission("Sprint", "create")
                            ?
                        <Button className="employee-details_head-create" onClick={OnSprint}>+ Add New Sprint</Button>
                        :<></>
                    }
                </div>

                <Table columns={filteredColumns(colums,"Sprint")}  dataSource={task} pagination={{pageSize: 10}} className="employee-details_table" />

                <Drawer title={`${heading} Sprint`} width={570} placement="right" onClose={() => setCreatingSprint(false)} open={isCreatingSprint} className="employee-details_drawer">
                    {
                        heading == "Edit" ? (<CreateSprintadd ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        heading == "Create" ? (<CreateSprintadd ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                    }
                </Drawer>

            </div>
            <Modal
                open={Popopen}
                title=""
                onOk={handleOk}
                onCancel={handleCancel}
                footer={[
                    <div style={{ display: "flex", justifyContent: "center" }}>
                        <Button
                            key="submit"
                            type="primary"
                            loading={loading}
                            onClick={handleOk}
                            style={{
                                display: "flex",
                                width: "206px",
                                padding: "15px 30px",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "10px",
                                borderRadius: "8px",
                                background: "#252947",
                            }}>
                            OK
                        </Button>
                    </div>,
                ]}
                width={"386px"}>
                <Space
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                    }}>
                    <Image
                        src={PopImage}
                        alt="image"
                        style={{
                            width: "150px",
                            height: "150px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    />
                    <p
                        style={{
                            color: "#101010",
                            textAlign: "center",
                            fontFamily: "revert",
                            fontSize: "32px",
                            fontStyle: "normal",
                            fontWeight: "700",
                            lineHeight: "normal",
                        }}>
                        {`${title}`} Successfully
                    </p>
                </Space>
            </Modal>
    </HRMLayout>
}

export default SprintManagement