import React, { useState, useRef, useEffect } from "react";
import {
  Button,
  DatePicker,
  Form,
  Input,
  Space,
  message,
  Select,
  Row,
  DatePickerProps,
  Col,
} from "antd";
import { useMutation, useQuery } from "@apollo/client";
import {
  GET_SPRINT_QUERY,
  INSERT_SPRINT,
  UPDATE_SPRINT,
  GET_PROJECT_NAME,
  } from "@/helpers";
import moment from 'moment';
import dayjs from "dayjs";

const CreateSprintadd: React.FC<any> = ({ ModalClose, editdraw, showModal }) => {
  const [user, setUser] = useState([]);
  const [sprint ,setSprint] = useState([]);
  const formRef = useRef(null);
  const [form] = Form.useForm();
  const [title, setTitle] = useState("");
  const { TextArea } = Input;
  const [date, setEdate] = useState(null);
  const [datee, setAdate] = useState(null);
  const [editforminitaldata, seteditforminitaldata]: any = useState(false);
  const [formtype, setformtype] = useState("create");
//start date
  const onChangedoe: DatePickerProps["onChange"] = (dateString: any) => {
    setEdate(dateString);
  };
  //Target Date
  const onChangedoa: DatePickerProps["onChange"] = (dateString: any) => {
    setAdate(dateString);
  };
  // to get project name in drop down
  //use query
  const {
    error: userError,
    loading: userLoading,
    data: userData,
    refetch: dataRefetcg,
  } = useQuery(GET_PROJECT_NAME);

  //use Effect

  useEffect(() => {
    if (userData) {
      let add = userData?.mst_project;
      setUser(add);
    }
  }, [userData]);
// ----------------------------------------------------
  //update
  const [
    updateSprint,
    { loading: updateloade, error: updateError, data: updateData },
  ] = useMutation(UPDATE_SPRINT, {
    errorPolicy: "all",
  });

  //Get
  const {
    error,
    loading,
    data: announData,
    refetch: refetchSprint,
  } = useQuery(GET_SPRINT_QUERY);

  //create
  const [
    createSprint,
    { loading: AnnounceLoading, error: AnnounceError, data: AnnounceData },
  ] = useMutation(INSERT_SPRINT, {
    errorPolicy: "all",
  });

  const onFinishFailed = (error: any) => {
  };

  useEffect(() => {
    if (editdraw) {
        let data = JSON.parse(JSON.stringify(editdraw))
        data.date = dayjs(editdraw.date)
        data.start_date = dayjs(editdraw.date)
        data.end_date = dayjs(editdraw.date)
        
        form.setFieldsValue(data) 
        setformtype("edit")
        seteditforminitaldata(data)
    }
}, [editdraw])


  const onFinish = (value: any) => {
    
   
    if (editdraw) {
      value.id = editdraw.id;
      updateSprint({ variables: value })
        .then((res: any) => {
          showModal('Updated')
          ModalClose(null);
          refetchSprint();
          message.success(`Update Sprint`);
        })
        .catch((error) => {
          message.error(error);
          message.error("Check the Fileds");
        });
    } else {
      createSprint({ variables: value })
        .then((res: any) => {
          showModal('Created')
          ModalClose(null);
          refetchSprint();
          message.success(`Add New Sprint`);
        })
        .catch((error) => {
          message.error("Check the Fileds");
        });
    }
  };

  return (
    <div>
      <Form
        name="basic"
        layout="vertical"
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        form={form}
        ref={formRef}
        className="assets_form"
      >
        <Form.Item
          label="Sprint Name"
          name="sprint_name"
          required={false}
          rules={[{ required: true, message: "Please enter Sprint Name" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>

       <Form.Item
          label="Start Date"
          name="start_date"
          required={false}
          rules={[{ required: true, message: 'Please select date' }]}
          className="employee-details_form_item"
        >
          <DatePicker className="employee-details_form-datepic"
            onChange={onChangedoe}
          />
        </Form.Item>
        <Form.Item
          label="End Date"
          name="end_date"
          required={false}
          rules={[{ required: true, message: 'Please select date' }]}
          className="employee-details_form_item"
        >
          <DatePicker className="employee-details_form-datepic"
            onChange={onChangedoa}
          />
        </Form.Item>
        <Form.Item
          label="Project Name"
          name="project_associationid"
          required={false}
          rules={[{ required: true, message: "Please Select Project Name!" }]}
          className="employee-details_form_item"
        >
          <Select className="employee-details_form_item-input"
          >
            {user.map((val: any) => {
              return (
                <Select.Option value={val.id} key={val.id}>
                  {val?.project_name}
                </Select.Option>
              );
            })}
          </Select>
        </Form.Item>
        <Form.Item
          label="Goal"
          name="goal"
          required={false}
          rules={[{ required: true, message: "Please enter Goal" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>
        <Form.Item
          label="Status"
          name="status"
          required={false}
          rules={[{ required: true, message: "Please Select the Status" }]}
          className="assets_form_item"
        >
          <Select className="assets_form_item-input">
            <Select.Option value="Planning">Planning</Select.Option>
            <Select.Option value="Active">Active</Select.Option>
            <Select.Option value="Completed">Completed</Select.Option>
          </Select>
        </Form.Item>
        <Form.Item>
          <div className="assets_submit">
            <Space>
              <Button
                htmlType="button"
                className="assets_cancel-btn"
                onClick={() => ModalClose(null)}
              >
                Cancel
              </Button>
              <Button htmlType="submit" className="assets_submit-btn">
                Submit
              </Button>
            </Space>
          </div>
        </Form.Item>
      </Form>
    </div>
  );
};

export default CreateSprintadd;
