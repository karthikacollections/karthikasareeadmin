import React, { useEffect, useState } from "react";
import HRMLayout from "../hrmlayout";
import {
  Button,
  DatePicker,
  DatePickerProps,
  Drawer,
  Form,
  Input,
  InputNumber,
  Popconfirm,
  Select,
  Space,
  Table,
} from "antd";
import { useAuth } from "@/components/auth";
import { useQuery } from "@apollo/client";
import {
  GET_EMPLOYDETAILS,
  GET_PAYROLL_DATA,
  GET_ORGANIZATION,
} from "@/helpers";
import { DeleteOutlined } from "@ant-design/icons";
import moment from "moment";
const ReFund = () => {
  const { user, userInEmploye, check_button_permission } = useAuth();
  const [form] = Form.useForm(); // Create a form instance
  const [openReFundForm, setOpenReFundForm] = useState<any>(null);
  const [emp, setEmp] = useState([]);
  const [userData, setUser] = useState<any>();
  const [reFundData, setReFundData] = useState<any>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [refundDate, setRefundDate] = useState(null);
  const pageSize = 10; // Number of items per page
  const { TextArea } = Input;
  const [selectedValue, setSelectedEmployee] = useState("");
  const [selectedOrgValue, setSelectedOrgValue] = useState("");
  const {
    error: userError,
    loading: userLoading,
    data: dataUser,
    refetch: refetEmployDetails,
  } = useQuery(GET_PAYROLL_DATA, { variables: {} });
  const [filterPayroll, setFilterPayroll] = useState<string | null>(null);


  //selecter
  let empDatas = [...(dataUser?.mst_employeedetails || [])];
  let sort = empDatas?.sort((a: any, b: any) => a?.name.localeCompare(b?.name));

  const handleSelectChange = (value: any) => {
    setSelectedEmployee(value);
  };

  const {
    error: orgError,
    loading: orgLoading,
    data: orgData,
    refetch: refetOrganizationDetails,
  } = useQuery(GET_ORGANIZATION);
  const handleSelectChangeOrganization = (value: any) => {
    // if (value === undefined) {
    //   sessionStorage.removeItem("searchPayRoll");
    // } else {
    //   sessionStorage.setItem("searchPayRoll", value);
    // }
    setSelectedOrgValue(value);
  };

  const onChange: DatePickerProps["onChange"] = (date, dateString) => {
    // setFilter(true);
    // const filterPayroll = userlist.filter((val: any) => {
    //   moment(val?.mst_employeedetails_mst_salary_payments?.paid_on).format(
    //       "MMMM YYYY"
    //     ) === moment(dateString).format("MMMM YYYY")
    //   });
    setFilterPayroll(dateString);
  };
  console.log("filterPayroll",filterPayroll)
  //pagination
  const handleTableChange = (pagination: {
    current: React.SetStateAction<number>;
  }) => {
    setCurrentPage(pagination.current);
  };

  //ReFundForm Drawer
  const handndleCloseRefundForm = () => {
    setOpenReFundForm(false);
    setUser("");
    setRefundDate(null);
    form.resetFields(); // Reset all fields
  };

  //get Employee
  const {
    error,
    loading,
    data: empData,
    refetch: reloadEmpData,
  } = useQuery(GET_EMPLOYDETAILS);

  useEffect(() => {
    if (empData) {
      let data = empData?.mst_employeedetails;
      setEmp(data);
    }
  }, [empData]);
  console.log(reFundData, "reFundData");

  //create Form
  const onFinish = (values: any) => {
    console.log("values:", values);
    setReFundData((prev: any) => [...prev, values]);
    handndleCloseRefundForm();
  };
  const onFinishFailed = (errorInfo: any) => {
    console.log("Failed:", errorInfo);
  };
  const onChangeDate = (dateString: any) => {
    setRefundDate(dateString);
  };


  //Refund Table Actions
  const handlePayClick = (value: any) => {
    console.log(value, "valuevalue");
  };
  const handleDelete = (value: any) => {
    console.log(value, "valuevalue");
  };

  //Refund Table
  const columns = [
    {
      title: "S.No",
      dataIndex: "sno",
      key: "sno",
      render: (text: any, record: any, index: number) =>
        (currentPage - 1) * pageSize + index + 1,
    },
    {
      title: "Date",
      dataIndex: "date",
      key: "date",
      render: (value: { $d: any }) => {
        // Access the actual Date object
        const dateValue = value?.$d || value;
        const dateFormat = dateValue
          ? moment(dateValue).format("DD MMMM YYYY")
          : "Invalid date";
        return <p>{dateFormat}</p>;
      },
    },
    {
      title: "Name",
      dataIndex: "emp_name",
      key: "emp_name",
    },
    {
      title: "ReFund",
      dataIndex: "refund",
      key: "refund",
    },
    {
      title: "Reason",
      dataIndex: "reason",
      key: "reason",
    },
    {
      title: "Actions",
      key: "action",
      render: (value: any) => {
        const isPaid = false;
        return (
          <>
            <Popconfirm
              title="Save the PayRoll"
              description="Are you sure to save this payment?"
              okText="Yes"
              cancelText="No"
              onConfirm={() => {
                handlePayClick(value);
              }}
            >
              <Button
                className="payroll_submit-btn"
                type="default"
                disabled={isPaid}
                style={
                  isPaid
                    ? {
                        backgroundColor: "#1890ff",
                        color: "#ffffff",
                        borderColor: "#1890ff",
                      }
                    : {}
                }
              >
                {isPaid ? "Paid" : "Pay"}
              </Button>
            </Popconfirm>
          </>
        );
      },
    },
    {
      title: "Action",
      key: "action",
      render: (value: any) => {
        //   const isPaid = checkPaymentStatus(value, filterPayroll);
        const isPaid = false;
        return (
          <>
            <Space size="large">
              {check_button_permission("Payroll", "delete") ? (
              <Popconfirm
                title="Delete the task"
                description="Are you sure to delete this task?"
                okText="Yes"
                cancelText="No"
                onConfirm={() => handleDelete(value)}
                disabled={!isPaid}
              >
                <span></span>
                <DeleteOutlined
                  className="role_delete"
                  style={{
                    opacity: !isPaid ? 0.5 : 1,
                    pointerEvents: !isPaid ? "none" : "auto",
                    cursor: !isPaid ? "not-allowed" : "pointer",
                  }}
                />
              </Popconfirm>
              ) : (
               <></>
                )}
            </Space>
          </>
        );
      },
    },
  ];

  return (
    <HRMLayout>
      <div className="refund">
        <div className="refund_head">
          <h2>ReFund</h2>
          <div className="refund_head-select">
            {user.email === "admin@gmail.com" && (
              <Select
                size={"large"}
                onChange={handleSelectChange}
                allowClear
                showSearch // Enable search functionality
                filterOption={(input: string, option: any) =>
                  option.children.toLowerCase().indexOf(input.toLowerCase()) >=
                  0
                }
                placeholder={"Select Employee"}
                className="Asset_selecter"
                style={{ width: "220px", marginRight: "10px" }}
              >
                {sort?.map((emp: any, index: any) => {
                  if (emp.isdeleteat == false) {
                    return (
                      <Select.Option value={emp.name} key={index}>
                        {emp?.name}
                      </Select.Option>
                    );
                  }
                })}
              </Select>
            )}

            {user.email === "admin@gmail.com" && (
              <Select
                size={"large"}
                onChange={handleSelectChangeOrganization}
                allowClear
                showSearch // Enable search functionality
                filterOption={(input: string, option: any) =>
                  option.children.toLowerCase().indexOf(input.toLowerCase()) >=
                  0
                }
                placeholder={"Select Organization"}
                className="Asset_selecter"
                defaultValue={sessionStorage.getItem("searchPayRoll")}
                style={{ width: "220px", marginRight: "10px" }}
              >
                {orgData?.mst_organization?.map((org: any, index: any) => {
                  return (
                    <Select.Option value={org.name} key={index}>
                      {org?.name}
                    </Select.Option>
                  );
                })}
              </Select>
            )}

            <DatePicker
              className="payroll_head-create refund_head-datepic"
              onChange={onChange}
              picker="month"
            />

            <Button
              className="attendance_head-create"
              onClick={() => setOpenReFundForm(true)}
            >
              Add New
            </Button>
          </div>
        </div>
        <Table
          columns={columns}
          dataSource={reFundData}
          pagination={{
            pageSize,
            total: reFundData.length,
            onChange: (page: React.SetStateAction<number>) =>
              setCurrentPage(page),
          }}
          // onChange={handleTableChange}
          className="employee-details_table"
        />
      </div>
      <Drawer
        title={"Create ReFund"}
        width={570}
        placement="right"
        onClose={handndleCloseRefundForm}
        open={openReFundForm}
      >
        <Form
          form={form}
          name="basic"
          initialValues={{ remember: true }}
          layout="vertical"
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          autoComplete="off"
          // onValuesChange={handleValuesChange}
          className="employee-details_form"
        >
          <Form.Item
            label="Employee Name"
            name="emp_name"
            required={false}
            rules={[
              {
                required: user?.email === "admin@gmail.com" ? true : false,
                message: "Please Select the Employee Name!",
              },
            ]}
          >
            {user?.email === "admin@gmail.com" ? (
              <Select
                className="employee-details_form_item-input"
                showSearch
                filterOption={(input: string, option: any) =>
                  option.children.toLowerCase().indexOf(input.toLowerCase()) >=
                  0
                }
                onChange={(value: any) => setUser(value)}
              >
                {emp?.map((data: any) => (
                  <Select.Option value={data.id} key={data.id}>
                    {data.name}
                  </Select.Option>
                ))}
              </Select>
            ) : (
              <Select
                className="employee-details_form_item-input"
                disabled
                defaultValue={userInEmploye?.mst_employeedetails[0]?.name}
                value={userInEmploye?.mst_employeedetails[0]?.name}
                onChange={(value: string[]) => setUser(value)}
              >
                {userInEmploye?.mst_employeedetails.map((data: any) => (
                  <Select.Option value={data.id} key={data.id}>
                    {data.name}
                  </Select.Option>
                ))}
              </Select>
            )}
          </Form.Item>
          <Form.Item
            label="Date"
            name="date"
            required={false}
            rules={[{ required: true, message: "Please select date" }]}
            className="employee-details_form_item"
          >
            <DatePicker
              className="employee-details_form-datepic"
              onChange={onChangeDate}
            />
          </Form.Item>

          <Form.Item
            label="ReFund"
            name="refund"
            required={false}
            rules={[
              { required: true, message: "Please enter refund" },
              {
                type: "number",
                min: 1,
                message: "Refund should be a valid price greater than  0",
              },
            ]}
            className="employee-details_form_item"
          >
            <InputNumber
              className="employee-details_form_item-input refund-input"
              formatter={(value) =>
                ` ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
              }
              min={0}
              parser={(value: string | undefined): number => {
                const numericValue = parseFloat(
                  (value ?? "").replace(/\$\s?|(,*)/g, "")
                );
                return isNaN(numericValue) ? 0 : numericValue;
              }}
            />
          </Form.Item>

          <Form.Item
            label="Reason"
            name="reason"
            required={false}
            rules={[{ required: true, message: "Please enter reason" }]}
            className="employee-details_form_item"
          >
            <TextArea
              rows={4}
              className="employee-details_form_item-input refund-input"
            />
          </Form.Item>

          <Form.Item>
            <div className="employee-details_submit">
              <Space>
                <Button
                  htmlType="button"
                  className="employee-details_cancel-btn"
                  onClick={handndleCloseRefundForm}
                >
                  Cancel
                </Button>
                <Button
                  htmlType="submit"
                  className="employee-details_submit-btn"
                >
                  Submit
                </Button>
              </Space>
            </div>
          </Form.Item>
        </Form>
      </Drawer>
    </HRMLayout>
  );
};

export default ReFund;
