import React, { ReactNode } from 'react';
import HRMnav from '../../components/Side_Nav/HRMnav';
import HRMLayout from './hrmlayout';

import withApollo from '../../config'



const HRMPage: React.FC = () => {
  return (
    <HRMLayout>
      {/* <h1>Settings Page</h1> */}
      {/* Add your Settings page content here */}
    </HRMLayout>
  );
};

 
export default HRMPage;

 