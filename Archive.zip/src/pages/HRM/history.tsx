import React from 'react'; 
import HRMLayout from './hrmlayout';

const HistoryPage = () => {
  return (
    <HRMLayout>
      <h1>History Page</h1>
      {/* Add your History page content here */}
    </HRMLayout>
  );
};

export default HistoryPage;