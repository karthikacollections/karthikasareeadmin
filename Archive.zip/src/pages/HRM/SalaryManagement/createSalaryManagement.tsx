import { Button, Form, Select, Space, Input, } from 'antd';
import React, { useEffect, useState, useRef } from 'react';
import { useQuery, useMutation } from "@apollo/client";
import { CREATE_SALARYMANAGEMENT, UPDATE_SALARYMANAGEMENT } from "../../../helpers/mutation"
import { GET_EMPLOYEE_SALARY } from '../../../helpers/queries'
import { GET_SALARYMANAGEMENT } from '../../../helpers/queries'

export const Employee: React.FC<any> = ({ ModalClose, editdraw,showModal }) => {
    const [user, setUser] = useState([])
    const [form] = Form.useForm();
    // const formRef = useRef(null);
    const [amount, setAmount] = useState('');
    const [name, setName] = useState('')
    const [FinalPay, SetFinalPay] = useState('');
    //     const [employee, setEmployee] = useState();

    const [dividedValues, setDividedValues] = useState<any>({
        basicSalary: Number,
        houseRent: Number,
        conveyanceAllowance: Number,
        medicalAllowance: Number,
        specialAllowance: Number,
        esi: Number,
    });


    const onFinishFailed = (errorInfo: any) => {
    };

    // GET
    const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetEmployDetails,
    } = useQuery(GET_EMPLOYEE_SALARY, {
        variables: {},
    });

    // Post
    const [createManage, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_SALARYMANAGEMENT, {
        errorPolicy: 'all',
    });

    // PUT
    const [updateManage, { loading: updateLoading, error: updateError, data: updateDataAddress }] = useMutation(UPDATE_SALARYMANAGEMENT, {
        errorPolicy: 'all',
    });

    useEffect(() => {
        if (dataUser) {
            let user = dataUser?.mst_employeedetails
            setUser(user)
        }
    }, [dataUser])

    useEffect(() => {
        if (editdraw) {
            setAmount(editdraw?.mst_employeedetails_mst_salarymanagements?.salary)
            setName(editdraw?.name)
            form.setFieldsValue({ // Use setFieldsValue to update form values
                editdraw
              });
            const dividedValue = editdraw?.mst_employeedetails_mst_salarymanagements?.final_pay / 6;


            const basicSalary = dividedValue * 3; // 40%
            const houseRent = dividedValue * 1; // 20%
            const conveyanceAllowance = dividedValue * 1; // 20%
            const medicalAllowance = dividedValue * 0.5; // 5%
            const specialAllowance = dividedValue * 0.5; // 5%
            // const esi = dividedValue * 0.5 - (dividedValue * 0.05 * 0.05); // 5% - 5%?
            const esi = dividedValue * 0; // 5% - 5%?
            const finalPay =
                basicSalary + houseRent + conveyanceAllowance + medicalAllowance + specialAllowance - esi; // Subtract 5% from the total amount

            setDividedValues({
                basicSalary,
                houseRent,
                conveyanceAllowance,
                medicalAllowance,
                specialAllowance,
                esi,
                finalPay,
            });
        }
    }, [editdraw])

    const {
        error: salaryError,
        loading: salaryLoading,
        data: dataSalary,
        refetch: refetSalary,
    } = useQuery(GET_SALARYMANAGEMENT, {
        variables: {},
    });
console.log(editdraw);


    const onFinish = (values: any,) => {
        if (editdraw?.mst_employeedetails_mst_salarymanagements?.id) {
           
            
            values.id = editdraw?.mst_employeedetails_mst_salarymanagements?.id
            values.basic_salary = Math.round(Number(dividedValues.basicSalary))
            values.rent_allowance = Math.round(Number(dividedValues.houseRent))
            values.conveyance_allowance = Math.round(Number(dividedValues.conveyanceAllowance))
            values.medical_allowance = Math.round(Number(dividedValues.medicalAllowance))
            values.special_allowance = Math.round(Number(dividedValues.medicalAllowance))
            values.esi = Math.round(Number(dividedValues.esi))
            values.final_pay = Math.round(dividedValues.finalPay)
            values.employee = editdraw?.mst_employeedetails_mst_salarymanagements?.employee
            values.salary = amount;
            updateManage({  
                variables: values,
            }).then((response) => {
                showModal("Updated")
                refetSalary()
                refetEmployDetails()
                ModalClose(null)
            });
        }
        else {            
            values.employee = editdraw?.id
            values.basic_salary = Math.round(Number(dividedValues.basicSalary))
            values.rent_allowance = Math.round(Number(dividedValues.houseRent))
            values.conveyance_allowance = Math.round(Number(dividedValues.conveyanceAllowance))
            values.medical_allowance = Math.round(Number(dividedValues.medicalAllowance))
            values.special_allowance = Math.round(Number(dividedValues.specialAllowance))
            values.esi = Math.round(Number(dividedValues.esi))
            values.final_pay = Math.round(Number(dividedValues.finalPay))
            values.salary = amount;
            values.employee = values.employee

            createManage({
                variables: values,
            }).then((response) => {
                showModal("Created")
                refetEmployDetails()
                refetSalary()
                ModalClose(null)
            });
        };

    }

    const handleAmountChange = (e: any) => {
        const inputValue = e.target.value;
        setAmount(inputValue);
        const dividedValue = inputValue / 6;

        const basicSalary = dividedValue * 3; // 40%
        const houseRent = dividedValue * 1; // 20%
        const conveyanceAllowance = dividedValue * 1; // 20%
        const medicalAllowance = dividedValue * 0.5; // 5%
        const specialAllowance = dividedValue * 0.5; // 5%
        // const esi = dividedValue * 0.1 - (dividedValue * 0.05 * 0.05); // 5% - 5%
        const esi = dividedValue * 0; // 5% - 5%?

        const finalPay =
            basicSalary + houseRent + conveyanceAllowance + medicalAllowance + specialAllowance - esi; // Subtract 5% from the total amount

        setDividedValues({
            basicSalary,
            houseRent,
            conveyanceAllowance,
            medicalAllowance,
            specialAllowance,
            esi,
            finalPay,
        });
    };


    return (
        <>
            <div>
                <Form
                    name="basic"
                    layout="vertical"
                    initialValues={editdraw}
                    onFinish={onFinish}
                    //  onValuesChange={handleValuesChange}
                    // onFieldsChange={handleInputChange}
                    onFinishFailed={onFinishFailed}
                    // autoComplete="off"
                    form={form}
                    // ref={formRef}
                    className="assets_form"

                >
                      <Form.Item label="Name">
                        <Input type="text" value={name}  />
                    </Form.Item>

                    <Form.Item label="Salary">
                        <Input type="number" value={amount} onChange={handleAmountChange} />
                    </Form.Item>

                    <Form.Item label="Basic Salary">
                        <Input value= {dividedValues.basicSalary} disabled />
                    </Form.Item>

                    <Form.Item label="House Rent Allowance">
                        <Input value= {dividedValues.houseRent} disabled />
                    </Form.Item>

                    <Form.Item label="Conveyance Allowance">
                        <Input value={dividedValues.conveyanceAllowance} disabled />
                    </Form.Item>

                    <Form.Item label="Medical Allowance">
                        <Input value={dividedValues.medicalAllowance} disabled />
                    </Form.Item>

                    <Form.Item label="Special Allowance">
                        <Input value={dividedValues.specialAllowance} disabled />
                    </Form.Item>

                    <Form.Item label="ESI">
                        <Input value={dividedValues.esi} disabled />
                    </Form.Item>

                    <Form.Item label="Final Pay">
                        <Input value={dividedValues.finalPay} disabled />
                    </Form.Item>

                    <Form.Item >
                        <div className="assets_submit">
                            <Space>
                                <Button htmlType="button" className="assets_cancel-btn" onClick={() => ModalClose(null)}>
                                    Cancel
                                </Button>
                                <Button htmlType="submit" className="assets_submit-btn">
                                    Submit
                                </Button>
                            </Space>
                        </div>
                    </Form.Item>


                </Form>
            </div >
        </>
    )
}


export default Employee