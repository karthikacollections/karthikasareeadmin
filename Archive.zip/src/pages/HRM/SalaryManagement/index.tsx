
import withApollo from '../../../config'
import React, { useEffect, useState, useRef } from 'react';
import { Space, Table, Modal, Drawer, Button,Select } from 'antd';
import type { ColumnsType } from 'antd/es/table';
// import { GET_SALARYMANAGEMENT } from '../../helpers/queries'
import { GET_EMPLOYEE_SALARY, GET_ORGANIZATION } from "../../../helpers/queries";
import { UPDATE_SALARYMANAGEMENT } from '../../../helpers/mutation'
import { useQuery, useMutation } from "@apollo/client";
import { DeleteOutlined, EditOutlined,FilterOutlined } from '@ant-design/icons';
import CreateSalary from "./createSalaryManagement";
import HRMLayout from '../hrmlayout'
import { useAuth } from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";

export const SalaryManage: React.FC = () => {
    const [open, setOpen] = useState<any>(null);
    const [editdraw, setEditdraw] = useState<any>()
    const [salary, setSalary] = useState([])
    const [userSalary, setUser] = useState([])
    const { check_button_permission, filteredColumns,check_user_type, user } = useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");
    const [selectedValue, setSelectedValue] = useState("");
    const [selectedOrgValue, setSelectedOrgValue] = useState("");

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
    };

    const handleOk = () => {
        refetEmployDetails();
        setPopOpen(false);
    };

    const handleCancel = () => {
        setPopOpen(false);
    };


    const ModalClose = () => {
        setOpen(false)
        // refetSalaryManage()

    }

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
    }

    const handleSelectChange = (value: any) => {
        setSelectedValue(value);
      };

    interface DataType {
        employee: string;
    }

    const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetEmployDetails,
    } = useQuery(GET_EMPLOYEE_SALARY, {
        variables: {},
    });

    const {
        error: orgError,
        loading: orgLoading,
        data: orgData,
        refetch: refetOrganizationDetails,
      } = useQuery(GET_ORGANIZATION);

    const search = (data: any) => {

        let searchOrg = sessionStorage.getItem("searchPayRoll");

     if (selectedValue && selectedOrgValue) {
      return data.filter(
        (u: any) =>
          u.name?.toLowerCase().includes(selectedValue?.toLowerCase()) &&
          u.mst_organization?.name
            ?.toLowerCase()
            .includes(selectedOrgValue?.toLowerCase())
      );
    } else if (selectedValue) {
      return data.filter((u: any) =>
        u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
      );
    } else if (selectedOrgValue) {
      return data?.filter((u: any) =>
        u?.mst_organization?.name
          ?.toLowerCase()
          .includes(selectedOrgValue?.toLowerCase())
      );
    } else if (searchOrg) {
      return data?.filter((u: any) =>
        u?.mst_organization?.name
          ?.toLowerCase()
          .includes(searchOrg?.toLowerCase())
      );
    } else {
      return data;
    }
      }

    let empData = [...(dataUser?.mst_employeedetails || [])]
    let sort = empData?.sort((a: any, b: any) => a?.name.localeCompare(b?.name));

    useEffect(() => {
        if (dataUser) {
            let userSalary = dataUser?.mst_employeedetails
            let filterActiveUsers = userSalary.filter((value:any)=>{
                
                
                return value.isdeleteat ===false && value.status=== true
            })
            setUser(filterActiveUsers)
        }
    }, [dataUser])
    const handleSelectChangeOrganization = (value: any) => {
        if (value === undefined) {
          sessionStorage.removeItem("searchPayRoll");
        } else {
          sessionStorage.setItem("searchPayRoll", value);
        }
        setSelectedOrgValue(value);
      };

    const columns: ColumnsType<DataType> = [

        {
            title: 'S.No',
            dataIndex: 'sno',
            key: 'sno',
            render: (text, record, index) => index + 1,
        },

        {
            title: 'Employee',

            render: (value) => {

                return (
                    <>
                        <p>{value.name}</p>
                    </>
                )
            }
        },
        {
            title:'Organization',
            render:(value:any)=>{
                let organization=value?.mst_organization?.name
                return(
                    <p>{organization}</p>
                )
            },
            filters: [
                {
                    text: 'Hysas',
                    value: 'Hysas',
                },
                {
                    text: 'Vinsoft',
                    value: 'Vinsoft',
                },
                {
                    text: 'Kitez',
                    value: 'Kitez',
                },
            ],
            onFilter: (value: any, record:any) => record?.mst_organization?.name?.indexOf(value) === 0,
            filterIcon: () => (
                user.email === "admin@gmail.com" && <FilterOutlined style={{ color: "white", fontSize: "18px" }} />
            ),
        },
        {
            title: 'Final Pay',

            render: (value) => {

                return (
                    <>
                        <p>{value?.mst_employeedetails_mst_salarymanagements?.final_pay}</p>
                    </>
                )
            }
        },




        {
            title: 'Action',
            key: 'action',
            render: (
                record: any) => (
                <Space size='large'>
                    {
                        check_button_permission("SalaryManagement", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="assets_edit"
                            /> :
                            <></>
                    }


                </Space>
            ),
        },
    ]
    return (
        <HRMLayout>
            <div className="employee-details">
                <div className="assets_head">
                    <h2 className="assets_head-text">Salary Management</h2>

                    {user.email === "admin@gmail.com" && (
            <Select
              size={"large"}
              onChange={handleSelectChangeOrganization}
              allowClear
              showSearch // Enable search functionality
              filterOption={(input, option: any) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
              placeholder={"Select Organization"}
              className="Asset_selecter"
              defaultValue={sessionStorage.getItem("searchPayRoll")}
              style={{ width: "220px" }}
            >
              {orgData?.mst_organization?.map((org: any, index: any) => {
                return (
                  <Select.Option value={org.name} key={index}>
                    {org?.name}
                  </Select.Option>
                );
              })}
            </Select>
          )}

                    {user.email === "admin@gmail.com" &&
                        <Select
                            size={'large'}
                            onChange={handleSelectChange}
                            allowClear
                            showSearch
                            filterOption={(input, option: any) =>
                                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                            placeholder={'Select Employee'}
                            className='Asset_selecter'
                            style={{ width: '220px', marginRight: '10px' }}
                        >

                            {sort?.map((emp: any, index: any) => {

                                return (
                                    <Select.Option value={emp.name} key={index}>{emp?.name}</Select.Option>
                                )
                            })}

                        </Select>
                    }
                    {/* <Button className="assets_head-create"
                        onClick={() => setOpen("Create")}
                    >Add New</Button> */}
                </div>
                <Table
                    columns={filteredColumns(columns, 'SalaryManagement')}
                    dataSource={search(userSalary)}
                    pagination={{ pageSize: 10 }}
                    className="assets_table" />


                <Drawer title={editdraw?.mst_employeedetails_mst_salarymanagements?.final_pay ? (<p>Edit</p>) : (<p>Create</p>)} width={570} placement="right"
                    onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}
                >
                    <CreateSalary ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />

                </Drawer>

            </div>
            <Modal
                open={Popopen}
                title=""
                onOk={handleOk}
                onCancel={handleCancel}
                footer={[
                    <div style={{ display: "flex", justifyContent: "center" }}>
                        <Button
                            key="submit"
                            type="primary"
                            loading={userLoading}
                            onClick={handleOk}
                            style={{
                                display: "flex",
                                width: "206px",
                                padding: "15px 30px",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "10px",
                                borderRadius: "8px",
                                background: "#252947",
                            }}>
                            OK
                        </Button>
                    </div>,
                ]}
                width={"386px"}>
                <Space
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                    }}>
                    <Image
                        src={PopImage}
                        alt="image"
                        style={{
                            width: "150px",
                            height: "150px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    />
                    <p
                        style={{
                            color: "#101010",
                            textAlign: "center",
                            fontFamily: "revert",
                            fontSize: "32px",
                            fontStyle: "normal",
                            fontWeight: "700",
                            lineHeight: "normal",
                        }}>
                        {`${title}`} Successfully
                    </p>
                </Space>
            </Modal>
        </HRMLayout>
    )
}

export default SalaryManage