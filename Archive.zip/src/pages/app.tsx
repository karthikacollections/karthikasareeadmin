import { useEffect, useState } from "react";
import { ApolloClient, ApolloProvider, InMemoryCache } from "@apollo/client";
import { inspect } from '@xstate/inspect'
import type { AppProps } from 'next/app'
import Head from 'next/head'
// import '../styles/globals.scss'
// import '../assets/scss/main.scss'
import axios from 'axios';
// import { Provider } from "next-auth";
export const PocketsAxios = axios.create({ baseURL: 'http://52.27.62.190' });
const devTools = typeof window !== 'undefined' && !!process.env.NEXT_PUBLIC_DEBUG
if (devTools) {
  inspect({
    url: 'https://stately.ai/viz?inspect',
    iframe: false
  })
}
// const nhost = new NhostClient({ backendUrl: BACKEND_URL, devTools });

const client = new ApolloClient({
  uri: "https://employeeapp.vinsoftconnected.com/v1/graphql", // <- Configure GraphQL Server URL (must be absolute)
  cache: new InMemoryCache()
});


function MyApp({ Component, pageProps }: AppProps) {



  useEffect(() => {



  }, [Component, pageProps])


  return (
    <>
      <Head>
        <title>Hysas Employee Login</title>
        <link rel="icon" href="/pockets logo.svg" />
        <meta name="viewport" content="minimum-scale=1, initial-scale=1, width=device-width" />
        <link rel="preconnect" href="https://fonts.googleapis.com"></link>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet"></link>
      </Head>
      <Component {...pageProps} />
    </>
  )
}

export default MyApp
