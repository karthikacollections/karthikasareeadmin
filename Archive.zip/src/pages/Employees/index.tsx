import React, { ReactNode } from 'react';
import EmployeeNav from '../../components/Side_Nav/Employeenav';
import EmployeeLayout from './employeelayout';

import withApollo from '../../config'



const EmployeePage: React.FC = () => {
  return (
    <EmployeeLayout>
      {/* <h1>Settings Page</h1> */}
      {/* Add your Settings page content here */}
    </EmployeeLayout>
  );
};

export default EmployeePage;