import { Button, Form, Input, Space, Select, InputNumber, } from 'antd';
import React, { useEffect, useState, useRef } from 'react';

import { useMutation, useQuery } from "@apollo/client";

import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { GET_EMPLOYDETAILS } from '../../../helpers/queries';
import { GET_SKILLSMANAGE } from '../../../helpers/queries';
import { CREATE_RESUME_PROJECTS,UPDATE_RESUME_PROJECTS } from '../../../helpers/mutation'


export const createResume: React.FC<any> = ({ ModalClose, editdraw }) => {

    const [form] = Form.useForm();
    const formRef = useRef(null);
    const [user, setUser] = useState([])
    const { Option } = Select;
    // const [employeeID, setEmployeeID] = useState('');
    // const [selectedSkills, setSelectedSkills] = useState([]);

    const [skillset, setSkills] = useState([])

    const [createResume, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_RESUME_PROJECTS, {
        errorPolicy: 'all',
    });

    // const [createProject, { loading: projectLoading, error: projectError, data: projectDataAddress }] = useMutation(UPDATE_RESUME_PROJECTS, {
    //     errorPolicy: 'all',
    // });


    const [updateResume, { loading: updateLoading, error: updateError, data: updateDataAddress }] = useMutation(UPDATE_RESUME_PROJECTS, {
        errorPolicy: 'all',
    });


    const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetEmployDetails,
    } = useQuery(GET_EMPLOYDETAILS, {
        variables: {},
    });


    useEffect(() => {
        if (dataUser) {
            let user = dataUser?.mst_employeedetails
            setUser(user)
        }
    }, [dataUser])

    const {
        data: dataSkills,
        refetch: refetSkills,
    } = useQuery(GET_SKILLSMANAGE, {
        variables: {},
    });

    useEffect(() => {
        if (dataSkills) {
            let skillset = dataSkills?.mst_skillsmanage
            setSkills(skillset)
        }
    }, [dataSkills])


    useEffect(() => {
        form.setFieldsValue(editdraw)
    }, [editdraw])


    const onFinish = (values: any) => {
        let employeeData = values?.employee.split('&')
         let sendpayload = {
            employee: employeeData[0],
            summary: values?.summary,
            skill: values?.skill,
            experience: values?.experience,
            project: values?.project,
            name:employeeData[1]
          
        }
       
        if (editdraw) {
            values.id = editdraw?.id
            updateResume({
                variables: values,
            }).then((response) => {
                refetEmployDetails()
                ModalClose(null)
                refetSkills()

            });
        }
        else {
            createResume({
                variables: sendpayload
            }).then((response) => {
                ModalClose(null)
                refetEmployDetails()
                refetSkills()

            });

           
        };
    }

    // const handleEmployeeSelect = (value: any) => {
    //     setEmployeeID(value);

    //         setSelectedSkills(value);

    //   }; 



    const onFinishFailed = (errorInfo: any) => {
    };

    function handleChange(value: any) {
    }


    return (

        <>
            <Form
                name="basic"
                layout="vertical"
                initialValues={{ remember: true }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                ref={formRef}
                className="Skills_form"

            >
                <Form.Item label="Employee"
                    name="employee"
                    required={false}
                    rules={[{ required: true, message: 'Please select your name!' }]}
                    className="attendance_form_item"
                >
                    <Select className="attendance_form_item-input"
                    // onChange={handleEmployeeSelect}
                    // value={employeeID}
                    >
                        {
                            user.map((val: any) => {
                                if(val.status === true){
                                    return (
                                        <Select.Option value={`${val.id}&${val.name}`} key={val.id}>{val.name}</Select.Option>
                                    )

                                }
                            })
                        }
                    </Select>



                </Form.Item>

                <Form.Item
                    label="Summary"
                    name="summary"
                    required={false}
                    rules={[{ required: true, message: 'Please input your Name!' }]}
                    className="Skills_form_item"
                >
                    <Input.TextArea className="Skills_form_item-input" />
                </Form.Item>

                <Form.Item
                    label="Skill"
                    name="skill"
                    required={false}
                    rules={[{ required: true, message: 'Please input your Skills!' }]}
                    className="Destination_form_item"
                >
                    <Input.TextArea placeholder="Skills" />
                </Form.Item>

                <Form.Item
                    label="Experience"
                    name="experience"
                    required={false}
                    rules={[{ required: true, message: 'Please enter your Experience!' }]}
                    className="Skills_form_item"
                >
                    <Input className="Skills_form_item-input" />
                </Form.Item>

                <Form.List name="project">
                    {(fields, { add, remove }) => (
                        <>
                            {fields.map(({ key, name, ...restField }) => (
                                <div key={key} >
                                    <Form.Item
                                        {...restField}
                                        name={[name, 'project_name']}
                                        label="Project Name"
                                        required={false}
                                        rules={[{ required: true, message: 'Missing project name' }]}
                                    >
                                        <Input className="Skills_form_item-input" />
                                    </Form.Item>

                                    <Form.Item
                                        {...restField}
                                        name={[name, 'description']}
                                        label="Description"
                                        required={false}
                                        rules={[{ required: true, message: 'Missing last name' }]}
                                    >
                                        <Input.TextArea placeholder="Description" />
                                    </Form.Item>

                                    <Form.Item
                                        {...restField}
                                        name={[name, 'skills']}
                                        label="Skills"
                                        required={false}
                                        rules={[{ required: true, message: 'Missing last name' }]}
                                    >

                                        <Input.TextArea placeholder="Skills" />

                                    </Form.Item>

                                    <Form.Item
                                        {...restField}
                                        name={[name, 'role']}
                                        label="My Role"
                                        required={false}
                                        rules={[{ required: true, message: 'Missing last name' }]}
                                    >
                                        <Input.TextArea className="Skills_form_item-input" />
                                    </Form.Item>

                                    <MinusCircleOutlined onClick={() => remove(name)} />
                                </div>
                            ))}
                            <Form.Item>
                                <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />}>
                                    Add field
                                </Button>
                            </Form.Item>
                        </>
                    )}
                </Form.List>

                <Form.Item >
                    <div className="Skills_submit">
                        <Space>
                            <Button htmlType="button" className="Skills_cancel-btn" onClick={() => ModalClose(null)}>
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="Skills_submit-btn">
                                Submit
                            </Button>

                        </Space>

                    </div>
                </Form.Item>
            </Form>
        </>
    )
}
export default createResume