
import withApollo from '../../../config'
import React, { useEffect, useState, } from 'react';
import { Space, Table, Button, Popconfirm, Drawer } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { GET_RESUME_MANAGEMENT } from '../../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import { DELETE_RESUME_PROJECTS } from "../../../helpers/mutation";
import { DeleteOutlined, EditOutlined, CloudDownloadOutlined, DownCircleOutlined } from '@ant-design/icons';
import { saveAs } from 'file-saver';
import CreateResume from "./createResume";
import EmployeeLayout from '../employeelayout'
import {useAuth} from '../../../components/auth'
import { log } from 'console';
interface DataType {
    Name: any;
    Summary: any;
    Role: any;
    Skill: any;

}

export const resume: React.FC = () => {

    const [open, setOpen] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("");
    const [resume, setDataResume] = useState([])
    const { check_button_permission,filteredColumns } = useAuth()
  
    const ModalClose = () => {
        setOpen(false)
        refetResume()
    }

    const {
        error: userError,
        loading: userLoading,
        data: dataresume,
        refetch: refetResume,
    } = useQuery(GET_RESUME_MANAGEMENT, {
        variables: {},
    });

    useEffect(() => {
        if (dataresume) {
            let res = dataresume?.mst_resume_creation
            setDataResume(res)
        }
    }, [dataresume])

    // delete destination

    const [deleteSkills, { loading, error, data }] = useMutation(DELETE_RESUME_PROJECTS);
    const handleDelete = (id: any) => {
        deleteSkills({
            variables: id,

            update: (cache: any) => {
                refetResume()
            },
        });
    };

    const handleDownload = (record: any) => {
     
        
        // let x=record.project?.project_name?.map((a:any)=>a.project_name).join(', ');
        const rowData = `
          Name: ${record.mst_resume_mst_employee?.name}
          Summary: ${record.summary}
          Role: ${record.role}
          Skill: ${record.skill}
          Project: ${record.project}
        `;

        const blob = new Blob([rowData], { type: 'text/plain' });

        const fileName = `${record.mst_resume_mst_employee?.name}.xls`;

        saveAs(blob, fileName);
      };
    //   const handleownload = (record: any) => {

    //     // const defaultProperties = {
    //     //     title: 'Resume Document',
    //     //     creator: 'Your Name',
    //     //     description: 'Generated Resume Document',
    //     //     lastModifiedBy: 'Your Name',
    //     //     sections: [],
    //     //   };

    //     // const properties = options? { ...defaultProperties, ...options } : defaultProperties;

    //     // const doc = new Document(properties);
    //     // const doc = new Document();
    //           const defaultProperties = {
    //         title: 'Resume Document',
    //         creator: 'Your Name',
    //         description: 'Generated Resume Document',
    //         lastModifiedBy: 'Your Name',
    //         sections: [],
    //       };

    //     // let paragraph = new Paragraph(plainTextData);
    //     const doc = new Document(defaultProperties);

    //     // doc.addParagraph(paragraph);      

    //     const fileName = `${record.mst_resume_mst_employee?.name}.docx`;

    //     Packer.toBuffer(doc).then((buffer: any) => {
    //         const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
    //         saveAs(blob, fileName);
    //     });

    // };

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
    }
    var count = 0
    const columns: ColumnsType<DataType> = [

        {
            title: 'S.no',
            dataIndex: 's.no',
            render: () => ++count,
        },
        {
            title: 'Employee',
            dataIndex: "name",
            key: "name"

          
        },
        {
            title: 'Summary',
            dataIndex: "summary",
            key: "summary"
        },
        {
            title: 'Skills',
            dataIndex: "skill",
            key: "skill"
        },

        {
            title: 'Experience',
            dataIndex: "experience",
            key: "experience"
        },

        {
            title: 'Projects',
            render: (value) => {
                const projectNames = value?.project?.length ? value.project.map((project :any) => project.project_name).join(', ') : 'No projects available';
                
                return <p>{projectNames}</p>;
            },
        },

        {
            title: 'Action',
            key: 'action',
            render: (_, record) => (
                <Space size='large'>
                    {
                        check_button_permission("ResumeCreation", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="Skills_edit"
                            />:<></>
                    }


                    {
                        check_button_permission("ResumeCreation", "delete")
                            ?
                    <Popconfirm
                        title="Delete the task"
                        description="Are you sure to delete this task?"
                        okText="Yes"
                        cancelText="No"
                        onConfirm={() => handleDelete(record)}
                    >
                        <DeleteOutlined className="Skills_delete" />
                    </Popconfirm>:<></>
                    }

                    <CloudDownloadOutlined
                        onClick={() => handleDownload(record)}
                        className="Skills_edit"
                    />
                    <DownCircleOutlined
                        // onClick={() => handleownload(record)}
                        className="Skills_edit"
                    />


                </Space>
            ),
        },
    ];


    return (
        <EmployeeLayout>
            <div className="Skills">
                <div className="Skills_head">
                    <h2 className="Skills_head-text">Resume</h2>
                    {
                        check_button_permission("ResumeCreation", "create")
                            ?
                        <Button className="Skills_head-create" onClick={() => setOpen("Create")}>+ Add new Resume</Button>
                        :<></>
                    }
                </div>
                <Table columns={filteredColumns(columns,"ResumeCreation")} dataSource={resume} pagination={false} className="Skills_tale" />
                <Drawer title={`${open} Resume`} width={570} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}>
                    {
                        open == "Edit" ? (<CreateResume ModalClose={ModalClose} editdraw={editdraw} />) : <></>
                    }
                    {
                        open == "Create" ? (<CreateResume ModalClose={ModalClose} editdraw={null} />) : <></>
                    }


                </Drawer>

            </div>
        </EmployeeLayout>
    )
}
export default resume
