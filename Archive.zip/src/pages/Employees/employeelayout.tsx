import React, { ReactNode } from 'react';
import EmployeeNav from '../../components/Side_Nav/Employeenav';
type EmployeeLayoutProps = {
  children: ReactNode;
};

const EmployeeLayout: React.FC<EmployeeLayoutProps> = ({ children }) => {
  return (
    <div className='setting_nav'>
      {/* <div>
        <EmployeeNav />
      </div> */}
      <div className='settings_style'>
        {children}
      </div>
    </div>
  );
};

export default EmployeeLayout