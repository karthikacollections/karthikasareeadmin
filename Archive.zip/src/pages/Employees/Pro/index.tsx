import EmployeeLayout from "../employeelayout";
import {useRouter} from "next/router";
import type {NextPage} from "next";
import {useQuery, useMutation, useLazyQuery} from "@apollo/client";
import React, {useEffect, useState, useRef} from "react";
import {GET_EMPLOYDETAILS,GET_EMPLOYEE_DATA, GET_ONE_EMPLOYDETAILS} from "../../../helpers/queries";
import {Button,Modal,Select,Card,Space,Input,Row,Col,Checkbox,InputNumber,} from "antd";
import { useAuth } from "../../../components/auth";
import Image from 'next/image';
import Link from "next/link";
import {LeftOutlined, CopyOutlined, DeleteOutlined, EyeOutlined} from "@ant-design/icons";
import moment from "moment";
import { UPDATE_STATUS_EMPLOYEEDETAILS } from "@/helpers";

export const EmployeeProfile: React.FC<any> = () => {
  const router = useRouter();
  const {data, id} = router.query;
  const [empDetails,setEmpDetails]=useState([])
  const { check_button_permission, filteredColumns, check_user_type, user } = useAuth();
  const [isActive, setIsActive] = useState<boolean>(true);
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);

  const {data: empData,refetch: refetEmp } = useQuery(GET_ONE_EMPLOYDETAILS,{variables:{id:JSON.parse(id as string)}});

  useEffect(()=>{
    if(empData){
      setEmpDetails(empData?.mst_employeedetails[0])
    }
  },[])
  
  

  let empOnePersonData = JSON.parse(data as string);
  
  const urlList = empOnePersonData?.image?.split(",");
  let doj = moment(empOnePersonData?.doj).format("DD/MM/YYYY");
  let dor = new Date(empOnePersonData?.dor)
  let dorFormat = moment(dor).format("DD/MM/YYYY")
  let createdat = moment(empOnePersonData?.createdat).format("DD/MM/YYYY");
  
  const toggleStatus = () => {
    setIsModalVisible(true);
  };

  const handleConfirm = () => {
    setIsModalVisible(false);
    let statusParam={id:'',status:false}
    statusParam.id = empOnePersonData.id
    statusParam.status = !empOnePersonData.status
    statsuEmployee({
      variables: statusParam
    })
    refetEmp()
  };

  const [statsuEmployee] =useMutation(UPDATE_STATUS_EMPLOYEEDETAILS)

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const copyEmail = (email: string) => {
    navigator.clipboard.writeText(email);
  };

  const copyPhone = (email: string) => {
    navigator.clipboard.writeText(email);
  };

  const viewCard =(param:any)=>{
    
    return (
      <a href={param}/>
    )
  }

  return (
    <EmployeeLayout>
      <div className="row-container">
        <Link href="/Employees/Employee">
          <span className="back-arrow">
            <LeftOutlined />
          </span>
        </Link>

        <Image
          className="profile-photo"
          src={empOnePersonData?.image?.split(",")[0]}
          width={100}
          height={100}
          alt="Profile"
        />
        <span className="name">{empOnePersonData?.name}</span>
        <span className="addon">Added On:</span>
        <span className="addon">{createdat}</span>
        {/* <Button className="delete-button">
          <DeleteOutlined />
          Delete
        </Button> */}
      </div>

      <div className="pro_profile">
        <div>
          <h2>Profile Photo</h2>
          <div className="pro_img">
          <Image
          className="profile-photo"
          src={empOnePersonData?.image?.split(",")[0]}
          style={{objectFit:'fill'}}
          width={300}
          height={300}
          alt="Profile"
        />
          </div>
        </div>
        <div>
          <div>
            <h2>Role</h2>
            <div className="pro_role">
              <div>
                <div className="pro_text">
                  <p>Employee ID</p>
                  <h4>{empOnePersonData.employeeid || '---'}</h4>
                </div>
              </div>
            </div>
          </div>
          <div className="pro_role">
            <div>
              <div className="pro_text">
                <p>Role</p>
                <h4>{empOnePersonData?.mst_role?.type}</h4>
              </div>
            </div>
          </div>
          <div className="pro_role">
            <div>
              <div className="pro_text">
                <p>Organisation</p>
                <h4>{empOnePersonData?.mst_organization?.name}</h4>
              </div>
            </div>
          </div>
        </div>
        <div>
          <div>
            <h2>Onboarding</h2>
          </div>
          <div className="pro_role">
            <div>
              <div className="pro_text">
                <p>Onboarding date</p>
                <h4>{doj}</h4>
              </div>
            </div>
          </div>
          <div className="pro_status">
            <div className="pro_statushead">
              <h4>Current Status</h4>
            </div>
            <p className={` ${empOnePersonData?.status ? "pro_Active" : "pro_Inactive"}`} >
              {empOnePersonData?.status ? "Active" : "Inactive"}
            </p>

            <Modal
              title={`Confirm ${isActive ? "Inactive" : "Active"}`}
              open={isModalVisible}
              onOk={handleConfirm}
              onCancel={handleCancel}>
              <p>
                Are you sure you want to change the status to{" "}
                {isActive ? "Inactive" : "Active"}?
              </p>
            </Modal>
          </div>
          {!empOnePersonData?.status 
          && 
          <div className="pro_role">
            <div>
              <div className="pro_text">
                <p>DOR</p>
                <h4>{dorFormat}</h4>
              </div>
            </div>
          </div>
          }
        </div>
      </div>

      <div className="pro_profile">
        <div>
          <div>
            <div className="pro_role">
              <div>
                <div className="pro_text">
                  <p>Name</p>
                  <h4>{empOnePersonData?.name}</h4>
                </div>
              </div>
            </div>
          </div>

          <div>
            <div className="pro_email">
              <div className="pro_text">
                <p>Phone</p>
                <h4>{empOnePersonData?.phone}</h4>
              </div>

              <div>
                <CopyOutlined
                  className="pro_button"
                  onClick={() => copyPhone("99999999")}
                />
              </div>
            </div>
          </div>
         {empOnePersonData?.adhar && 
          <div>
            <div className="pro_email">
              
              <div className="pro_text">
                  <p>Adhaar No</p>
                  <h4>{empOnePersonData?.adhar}</h4>
              </div>

              <div>
                <CopyOutlined
                  className="pro_button"
                  onClick={() => copyEmail(empOnePersonData?.email)}
                />
              </div>
            </div>
            <div className="pro_link_adhaar">
                
                <div className="pro_link_adhaar_head">
                  <p>Adhaar</p>
                  <h4 className="pro_link_adhaar_head_linkText">{empOnePersonData?.adhaar_photo}</h4>
                </div>

                <div className="pro_link_adhaar_link">
                  <a style={{color:'black'}} href={empOnePersonData?.adhaar_photo || '#'} target='_blank'><EyeOutlined /></a>
                </div>

            </div>
          </div>}
        </div>
        <div>
          <div>
            <div className="pro_role">
              <div>
              <div className="pro_text">
                <p>Email</p>
                <h4>{empOnePersonData?.email}</h4>
              </div>
              </div>
            </div>
          </div>
          {empOnePersonData?.pan &&
          <>
          <div className="pro_role">
            <div>
              <div className="pro_text">
                <p>Pan No</p>
                <h4>{empOnePersonData?.pan}</h4>
              </div>
            </div>
          </div>
          <div className="pro_role">
            <div>
              <div className="pro_link_adhaar">
                
                <div className="pro_link_adhaar_head">
                  <p>Pan</p>
                  <h4 className="pro_link_adhaar_head_linkText">{empOnePersonData?.pan_photos}</h4>
                </div>

                <div className="pro_link_adhaar_link">
                  <a style={{color:'black'}} href={empOnePersonData?.pan_photos || '#'} target='_blank'><EyeOutlined /></a>
                </div>

              </div>
              
            </div>
          </div>
          </> 
          }
        </div>
        <div>
          {/* <div>
            <div className="pro_role">
              <div>
                <div className="pro_text">
                  <p>Employee ID</p>
                  <h4>HYS022</h4>
                </div>
              </div>
            </div>
          </div> */}
          <div className="pro_role">
            <div>
              <div className="pro_text">
                <p>Role</p>
                <h4>{empOnePersonData?.mst_role?.type}</h4>
              </div>
            </div>
          </div>
          <div>
            {/* <div className="pro_email">
              <div className="pro_text">
                <p>Email</p>
                <h4>{empOnePersonData?.email}</h4>
              </div>
              

              <div>
                <CopyOutlined
                  className="pro_button"
                  onClick={() => copyEmail(empOnePersonData?.email)}
                />
              </div>
            </div> */}
            <div className="pro_link_adhaar">
                
                <div className="pro_link_adhaar_head">
                  <p>Profile</p>
                  <h4 className="pro_link_adhaar_head_linkText">{empOnePersonData?.image}</h4>
                </div>

                <div className="pro_link_adhaar_link">
                  <a style={{color:'black'}} href={empOnePersonData?.image || '#'} target='_blank'><EyeOutlined /></a>
                </div>

              </div>
          </div>
        </div>
        {/* Fullscreen Image Overlay */}
      </div>
    </EmployeeLayout>
  );
};

export default EmployeeProfile;
