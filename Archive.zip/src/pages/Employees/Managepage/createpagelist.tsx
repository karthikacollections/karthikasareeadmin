import { Button, Form, Input, Space, message } from 'antd';
import React, { useEffect } from 'react';

import { useMutation, useApolloClient } from "@apollo/client";

import { CHECK_PAGE_PARENT_EXISTS } from '../../../helpers/queries'
import { CREATE_PAGE, UPDATE_PAGE_NAME } from '../../../helpers/mutation'


export const createResume: React.FC<any> = ({ ModalClose, editdraw,showModal }) => {

    const [form] = Form.useForm();
    const client = useApolloClient();

    const [create_page, { loading: PageLoading, error: PageError, data: PageData }] = useMutation(CREATE_PAGE, {
        errorPolicy: 'all',
    });


    const [update_page_name, { loading: updateLoading, error: updateError, data: updateDataAddress }] = useMutation(UPDATE_PAGE_NAME, {
        errorPolicy: 'all',
    });

    useEffect(() => {
        form.setFieldsValue(editdraw)
    }, [editdraw])

    const api = (values: any) => {
        if (editdraw) {
            update_page_name({
                variables: { ...values, id: editdraw?.id },
            }).then((response) => {
                showModal("Updated")
                ModalClose(null)
            });
        }
        else {
            create_page({
                variables: values
            }).then((response) => {
                showModal("Created")
                ModalClose(null)
            });
        }
    }


    const onFinish = async (values: any) => {

        if (values?.parentpage == values?.pagename) {

            message.error("Page name and Parent page name can't be equal")

        } else if (values?.parentpage) {

            const { data: check_parent_exists } = await client.query({ query: CHECK_PAGE_PARENT_EXISTS, variables: { pagename: values?.parentpage } });


            if (check_parent_exists?.mst_page_list[0]?.id) {
                api(values)
            } else {
                message.error("Parent page name is not exist")
            }
        } else {
            api(values)
        };
    }

    const onFinishFailed = (errorInfo: any) => {
    };


    return (

        <>
            <Form name="basic" layout="vertical" initialValues={{ remember: true }} onFinish={onFinish} onFinishFailed={onFinishFailed} autoComplete="off" form={form} className="Skills_form">
                <Form.Item label="Page Name" name="pagename" rules={[{ required: true, message: 'Please input your pagename!' }]} className="Destination_form_item">
                    <Input placeholder="Page Name" />
                </Form.Item>
                <Form.Item label="Parent Page Name" name="parentpage" rules={[{ message: 'Please input your pagename!' }]} className="Destination_form_item">
                    <Input placeholder="Parent Page Name" />
                </Form.Item>
                <Form.Item >
                    <div className="Skills_submit">
                        <Space>
                            <Button htmlType="button" className="Skills_cancel-btn" onClick={() => ModalClose(null)}>
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="Skills_submit-btn">
                                Submit
                            </Button>
                        </Space>
                    </div>
                </Form.Item>
            </Form>
        </>
    )
}
export default createResume