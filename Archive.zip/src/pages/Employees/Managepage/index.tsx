
import React, { useEffect, useState, } from 'react';
import { Space, Table, Button, Popconfirm, Drawer, message,Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { GET_PAGE_LIST, CHECK_PAGE_CHILD_EXISTS } from '../../../helpers/queries';
import { useQuery, useMutation, useApolloClient } from "@apollo/client";
import { DELETE_PAGE } from "../../../helpers/mutation";
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import Create_Page from "./createpagelist";
import EmployeeLayout from '../employeelayout'
import {useAuth} from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";

interface DataType {
    Name: any;
    Summary: any;
    Role: any;
    Skill: any;
}

export const resume: React.FC = () => {

    const client = useApolloClient();
    const [open, setOpen] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("");
    const { check_button_permission,filteredColumns } = useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
      };
      
      const handleOk = () => {
        Re_Fetch_Page_List();
        setPopOpen(false);
      };
    
      const handleCancel = () => {
        setPopOpen(false);
      };
    

    const ModalClose = () => {
        setOpen(false)
        Re_Fetch_Page_List()
    }

    const { error: userError, loading: fetch_page_list_Loading, data: page_list, refetch: Re_Fetch_Page_List } = useQuery(GET_PAGE_LIST, { variables: {}, });

    // delete destination

    const [delete_page, { loading, error, data }] = useMutation(DELETE_PAGE);

    const handleDelete = async (id: any) => {



        const { data: check_parent_exists } = await client.query({ query: CHECK_PAGE_CHILD_EXISTS, variables: { parentpage: id?.pagename } });

        if (check_parent_exists?.mst_page_list[0]?.id) {
            message.error(`Failed : Due to ${id?.pagename} child page exist`)
        } else {
            delete_page({
                variables: id,
            }).then(() => {
                Re_Fetch_Page_List()
            });
        }
    };

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
    }
    var count = 0
    const columns: ColumnsType<DataType> = [

        // {
        //     title: 'S.no',
        //     dataIndex: 's.no',
        //     render: () => ++count,
        // },
        {
            title: 'Page Name',
            dataIndex: 'pagename',
            key: 'pagename',
        },
        {
            title: 'Parent Page',
            dataIndex: 'parentpage',
            key: 'parentpage',
        },
        {
            title: 'Action',
            key: 'action',
            render: (_, record) => (
                <Space size='large'>
                    {
                        check_button_permission("Managepage", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="Skills_edit"
                            />:<></>
                    }

                    {
                        check_button_permission("Managepage", "delete")
                            ?
                            <Popconfirm
                                title="Delete the task"
                                description="Are you sure to Delete?"
                                okText="Yes"
                                cancelText="No"
                                onConfirm={() => handleDelete(record)}
                            >
                                <DeleteOutlined className="Skills_delete" />
                            </Popconfirm>:<></>
                    }
                </Space>
            ),
        },
    ];

    const check_parent_name = (record: any) => {
        if (page_list?.mst_page_list?.length > 0) {
            if (page_list?.mst_page_list.find((item: any) => item.parentpage === record.pagename)) {
                return true
            } else {
                return false
            }
        } else {
            return false
        }
    }

    const Expand_table_config = (param: any) => {

        if (page_list?.mst_page_list?.length > 0) {
            let filter_parent_relation_name = page_list?.mst_page_list?.filter((record: any) => {
                return record?.parentpage == param?.pagename
            })

            return (
                <>
                    <Table
                        columns={columns}
                        dataSource={filter_parent_relation_name}
                        pagination={false}
                        className="Skills_table"
                        expandable={{
                            expandedRowRender: (record: any) => {
                                
                                return (
                                    Expand_table_config(record)
                                );
                            },
                            rowExpandable: (record: any) => { return check_parent_name(record) }
                        }}
                    />
                </>
            )



        } else {
            return ""
        }
    }

    const Expand_row = () => {


        return
    }

    const Add_key_value=()=>{
        
        
        let filterData=page_list?.mst_page_list?.filter((record: any) => !record?.parentpage)
        let retrunData=filterData?.map((param:any)=>{
            let addKey={...param,key:param?.id}
            return addKey
        })
        
        return retrunData
    }

    return (
        <EmployeeLayout>

            <div className="Skills">
                <div className="Skills_head">
                    <h2 className="Skills_head-text">Manage Page</h2>
                    {
                        check_button_permission("Managepage", "create")
                            ?
                    <Button className="Skills_head-create" onClick={() => setOpen("Create")}>+ Add Page</Button>
                    :<></>
                    }
                </div>
                <Table
                    columns={filteredColumns(columns,"Managepage")}
                    dataSource={Add_key_value()}
                    pagination={false}
                    className="Skills_table"
                    expandable={{
                        expandedRowRender: (record: any) => {
                            return (
                                Expand_table_config(record)
                            );
                        },
                        rowExpandable: (record: any) => { return check_parent_name(record) }
                    }}
                />

                <Drawer title={`${open} Page`} width={570} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}>
                    {
                        open == "Edit" ? (<Create_Page ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        open == "Create" ? (<Create_Page ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                    }


                </Drawer>

            </div>

            <Modal
                open={Popopen}
                title=""
                onOk={handleOk}
                onCancel={handleCancel}
                footer={[
                <div style={{display: "flex", justifyContent: "center"}}>
                    <Button
                    key="submit"
                    type="primary"
                    loading={loading}
                    onClick={handleOk}
                    style={{
                        display: "flex",
                        width: "206px",
                        padding: "15px 30px",
                        justifyContent: "center",
                        alignItems: "center",
                        gap: "10px",
                        borderRadius: "8px",
                        background: "#252947",
                    }}>
                    OK
                    </Button>
                </div>,
                ]}
                width={"386px"}
            >
                <Space
                style={{
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                }}>
                <Image
                    src={PopImage}
                    alt="image"
                    style={{
                    width: "150px",
                    height: "150px",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    }}
                />
                <p
                    style={{
                    color: "#101010",
                    textAlign: "center",
                    fontFamily: "revert",
                    fontSize: "32px",
                    fontStyle: "normal",
                    fontWeight: "700",
                    lineHeight: "normal",
                    }}>
                    {`${title}`} Successfully
                </p>
                </Space>
            </Modal>

        </EmployeeLayout>
    )
}

export default resume
