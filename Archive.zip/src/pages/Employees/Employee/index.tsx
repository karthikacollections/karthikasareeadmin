import React, { useState, useEffect } from "react";
import {
  Space,
  Table,
  Form,
  Button,
  Popconfirm,
  Modal,
  Drawer,
  Select,
} from "antd";
import type { ColumnsType } from "antd/es/table";
import { Switch } from "antd";
import { useQuery, useMutation, useLazyQuery } from "@apollo/client";
import { GET_EMPLOYDETAILS, GET_ORGANIZATION } from "../../../helpers/queries";
import {
  UPDATE_DELETE_EMPLOYEEDETAILS,
  GETUSER_QUERY,
  UPDATE_STATUS_EMPLOYEEDETAILS,
  UPDATE_EMPLOYEE_DOR,
} from "../../../helpers/mutation";
import {
  DeleteOutlined,
  EditOutlined,
  FilterOutlined,
  DownCircleOutlined,
} from "@ant-design/icons";
import CreateEmp from "./createEmp";
import moment from "moment";
import EmployeeLayout from "../employeelayout";
import { useAuth } from "../../../components/auth";
import Link from "next/link";
import Pro, { EmployeeProfile } from "../Pro";
import { createContext } from "vm";
import { useRouter } from "next/router";
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";
import * as FileSaver from "file-saver";
import * as XLSX from "sheetjs-style";

interface DataType {
  key: string;
  name: string;
  email: string;
  destination: string;
  doj: number;
  adhar: string;
  pan: string;
  education: string;
  role: string;
  createdat: number;
}

export const Employee: React.FC<any> = ({ urlList }) => {
  const [userlist, setUser] = useState([]);
  const [FilteredUserlist, setFilteredUser] = useState([]);
  const [open, setOpen] = useState<any>(null);
  const [editdraw, setEditdraw] = useState("");
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [empName, setEmpName] = useState("");
  const [count, setCount] = useState(1);
  const router = useRouter();
  const { check_button_permission, filteredColumns, check_user_type, user } =
    useAuth();
  const [selectedValue, setSelectedValue] = useState("");
  const [selectedOrgValue, setSelectedOrgValue] = useState("") ;
  const handleSelectChange = (value: any) => {
    setSelectedValue(value);
  };

  const handleSelectChangeOrganization = (value: any) => {
    if (value === undefined) {
      sessionStorage.removeItem("search");
    } else {
      sessionStorage.setItem("search", value);
    }
    setSelectedOrgValue(value);
  };

  const fileType =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  const fileExtension = ".xlsx";
  const xlsDownload = async (record: any) => {
    const ws = XLSX.utils.json_to_sheet(record);
    const wb = { Sheets: { data: ws }, SheetNames: ["data"] };
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], { type: fileType });
    FileSaver.saveAs(data, `table_data${fileExtension}`);
  };

  let a = check_user_type();

  const ModalClose = () => {
    setOpen(false);
    refetEmployDetails();
  };

  const [
    refetEmployDetails,
    {
      loading: loadingUser,
      error: userError,
      data: dataUser,
      refetch: refetEmp,
    },
  ] = useLazyQuery(GET_EMPLOYDETAILS);

  const {
    error: orgError,
    loading: userLoading,
    data: orgData,
    refetch: refetOrganizationDetails,
  } = useQuery(GET_ORGANIZATION);

  const search = (data: any) => {
    let searchOrg = sessionStorage.getItem("search");

    if (selectedValue && selectedOrgValue) {
      return data.filter(
        (u: any) =>
          u.name?.toLowerCase().includes(selectedValue?.toLowerCase()) &&
          u.mst_organization?.name
            ?.toLowerCase()
            .includes(selectedOrgValue?.toLowerCase())
      );
    } else if (selectedValue) {
      return userlist.filter((u: any) =>
        u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
      );
    } else if (selectedOrgValue) {
      return data?.filter((u: any) =>
        u?.mst_organization?.name
          ?.toLowerCase()
          .includes(selectedOrgValue?.toLowerCase())
      );
    } else if (searchOrg) {
      return data?.filter((u: any) =>
        u?.mst_organization?.name
          ?.toLowerCase()
          .includes(searchOrg?.toLowerCase())
      );
    } else {
      return data;
    }
  };

  let empData = [...(dataUser?.mst_employeedetails || [])];
  let sort = empData?.sort((a: any, b: any) => a?.name.localeCompare(b?.name));

  const [
    refetEmployDetailsOne,
    { loading: loadingUserOne, error: userErrorOne, data: dataUserOne },
  ] = useLazyQuery(GETUSER_QUERY);

  const PassContext = createContext({});

  // useEffect(() => {
  //   if (check_user_type() === true) {
  //     let userlist = dataUser?.mst_employeedetails?.filter(
  //       (param: any) => !param?.isdeleteat
  //     );
  //      setUser(userlist);
  //   } else {
  //     let userlist = dataUserOne?.mst_employeedetails?.filter(
  //       (param: any) => !param?.isdeleteat
  //     );
  //     setUser(userlist);
  //   }
  // }, [dataUser, dataUserOne]);

  useEffect(() => {
    if (check_user_type() === true) {
      let userlist: [] = dataUser?.mst_employeedetails?.map((param: any) => {
        return param;
      });
      let sortEmpData = userlist?.sort((a: any, b: any) =>
        a?.name.localeCompare(b?.name)
      );
      setUser(sortEmpData);
      if (userlist) {
        let filterActiveEmployee = userlist?.filter((data: any) => {
          return data?.status === true;
        });
        setFilteredUser(filterActiveEmployee)
      }
    } else {
      let userlist = dataUserOne?.mst_employeedetails?.filter(
        (param: any) => !param?.isdeleteat
      );
      setUser(userlist);
    }
  }, [dataUser, dataUserOne]);

  const get_User_Type_Data = () => {
    let user_type = check_user_type();
    if (user_type === true) {
      refetEmployDetails({
        variables: {},
      });
    } else {
      refetEmployDetailsOne({ variables: { email: user_type } });
    }
  };

  useEffect(() => {
    get_User_Type_Data();
  }, []);

  const deleteAccount = async (email: any) => {
    try {
      const response = await fetch("/api/auth/delete-account", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      if (response.ok) {
        const data = await response.json();
      } else {
      }
    } catch (error) {}
  };

  const [deleteEmployee, { loading, error, data }] = useMutation(
    UPDATE_DELETE_EMPLOYEEDETAILS
  );

  const [
    updateDorEmployee,
    { loading: dorLoading, error: dorError, data: dorData },
  ] = useMutation(UPDATE_EMPLOYEE_DOR);

  const [
    statsuEmployee,
    { loading: loadingStatus, error: errorStatus, data: dataStatus },
  ] = useMutation(UPDATE_STATUS_EMPLOYEEDETAILS);

  const handleDelete = (req: any) => {
  let deleteParam = { id: "", isdeleteat: false };
    deleteParam.id = req.id;
    deleteParam.isdeleteat = !req.isdeleteat;
    deleteEmployee({
      variables: deleteParam,
    }).then((res: any) => {
      showModal("Delete", req?.name);
    });
    // deleteAccount(req?.email);
  };

  const handleStatus = (req: any) => {
    let date = new Date();
    let statusParam = { id: "", status: false };
    let updateDorParam: any = { id: "" };
    statusParam.id = req.id;
    statusParam.status = !req.status;
    updateDorParam.dor = date;
    updateDorParam.id = req.id;

    statsuEmployee({
      variables: statusParam,
    }).then((res: any) => {
      refetEmp();
    });
    if (req.status) {
      updateDorEmployee({
        variables: updateDorParam,
      });
    }
  };

  const handleChange = (record: any) => {
    setEditdraw(record);
    setOpen("Edit");
  };

  const columns: ColumnsType<DataType> = [
    {
      title: "S.No",
      render: (text, record, rowIndex) => count + rowIndex,
    },
    {
      title: "Profile Pic",
      render: (urlList: any) => {
        return (
          <img
            src={urlList?.image}
            alt="Image"
            style={{ width: "100px" }}
            className="employee-details_table-profile"
          />
        );
      },
    },
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },

    {
      title: "Organization",
      render: (value: any) => {
        let organization = value?.mst_organization?.name;
        return <p>{organization}</p>;
      },
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Status",
      render: (record: any) => {
        let cheackStatus = record?.status;

        return (
          <Popconfirm
            title="Change employee status"
            description="Are you sure to change employee status?"
            okText="Yes"
            cancelText="No"
            onConfirm={() => handleStatus(record)}
          >
            <Button
              className={`status-toggle ${
                cheackStatus ? "active" : "inactive"
              }`}
            >
              {cheackStatus ? "Active" : "InActive"}
            </Button>
          </Popconfirm>
        );
      },
    },
    {
      title: "View",
      dataIndex: "view",
      key: "view",
      render: (_, record: any) => {
        const EmpData = () => {
          return <EmployeeProfile data={record} />;
        };
        return (
          <>
            <Link
              href={{
                pathname: `/Employees/Pro`,
                query: {
                  data: JSON.stringify(record),
                  id: JSON.stringify(record?.id),
                },
              }}
            >
              <Button type="primary">View</Button>
            </Link>
          </>
        );
      },
    },
    {
      title: "Action",
      key: "action",
      render: (record: any) => (
        <Space size="large">
          {check_button_permission("Employee", "edit") ? (
            <EditOutlined
              onClick={() => handleChange(record)}
              className="employee-details_edit"
            />
          ) : (
            <></>
          )}

          {check_button_permission("Employee", "delecte") ? (
            <Popconfirm
              title="Delete the employee details"
              description="Are you sure to delete this employee details?"
              okText="Yes"
              cancelText="No"
              onConfirm={() => handleDelete(record)}
            >
              <DeleteOutlined className="employee-details_delete" />
            </Popconfirm>
          ) : (
            <></>
          )}
        </Space>
      ),
    },
  ];

  const showModal = (param: any, paramData: any) => {
    setPopOpen(true);
    setTitle(param);
    setEmpName(paramData);
  };

  const handleOk = () => {
    refetEmp();
    setPopOpen(false);
  };

  const handleCancel = () => {
    setPopOpen(false);
  };
  const onChangeToggle = (checked:any) => {
    if(!checked){
      let filterActiveEmployee = userlist?.filter((data: any) => {
        return data?.status === true;
      });
      setFilteredUser(filterActiveEmployee)
    } else {
      let filterActiveEmployee = userlist?.filter((data: any) => {
        return data?.status === false;
      });
      setFilteredUser(filterActiveEmployee)
    }
  };

  return (
    <EmployeeLayout>
      <div className="employee-details">
        <div className="employee-details_head">
          <h3 className="employee-details_head-text">Employee Details</h3>

         {user.email === "admin@gmail.com" && (
          <h3 className="employee-details_head-text">
            Inactive Employee
            <Switch size="small" className="employee-details_head-text_btn" onChange={onChangeToggle} />
          </h3>
          )}
      
         <div className="header_right">
            {user.email === "admin@gmail.com" && (
              <Select
                size={"large"}
                onChange={handleSelectChangeOrganization}
                allowClear
                showSearch
                filterOption={(input, option: any) =>
                  option.children.toLowerCase().indexOf(input.toLowerCase()) >=
                  0
                }
                placeholder={"Select Organization"}
                defaultValue={sessionStorage.getItem("search")}
                className="Asset_selecter"
                style={{ width: "220px", marginRight: "10px" }}
              >
                {orgData?.mst_organization?.map((org: any, index: any) => (
                  <Select.Option value={org?.name} key={index}>
                    {org?.name}
                  </Select.Option>
                ))}
              </Select>
            )}
            {user.email === "admin@gmail.com" && (
              <Select
                size={"large"}
                onChange={handleSelectChange}
                allowClear
                showSearch
                filterOption={(input, option: any) =>
                  option.children.toLowerCase().indexOf(input.toLowerCase()) >=
                  0
                }
                placeholder={" Select Employee"}
                className="Asset_selecter"
                style={{ width: "220px", marginRight: "10px" }}
              >
                {sort?.map((emp: any, index: any) => {
                  return (
                      <Select.Option value={emp.name} key={index}>
                        {emp?.name}
                      </Select.Option>
                    );
                 })}
              </Select>
            )}
            {/* <Button
            className="employee-details_head-create"
            onClick={() => xlsDownload(newArray)}>Download</Button> */}
            {check_button_permission("Employee", "create") ? (
              <Button
                className="employee-details_head-create"
                onClick={() => setOpen("Create")}
              >
                + Add New Employee
              </Button>
            ) : (
              <></>
            )}
          </div>
        </div>

        {user.email === "admin@gmail.com"? (
           <Table
          columns={filteredColumns(columns, "Employee")}
          dataSource={search(FilteredUserlist)}
          pagination={{ pageSize: 10 }}
          className="employee-details_table"
        />
        ): <Table
        columns={filteredColumns(columns, "Employee")}
        dataSource={search(userlist)}
        pagination={{ pageSize: 10 }}
        className="employee-details_table"
      />
        }

       

        <Drawer
          title={`${open} Employee`}
          width={870}
          placement="right"
          onClose={() => setOpen(false)}
          open={open?.length > 1 ? true : false}
          className="employee-details_drawer"
        >
          {open == "Edit" ? (
            <CreateEmp
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={editdraw}
            />
          ) : (
            <></>
          )}

          {open == "Create" ? (
            <CreateEmp
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={null}
            />
          ) : (
            <></>
          )}
        </Drawer>
      </div>
      <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{ display: "flex", justifyContent: "center" }}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}
            >
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}
      >
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "28px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}
          >
            {`${empName}`} {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
    </EmployeeLayout>
  );
};

export default Employee;
