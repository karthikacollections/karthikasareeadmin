import React, { useRef, useEffect, useState } from 'react'
import dayjs from "dayjs";
import moment from 'moment';
import { Form, Modal, Input, Button, Popconfirm, Select, Space, DatePickerProps, Drawer, DatePicker, message, Upload, Row, Col } from 'antd';
import { CREATE_EMPLOYDETAILS, UPDATE_EMPLOYDETAILS, } from "../../../helpers/mutation";
import { useQuery, useMutation, useLazyQuery } from "@apollo/client";
import { UploadOutlined, ExclamationCircleOutlined, DeleteOutlined } from '@ant-design/icons';
import { GET_DESTINATION, GET_ROLE, GET_ORGANIZATION, GET_DEPARTMENT } from '../../../helpers/queries'
import { GET_EMPLOYDETAILS } from '../../../helpers/queries'
import { GETUSER_QUERY } from '../../../helpers/mutation';
import { signup, change_password, change_email } from '../../../components/auth'
import { log } from 'console';

const { Option } = Select;

const createEmp: React.FC<any> = ({ ModalClose, editdraw, showModal }) => {


    const [user, setUser] = useState([])
    const formRef = useRef(null);
    const [form] = Form.useForm();
    const [doj, setDoj] = useState(null)
    const [dob, setDob] = useState(null)
    // const [dor, setDor] = useState(null)
    const [checkEmailExists, { loading, error, data }] = useLazyQuery(GETUSER_QUERY);
    const [destUser, setDestUser] = useState([])
    const [role, setRole] = useState([])
    const [org, setOrg] = useState([])
    const [dep, setDep] = useState([])
    const [urlList, setUrlList] = useState([] as any[]);
    const [urlAdhaar, seturlAdhaar] = useState([] as any[]);
    const [urlPan, seturlPan] = useState([] as any[]);
    const [urlEdu, seturlEdu] = useState([] as any[]);
    const [urlExp, seturlExp] = useState([] as any[]);
    const [urlResume, seturlResume] = useState([] as any[]);
    const [loadingMP, setLoading] = useState(false);
    const { Dragger } = Upload;
    const [formtype, setformtype] = useState("create")
    const [updatepasswordform, setupdatepasswordform] = useState(false)
    const [isEmailChanged, setIsEmailChanged] = useState(false);
    const [editforminitaldata, seteditforminitaldata]: any = useState(false);
    const [modalImageOpen, setModalImageOpen] = useState<boolean>(false)
    const [modalImage, setModalImage] = useState<any>(null)
    const [personID, setPersonID] = useState<boolean>(true)

    const ImageUploaderProp: any = {
        name: "file",
        multiple: true,
        action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
        onChange(info: any) {

            const { status } = info.file;
            if (status !== "uploading") {
            }
            if (status === "done") {
                message.success(`${info.file.name} file uploaded successfully.`);
            } else if (status === "error") {
                message.error(`${info.file.name} file upload failed.`);
            }
        },
    };


    const uploadImages = async (options: any) => {
        const { onSuccess, onError, file } = options;
        try {
            {
                setLoading(true);
                const data = new FormData();
                data.append("upload_preset", "Employee");
                data.append("file", file);
                data.append("cloud_name", "dgcgmcaxb");
                fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
                    method: "post",
                    body: data,
                })
                    .then((resp) => resp.json())
                    .then((data) => {
                        setUrlList((urlList) => [...urlList, data.url]);
                        setLoading(false);
                    })
                    .catch((err) => {
                        setLoading(false);
                    });
                onSuccess("Ok");
            }
        } catch (err) {
            const error = new Error("Some error");
            onError({ err });
        }
    };

    const uploadPan = async (options: any) => {
        const { onSuccess, onError, file } = options;
        try {
            {
                setLoading(true);
                const data = new FormData();
                data.append("upload_preset", "Employee");
                data.append("file", file);
                data.append("cloud_name", "dgcgmcaxb");


                fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
                    method: "post",
                    body: data,
                })
                    .then((resp) => resp.json())
                    .then((data) => {
                        seturlPan((urlPan) => [...urlPan, data.url]);
                        setLoading(false);
                    })
                    .catch((err) => {
                        setLoading(false);
                    });
                onSuccess("Ok");
            }
        } catch (err) {
            const error = new Error("Some error");
            onError({ err });
        }
    };

    const uploadAdhaar = async (options: any) => {
        const { onSuccess, onError, file } = options;
        try {
            {
                setLoading(true);
                const data = new FormData();
                data.append("upload_preset", "Employee");
                data.append("file", file);

                data.append("cloud_name", "dgcgmcaxb");


                fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
                    method: "post",
                    body: data,
                })
                    .then((resp) => resp.json())
                    .then((data) => {
                        seturlAdhaar((urlAdhaar) => [...urlAdhaar, data.url]);
                        setLoading(false);
                    })
                    .catch((err) => {
                        setLoading(false);
                    });
                onSuccess("Ok");
            }
        } catch (err) {
            const error = new Error("Some error");
            onError({ err });
        }
    };

    const uploadEducation = async (options: any) => {
        const { onSuccess, onError, file } = options;
        try {
            {
                setLoading(true);
                const data = new FormData();
                data.append("upload_preset", "Employee");
                data.append("file", file);
                data.append("cloud_name", "dgcgmcaxb");


                fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
                    method: "post",
                    body: data,
                })
                    .then((resp) => resp.json())
                    .then((data) => {
                        seturlEdu((urlEdu) => [...urlEdu, data.url]);
                        setLoading(false);
                    })
                    .catch((err) => {
                        setLoading(false);
                    });
                onSuccess("Ok");
            }
        } catch (err) {
            const error = new Error("Some error");
            onError({ err });
        }
    };

    const uploadResume = async (options: any) => {
        const { onSuccess, onError, file } = options;
        try {
            {
                setLoading(true);
                const data = new FormData();
                data.append("upload_preset", "Employee");
                data.append("file", file);
                data.append("cloud_name", "hysas-tech");


                fetch("https://api.cloudinary.com/v1_1/hysas-tech/image/upload", {
                    method: "post",
                    body: data,
                })
                    .then((resp) => resp.json())
                    .then((data) => {
                        seturlResume((urlResume) => [...urlResume, data.url]);
                        setLoading(false);
                    })
                    .catch((err) => {
                        setLoading(false);
                    });
                onSuccess("Ok");
            }
        } catch (err) {
            const error = new Error("Some error");
            onError({ err });
        }
    };

    const uploadExp = async (options: any) => {
        const { onSuccess, onError, file } = options;
        try {
            {
                setLoading(true);
                const data = new FormData();
                data.append("upload_preset", "Employee");
                data.append("file", file);
                data.append("cloud_name", "dgcgmcaxb");


                fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
                    method: "post",
                    body: data,
                })
                    .then((resp) => resp.json())
                    .then((data) => {
                        seturlExp((urlExp) => [...urlExp, data.url]);
                        setLoading(false);
                    })
                    .catch((err) => {
                        setLoading(false);
                    });
                onSuccess("Ok");
            }
        } catch (err) {
            const error = new Error("Some error");
            onError({ err });
        }
    };

    const handleBeforeUpload = (file: any) => {
        const fileSizeInMB = file.size / 1024 / 1024; // Convert bytes to megabytes
        const maxFileSizeInMB = 2;
        if (fileSizeInMB > maxFileSizeInMB) {
            message.error(`File size must be within ${maxFileSizeInMB}MB!`);
            return false;
        }
        return true;
    };


    const handleRemove = async (images: any) => {
        let filteredImage = urlList?.filter(e => e !== images);
        setUrlList(filteredImage);
    };

    const handleDelete = async (images: any) => {
        let filteredImage = urlAdhaar?.filter(e => e !== images);
        seturlAdhaar(filteredImage);

    };

    const deletePan = async (images: any) => {
        let filteredImage = urlPan?.filter(e => e !== images);
        seturlPan(filteredImage);

    };

    const deleteEdu = async (images: any) => {
        let filteredImage = urlEdu?.filter(e => e !== images);
        seturlEdu(filteredImage);

    };

    const deleteExp = async (images: any) => {
        let filteredImage = urlExp?.filter(e => e !== images);
        seturlExp(filteredImage);

    };

    const deleteRes = async (images: any) => {
        let filteredImage = urlResume?.filter(e => e !== images);
        seturlResume(filteredImage);

    };

    // get destination details
    const {
        error: destnationError,
        loading: destinationLoading,
        data: datadestination,
        refetch: refetdestination,
    } = useQuery(GET_DESTINATION, {
        variables: {},
    });

    useEffect(() => {
        if (datadestination) {
            let destUser = datadestination?.mst_destination;
            setDestUser(destUser)
        }
    }, [datadestination])



    // get rol
    const {
        error: roleError,
        loading: roleLoading,
        data: dataRole,
        refetch: refetrole,
    } = useQuery(GET_ROLE, {
        variables: {},
    });

    useEffect(() => {
        if (dataRole) {
            let role = dataRole?.mst_role
            setRole(role)
        }
    }, [dataRole])

    // get oragnization
    const {
        error: orgError,
        loading: orgLoading,
        data: dataOrg,
        refetch: refetorg,
    } = useQuery(GET_ORGANIZATION, {
        variables: {},
    });

    useEffect(() => {
        if (dataOrg) {
            let Org = dataOrg?.mst_organization
            setOrg(Org)
        }
    }, [dataOrg])

    // get oragnization
    const {
        error: depError,
        loading: depLoading,
        data: datadep,
        refetch: refetdep,
    } = useQuery(GET_DEPARTMENT, {
        variables: {},
    });

    useEffect(() => {
        if (datadep) {
            let dep = datadep?.mst_department
           setDep(dep);
         }
    }, [datadep])


  // get employDetails

    const {
        error: userError,
        loading: userLoading,
        data: dataUser,
        refetch: refetEmployDetails,
    } = useQuery(GET_EMPLOYDETAILS, {
        variables: {},
    });

    useEffect(() => {
        if (dataUser) {
            let user = dataUser?.mst_employeedetails
            setUser(user)
        }
    }, [dataUser])


    // create employDetails

    const [createEmployee, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_EMPLOYDETAILS, {
        errorPolicy: 'all',
    });



    // update employDetails

    const [
        updateEmployee,
        { loading: updateloading, error: updateerror, data: updatedataAddress },
    ] = useMutation(UPDATE_EMPLOYDETAILS, {
        errorPolicy: "all",
    });

    useEffect(() => {
        if (editdraw) {
            let data = JSON.parse(JSON.stringify(editdraw))
            data.doj = dayjs(editdraw.doj)
            data.dob = data.dob !== null ? dayjs(editdraw.dob) : ''
            // data.dor = dayjs(editdraw.dor)
            data.date = dayjs(editdraw.date)
            setUrlList(data?.image?.split(','));
            seturlAdhaar(data?.adhaar_photo?.split(','));
            seturlPan(data?.pan_photos?.split(','));
            seturlExp(data?.experience_letter?.split(','));
            seturlResume(data?.resume?.split(','));
            seturlEdu(data?.education_photo?.split(','));
            form.setFieldsValue(data)
            setformtype("edit")
            setDoj(data.doj)
            setDob(data.dob)
            seteditforminitaldata(data)
        }
    }, [editdraw])


    const { data: asdasd } = useQuery(GETUSER_QUERY, {
        variables: { email: "nathan@gmail.com" },
    });



    const onFinish = async (values: any) => {
        if (values?.adhar?.length === 0 || values?.pan?.length === 0) {
            setPersonID(true)
        } else {
            setPersonID(false)
        }

        if (editdraw) {
            values.id = editdraw?.id
            values.image = urlList.toString()
            values.adhaar_photo = urlAdhaar.toString()
            values.pan_photos = urlPan.toString()
            values.resume = urlResume.toString()
            values.experience_letter = urlExp.toString()
            values.education_photo = urlEdu.toString()
            values.doj = dayjs(doj).format('YYYY-MM-DD')
            values.dob = dayjs(dob).format('YYYY-MM-DD')
            updateEmployee({
                variables: values,
            }).then((response) => {
                refetEmployDetails()
                ModalClose(null)
                showModal('Updated', values?.name)

            });
            if (isEmailChanged) {
                let response: any = change_email(editforminitaldata?.email, values?.email, values?.password)
                // setIsEmailChanged(false);
                if (!response?.err) {
                    setIsEmailChanged(true);
                }
            }
        }
        else {
            let email = values?.email
            checkEmailExists({ variables: { email } }).then(async (res: any) => {

                if (res?.data?.mst_employeedetails?.length > 0) {
                    message.error(`Already Email Exist in Hasura`);
                } else {

                    await fetch("/api/auth/create-account", {
                        method: "POST",
                        headers: { "Content-Type": "application/json", },
                        body: JSON.stringify({ email: values.email, password: values.password }),
                    }).then((response) => {
                        if (response.ok) {
                            const data = response
                            if (data?.ok) {

                                values.image = urlList.toString()
                                values.adhaar_photo = urlAdhaar.toString()
                                values.pan_photos = urlPan.toString()
                                values.resume = urlResume.toString()
                                values.experience_letter = urlExp.toString()
                                values.education_photo = urlEdu.toString()
                                values.doj = dayjs(doj).format('YYYY-MM-DD')
                                values.dob = dayjs(dob).format('YYYY-MM-DD')

                                createEmployee({ variables: values, }).then((response: any) => {
                                    // message.success(`Hasura Signup Success`);
                                    refetEmployDetails();
                                    ModalClose(null)
                                }).catch((err) => {
                                    message.error(`Hasura Signup Failed`);
                                });

                                // message.success(`Employee Created`);
                                showModal('Created', values?.name)

                            } else {
                                message.error(`Already Email Exist in Firebase`);
                            }
                        } else {
                        }
                    }).catch((error) => {
                        message.error("Error in Create Firebase Account")
                    });
                }

            }).catch((err) => {


            });

        };
    }

    const onFinishFailed = (errorInfo: any) => {

    };



    const onChangedoj: DatePickerProps["onChange"] = (dateString: any) => {
        setDoj(dateString);
    };

    const onChange_DOB: DatePickerProps["onChange"] = (dateString: any) => {
        setDob(dateString);
    };
    // const onChangedor: DatePickerProps["onChange"] = (dateString: any) => {
    //     setDor(dateString);
    // };

    //reset password
    const resetPassword = async (email: any) => {
        try {
            const response = await fetch('/api/auth/reset-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email }),
            });



            if (response.ok) {
                const data = await response.json();
                message.success("Reset link sent : " + response.statusText)
            } else {
                message.error("Error resetting password : " + response.statusText)
            }
        } catch (error) {
            message.error("An error occurred while resetting the password")
        }
    };

    const Change_password = async (email: any, oldpaswrd: any, newpasswrd: any) => {
        await change_password(email, oldpaswrd, newpasswrd)
        form.setFieldValue("oldpassword", "")
        form.setFieldValue("newpassword", "")
    }

    const handleValuesChange = (changedValues: any, allValues: any) => {
        if ('email' in changedValues) {
            let email = form.getFieldValue('email');
            if (email == editforminitaldata?.email) {
                setIsEmailChanged(false)
            } else {
                setIsEmailChanged(true)
            }
        }
    };

    const validateAadhaar = (rule: any, aadhaar: string) => {
        // Regular expression for Aadhaar validation
        const aadhaarRegex = /^[2-9]{1}[0-9]{11}$/;
        if (!aadhaarRegex.test(aadhaar)) {
            return Promise.reject('Invalid Aadhaar Number');
        }
        return Promise.resolve();
    }

    const validatePan = (rule: any, pan: string) => {
        // Regular expression for PAN card validation
        const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]$/;
        if (!panRegex.test(pan)) {
            return Promise.reject('Invalid PAN Card Number');
        }
        return Promise.resolve()
    };

    const modalImageView = (LinkBox: any) => {
        setModalImageOpen(!modalImageOpen)
        setModalImage(LinkBox)
    }

    const modalImageClose = () => {
        setModalImageOpen(!modalImageOpen)
        setModalImage(null)
    }

    return (
        <>
            <Form
                name="basic"
                initialValues={{ remember: true }}
                layout="vertical"
                onFinish={onFinish}
                ref={formRef}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                onValuesChange={handleValuesChange}
                className="employee-details_form"
            >
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            label="Name "
                            name="name"
                            required={false}
                            // style={{width:''}}
                            rules={[{ required: true, message: 'Please input your Name!' }]}
                            className="employee-details_form_item"
                        >
                            <Input className="employee-details_form_item_input" />
                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item
                            label="Designation"
                            name="destination"
                            // style={{width:'200px'}}
                            required={false}
                            rules={[{ required: true, message: 'Please input your Name!' }]}
                            className="employee-details_form_item"
                        >
                            <Select className="employee-details_form_item_select">
                                {destUser.map((data: any) => (
                                    <Select.Option value={data.id} key={data.id}>{data?.name}</Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            label="DOB"
                            name="dob"
                            required={false}
                            // style={{width:''}}
                            rules={[{ required: true, message: 'Please select your DOB' }]}
                            className="employee-details_form_item"
                        >
                            <DatePicker className="employee-details_form-datepic" style={{ width: '300px' }} onChange={onChange_DOB} />
                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item
                            label="Gender"
                            name="gender"
                            // style={{width:'200px'}}
                            required={false}
                            rules={[{ required: true, message: 'Please select your gender' }]}
                            className="employee-details_form_item"
                        >
                            <Select className="employee-details_form_item_select">
                                <Select.Option value='Male'>Male</Select.Option>
                                <Select.Option value='Female'>Female</Select.Option>
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            label="DOJ"
                            name="doj"
                            required={false}
                            rules={[{ required: true, message: 'Please select your doj' }]}
                            className="employee-details_form_item"
                        >
                            <DatePicker className="employee-details_form-datepic" style={{ width: '300px' }} onChange={onChangedoj} />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            label="Phone"
                            name="phone"
                            required={false}
                            rules={[
                                {
                                    required: true,
                                    message: 'Please enter your Phone number!',
                                    pattern: /^\d{10}$/,
                                },
                            ]}
                            className="employee-details_form_item"
                        >
                            <Input className="employee-details_form_item_input" />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            label="Employee Id"
                            name="employeeid"
                            required={false}
                            rules={[{ required: false, message: 'Please select your doj' }]}
                            className="employee-details_form_item"
                        >
                            <Input className="employee-details_form_item_input" />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            label="Blood Group"
                            name="blood_group"
                            required={false}
                            rules={[{ required: false, message: 'Please select your doj' }]}
                            className="employee-details_form_item"
                        >
                            <Input className="employee-details_form_item_input" />
                        </Form.Item>
                    </Col>
                </Row>

                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            label="Marital status"
                            name="marital_status"
                            required={false}
                            rules={[{ required: false, message: 'Please select your doj' }]}
                            className="employee-details_form_item"
                        >
                            <Select className="employee-details_form_item_input">
                                <Option value="Married">Married</Option>
                                <Option value="Unmarried">Unmarried</Option>
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>

                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item label="Email " name="email" required={false} rules={[{ required: true, message: 'Please input your Email' }, {
                            type: 'email',
                            message: 'Please enter a valid email address!',
                        },]} className="employee-details_form_item">
                            <Input className="employee-details_form_item_input" />
                        </Form.Item>
                    </Col>

                    {
                        isEmailChanged
                            ?
                            <Col span={12}>
                                <Form.Item label="Required Password to change email" name="password" required={false} rules={[{ required: true, message: 'Please input your Password!' }]} className="employee-details_form_item">
                                    <Input className="employee-details_form_item_input" />
                                </Form.Item>
                            </Col>
                            :
                            <></>
                    }

                    {
                        isEmailChanged ? <></> : formtype == "create"
                            ?
                            <Col span={12}>
                                <Form.Item label="Password " name="password" required={false} rules={[{ required: true, message: 'Please input your Password!' }]} className="employee-details_form_item">
                                    <Input className="employee-details_form_item_input" />
                                </Form.Item>
                            </Col>
                            :
                            updatepasswordform
                                ?
                                <>
                                    <Form.Item label="Old Password " name="oldpassword" required={false} rules={[{ required: true, message: 'Please input your Password!' }]} className="employee-details_form_item">
                                        <Input className="employee-details_form_item_input" />
                                    </Form.Item>
                                    <Form.Item label="New Password " name="newpassword" required={false} rules={[{ required: true, message: 'Please input your Password!' }]} className="employee-details_form_item">
                                        <Input className="employee-details_form_item_input" />
                                    </Form.Item>
                                    <Form.Item required={false} rules={[{ required: true, message: 'Please input your Password!' }]} className="employee-details_form_item">
                                        <Button onClick={() => {
                                            let email = form.getFieldValue('email');
                                            let oldpasswrd = form.getFieldValue('oldpassword');
                                            let newpasswrd = form.getFieldValue('newpassword');

                                            if (email) {
                                                Change_password(email, oldpasswrd, newpasswrd)
                                                setupdatepasswordform(false)
                                            } else {
                                                message.error("Reset failed")
                                            }
                                        }} type='primary'>Change
                                        </Button>
                                    </Form.Item>
                                </>
                                :


                                <Form.Item label="Password" name="" className="employee-details_form_item">
                                    <Space>
                                        <Button onClick={() => {
                                            setupdatepasswordform(true)
                                        }} type='primary'>Change password
                                        </Button>
                                        <Button onClick={() => {
                                            let email = form.getFieldValue('email');

                                            if (email) {
                                                resetPassword(email)

                                            } else {
                                                message.error("Reset failed")
                                            }
                                        }} type='primary'>Reset
                                        </Button>
                                    </Space>

                                </Form.Item>

                    }


                </Row>

                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            label="Department"
                            name="department"
                            required={false}
                            rules={[{ required: false, message: 'Please input your department!' }]}
                            className="employee-details_form_item"
                        >
                            <Select className="employee-details_form_item-input">
                                {dep.map((val: any) => {

                                    return (
                                        <Select.Option value={val.id} key={val.id}>{val?.department_name}</Select.Option>
                                    )
                                })
                                }
                            </Select>
                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item
                            label="Role"
                            name="role"
                            required={false}
                            rules={[{ required: true, message: 'Please input your role!' }]}
                            className="employee-details_form_item"
                        >
                            <Select className="employee-details_form_item-input">
                                {role.map((val: any) => {

                                    return (
                                        <Select.Option value={val.id} key={val.id}>{val?.type}</Select.Option>
                                    )
                                })
                                }
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>

                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            label="Referral"
                            name="referral"
                            required={false}
                            // rules={[{ required: true, message: 'Please input your referal!' }]}
                            className="employee-details_form_item"
                        >
                            <Select className="employee-details_form_item-input">
                                {user.map((val: any) => {
                                    if(val.status === true ){
                                        return (
                                            <Select.Option value={val?.id} key={val.id}>{val?.name}</Select.Option>
                                        )
                                    }
                                 })
                                }
                            </Select>
                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item
                            label="Organization"
                            name="organization"
                            required={false}
                            rules={[{ required: true, message: 'Please input your organization!' }]}
                            className="employee-details_form_item"
                        >
                            <Select className="employee-details_form_item-input">
                                {org.map((val: any) => {

                                    return (
                                        <Select.Option value={val.id} key={val.id}>{val?.name}</Select.Option>
                                    )
                                })
                                }
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>

                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            label="Adhaar"
                            name="adhar"
                            required={false}
                            rules={[
                                ({ getFieldValue }) => ({
                                    required: !getFieldValue('pan'),
                                    message: 'Please input your Adhaar',
                                    pattern: /^\d{12}$/,
                                }),
                            ]}
                            className="employee-details_form_item"
                        >
                            <Input className="employee-details_form_item_input" />
                        </Form.Item>

                        <Col span={12}>
                            <Form.Item
                                className="image_dragger"
                                required={false}
                                rules={[{ required: true, message: "Please Upload your Adhar Photo" }]}
                            >
                                {urlAdhaar?.length === 0 &&
                                    <Dragger
                                        {...ImageUploaderProp}
                                        name="file"
                                        beforeUpload={handleBeforeUpload}
                                        showUploadList={false}
                                        customRequest={uploadAdhaar}
                                        className="dragger"
                                        style={{ width: "100%", border: "2px dashed #7FACD6" }}
                                    >
                                        <UploadOutlined className="employee-details_uploade-photo" />
                                        <p>Drag & drop or Browse</p>

                                    </Dragger>
                                }
                                {
                                    urlAdhaar?.map((value) => {
                                        const filename = value?.split('/').pop();

                                        return <>
                                            <div className='employee-details_photodelete_pan' >
                                                <img src={value} alt="profile" width={45} height={45} onClick={() => modalImageView(value)} />
                                                <p className='employee-details_photodelete-para' >{filename}</p>
                                                <DeleteOutlined onClick={() => handleDelete(value)} className='employee-details_delete_icon' />
                                            </div>
                                        </>
                                    })
                                }
                            </Form.Item>
                        </Col>
                    </Col>

                    <Col span={12}>
                        <Form.Item
                            label="Pan"
                            name="pan"
                            className="employee-details_form_item"
                            required={false}
                            rules={[
                                ({ getFieldValue }) => ({
                                    required: !getFieldValue('adhar'),
                                    message: 'Please input your Pan No',
                                    min: 10,
                                    max: 10,
                                }),
                            ]}
                        >
                            <Input className="employee-details_form_item_input" />
                        </Form.Item>

                        <Col span={12}>
                            <Form.Item
                                className="image_dragger"
                            >
                                {urlPan?.length === 0 &&
                                    <Dragger
                                        {...ImageUploaderProp}
                                        name="file"
                                        beforeUpload={handleBeforeUpload}
                                        showUploadList={false}
                                        customRequest={uploadPan}
                                        className="dragger"
                                        style={{ width: "100%", border: "2px dashed #7FACD6" }}
                                    >
                                        <UploadOutlined className="employee-details_uploade-photo" />
                                        <p>Drag & drop or Browse</p>
                                    </Dragger>
                                }
                                {
                                    urlPan?.map((value) => {

                                        const filename = value?.split('/').pop();

                                        return <>
                                            <div className='employee-details_photodelete_pan'>
                                                <img src={value} alt="profile" width={45} height={45} onClick={() => modalImageView(value)} />
                                                <p className='employee-details_photodelete-para' >{filename}</p>
                                                <DeleteOutlined onClick={() => deletePan(value)} className='employee-details_delete_icon' />
                                            </div>
                                        </>
                                    })
                                }
                            </Form.Item>
                        </Col>
                    </Col>
                </Row>

                <Row gutter={16}>
                    <Col span={12}>

                        <Form.Item
                            label="Education"
                            name="education"
                            required={false}
                            rules={[{ required: true, message: "Please Enter the Education details" }]}
                            className="employee-details_form_item"
                        >
                            <Input className="employee-details_form_item_input" />
                        </Form.Item>

                        <Form.Item
                            className="image_dragger"
                        >
                            {urlEdu?.length === 0 &&
                                <Dragger
                                    {...ImageUploaderProp}
                                    name="file"
                                    beforeUpload={handleBeforeUpload}
                                    showUploadList={false}
                                    customRequest={uploadEducation}
                                    className="dragger"
                                    style={{ width: "100%", border: "2px dashed #7FACD6" }}
                                >
                                    <UploadOutlined className="employee-details_uploade-photo" />
                                    <p>Drag & drop or Browse</p>

                                </Dragger>
                            }
                            {
                                urlEdu?.map((value) => {
                                    const filename = value?.split('/').pop();

                                    return <>
                                        <div className='employee-details_photodelete'>
                                            <img src={value} alt="profile" width={45} height={45} onClick={() => modalImageView(value)} />
                                            <p className='employee-details_photodelete-para' >{filename}</p>
                                            <DeleteOutlined onClick={() => deleteEdu(value)} className='employee-details_delete_icon' />
                                        </div>
                                    </>
                                })
                            }
                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item
                            label="Experience letter"
                            name='expericeLetter'
                        >
                            {urlExp?.length === 0 &&
                                <Dragger
                                    {...ImageUploaderProp}
                                    name="file"
                                    beforeUpload={handleBeforeUpload}
                                    showUploadList={false}
                                    customRequest={uploadExp}
                                    className="dragger"
                                    style={{ width: "100%", border: "2px dashed #7FACD6" }}
                                >
                                    <UploadOutlined className="employee-details_uploade-photo" />
                                    <p>Drag & drop or Browse</p>

                                </Dragger>
                            }
                            {
                                urlExp?.map((value) => {
                                    const filename = value?.split('/').pop();

                                    return <>
                                        <div className='employee-details_photodelete'>
                                            <img src={value} alt="profile" width={45} height={45} onClick={() => modalImageView(value)} />
                                            <p className='employee-details_photodelete-para' >{filename}</p>
                                            <DeleteOutlined onClick={() => deleteExp(value)} className='employee-details_delete_icon' />
                                        </div>
                                    </>
                                })
                            }
                        </Form.Item>
                    </Col>
                </Row>

                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            label="Resume"
                            name="resumeFile"
                        >
                            {urlResume.length === 0 && (
                                <Dragger
                                    {...ImageUploaderProp}
                                    name="file"
                                    beforeUpload={handleBeforeUpload}
                                    showUploadList={false}
                                    customRequest={uploadResume}
                                    className="dragger"
                                    style={{ width: "100%", border: "2px dashed #7FACD6" }}
                                    maxCount={1}
                                >
                                    <UploadOutlined className="employee-details_uploade-photo" />
                                    <p>Drag & drop or Browse</p>
                                </Dragger>
                            )}
                            {
                                urlResume?.map((value) => {
                                    const filename = value?.split('/').pop();

                                    return <>
                                        <div className='employee-details_photodelete' >
                                            {value ? 
                                            <a href={value} target='_blank'><p className='employee-details_photodelete-para' >{filename}</p></a>
                                            :
                                            <img src={value} alt="profile" width={45} height={45} onClick={() => modalImageView(value)} /> 
                                               
                                             }
                                            
                                            <DeleteOutlined onClick={() => deleteRes(value)} className='employee-details_delete_icon' />
                                        </div>
                                    </>
                                })
                            }
                        </Form.Item>
                    </Col>
                </Row>


                <Form.Item
                    className="image_dragger"
                    required={false} rules={[{ required: true, message: "Please Upload your Photos / videos" }]}
                    label={<p className="create_post_lable">Upload Photos</p>}
                >
                    {urlList.length === 0 && (
                        <Dragger
                            {...ImageUploaderProp}
                            maxCount={1}
                            name="file"
                            beforeUpload={handleBeforeUpload}
                            showUploadList={true}
                            customRequest={uploadImages}
                            className="dragger"
                            style={{ width: "100%", border: "2px dashed #7FACD6" }}
                        >
                            <UploadOutlined className="employee-details_uploade-photo" />
                            <p>Drag & drop or Browse</p>
                            <p className="ant-upload-text">
                                Photo formates: JPEG, PNG, (maximum image size 2 mb).
                            </p>
                        </Dragger>
                    )}

                    <div className="danger_alert">
                        <p> <ExclamationCircleOutlined className="employee-details_uploade-icon" /> maximum 1 slide</p>
                    </div>

                    {
                        urlList.map((value) => {
                             const filename = value?.split('/').pop();

                            return <>
                                <div className='employee-details_photodelete_profile'>
                                    <img src={value} alt="profile" width={45} height={45} onClick={() => modalImageView(value)} />
                                    <p className='employee-details_photodelete-para' >{filename}</p>
                                    <DeleteOutlined onClick={() => handleRemove(value)} className='employee-details_delete_icon' />
                                </div>
                            </>
                        })
                    }
                </Form.Item>

                <Form.Item >
                    <div className="employee-details_submit">
                        <Space>
                            <Button htmlType="button" className="employee-details_cancel-btn" onClick={() => ModalClose(null)}>
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="employee-details_submit-btn">
                                Submit
                            </Button>
                        </Space>

                    </div>
                </Form.Item>
            </Form>
            <Modal
                open={modalImageOpen}
                onCancel={modalImageClose}
                footer={null}
                className='modal_body'
            >
                <img alt="example" style={{ width: '100%', backgroundColor: 'transparent' }} src={modalImage} />
            </Modal>
        </>
    )
}

export default createEmp