import React from 'react'; 
import EmployeeLayout from './employeelayout';

const HistoryPage = () => {
  return (
    <EmployeeLayout>
      <h1>History Page</h1>
      {/* Add your History page content here */}
    </EmployeeLayout>
  );
};

export default HistoryPage;