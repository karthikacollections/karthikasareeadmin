import React, { useEffect, useState, } from 'react';
import { Space, Table, Button, Popconfirm, Drawer, Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { GET_ROLE, GET_PAGE_LIST } from '../../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import { DELETE_ROLE } from "../../../helpers/mutation";
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import CreateResume from "./createRole";
import EmployeeLayout from '../employeelayout'
import moment from "moment";
import { useAuth } from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";

interface DataType {
    Name: any;
    Summary: any;
    Role: any;
    Skill: any;
}

export const resume: React.FC = () => {

    var count = 0
    let keyValue=0
    const [open, setOpen] = useState<any>(null);
    const [details, setdetails]: any = useState([])
    const [editdraw, setEditdraw] = useState({});
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [role, setRole] = useState([])
    const { check_button_permission, filteredColumns } = useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
      };
      
      const handleOk = () => {
        Re_Fetch_Role();
        setPopOpen(false);
      };
    
      const handleCancel = () => {
        setPopOpen(false);
      };
    
   
    // get rol
    const { error: roleError, loading: roleLoading, data: dataRole, refetch: Re_Fetch_Role, } = useQuery(GET_ROLE, {
        variables: {},
    });

    const { error: userError, loading: fetch_page_list_Loading, data: page_list } = useQuery(GET_PAGE_LIST, { variables: {}, });


    const ModalClose = (param1: any, api_status: any) => {
        setOpen(false)
        if (api_status == "success") {
            Re_Fetch_Role()
        }
    }

    useEffect(() => {
        if (dataRole) {
            let role = dataRole?.mst_role
            setRole(role)
        }
    }, [dataRole])


    const Enable = () => <>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="green" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 10.5993L2.52588 8.12521C2.13545 7.73479 1.50279 7.73479 1.11236 8.12521C0.721934 8.51564 0.721934 9.14831 1.11236 9.53874L4.11236 12.5387C4.50279 12.9291 5.13545 12.9291 5.52588 12.5387L14.5259 3.53874C14.9163 3.14831 14.9163 2.51564 14.5259 2.12521C14.1355 1.73479 13.5028 1.73479 13.1124 2.12521L5 10.5993Z" />
        </svg>
    </>

    const Disable = () => <>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="red" xmlns="http://www.w3.org/2000/svg">
            <path d="M13.4 2.92974C12.9995 2.52931 12.3668 2.52931 11.9663 2.92974L8 6.89562L4.0331 2.92974C3.63267 2.52931 2.99999 2.52931 2.59956 2.92974C2.19914 3.33016 2.19914 3.96282 2.59956 4.36324L6.56646 8.32913L2.59956 12.296C2.19914 12.6964 2.19914 13.329 2.59956 13.7294C3.00043 14.1303 3.63325 14.1297 4.0331 13.7294L8 9.76257L11.9663 13.7294C12.3662 14.1297 12.999 14.1303 13.4 13.7294C13.8004 13.329 13.8004 12.6964 13.4 12.296L9.43309 8.32913L13.4 4.36324C13.8004 3.96282 13.8004 3.33016 13.4 2.92974Z" />
        </svg>
    </>



    // delete destination
    const [delete_Role, { loading, error, data }] = useMutation(DELETE_ROLE);

    const handleDelete = (id: any) => {
        delete_Role({
            variables: id
        }).then(() => {
            Re_Fetch_Role()
        });
    };

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
    }

    let structure = [{ "allow": ["edit", "update", "delete"], "pageName": "Holiday_list" }]

    const columns: ColumnsType<DataType> = [
        {
            title: 'S.no',
            dataIndex: 's.no',
            render: () => ++count,
        },
        {
            title: 'Type',
            dataIndex: "type",
            key: "type"
        },
        {
            title: 'Created At',
            dataIndex: "createdat",
            key: "createdat",
            render: (value) => {
                return (
                    <>
                        <p>{moment(value).format("DD MMMM YYYY")}</p>
                    </>
                )
            }
        },
        {
            title: 'Permission',
            dataIndex: "permission",
            key: "permission",
            render: (_, record: any) => {
                return (
                    <>
                        <Button type='primary' onClick={() => { setdetails(record?.permission ? record?.permission : []), setIsModalOpen(true) }}>View</Button>
                    </>
                )
            }
        },
        {
            title: 'Action',
            key: 'action',
            render: (_, record) => (

                <Space size='large'>
                    {
                        check_button_permission("Role", "edit")
                            ?
                            <EditOutlined onClick={() => handleChange(record)} className="Skills_edit" />
                            : <></>
                    }

                    {
                        check_button_permission("Role", "delete")
                            ?
                            <Popconfirm title="Delete the task" description="Are you sure? Do you want to delete role?"  okText="Yes" cancelText="No" onConfirm={() => handleDelete(record)}>
                                <DeleteOutlined className="Skills_delete" />
                            </Popconfirm>
                            : <></>
                    }
                </Space>
            ),
        }
    ];

    const checkpage_access = (param: any, type: any) => {
        let check_page_exists = details?.some((val: any) => {
            if (val?.pageName == param?.pagename) {
                let check_page_permission_exists = val?.allow?.some((val: any) => { return val == type })
                return check_page_permission_exists
            } else {
                return false
            }
        })
        return check_page_exists
    }

    const View_Permission_columns: any = [
        {
            title: 'Page Name',
            dataIndex: 'pagename',
            key: 'name',
            align: "center",
            width: "20%"
        },
        {
            title: 'Create',
            key: 'name',
            align: "center",
            width: "20%",
            render: (_: any, record: any) => {
                return <span className='permission_table'>{checkpage_access(record, "create") ? <Enable /> : <Disable />}</span>;
            },
        },
        {
            title: 'Edit',
            dataIndex: 'name',
            key: 'name',
            align: "center",
            width: "20%",
            render: (_: any, record: any) => {
                return <span className='permission_table'>{checkpage_access(record, "edit") ? <Enable /> : <Disable />}</span>;
            },
        },
        {
            title: 'View',
            dataIndex: 'name',
            key: 'name',
            align: "center",
            width: "20%",
            render: (_: any, record: any) => {
                return <span className='permission_table'>{checkpage_access(record, "view") ? <Enable /> : <Disable />}</span>;
            },
        },
        {
            title: 'Delete',
            dataIndex: 'name',
            key: 'name',
            align: "center",
            width: "20%",
            render: (_: any, record: any) => {
                return <span className='permission_table'>{checkpage_access(record, "delete") ? <Enable /> : <Disable />}</span>;
            },
        },
    ]

    const check_parent_name = (record: any) => {
        
        if (page_list?.mst_page_list?.length > 0) {
            if (page_list?.mst_page_list.find((item: any) => item.parentpage === record.pagename)) {
                return true
            } else {
                return false
            }
        } else {
            return false
        }
    }

    const Expand_table_config = (param: any) => {
        

        if (page_list?.mst_page_list?.length > 0) {
            let filter_parent_relation_name = page_list?.mst_page_list?.filter((record: any) => {
                return record?.parentpage == param?.pagename
            })

            return (
                <>
                    <Table
                        columns={View_Permission_columns}
                        dataSource={filter_parent_relation_name}
                        pagination={false}
                        expandable={{
                            expandedRowRender: (record: any) => {
                                
                                return (
                                    Expand_table_config(record)
                                );
                            },
                            rowExpandable: (record: any) => { return check_parent_name(record)
                            }
                        }}
                    />
                </>
            )



        } else {
            return ""
        }
    }

    const Add_key_value=()=>{
        let filterData=page_list?.mst_page_list?.filter((record: any) => !record?.parentpage)
        let retrunData=filterData?.map((param:any)=>{
            let addKey={...param,key:param?.id}
            return addKey
        })

        return retrunData
    }

    return (
        <EmployeeLayout>
            <div className="Skills">
                <div className="Skills_head">
                    <h2 className="Skills_head-text">Role</h2>
                    {
                        check_button_permission("Role", "create")
                            ?
                            <Button className="Skills_head-create" onClick={() => setOpen("Create")}>+ Add new Role</Button>
                            : <></>
                    }
                </div>
                <Table columns={filteredColumns(columns, "Role")} dataSource={role} pagination={false} className="Skills_tale" />
                <Drawer title={`${open} Role`} width={570} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}>
                    {open == "Edit" ? (<CreateResume ModalClose={ModalClose} editdraw={editdraw} showModal={showModal} pagetype={"Edit"} />) : <></>}
                    {open == "Create" ? (<CreateResume ModalClose={ModalClose} editdraw={null} showModal={showModal} pagetype={"Add"} />) : <></>}
                </Drawer>
                <Modal title="" open={isModalOpen} footer={false} onCancel={() => setIsModalOpen(false)} width={1000} >
                    <div>
                        <Table
                            columns={View_Permission_columns}
                            dataSource={Add_key_value()}
                            pagination={{ pageSize: 10 }}
                            expandable={{
                                expandedRowRender: (record: any) => {
                                    return (
                                        Expand_table_config(record)
                                    );
                                },
                                rowExpandable: (record: any) => {
                                return check_parent_name(record) }
                            }}
                        />
                    </div>
                   
                </Modal>
            </div>
            <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{display: "flex", justifyContent: "center"}}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
        </EmployeeLayout>
    )
}
export default resume
