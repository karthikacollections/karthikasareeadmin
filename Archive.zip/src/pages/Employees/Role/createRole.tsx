import { Button, Form, Input, Space, Modal, Table, Spin } from 'antd';
import React, { useEffect, useRef, useState } from 'react';
import { useMutation, useQuery } from "@apollo/client";
import { GET_PAGE_LIST } from '../../../helpers/queries';
import { CREATE_Role, UPDATE_ROLE } from '../../../helpers/mutation'
import Custom_Button from "../../../custom_components/permission_table_button"

export const createResume: React.FC<any> = ({ ModalClose, editdraw, pagetype, apistatus,showModal }) => {

    const [form] = Form.useForm();
    const formRef = useRef(null);
    const [details, setdetails]: any = useState([])
    const [hoveredRow, setHoveredRow] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const [createRole, { loading: RoleLoading, error: RoleError, data: Roledata }] = useMutation(CREATE_Role, { errorPolicy: 'all', });
    const [updateRole, { loading: updateroleLoading, error: updateroleError, data: updateroleData }] = useMutation(UPDATE_ROLE, { errorPolicy: 'all', });
    const { error: userError, loading: fetch_page_list_Loading, data: page_list } = useQuery(GET_PAGE_LIST, { variables: {}, });

    useEffect(() => {
        form.setFieldsValue(editdraw)
        setdetails(editdraw ? editdraw?.permission : [])

    }, [editdraw])



    const onFinish = (values: any) => {
        let sendpayload: any = {
            type: values?.type,
            permission: details
        }

        if (editdraw) {
            sendpayload.id = editdraw?.id
            updateRole({
                variables: sendpayload,
            }).then((response) => {
                showModal("Updated")
                ModalClose(null, "success")
            });
        }
        else {
            createRole({
                variables: sendpayload
            }).then((response) => {
                showModal("Created")
                ModalClose(null, "success")
            });
        };
    }

    const onFinishFailed = (errorInfo: any) => {
    };

    const Enable = () => <>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="green" xmlns="http://www.w3.org/2000/svg">
            <path d="M5 10.5993L2.52588 8.12521C2.13545 7.73479 1.50279 7.73479 1.11236 8.12521C0.721934 8.51564 0.721934 9.14831 1.11236 9.53874L4.11236 12.5387C4.50279 12.9291 5.13545 12.9291 5.52588 12.5387L14.5259 3.53874C14.9163 3.14831 14.9163 2.51564 14.5259 2.12521C14.1355 1.73479 13.5028 1.73479 13.1124 2.12521L5 10.5993Z" />
        </svg>
    </>

    const Disable = () => <>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="red" xmlns="http://www.w3.org/2000/svg">
            <path d="M13.4 2.92974C12.9995 2.52931 12.3668 2.52931 11.9663 2.92974L8 6.89562L4.0331 2.92974C3.63267 2.52931 2.99999 2.52931 2.59956 2.92974C2.19914 3.33016 2.19914 3.96282 2.59956 4.36324L6.56646 8.32913L2.59956 12.296C2.19914 12.6964 2.19914 13.329 2.59956 13.7294C3.00043 14.1303 3.63325 14.1297 4.0331 13.7294L8 9.76257L11.9663 13.7294C12.3662 14.1297 12.999 14.1303 13.4 13.7294C13.8004 13.329 13.8004 12.6964 13.4 12.296L9.43309 8.32913L13.4 4.36324C13.8004 3.96282 13.8004 3.33016 13.4 2.92974Z" />
        </svg>
    </>

    const handleMouseEnter = (record: any) => {
        setHoveredRow(record?.id);
    };

    const handleMouseLeave = () => {
        setHoveredRow(null);
    };

    const renderRow = (record: any) => (
        {
            onMouseEnter: () => handleMouseEnter(record),
            onMouseLeave: handleMouseLeave,
        });

    const checkpage_access = (param: any, type: any) => {
        let check_page_exists = details?.some((val: any) => {
            if (val?.pageName == param?.pagename) {
                let check_page_permission_exists = val?.allow?.some((val: any) => { return val == type })
                return check_page_permission_exists
            } else {
                return false
            }
        })
        return check_page_exists
    }

    const changestatus = (pagename_cellname_allow: any) => {
        let split_content = pagename_cellname_allow?.split("_=_")


        let check_page_exists = details?.some((val: any) => { return val?.pageName == split_content[0] })

        if (check_page_exists) {
            let config_permission = details?.map((val: any) => {

                if (val?.pageName == split_content[0]) {

                    if (split_content[2] == "NO") {
                        let returndata = val?.allow?.filter((allow_param: any) => {
                            if (allow_param == split_content[1]) {
                                return false
                            } else {
                                return allow_param
                            }
                        })
                        return { ...val, allow: returndata }

                    } else if (split_content[2] == "YES") {

                        return { ...val, allow: [...val?.allow, split_content[1]] }

                    } else {
                        return val
                    }


                } else {


                    // if (check_page_exists == false) {
                    //     return { ...val, allow: [split_content[1]] }
                    // } else {
                    return val
                    // }

                }
            })
            setdetails(config_permission)
        } else {
            setdetails([...details, { pageName: split_content[0], allow: [split_content[1]] }])
        }


    }

    const columns: any = [
        {
            title: 'Page Name',
            dataIndex: 'pagename',
            key: 'name',
            align: "center",
            width: "20%"
        },
        {
            title: 'Create',
            key: 'name',
            align: "center",
            width: "20%",
            render: (_: any, record: any) => {
                if (hoveredRow === record?.id) {
                    return <Custom_Button pre_status={checkpage_access(record, "create")} id={record?.pagename + "_=_" + "create"} changestatus={(param: any) => changestatus(param)} />;
                }
                return <span className='permission_table'>{checkpage_access(record, "create") ? <Enable /> : <Disable />}</span>;
            },
        },
        {
            title: 'Edit',
            dataIndex: 'name',
            key: 'name',
            align: "center",
            width: "20%",
            render: (_: any, record: any) => {
                if (hoveredRow === record?.id) {
                    return <Custom_Button pre_status={checkpage_access(record, "edit")} id={record?.pagename + "_=_" + "edit"} changestatus={(param: any) => changestatus(param)} />;
                }
                return <span className='permission_table'>{checkpage_access(record, "edit") ? <Enable /> : <Disable />}</span>;
            },
        },
        {
            title: 'View',
            dataIndex: 'name',
            key: 'name',
            align: "center",
            width: "20%",
            render: (_: any, record: any) => {
                if (hoveredRow === record?.id) {
                    return <Custom_Button pre_status={checkpage_access(record, "view")} id={record?.pagename + "_=_" + "view"} changestatus={(param: any) => changestatus(param)} />;
                }
                return <span className='permission_table'>{checkpage_access(record, "view") ? <Enable /> : <Disable />}</span>;
            },
        },
        {
            title: 'Delete',
            dataIndex: 'name',
            key: 'name',
            align: "center",
            width: "20%",
            render: (_: any, record: any) => {
                if (hoveredRow === record?.id) {
                    return <Custom_Button pre_status={checkpage_access(record, "delete")} id={record?.pagename + "_=_" + "delete"} changestatus={(param: any) => changestatus(param)} />;
                }
                return <span className='permission_table'>{checkpage_access(record, "delete") ? <Enable /> : <Disable />}</span>;
            },
        },
    ]

    const check_parent_name = (record: any) => {
        if (page_list?.mst_page_list?.length > 0) {
            if (page_list?.mst_page_list.find((item: any) => item.parentpage === record.pagename)) {
                return true
            } else {
                return false
            }
        } else {
            return false
        }
    }

    const Expand_table_config = (param: any) => {

        if (page_list?.mst_page_list?.length > 0) {
            let filter_parent_relation_name = page_list?.mst_page_list?.filter((record: any) => {
                return record?.parentpage == param?.pagename
            })

            return (
                <>
                    <Table
                        columns={columns}
                        dataSource={filter_parent_relation_name}
                        pagination={false}
                        onRow={renderRow}
                        expandable={{
                            expandedRowRender: (record: any) => {
                                return (
                                    Expand_table_config(record)
                                );
                            },
                            rowExpandable: (record: any) => { return check_parent_name(record) }
                        }}
                    />
                </>
            )



        } else {
            return ""
        }
    }

    const Add_key_value=()=>{
        let filterData=page_list?.mst_page_list?.filter((record: any) => !record?.parentpage)
        let retrunData=filterData?.map((param:any)=>{
            let addKey={...param,key:param?.id}
            return addKey
        })

        return retrunData
    }

    return (

        <>
            <Form name="basic" layout="vertical" initialValues={{ remember: true }} onFinish={onFinish} onFinishFailed={onFinishFailed} autoComplete="off" form={form} ref={formRef} className="Skills_form">

                <Form.Item label="Type" name="type" required={false} rules={[{ required: true, message: 'Please input your type!' }]} className="Skills_form_item" >
                    <Input className="Skills_form_item-input" />
                </Form.Item>

                {
                    fetch_page_list_Loading
                        ?
                        <Spin />
                        :
                        <Form.Item label="Table Permission" name="permission" required={false} className="Skills_form_item" >
                            <Button type='primary' danger onClick={() => { setIsModalOpen(true); }}>{pagetype} Permission</Button>
                        </Form.Item>
                }


                <Form.Item >
                    <div className="Skills_submit">
                        <Space>
                            <Button htmlType="button" className="Skills_cancel-btn" onClick={() => ModalClose(null)}>
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="Skills_submit-btn">
                                Submit
                            </Button>
                        </Space>
                    </div>
                </Form.Item>
            </Form>

            <Modal title="" open={isModalOpen} footer={false} onCancel={() => setIsModalOpen(false)} width={1000} >
                <div>
                    <Table
                        columns={columns}
                        dataSource={Add_key_value()}
                        pagination={{ pageSize: 10 }}
                        onRow={renderRow}
                        expandable={{
                            expandedRowRender: (record: any) => {
                                return (
                                    Expand_table_config(record)
                                );
                            },
                            rowExpandable: (record: any) => { return check_parent_name(record) }
                        }}
                    />
                </div>
            </Modal>
        </>
    )
}

export default createResume