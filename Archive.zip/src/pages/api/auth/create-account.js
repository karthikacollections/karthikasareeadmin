const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json');



export default async (req, res) => {

    if (!admin.apps.length) {
        admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            // Add any other Firebase Admin configuration options here
        });
    }


    const { email, password } = req.body;

    // Define the user information
    const newUser = {
        email: email,
        password: password,
        displayName: 'User Display Name',
    };

    try {
        await admin.auth().createUser(newUser)
        return res.status(200).json({ message: 'User account Create successfully.' });
    } catch (error) {
        return res.status(500).json({ error: 'Internal server error' });
    }
};