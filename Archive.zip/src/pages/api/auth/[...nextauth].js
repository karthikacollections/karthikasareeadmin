import NextAuth from 'next-auth';
import bcrypt from 'bcryptjs';
import CredentialsProvider from "next-auth/providers/credentials";
import { useQuery } from "@apollo/client";
import { GETUSER_QUERY } from '../../../helpers/mutation'; 
// Import the query from your separate pag
// const getUserByEmail = async (email) => {
//     try {
//       const { loading, error, data } = await useQuery(GETUSER_QUERY, {
//         variables: { email },
//       });
//       if (loading) {
//         // Handle loading state if needed
//       }
//       if (error) {
//         // Handle error state if needed
//         console.error('Error fetching user by email:', error);
//         throw new Error('Failed to fetch user');
//       }
//       console.log(data, 'userData');
//       return data.userByEmail; // Modify this to match your API response structure
//     } catch (error) {
//       console.error('Error fetching user by email:', error);
//       throw new Error('Failed to fetch user');
//     }
//   };
//   export default NextAuth({
//     providers: [
//       CredentialsProvider({
//         name: 'Credentials',
//         credentials: {
//           email: { label: 'Email', type: 'text' },
//           password: { label: 'Password', type: 'password' }
//         },
//         async authorize(credentials) {
//           const { email, password } = credentials;
//           const user = await getUserByEmail(email); // Fetch user by email from your Hasura API
  
//           if (user) {
//             const isValidPassword = await bcrypt.compare(password, user.password);
  
//             if (isValidPassword) {
//               return user;
//             } else {
//               throw new Error('Invalid password');
//             }
//           } else {
//             throw new Error('User not found');
//           }
//         }
//       })
//     ],
//     callbacks: {
//       async jwt(token, user) {
//         if (user) {
//           token.id = user.id;
//         }
//         return token;
//       },
//       async session(session, token) {
//         session.user.id = token.id;
//         return session;
//       }
//     }
//   });    