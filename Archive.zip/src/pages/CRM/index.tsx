import React, { ReactNode } from 'react';
import CRMLayout from './crmlayout';



const EmployeePage: React.FC = () => {
  return (
    <CRMLayout>
    </CRMLayout>
  );
};

export default EmployeePage;