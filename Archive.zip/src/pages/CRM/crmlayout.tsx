import React, { ReactNode } from 'react';
import CRMnav from '../../components/Side_Nav/CRMnav';
import withApollo from '../../config'

type CRMLayoutProps = {
    children: ReactNode;
};

const CRMLayout: React.FC<CRMLayoutProps> = ({ children }) => {
    return (
      <div className='setting_nav'>
      <div>
      <CRMnav />
      </div>
      <div className='settings_style'>
        {children}
      </div>
    </div>
    );
  };

export default CRMLayout
