import React, { useEffect, useState, useRef } from 'react';
import { useQuery, useMutation } from "@apollo/client";
import { GET_INVOICE, GET_PRODUCT, GET_CLIENT } from '../../helpers/queries'
import { CREATE_INVOICE, UPDATE_ASSTMANAGE } from "../../helpers/mutation"

import { Button, Form, Select, Space, Input, Row, Col, Checkbox, InputNumber } from 'antd';
import { LeftOutlined } from '@ant-design/icons';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';

const { TextArea } = Input;
const { Option } = Select;

interface SelectedProduct {
    productId: string;
    quantity: number;
    productName: string;
    price: number; // Add the price property to the SelectedProduct interface
}
export const bill: React.FC = () => {

    const { loading: productLoading, error: productError, data: productData } = useQuery(GET_PRODUCT);
    const { loading: clientLoading, error: clientError, data: clientData } = useQuery(GET_CLIENT);
    const [createInvoice] = useMutation(CREATE_INVOICE);
    const [reduction, setReduction] = useState(0);
    const [finalAmount, setFinalAmount] = useState(0);
    const [additionalCharges, setAdditionalCharges] = useState(0);
    const [selectedProducts, setSelectedProducts] = useState<SelectedProduct[]>([
        { productId: '', quantity: 1, productName: '', price: 0 },
    ]);
    const [form] = Form.useForm();
    const formRef = useRef(null);
    const invoiceNumberRef = useRef(1);

    const currentDate = new Date().toISOString().split('T')[0];

    const futureDate = new Date(currentDate);
    futureDate.setDate(futureDate.getDate() + 30);

    const formatDate = (date: Date) => {
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const day = date.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    };

    const defaultDateValue = formatDate(futureDate)

    const getAvailableProducts = (): { id: string; name: string }[] => {
        // Filter out already selected products from the available product list
        const selectedProductIds = selectedProducts.map((product) => product.productId);
        return productData?.mst_product.filter((product: any) => !selectedProductIds.includes(product.name)) || [];
    };

    const handleProductChange = (index: any, value: any, option: any) => {
        setSelectedProducts((prevSelectedProducts) => {
            const updatedProducts = [...prevSelectedProducts];
            updatedProducts[index].productId = value;
            updatedProducts[index].productName = option.label; // Set the product name from the option label
            return updatedProducts;
        });
    };

    const handleQuantityChange = (index: any, value: any) => {
        setSelectedProducts((prevSelectedProducts) => {
            const updatedProducts = [...prevSelectedProducts];
            updatedProducts[index].quantity = value;
            return updatedProducts;
        });
    };

    const getProductPrice = (productId: any) => {
        const selectedProductObj = productData?.mst_product.find((product: any) => product.id === productId);
        return selectedProductObj ? selectedProductObj.price : 0;
    };

    const getTotalAmount = (productId: any, quantity: any) => {
        return getProductPrice(productId) * quantity;
    };

    const getFinalAmount = () => {
        const totalProductAmount = selectedProducts.reduce((acc, product) => acc + getTotalAmount(product.productId, product.quantity), 0);
        const finalAmount = totalProductAmount + additionalCharges - reduction; // Step 2: Include reduction in the calculation
        return finalAmount >= 0 ? finalAmount : 0; // Ensure finalAmount is not negative
    };

    useEffect(() => {
        // Recalculate the Final Amount whenever selectedProducts, additionalCharges, or reduction change
        const finalAmount = getFinalAmount();
        setFinalAmount(finalAmount);
    }, [selectedProducts, additionalCharges, reduction]);

    useEffect(() => {
        // Load the last used invoice number from local storage
        const lastInvoiceNumber = localStorage.getItem('lastInvoiceNumber');
        if (lastInvoiceNumber) {
            invoiceNumberRef.current = parseInt(lastInvoiceNumber, 10);
        }
    }, []);

    const generateInvoiceNumber = () => {
        const paddedInvoiceNumber = String(invoiceNumberRef.current).padStart(5, '0');
        invoiceNumberRef.current;
        // Save the latest invoice number in local storage
        localStorage.setItem('lastInvoiceNumber', String(invoiceNumberRef.current));
        return `INV-${paddedInvoiceNumber}`;
    };

    const selectedProductsJSONB = selectedProducts.map((product) => ({
        product: product.productId,
        quantity: product.quantity,
        productName: product.productName,
        price: getProductPrice(product.productId),
    }));

    const onFinish = () => {
        form.validateFields().then((values) => {
            // Get the selected client ID from the form values
            const selectedClient = values.client;
            if (!selectedClient) {
                return;
            }

            const input = {
                client: selectedClient,
                date: values.date,
                due_date: values.due_date,
                invoice: values.invoice,
                product: selectedProductsJSONB,
                reduction,
                // price: values.price, 
                sales: values.sales,
                terms: values.terms,
                total_amount: finalAmount,
                notes: values.notes,
                type: values.type,
                additional_charges: additionalCharges,
            };
            createInvoice({ variables: input })
                .then((result) => {
                    // Do additional actions after successful insertion if needed
                })
                .catch((error) => {
                    // Handle error if needed
                });
        });
    };

    if (productLoading || clientLoading) return <p>Loading...</p>;
    if (productError || clientError) return <p>Error: {productError?.message || clientError?.message}</p>;

    return <>
        <div>

            <div className='bill_namecard'>
                <h1>HYSAS TECHNOLOGIES PRIVATE LIMITED</h1>
                <h4>61A1 BOLTEN PURAM  <span>3RD STREET</span></h4>

                <h4>THOOTHUKUDI</h4>
                <h4>TAMILNADU, INDIA</h4>
                <h4>GST:33AAECH5044E1Z0</h4>
            </div>

            <Form
                name="basic"
                layout="horizontal"
                initialValues={{ remember: true }}
                onFinish={onFinish}
                // onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                ref={formRef}
            >

                <Form.Item
                    label="Invoice No"
                    name="invoice"
                    initialValue={`IND-${String(invoiceNumberRef.current).padStart(5, '0')}`}
                    required={false}
                    rules={[{ required: true, message: 'Please enter product name!' }]}

                >
                    <Input value={generateInvoiceNumber()} disabled />
                </Form.Item>

                <Form.Item label="Invoice Date"
                    name="date"
                    initialValue={currentDate}
                    required={false}
                    rules={[{ message: 'Please enter product name!' }]}
                >
                    <Input type="date" defaultValue={currentDate} disabled />
                </Form.Item>

                <Form.Item label="Due Date"
                    name="due_date"
                    initialValue={defaultDateValue}
                    required={false}
                    rules={[{ message: 'Please enter product name!' }]}
                >
                    <Input type="date" defaultValue={defaultDateValue} disabled />
                </Form.Item>

                <Form.Item
                    name="client"
                    label="Client"
                    rules={[{ message: 'Please select a product' }]}
                >
                    <Select
                        placeholder="Select a client"
                    // value={selectedProduct}
                    // onChange={handleProductChange}
                    >
                        {clientData?.mst_clientmanagement.map((client: any) => (
                            <Option key={client.id} value={client.id}>
                                {client.name}
                            </Option>
                        ))}
                    </Select>
                </Form.Item>

                <Form.Item
                    label="Type"
                    name="type"
                    required={false}
                    rules={[{ required: true, message: 'Please enter product name!' }]}
                    className='bill_type_total'
                >
                    <Select>
                        <Option value="International">International</Option>
                        <Option value="Domestic">Domestic</Option>
                    </Select>
                </Form.Item>

                <Form.Item
                    label="Sale By"
                    name="sales"
                    required={false}
                    rules={[{ required: true, message: 'Please enter product name!' }]}
                >
                    <Select>
                        <Option value="Person 1">Person 1</Option>
                        <Option value="Person 2">Person 2</Option>
                    </Select>
                </Form.Item>

                <Form.Item
                    name='terms'>

                    <TextArea name='terms' placeholder='Terms and Conditions' rows={4} />
                </Form.Item>

                <Form.Item
                    name='notes'
                    required={false}
                    rules={[{ message: 'Please enter product name!' }]}
                >
                    <TextArea placeholder='Notes' rows={4} />
                </Form.Item>
                {selectedProducts.map((product, index) => (
                    <React.Fragment key={index}>
                        <Space key={index} style={{ display: 'flex', marginBottom: 8 }} align="baseline">
                            <Form.Item
                                name={`product-${index}`}
                                label="Product"
                                rules={[{ required: true, message: 'Please select a product' }]}
                            >
                                <Select
                                    placeholder="Select a product"
                                    value={product.productName} // Use product.productName to display the product name
                                    onChange={(value, option) => handleProductChange(index, value, option)} // Pass the whole option to the handler
                                >
                                    {getAvailableProducts().map((product: any) => (
                                        <Option key={product.id} value={product.id}>
                                            {product.name} {/* Display product name */}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>

                            <Form.Item
                                name={`quantity-${index}`}
                                initialValue={product.quantity}
                                label="Quantity"
                            >
                                <InputNumber
                                    value={product.quantity}
                                    onChange={(value) => handleQuantityChange(index, value)}
                                    min={1}
                                />
                            </Form.Item>

                            <Form.Item
                                // name={`price-${index}`}
                                label="Price"
                            >
                                <Input value={getProductPrice(product.productId)} disabled />
                            </Form.Item>

                            <Form.Item
                                // name={`total-amount-${index}`}
                                label="Total Amount"
                            >
                                <Input value={getTotalAmount(product.productId, product.quantity)} disabled />
                            </Form.Item>

                            {index === selectedProducts.length - 1 && (
                                <Form.Item>
                                    <Button
                                        type="dashed"
                                        onClick={() => setSelectedProducts([
                                            ...selectedProducts,
                                            { productId: '', quantity: 1, price: 0, productName: '' }, // Add default values for a new product
                                        ])}
                                        block
                                        icon={<PlusOutlined />}
                                    >
                                        Add Product
                                    </Button>
                                </Form.Item>
                            )}
                            {selectedProducts.length > 1 && (
                                <Form.Item>
                                    <Button
                                        type="dashed"
                                        onClick={() => setSelectedProducts(selectedProducts.filter((_, i) => i !== index))}
                                        block
                                        icon={<MinusCircleOutlined />}
                                    >
                                        Remove Product
                                    </Button>

                                </Form.Item>

                            )}
                        </Space>
                    </React.Fragment>
                ))}

                <Form.Item
                    required={false}
                    rules={[{ required: true, message: 'Please enter product name!' }]}
                >
                    <Input placeholder='Select Additional Charges' />
                </Form.Item>

                <Form.Item

                    required={false}
                    rules={[{ required: true, message: 'Please enter product name!' }]}
                >
                    <InputNumber
                        name='additional_charges'
                        value={additionalCharges}
                        onChange={(value) => setAdditionalCharges(value || 0)} // Set additionalCharges to 0 if value is null
                    />

                </Form.Item>

                <Form.Item
                    name='reduction'
                    label="Adjsutments"
                    required={false}
                    rules={[{ required: true, message: 'Please enter product name!' }]}
                >
                    <InputNumber

                        value={reduction}
                        onChange={(value) => setReduction(value || 0)}
                    />
                </Form.Item>

                <Form.Item
                    // name='total_amount'
                    initialValue={finalAmount}
                    required={false}
                    rules={[{ required: true, message: 'Please enter product name!' }]}
                >
                    <Input value={finalAmount} disabled />
                </Form.Item>

                <Form.Item>
                    <div className="assets_submit">
                        <Space style={{ display: 'block' }} align="center">
                            <Button htmlType="button" className="assets_cancel-btn">
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="assets_submit-btn">
                                Create
                            </Button>
                        </Space>
                    </div>
                </Form.Item>

            </Form>

        </div>
    </>
}
export default bill