// import { authProtected } from "@/components/protectedroute"
import { Button, Drawer, Popconfirm, Space, Table, Modal, Select } from "antd";
import React, { useEffect, useState } from "react"
import  CreateSubCategory  from "./create";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@apollo/client";
import { DELETE_SUB_CATEGORY, GET_SHOP, GET_SUB_CATEGORY,SUB_CATEGORY_SOFT_DELETE } from "@/helpers";
import CRMnav from '../crmlayout'
import {useAuth} from '../../../components/auth'
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";
import { useShopContext } from "../../../context/shopContext";

export const SubCategory:React.FC<any>=()=>{
    const[subCategory,setSubCategory]=useState([])
    const [open, setOpen] = useState<any>(null);
    const [heading, setHeading] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("")
    const { check_button_permission,filteredColumns } = useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");
    const [selectedSubCategory, setselectedSubCategory] = useState<string | null>(null);
    const { selectedOrgValue, setSelectedOrgValue } = useShopContext();

    const { data: shopData } = useQuery(GET_SHOP);

    const{error,loading,data, refetch: refetSubCategoryData}=useQuery(GET_SUB_CATEGORY)
    const handleSelectChange = (value: any) => {
        setselectedSubCategory(value);
      };
    
    const[delectSubCategory,{error:delectError,loading:delectLoading, data:deleteData}]=useMutation(SUB_CATEGORY_SOFT_DELETE,{
        errorPolicy:'all'
    })

    useEffect(() => {
        if (data) {
            let res = data?.mst_sub_category;
            setSubCategory(res);
        }
    }, [data]);

    const OnOpen=()=>{
        setOpen(true)
        setHeading('Create')
    }

    const ModalClose = () => {
        setOpen(false)
    }

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
        setHeading('Edit')
    }
    const handleDelete=(record:any)=>{
        
        delectSubCategory({
            variables:record,
            update:(cache:any)=>{
                showModal("Deleted");
                refetSubCategoryData()
            }
        })
    }

    var count=0

    const columns=[
        {
            title:'S.no',
            render:()=>++count
        },
        {
            title: "Image",
            render: (urlList: any) => {
                if (urlList?.image){
              return (
                <img
                  src={urlList?.image}
                  alt="Image"
                  style={{ width: "100px" }}
                  className="employee-details_table-profile"
                />
              );
            }
            else {
                return "No Image";
              }
            }
          },
        {
            title:'Name',
            dataIndex:'sub_name',
            key:'sub_name'
        },
        {
            title:'Category',
            render:(value:any)=>{
                let category=value?.mst_category_sub_category?.category
                return(
                    <p>{category}</p>
                )
            }
        },
        {
            title:'Description',
            dataIndex:'description',
            key:'description'
        },
        
        {
            title:'Action',
            key:'action',
            render:(record:any)=>(
                <Space size='large'>
                    {
                        check_button_permission("SubCategory", "edit")
                            ?
                        <EditOutlined
                            onClick={() => handleChange(record)}
                            className="employee-details_edit"
                        />:<></>
                    }

                    {
                        check_button_permission("SubCategory", "delete")
                            ?
                            <Popconfirm
                                title="Delete the Client"
                                description="Are you sure to delete this Client?"
                                okText="Yes"
                                cancelText="No"
                                onConfirm={()=>handleDelete(record)}
                            >
                                <DeleteOutlined className="employee-details_delete" />
                            </Popconfirm>
                            :<></>
                    }
            </Space>   
            )   
        }
    ]

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
    };

    const handleOk = () => {
        refetSubCategoryData();
        setPopOpen(false);
    };

    const handleCancel = () => {
        setPopOpen(false);
    };

    const search = (data: any) => {
        const filteredData = data?.filter((record: any) => {
          const subCategoryName = record?.sub_name?.toLowerCase();
          const selectedShop = selectedOrgValue?.toLowerCase();
          const selectedSubCategoryLowerCase = selectedSubCategory?.toLowerCase();
      
          const matchesShop = selectedShop ? record?.mst_category_sub_category?.shop?.shop_name?.toLowerCase() === selectedShop : true;
          const matchesSubCategory = selectedSubCategoryLowerCase
            ? subCategoryName === selectedSubCategoryLowerCase
            : true;
      
          return matchesShop && matchesSubCategory;
        });
      
        return filteredData;
      };
      
      
    
    const handleSelectChangeOrganization = (value: any) => {
        setSelectedOrgValue(value);
        setselectedSubCategory("");
    };

    return(
        <CRMnav>
        <div className="employee-details">
        <h1 className="employee-details_head-text">{selectedOrgValue}</h1>
                <div className="employee-details_head">
                    <h2 className="employee-details_head-text">Sub Category Details</h2>

                    {/* <Select
    size={"large"}
    onChange={handleSelectChangeOrganization}
    allowClear
    showSearch
    filterOption={(input, option: any) =>
        option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    }
    placeholder={"Search Shop"}
    className="Asset_selecter"
    style={{ width: "220px", marginRight: "10px" }}
    value={selectedOrgValue} // Add this line to control the selected value
>
    {shopData?.mst_shop?.map((shop: any, index: any) => (
        <Select.Option value={shop?.shop_name} key={index}>
            {shop?.shop_name}
        </Select.Option>
    ))}
</Select> */}
<Select
  size={"large"}
  onChange={handleSelectChange}
  allowClear
  showSearch
  filterOption={(input, option: any) =>
    option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
  }
  
  
  placeholder={"Search Sub Category"}
  className="Asset_selecter"
  style={{ width: "220px", marginRight: "10px" }}
  value={selectedSubCategory} // Set the default value
>
    
  {data?.mst_sub_category
    ?.filter((subCat: any) =>
      selectedOrgValue ? subCat.mst_category_sub_category?.shop?.shop_name === selectedOrgValue : true
    )
    .sort((a: any, b: any) => {
      return (a.sub_name || '').localeCompare(b.sub_name || '');
    })
    .map((subCat: any, index: any) => (
      <Select.Option value={subCat?.sub_name} key={index}>
        {subCat?.sub_name}
      </Select.Option>
      
    ))}
</Select>

                    {
                        check_button_permission("SubCategory", "create")
                            ?
                            <Button className="employee-details_head-create" onClick={OnOpen}>+ Add New Sub Category</Button>
                            :<></>
                    }
                </div>

                <Table columns={filteredColumns(columns,"SubCategory")} dataSource={search(subCategory)} pagination={false} className="employee-details_table" />

                <Drawer title={`${heading} Sub Category`} width={570} placement="right" onClose={() => setOpen(false)} open={open} className="employee-details_drawer">
                    {
                        heading == "Edit" ? (<CreateSubCategory ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        heading == "Create" ? (<CreateSubCategory ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                    }
                </Drawer>

            </div>
            <Modal
                open={Popopen}
                title=""
                onOk={handleOk}
                onCancel={handleCancel}
                footer={[
                    <div style={{ display: "flex", justifyContent: "center" }}>
                        <Button
                            key="submit"
                            type="primary"
                            loading={loading}
                            onClick={handleOk}
                            style={{
                                display: "flex",
                                width: "206px",
                                padding: "15px 30px",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "10px",
                                borderRadius: "8px",
                                background: "#252947",
                            }}>
                            OK
                        </Button>
                    </div>,
                ]}
                width={"386px"}>
                <Space
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                    }}>
                    <Image
                        src={PopImage}
                        alt="image"
                        style={{
                            width: "150px",
                            height: "150px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    />
                    <p
                        style={{
                            color: "#101010",
                            textAlign: "center",
                            fontFamily: "revert",
                            fontSize: "32px",
                            fontStyle: "normal",
                            fontWeight: "700",
                            lineHeight: "normal",
                        }}>
                        {`${title}`} Successfully
                    </p>
                </Space>
            </Modal>
        </CRMnav>
    )
}

export default SubCategory