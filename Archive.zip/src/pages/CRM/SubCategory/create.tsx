import React, { useState, useRef, useEffect } from "react";
import { Button, Form, Input, Modal, Select, Space, message } from "antd";
import { useMutation, useQuery } from "@apollo/client";
import { CREATE_SUB_CATEGORY, GET_CATEGORY, GET_SUB_CATEGORY, UPDATE_SUB_CATEGORY } from "@/helpers";
import { DeleteOutlined, ExclamationCircleOutlined, UploadOutlined } from "@ant-design/icons";

const CreateSubCategory: React.FC<any> = ({ ModalClose, editdraw, showModal }) => {
  const [category, setCategory] = useState([]);
  const formRef = useRef<any>(null);
  const [form] = Form.useForm();
  const [urlLogo, setUrlLogo] = useState<string[]>([]);
  const [loadingMP, setLoading] = useState(false);
  const [initialLogo, setInitialLogo] = useState<string[]>([]);
  const [modalImageOpen, setModalImageOpen] = useState<boolean>(false);
  const [modalImage, setModalImage] = useState<string | null>(null);
  const Dragger = require("antd/es/upload/Dragger").default;
  const { error, loading, data, refetch: refetCategoryData } = useQuery(GET_CATEGORY);
  const { error: subError, loading: subLoading, data: subData, refetch: refetSubCategoryData } = useQuery(GET_SUB_CATEGORY);
  const [createSubCategory, { error: createError, loading: createLoading }] = useMutation(CREATE_SUB_CATEGORY, { errorPolicy: 'all' });
  const [updateSubCategory, { error: updateError, loading: updateLoading }] = useMutation(UPDATE_SUB_CATEGORY, { errorPolicy: 'all' });

  useEffect(() => {
    if (data) {
      let res = data?.mst_category;
      setCategory(res);
    }
  }, [data]);
  useEffect(() => {
    if (editdraw) {
      form.setFieldsValue({
        sub_name: editdraw.sub_name,
        category: editdraw.category,
        description: editdraw.description,
        company_logo: editdraw.image,
      });

      setInitialLogo(editdraw.image ? [editdraw.image] : []);
      setUrlLogo(editdraw.image ? [editdraw.image] : []);
    }
  }, [editdraw, form]);


  const ImageUploaderProp: any = {
    name: "file",
    multiple: true,
    action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
    onChange(info: any) {
      const { status } = info.file;
      if (status !== "uploading") {
      }
      if (status === "done") {
        message.success(`${info.file.name} file uploaded successfully.`);
      } else if (status === "error") {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
  };

  const uploadLogo = async (options: any) => {
    const { onSuccess, onError, file } = options;
    try {
      setLoading(true);
      const data = new FormData();
      data.append("upload_preset", "Employee");
      data.append("file", file);
      data.append("cloud_name", "dgcgmcaxb");

      fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
        method: "post",
        body: data,
        redirect: 'follow',
      })
        .then((resp) => resp.json())
        .then((data) => {
          setUrlLogo((urlLogo) => [...urlLogo, data.url]);
          setLoading(false);
          onSuccess("Ok");
        })
        .catch((err) => {
          setLoading(false);
          onError(err);
        });
      onSuccess("Ok");
    } catch (err) {
      const error = new Error("Some error");
      onError({ err });
    }
  };

  const handleBeforeUpload = (file: any) => {
    const fileSizeInMB = file.size / 1024 / 1024;
    const maxFileSizeInMB = 2;
    if (fileSizeInMB > maxFileSizeInMB) {
      message.error(`File size must be within ${maxFileSizeInMB}MB!`);
      return false;
    }
    return true;
  };

  const onFinish = (values: any) => {
    if (editdraw) {
      values.id = editdraw?.id;
      values.image = urlLogo[0];

      updateSubCategory({
        variables: values,
      })
        .then((response) => {
          showModal("Updated");
          refetSubCategoryData();
          ModalClose(null);
          message.success(`Update SubCategory Details`);
        })
        .catch((error) => {
          message.error("Check the Fields");
        });
    } else {
      values.image = urlLogo.length > 0 ? urlLogo[0] : initialLogo[0];

      createSubCategory({
        variables: values,
      })
        .then((response) => {
          showModal("Created");
          refetSubCategoryData();
          message.success(`Add New Details`);
          ModalClose(null);
        })
        .catch((error) => {
          // Handle error if needed
        });
    }
  };

  const onFinishFailed = (error: any) => {
    message.error('Form submission failed. Please check the fields.');
  };

  const modalImageView = (imageUrl: string) => {
    setModalImageOpen(!modalImageOpen);
    setModalImage(imageUrl);
  };
  const modalImageClose = () => {
    setModalImageOpen(!modalImageOpen)
    setModalImage(null)
  }

  const filename = (url: string) => {
    return url.split('/').pop();
  };

  const deleteRes = (image: string) => {
    let filteredImage = urlLogo?.filter((e) => e !== image);
    setUrlLogo(filteredImage);
  };

  return (
    <div>
      <Form
        name="subCategory"
        layout="vertical"
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        form={form}
        ref={formRef}
        className="employee-details_form"
      >
        <Form.Item
          label="Name"
          name="sub_name"
          required={false}
          rules={[{ required: true, message: 'Please Enter the Name' }]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label='Category'
          name='category'
          required={false}
          rules={[{ required: true, message: 'Please Select the Category' }]}
        >
          <Select>
            {category.map((item: any, key: any) => {
              return (
                <Select.Option value={item.id} key={key}>{item.category}</Select.Option>
              )
            })}
          </Select>
        </Form.Item>
        <Form.Item
          label="Description"
          name="description"
          required={false}
          rules={[{ required: true, message: 'Please Enter the Description' }]}
        >
          <Input.TextArea rows={3} autoSize={false} style={{ resize: 'none', height: '100px' }} />
        </Form.Item>

        <Form.Item
          label="Image"
          name="name"
        >
          {urlLogo.length === 0 && (
            <Dragger
              {...ImageUploaderProp}

              name="file"
              beforeUpload={handleBeforeUpload}
              showUploadList={true}
              customRequest={uploadLogo}
              className="dragger"
              style={{ width: "100%", border: "2px dashed #7FACD6" }}
              maxCount={1}
            >
              <UploadOutlined className="employee-details_uploade-photo" />
              <p>Drag & drop or Browse</p>
            </Dragger>
          )}
          <div className="danger_alert">
            <p> <ExclamationCircleOutlined className="employee-details_uploade-icon" /> maximum 1 slide</p>
          </div>
          {urlLogo?.map((values, index) => (
            <div className='employee-details_photodelete' key={index}>
              <img
                src={values}
                alt="profile"
                width={45}
                height={45}
                onClick={() => {
                  console.log('Image URL:', values);
                  modalImageView(values);
                }}
              />
              <p className='employee-details_photodelete-para'>{filename(values)}</p>
              <DeleteOutlined onClick={() => deleteRes(values)} className='employee-details_delete_icon' />
            </div>
          ))}
        </Form.Item>
        <Form.Item>
          <div className="employee-details_submit">
            <Space>
              <Button htmlType="button" onClick={() => ModalClose(null)} className="employee-details_cancel-btn">
                Cancel
              </Button>
              <Button htmlType="submit" className="employee-details_submit-btn">
                Submit
              </Button>
            </Space>
          </div>
        </Form.Item>
      </Form>
      <Modal
        open={modalImageOpen}
        onCancel={modalImageClose}
        footer={null}
        className='modal_body'
      >
        <img
          alt="example"
          style={{ width: '100%', backgroundColor: 'transparent' }}
          src={modalImage || undefined}  // Use 'modalImage || undefined' to ensure it's of type 'string | undefined'
        />

      </Modal>

    </div>
  );
};

export default CreateSubCategory;
