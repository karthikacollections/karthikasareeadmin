import { Button, Drawer, Popconfirm, Space, Table, Modal } from "antd";
import React, { useEffect, useState } from "react"
import { DeleteOutlined, DownloadOutlined, EditOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@apollo/client";
import { CREATE_INVOICE_DETAILS, GET_SUB_INVOICE } from "@/helpers";
import CRMnav from '../crmlayout'
import { useAuth } from '../../../components/auth'
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";
import moment from "moment";
import jsPDF from "jspdf";

export const Category: React.FC<any> = () => {
    const [category, setCategory] = useState([])
    const [settings, setSettings] = useState([])
    const [open, setOpen] = useState<any>(null);
    const { check_button_permission, filteredColumns } = useAuth()
    const [heading, setHeading] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("")
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");
   
    
 const { error: reminderDaysError, loading: reminderDaysLoading, data: reminderDaysData } = useQuery(CREATE_INVOICE_DETAILS);
   useEffect(() => {
    if (reminderDaysData) {
        let res = reminderDaysData?.mst_company_details
        setCategory(res)
    }
}, [reminderDaysData])

 const { error, loading, data, refetch: refetCategoryData } = useQuery(GET_SUB_INVOICE)
  useEffect(() => {
        if (data) {
            let res = data?.mst_invoice
            setCategory(res)
        }
    }, [data])

const OnOpen = () => {
        setOpen(true)
        setHeading('Create')
    }

    const ModalClose = () => {
        setOpen(false)
    }

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
        setHeading("Edit")
    }
    const generatePDF = (record: any, reminderDaysData: any) => {
      const pdf = new jsPDF();
      pdf.setFontSize(12);
      const lineHeight = 15;
      const maxWidth = pdf.internal.pageSize.getWidth();
      const rightMargin = 20; // Adjust the right margin as needed
      const maxAllowedX = maxWidth - rightMargin;
      const companyLogoUrl = reminderDaysData?.mst_company_details[0]?.company_logo;
      pdf.addImage(companyLogoUrl, 'JPEG', 20, 20, 50, 50); 
      
     // pdf.text("Invoice", 170, 20,);
    pdf.setFontSize(20);// Set the font size
    pdf.setFont("helvetica", "bold");
    const invoiceTextWidth = pdf.getTextWidth("Invoice");
    const invoiceTextX = maxAllowedX - invoiceTextWidth;
    pdf.text("Invoice", invoiceTextX, 20);
     // pdf.text(`Company Name: ${reminderDaysData?.mst_company_details[0]?.company_name}`, 170, 40,);
    pdf.setFontSize(14);
    pdf.setFont("helvetica", "normal");
    const companyNameText = `${reminderDaysData?.mst_company_details[0]?.company_name}`;
    const companyNameTextWidth = pdf.getTextWidth(companyNameText);
    const companyNameTextX = maxAllowedX - companyNameTextWidth;
     pdf.text(companyNameText, companyNameTextX, 30);
     pdf.setFontSize(12);
    const gstNumber = `GST.NO: ${reminderDaysData?.mst_company_details[0]?.gst_no}`;
    const gstNumberTextWidth = pdf.getTextWidth(gstNumber);
    const gstnumberTextX = maxAllowedX - gstNumberTextWidth;
     pdf.text(gstNumber, gstnumberTextX, 40);
     pdf.setFontSize(12);
     const phoneNameText = `${reminderDaysData?.mst_company_details[0]?.phone_number}`;
    const phoneNameTextWidth = pdf.getTextWidth(phoneNameText);
    const phoneNameTextX = maxAllowedX - phoneNameTextWidth;
     pdf.text(phoneNameText, phoneNameTextX, 50);
     pdf.setFontSize(12);
     const companyAddressText = `${reminderDaysData?.mst_company_details[0]?.company_address}`;
    const companyAddressTextWidth = pdf.getTextWidth(companyAddressText);
    const companyAddressTextX = maxAllowedX - companyAddressTextWidth;
     pdf.text(companyAddressText, companyAddressTextX, 60);
    
     const lineY = 60 + lineHeight; // Adjust based on the desired line height
     pdf.line(15, lineY, maxAllowedX, lineY);
     pdf.setFontSize(14);
     pdf.setFont("helvetica", "bold");
     pdf.text(`Bill To:`, 20, 90);
     pdf.setFontSize(12);
     pdf.setFont("helvetica", "normal");
     pdf.text(`${record.mst_client.company_name}`, 20, 95);
     pdf.text(`GST.NO: ${record.mst_client.gst}`, 20, 100);
     pdf.text(`${record.mst_client.phone_number}`, 20, 105);
     pdf.text(`${record.mst_client.address}`, 20, 110);
     
    const invoiceId = `Invoice.No: ${String(record.id).slice(-4)}`;
    const invoiceIdTextWidth = pdf.getTextWidth(invoiceId);
    const invoicenumberTextX = maxAllowedX - invoiceIdTextWidth;
     pdf.text(invoiceId, invoicenumberTextX, 90);
     const dateText = `Date: ${moment(record?.mst_product?.created_at).format('DD-MMM-YY')}`;
    const dateTextWidth = pdf.getTextWidth(dateText);
    const dateTextX = maxAllowedX - dateTextWidth;
     pdf.text(dateText, dateTextX, 100);
     const duedateText = `Due Date: ${moment(record.created_at).format('DD-MMM-YY')}`;
     const duedateTextWidth = pdf.getTextWidth(duedateText);
     const duedateTextX = maxAllowedX - duedateTextWidth;
      pdf.text(duedateText, duedateTextX, 110);
      const lineT = 108 + lineHeight; // Adjust based on the desired line height
     
      pdf.line(10, lineT, maxAllowedX, lineT);
      pdf.setFillColor(200, 200, 200); // RGB values, adjust as needed
      // Draw a filled rectangle between lineT and lineD
     pdf.rect(10, lineT, maxAllowedX - 10, 10, 'F');
      const tableHeaders = ["S.No","Product Name", "Quantity", "Price", "Amount"];
      
      
      const lineD = 118 + lineHeight; // Adjust based on the desired line height
      pdf.line(10, lineD, maxAllowedX, lineD);
      
      const tableData = [
        [1,record?.mst_product?.name, record?.quantity, record?.price, record?.total_price]
      ];
      // Set the starting position for the table
      const tableStartX = 20; // Adjust as needed
      const tableStartY = 130; // Adjust as 
      
      // Set column widths
      const columnWidths = [20,40, 37, 37, 37]; // Adjust as needed
      //const columnHeights = [10, 10, 10, 10];
      // Draw table headers
      let currentX = tableStartX;
      tableHeaders.forEach((header, index) => {
        pdf.text(header, currentX, tableStartY);
        currentX += columnWidths[index];
      });
      const totalTableWidth = columnWidths.reduce((sum, width) => sum + width, 0);

// Draw table data
let subTotal = 0; // Initialize subTotal
tableData.forEach((rowData, rowIndex) => {
  currentX = tableStartX;
  const lineHeight = 10; // Adjust as needed
  const tableRowY = tableStartY + (rowIndex + 1) * lineHeight;
 
  pdf.text(String(rowIndex + 1), tableStartX, tableRowY);

  rowData.forEach((cell, cellIndex) => {
    pdf.text(String(cell), currentX, tableRowY);
    currentX += columnWidths[cellIndex];

    // If it's the "total_price" column, add it to subTotal
    if (cellIndex === 3) {
      subTotal += parseFloat(cell); // Assuming "total_price" is a numeric value
    }
  });
});

// Draw the straight horizontal line below the last row of the table
 // Use the same calculation as in your original code
const linez = tableStartY + (tableData.length + 1) * lineHeight; // Position it below the last row
pdf.line(10, linez, tableStartX + totalTableWidth, linez);
const paymentInstructionY = linez + 10; // Adjust the value to control the distance between the line and the text
pdf.setFont("helvetica", "bold");
pdf.text("Payment Instruction:", 15, paymentInstructionY);

const firstTextHeight = 5; // Adjust as needed
const verticalSeparation = 5; // Adjust as needed

// Calculate the Y-coordinate for the next row
const nextRowY = paymentInstructionY + firstTextHeight + verticalSeparation;
pdf.setFont("helvetica", "normal");
pdf.text(`Bank Name: ${reminderDaysData?.mst_company_details[0]?.bank_name}`, 15, nextRowY);

// Calculate the Y-coordinate for the next row after the "Bank Name" line
const nextRow1Y = nextRowY + firstTextHeight + verticalSeparation;
pdf.text(`Account No: ${reminderDaysData?.mst_company_details[0]?.account_number}`, 15, nextRow1Y);

// Calculate the Y-coordinate for the next row after the "Account No" line
const nextRow2Y = nextRow1Y + firstTextHeight + verticalSeparation;
pdf.setFont("helvetica", "bold");
pdf.text(`QR/UPI Payment:`, 15, nextRow2Y);
const nextRow3Y = nextRow2Y + firstTextHeight + verticalSeparation;
// Add the image
const QrCodeUrl = reminderDaysData?.mst_company_details[0]?.qr_code;
pdf.addImage(QrCodeUrl, 'JPEG', 15, nextRow3Y, 50, 50);
const nextRow4Y = nextRow3Y + 50 + verticalSeparation; // Assuming the image height is 50
pdf.setFont("helvetica", "normal");
pdf.text(`Scan to pay via UPI`, 15, nextRow4Y);


// Calculate GST amount
const gstPercent = reminderDaysData?.mst_company_details[0]?.gst_percent || 0; // Assuming gst_percent is a numeric value
const gstAmount = (subTotal * gstPercent) / 100;

// Calculate the total amount (Sub Total + GST)
const totalAmount = subTotal + gstAmount;
pdf.text(`Sub Total: ${subTotal}`, 185, paymentInstructionY, { align: 'right' });
pdf.text(`GST Included(${gstPercent}%) : ${gstAmount}`, 185, nextRowY, { align: 'right' });
pdf.setFont("helvetica", "bold");
pdf.text(`Total Amount: ${totalAmount}`, 185, nextRowY + 10, { align: 'right' });

const lineAfterScan = nextRow4Y + firstTextHeight + verticalSeparation;
pdf.line(10, lineAfterScan, maxAllowedX, lineAfterScan);
const nextRow5Y = lineAfterScan + verticalSeparation; // Assuming the line height is verticalSeparation
pdf.setFont("helvetica", "normal");
pdf.text(`This is a Computer Generated Bill`, 75, nextRow5Y);
 //     pdf.text(`Product: ${record.mst_product.name}`, 30, 60);
 // Save the PDF
        pdf.save("invoice.pdf");
        setPopOpen(true);
      };

    var count = 0

    const columns = [
        {
            title: 'S.no',
            render: () => ++count
        },

        {
            title: 'Invoice No',
            dataIndex: 'id',
            key: 'id',
            render: (text: any) => String(text).slice(-5) // Convert to string and display only the last 5 digits
        },

        {
            title: 'Client',
            render: (value: any) => <p>{value?.mst_client?.name}</p>,
        },
        {
            title: 'Product',
            render: (value: any) => <p>{value?.mst_product?.name}</p>
        },
        {
            title: 'Date',
            dataIndex: 'created_at',
            key: 'created_at',
            render: (text:any) => moment(text).format('DD-MMM-YY')
          },
        {
            title: 'Price',
            dataIndex: 'price',
            key: 'price'
        },
        {
            title: 'Quantity',
            dataIndex: 'quantity',
            key: 'quantity'
        },
        {
            title: 'Total',
            dataIndex: 'total_price',
            key: 'total_price'
        },
        {
            title: 'Action',
            key: 'action',
            render: (record: any) => (
              <Space size='large'>
                <Button
                  type="primary"
                  icon={<DownloadOutlined />}
                  onClick={() => generatePDF(record,reminderDaysData)}
                  style={{ backgroundColor: 'green', borderColor: 'green' }}
                >
                  PDF
                </Button>
              </Space>
            ),
          }
    ]

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
    };

    const handleOk = () => {
        refetCategoryData();
        setPopOpen(false);
    };

    const handleCancel = () => {
        setPopOpen(false);
    };

    return (
        <CRMnav>
            <div className="employee-details">
                <div className="employee-details_head">
                    <h2 className="employee-details_head-text">Invoice</h2>
                    {/* {
                        check_button_permission("Category", "create")
                            ?
                        <Button className="employee-details_head-create" onClick={OnOpen}>+ Add New Category</Button>
                        :<></>
                    } */}
                </div>

                <Table columns={filteredColumns(columns, Category)} dataSource={category} pagination={false}  className="employee-details_table" />

                {/* <Drawer title={`${heading} Category`} width={570} placement="right" onClose={() => setOpen(false)} open={open} className="employee-details_drawer"> */}
                {/* {
                        heading == "Edit" ? (<CreateCategory ModalClose={ModalClose}  showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        heading == "Create" ? (<CreateCategory ModalClose={ModalClose}  showModal={showModal} editdraw={null} />) : <></>
                    }
                </Drawer> */}

            </div>
            <Modal
                open={Popopen}
                title=""
                onOk={handleOk}
                onCancel={handleCancel}
                footer={[
                    <div style={{ display: "flex", justifyContent: "center" }}>
                        <Button
                            key="submit"
                            type="primary"
                            loading={loading}
                            onClick={handleOk}
                            style={{
                                display: "flex",
                                width: "206px",
                                padding: "15px 30px",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "10px",
                                borderRadius: "8px",
                                background: "#252947",
                            }}>
                            OK
                        </Button>
                    </div>,
                ]}
                width={"386px"}>
                <Space
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                    }}>
                    <Image
                        src={PopImage}
                        alt="image"
                        style={{
                            width: "150px",
                            height: "150px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    />
                    <p
                        style={{
                            color: "#101010",
                            textAlign: "center",
                            fontFamily: "revert",
                            fontSize: "32px",
                            fontStyle: "normal",
                            fontWeight: "700",
                            lineHeight: "normal",
                        }}>
                        PDF Created
                    </p>
                </Space>
            </Modal>
        </CRMnav>
    )
}

export default Category


