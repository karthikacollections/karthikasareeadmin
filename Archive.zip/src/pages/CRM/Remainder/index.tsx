import React, { useEffect, useState } from "react"
import { GET_REMINDER, DELETE_REMINDER, UPDATE_REMINDER } from "@/helpers";
import CRMnav from '../crmlayout'
import { useAuth } from '../../../components/auth'
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";
import { ClockCircleOutlined, CloseOutlined, DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@apollo/client";
import { Button, Modal, Popconfirm, Select, Space, Table, Tooltip } from "antd";
import moment from "moment";

export const Redminder: React.FC<any> = () => {
  const { check_button_permission, filteredColumns } = useAuth()
  const [reminders, setReminders] = useState([] as any)
  const [deleteReminderTrue] = useMutation(DELETE_REMINDER);
  const [modalContent, setModalContent] = useState<string>("Invoice Created");
  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, '0');
  const day = String(currentDate.getDate()).padStart(2, '0');
  const formattedDate = `${year}-${month}-${day}`;
  const queryVariables = { snooze: formattedDate }
  const { loading, error, data, refetch } = useQuery(GET_REMINDER, { variables: queryVariables })

  useEffect(() => {
    if (data) {
      let datum = data?.mst_reminder
      setReminders(datum)
    }
  }, [data])

  const handleCancelSubscription = async (record: any) => {
    try {
      const result = await deleteReminderTrue({
        variables: {
          id: record.id,
        },
        refetchQueries: [{ query: GET_REMINDER }],
      });
      setReminders((prevReminder: any) =>
        prevReminder.filter((item: any) => item.id !== record.id)
      );
      setModalContent("Bookings Canceled");
      setModalVisible(true);
    } catch (error) {
    }
  };

  const [updateReminder] = useMutation(UPDATE_REMINDER);


  const handleSoonze = async (record: any) => {
    try {
      // Assuming snoozeData?.mst_reminder is an array
      const reminder = data?.mst_reminder[0];

      if (reminder) {
        const currentSnoozeDate = new Date(reminder.snooze);
        const newSnoozeDate = new Date(currentSnoozeDate.setDate(currentSnoozeDate.getDate() + 1));

        await updateReminder({
          variables: {
            snooze: newSnoozeDate.toISOString(),
            _eq: record.id,
          },
        });

        // Handle success, e.g., show a notification
        console.log("Snooze successful!");
      } else {
        console.error("No reminder found for snooze");
      }
      setModalContent("Bookings Soonzed");
      setModalVisible(true);

    } catch (error) {
      // Handle error, e.g., show an error message
      // console.error("Error snoozing reminder", error.message);
    }
    refetch();
  };

 

  const columns = [
    {
      title: "S.no",
      dataIndex: "s.no",
      render: (text: any, record: any, index: number) => index + 1,
    },
    {
      title: "Client",
      render: (value: any) => <p>{value?.mst_client?.name}</p>,
    },
    {
      title: "Company",
      render: (value: any) => <p>{value?.mst_client?.company_name}</p>,
    },
    {
      title: "Product Name",
      render: (value: any) => <p>{value?.mst_product?.name}</p>,
    },
    {
      title: 'Renewal',
      render: (record: any) => {
        let renewal = moment(record?.renewal).format('DD MMM YY')
console.log(renewal,'renewal');
console.log(record?.renewal,'record?.renewal');

        return (
          <p>{renewal}</p>
        )
      }
    },
    {
      title: 'Snooze',
      render: (record: any) => {
        let snooze = moment(record?.snooze).format('DD MMM YY')

        return (
          <p>{snooze}</p>
        )
      }
    },
   
    {
      title: "Action",
      key: "action",
      render: (record: any) => (
        <Space size="large">
          {check_button_permission("subscription", "cancel") && (
            <Tooltip title="Cancel Bookings">
              <Popconfirm
                title="Are you sure you want to cancel this reminder?"
                onConfirm={() => handleCancelSubscription(record)}
                okText="Yes"
                cancelText="No"
              >
                <CloseOutlined className="employee-details_cancel" />
              </Popconfirm>
            </Tooltip>
          )}
          {check_button_permission("subscription", "cancel") && (
            <Tooltip title="Snooze">
              <Popconfirm
                title="Are you sure you want to Soonze?"
                onConfirm={() => handleSoonze(record)}
                okText="Yes"
                cancelText="No"
              >
                <ClockCircleOutlined className="employee-details_cancel" />

              </Popconfirm>
            </Tooltip>
          )}
        </Space>
      ),
    },
  ];

  const handleOk = () => {
    setModalVisible(false);
  };

  const handlecancel = () => {
    setModalVisible(true);
  };

  return (
    <CRMnav>

      <div className="employee-details">
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Reminder</h2>
          {/* {
            check_button_permission("Category", "create")
              ?
              <Button className="employee-details_head-create" onClick={OnOpen}>+ Add New Category</Button>
              : <></>
          } */}
        </div>
        <Table
          columns={filteredColumns(columns, "Reminder")}
          dataSource={reminders}
          pagination={false}
          className="employee-details_table"
        />
          <Modal
          open={modalVisible}
          title=""
          onOk={handleOk}
          onCancel={handlecancel}
          footer={[
            <div style={{ display: "flex", justifyContent: "center" }}>
              <Button
                key="submit"
                type="primary"
                loading={loading}
                onClick={handleOk}
                style={{
                  display: "flex",
                  width: "206px",
                  padding: "15px 30px",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: "10px",
                  borderRadius: "8px",
                  background: "#252947",
                }}>
                OK
              </Button>
            </div>,
          ]}
          width={"386px"}>
          <Space
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            }}>
            <Image
              src={PopImage}
              alt="image"
              style={{
                width: "150px",
                height: "150px",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            />
            <p
              style={{
                color: "#101010",
                textAlign: "center",
                fontFamily: "revert",
                fontSize: "32px",
                fontStyle: "normal",
                fontWeight: "700",
                lineHeight: "normal",
              }}>
              {modalContent}
            </p>
          </Space>
        </Modal>
      </div>
    </CRMnav>
  )
}

export default Redminder