import React from 'react'
import CRMnav from '../crmlayout'

export const ServiceDashboard: React.FC = () => {
    return (
        <CRMnav>
            <div className="employee-details">
                <div className="employee-details_head">
                    <h2 className="employee-details_head-text">Dashboard</h2>
                </div>
            </div>
        </CRMnav>
    )
}

export default ServiceDashboard