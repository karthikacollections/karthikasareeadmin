import { Button, Table, Modal, Select, DatePicker, Popconfirm, Space, Drawer } from "antd";
import React, { useEffect, useState } from "react";
import { useMutation, useQuery } from "@apollo/client";
import { GET_SUBSCRIPTION, GET_SERVICE_USERS, GET_SHOP, UPDATE_BOOKING_STATUS } from "@/helpers";
import { format } from 'date-fns';
import CRMnav from '../crmlayout';
import { useAuth } from '../../../components/auth';
import { useRouter } from 'next/router';
import moment from "moment";
import { useShopContext } from "../../../context/shopContext";
import CheckCircleOutlined from "@ant-design/icons/lib/icons/CheckCircleOutlined";
import CloseCircleOutlined from "@ant-design/icons/lib/icons/CloseCircleOutlined";
import RightOutlined from "@ant-design/icons/lib/icons/RightOutlined";
import { DeleteOutlined, DownOutlined, EditOutlined } from "@ant-design/icons";
import CreateTracking from "./createSubscription";

interface UpdatedStatus {
    [key: string]: string;
}

export const OrderBookings: React.FC<any> = () => {
    const { check_button_permission, filteredColumns, user } = useAuth();
    const [booking, setBooking] = useState([]);
    const [isStatusModalVisible, setStatusModalVisible] = useState(false);
    const { selectedOrgValue, setSelectedOrgValue } = useShopContext();
    const [selectedShopId, setSelectedShopId] = useState<string | null>(null); // State for selected shop ID
    const { error, loading, data, refetch } = useQuery(GET_SUBSCRIPTION);
    const { data: shopData } = useQuery(GET_SHOP);
    const { data: clientData, refetch: refetchClient } = useQuery(GET_SERVICE_USERS);
    const router = useRouter();
    const [modalVisible, setModalVisible] = useState(false);
    const [taskData, setTaskData] = useState<any>([]);
    const [selectedUser, setSelectedUser] = useState<string>("");
    const [updateBookingStatus] = useMutation(UPDATE_BOOKING_STATUS);
    const [selectedDate, setSelectedDate] = useState<string | null>(null);
    const [updatedStatus, setUpdatedStatus] = useState<UpdatedStatus>({});
    const [viewingAddress, setViewingAddress] = useState(false); 
    const [editdraw, setEditdraw] = useState("");
    const [heading, setHeading] = useState<any>(null);
    const [open, setOpen] = useState<any>(null);

    console.log(clientData,"clientData")
    useEffect(() => {
        if (data) {
            let res = data?.mst_bookings;
            setBooking(res);
        }
    }, [data]);

    useEffect(() => {
        // Refetch clients when selected shop ID changes
        refetchClient();
    }, [selectedShopId]);

    const OnOrder = () => {
        router.push('/CRM/Bookings');
    };

    const showModal = (param: any ,isAddress: boolean = false) => {
        setModalVisible(true);
        setTaskData(param);
        setViewingAddress(isAddress);
    };

    const showStatusModal = (param: any) => {
        setStatusModalVisible(true);
        setTaskData(param);
      };
    
      const handleStatusModalOk = () => {
        setStatusModalVisible(false); // Close the modal
      };
    
      const handleStatusModalCancel = () => {
        setStatusModalVisible(false); // Close the modal
      };

    const getProductsByBookingId = (bookingId: any) => {
        const booking = data?.mst_bookings.find((booking: any) => booking.id === bookingId);
        return booking?.mst_booked_products || [];
    };

    const search = (data: any) => {
        let filteredData = data;

        if (selectedShopId) {
            filteredData = filteredData?.filter((u: any) =>
                u?.userAddress?.mst_user?.shop?.id === selectedShopId
            );
        }

        // Filter by selected user
    if (selectedUser) {
        filteredData = filteredData?.filter((u: any) =>
            u?.userAddress?.mst_user?.id === selectedUser
        );
    }
        if (selectedDate) {
            filteredData = filteredData?.filter((u: any) =>
                moment(u.created_at).format('YYYY-MM-DD') === selectedDate
            );
        }

        return filteredData;
    };

    const handleDateChange = (date: any, dateString: string) => {
        setSelectedDate(dateString);
    };

    const handleSelectChangeUser = (value: any) => {
        console.log(value,"value in handleSelectChangeUser")
        setSelectedUser(value);
       
    };

    const handleSelectChangeOrganization = (value: any) => {
        setSelectedOrgValue(value);
        const selectedShop = shopData?.mst_shop.find((shop: any) => shop.shop_name === value);
        setSelectedShopId(selectedShop?.id || null);
    };

   const handleStatusChange = (id: string, status: string, record: any) => {
//     const currentTime = new Date().toLocaleString(); // Current timestamp in ISO 8601 format
//   console.log(currentTime,"currentTime")

  const currentTime = format(new Date(), 'MM/dd/yyyy HH:mm:ss'); // Adjust the format string as needed
console.log(currentTime, "currentTime");
    // Find the current booking details from the query data
    const currentBooking = data?.mst_bookings?.find((booking: any) => booking.id === id);

    if (!currentBooking) {
        console.error("Booking not found");
        return;
    }

    const variables = {
        id,
        status,
        rejected_at: currentBooking.rejected_at,
        accepted_at: currentBooking.accepted_at,
        dispatched_at: currentBooking.dispatched_at,
        inTransit_at: currentBooking.inTransit_at,
        delivered_at: currentBooking.delivered_at,
    };

    // Update only the timestamp corresponding to the new status
    if (status === "Rejected") {
        variables.rejected_at = currentTime;
    } else if (status === "Accepted") {
        variables.accepted_at = currentTime;
    } else if (status === "Ready to Ship") {
        variables.dispatched_at = currentTime;
    } else if (status === "In Transit") {
        variables.inTransit_at = currentTime;
    } else if (status === "Delivered") {
        variables.delivered_at = currentTime;
    }

    // Execute the mutation
    updateBookingStatus({ variables })
        .then(() => {
            console.log(`Status updated to ${status} for booking ID: ${id}`);
            setUpdatedStatus((prev) => ({ ...prev, [id]: status })); 
            refetch(); 
            if (status === "In Transit") {
                handleChange(record); // Pass the record to handleChange
            }
        })
        
        .catch((error) => {
            console.error("Error updating status:", error);
        });
};
const formatDate = (date: string) => {
    return format(new Date(date), 'MMMM dd, yyyy HH:mm:ss');
  };
  // Function to render the date field only if it's not "N/A"
  const renderDateField = (label: string, date: string | null | undefined) => {
    if (date && date !== "N/A") {
      return <p><strong>{label}:</strong> {formatDate(date)}</p>;
    }
    return null;  // Return nothing if it's "N/A" or null
  };

  const handleChange = (record: any) => {
    console.log("Record selected for edit:", record); // Debugging log
    setEditdraw(record);
    setOpen("Edit");
    setHeading("Edit");
};

  const OnOpen = () => {
    setOpen(true);
    setHeading("Create");
  };

  const ModalClose = () => {
    setOpen(false);
  };
    

    var count = 0;

    const columns = [
        {
            title: 'S.no',
            render: () => ++count
        },
        {
            title: "Booking Id",
            key: "id",
            dataIndex: "id",
            render: (id: string) => {
                const truncatedId = id.slice(0, 8); // Get the first 8 characters
                return <span>{truncatedId}</span>;
            },
        },
        
        {
            title: 'Booked Date',
            dataIndex: 'created_at',
            key: 'created_at',
            render: (text: any) => moment(text).format('DD-MMM-YY HH:mm')
        },

        {
            title: 'Payment',
            dataIndex: 'payment_type',
            key: 'payment_type',
            
        },
        {
            title: "User",
            render: (record: any) => {
                let client = record?.userAddress?.mst_user?.name;
                return <p>{client}</p>;
            }
        },
        {
            title: 'Items',
            render: (value: any) => {
                let bookedProducts = value?.mst_booked_products || [];
                return <p>{bookedProducts.length}</p>;
            },
        },
        {
            title: "Total",
            dataIndex: "total",
            key: "total",
        },

        {
            title: "Coupon",
            dataIndex: "coupon_code",
            key: "coupon_code",
        },
        {
            title: "Products",
            render: (value: any) => {
                return (
                    <Button className="employee-details_head-create" onClick={() => showModal(value)}>
                        View
                    </Button>
                );
            },
        },
        {
            title: "Address",
            key: "address",
            render: (record: any) => {
                // const address = record?.userAddress?.address;
                
                return (
                    <Button className="employee-details_head-create"  onClick={() => showModal(record, true)}>
                        View
                    </Button>
                );
            },
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            render: (text: string, record: any) => {
                const status = updatedStatus[record.id] || record.status;
                const isAccepted = status === 'Accepted';
                const isRejected = status === 'Rejected';
                const isReadyToShip = status === 'Ready to Ship';
                const isTransit = status === 'In Transit';
                const isDelivered = status === 'Delivered';

                return (
                    <>
                        {status === 'Pending' ? (
                            <>
                                <div style={{ display: 'flex',marginLeft:'35px', justifyContent: 'flex-start', alignItems: 'center', gap: '8px' }}>
        <CheckCircleOutlined
            style={{ color: 'green' }}
            onClick={() => handleStatusChange(record.id, 'Accepted', record)}
        />
        <CloseCircleOutlined
            style={{ color: 'red' }}
            onClick={() => handleStatusChange(record.id, 'Rejected', record)}
        />
    </div>
                            </>
                        ) : (
                            <>
                                <Button
                                    // icon={!isRejected && !isDelivered && <RightOutlined />}
                                    style={{
                                        marginLeft: 8,
                                        backgroundColor: isRejected
                                            ? '#252947'
                                            : isReadyToShip
                                            ? '#252947'
                                            : isTransit
                                            ? '#252947' // Light orange color
                                            : isDelivered
                                            ? '#252947' 
                                            : 'green',
                                        color: '#fff',
                                        borderColor: isRejected
                                            ? '#252947'
                                            : isReadyToShip
                                            ? '#252947'
                                            : isTransit
                                            ? '#252947'
                                            : isDelivered
                                            ? '#252947' 
                                            : 'green',
                                    }}
                                    onClick={() => {
                                        if (isAccepted) handleStatusChange(record.id, 'Ready to Ship', record);
                                        if (isReadyToShip) handleStatusChange(record.id, 'In Transit', record);
                                        if (isTransit) handleStatusChange(record.id, 'Delivered', record);
                                    }}
                                >
                                    {status}
                                </Button>
                                <DownOutlined  
    style={{ marginLeft: "8px" }}
    onClick={() => showStatusModal(record)}
/>

                            </>
                        )}
                    </>
                );
            }
        },

        {
            title: "Tracking",
            key: "action",
            render: (record: any) => (
              <Space size="large">
                {check_button_permission("Category", "edit") ? (
            <EditOutlined
              onClick={() => handleChange(record)}
              className="employee-details_edit"
            />
          ) : (
            <></>
          )}
              </Space>
            ),
          },
    ];

    var number = 0;
    const column = [
        {
            title: 'S.no',
            render: () => ++number
        },
        {
            title: "Product",
            render: (values: any) => {
                let productName = values?.mst_products[0]?.name;
                return (
                    <p>{productName}</p>
                );
            }
        },
        {
            title: 'Quantity',
            key: 'quantity',
            dataIndex: 'quantity'
        },
        {
            title: 'Price',
            render: (values: any) => {
                let productPrice = values?.mst_products[0]?.offered_price;

                if (!productPrice) {
                    const priceAttribute = values?.mst_products[0]?.attributes?.find((attr: any) => attr.keys === 'price');
                    if (priceAttribute) {
                        productPrice = priceAttribute.values[0];
                    }
                }

                return <p>{productPrice}</p>;
            },
        },
        {
            title: 'Sub Total',
            key: 'sub_total',
            dataIndex: 'sub_total'
        },
       
          
    ];

    return (
        <CRMnav>
            <div className="employee-details">
                <h1 className="employee-details_head-text">{selectedOrgValue}</h1>
                <div className="employee-details_head">
                    <h2 className="employee-details_head-text">Order Bookings</h2>
                    {/* <Select
                        size={"large"}
                        onChange={handleSelectChangeOrganization}
                        allowClear
                        showSearch
                        filterOption={(input, option: any) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                        placeholder={"Search Shop"}
                        className="Asset_selecter"
                        style={{ width: "220px", marginRight: "10px" }}
                        value={selectedOrgValue}
                    >
                        {shopData?.mst_shop?.map((shop: any, index: any) => (
                            <Select.Option value={shop?.shop_name} key={index}>
                                {shop?.shop_name}
                            </Select.Option>
                        ))}
                    </Select> */}
                    <Select
                        size={"large"}
                        onChange={handleSelectChangeUser}
                        allowClear
                        showSearch
                        filterOption={(input, option: any) =>
                            option.children?.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                        placeholder={"Search User"}
                        value={selectedUser || undefined}
                        className="Asset_selecter"
                        style={{ width: "220px", marginRight: "10px" }}
                    >
                        {clientData?.mst_users?.map((org: any, index: any) => (
                            <Select.Option value={org?.id} key={index}>
                                {org?.name}
                                
                            </Select.Option>
                        ))}
                    </Select>
                    <div>
                        <DatePicker onChange={handleDateChange} />
                    </div>
                    {/* {
                        check_button_permission("OrderBookings", "create")
                            ?
                            <Button className="employee-details_head-create" onClick={OnOrder}>
                                + Add New Orders
                            </Button>
                            : <></>
                    } */}
                </div>

                <Table columns={columns} dataSource={search(booking)} pagination={{ pageSize: 10 }} className="employee-details_table" />
                <Drawer
          title={`${heading} Tracking`}
          width={570}
          placement="right"
          onClose={() => setOpen(false)}
          open={open}
          className="employee-details_drawer"
        >
          {heading == "Edit" ? (
            <CreateTracking
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={editdraw}
            />
          ) : (
            <></>
          )}
         
        </Drawer>

                <Modal
                    title={
                        <React.Fragment>
                            <div className='task'>
                                <div className='task_header'>
                                <div style={{ justifyContent: 'start' }} className='task_header_body'>
    <p className='task_header_title'>{viewingAddress ? 'Address' : 'Products'}</p>
</div>

                                </div>
                            </div>
                        </React.Fragment>
                    }
                    open={modalVisible}
                    onCancel={() => setModalVisible(false)}
                    footer={null}
                    width={900}
                >
                    {viewingAddress ? (
                        <div>
                        <p><strong>Address:</strong> {taskData?.userAddress?.address}</p>
                        <p><strong>City:</strong> {taskData?.userAddress?.city}</p>
                        <p><strong>Landmark:</strong> {taskData?.userAddress?.landmark}</p>
                        <p><strong>Pincode:</strong> {taskData?.userAddress?.pincode}</p>
                        {/* Add any other fields if needed */}
                    </div>
                        
                    ) : (
                        <Table
                            dataSource={getProductsByBookingId(taskData?.id)} columns={column} pagination={false} />
                    )}
                </Modal>
                <Modal
        title="Status and Time Details"
        visible={isStatusModalVisible}
        onOk={handleStatusModalOk}  // Action when OK is clicked
        onCancel={handleStatusModalCancel}  // Action when Cancel button is clicked
       
      >
             <div>
          <p><strong>Status:</strong> {taskData?.status}</p>
          {renderDateField("Order Placed At", taskData?.created_at)}
          {renderDateField("Accepted At", taskData?.accepted_at)}
          {renderDateField("Rejected At", taskData?.rejected_at)}
          {renderDateField("Dispatched At", taskData?.dispatched_at)}
          {renderDateField("In Transit At", taskData?.inTransit_at)}
          {renderDateField("Delivered At", taskData?.delivered_at)}
        </div>
      </Modal>
      
            </div>
        </CRMnav>
    );
};

export default OrderBookings;
