import React, { useCallback, useEffect, useReducer, useState } from "react";
import { gql, useLazyQuery, useMutation } from "@apollo/client";
import { CHECK_PRODUCT_BY_CODE, insertBookingMutation } from "@/helpers";
import { Modal } from "antd";
import { color } from "html2canvas/dist/types/css/types/color";

interface Product {
  id: string; // Adjust type as necessary
  productCode: string;
  productName: string;
  quantity: number;
  unit: string;
  price: number | null;
  discount: number | null;
  total: number | null;
}

const Pos: React.FC<any> = () => {
  const [productCode, setProductCode] = useState("");
  const [displayedProducts, setDisplayedProducts] = useState<Product[]>([]); // Define the type here
  const [savedProductCode, setSavedProductCode] = useState("");
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [totalPrice, setTotalPrice] = useState(0);
  const [isEditingQuantity, setIsEditingQuantity] = useState(false);
  const [newQuantity, setNewQuantity] = useState(1); // Default to 1 or current quantity
  const [selectedProductIndex, setSelectedProductIndex] = useState<number | null>(null);
  const [isAddingRow, setIsAddingRow] = useState<boolean>(true);
  const [savedQuantity, setSavedQuantity] = useState(1); // Default value
  const [errorMessage, setErrorMessage] = useState<string | null>(null); // State for error messages
  const [insertBooking] = useMutation(insertBookingMutation);
  const [searchTrigger, setSearchTrigger] = useState(0);

  const [currentDateTime, setCurrentDateTime] = useState({
    date: "",
    time: ""
  });
  const [searchProduct, { loading, data, error,refetch }] = useLazyQuery(CHECK_PRODUCT_BY_CODE);

  // Load products from local storage on component mount
  useEffect(() => {
    const existingProducts = JSON.parse(localStorage.getItem("displayedProducts") || "[]");
    setDisplayedProducts(existingProducts);
  }, []);

   // Handle product search and add product to displayed products
   const handleSearch = useCallback(() => {
    const currentCode = productCode;
    const quantity = newQuantity;
  
    console.log("quantity in handleSearch", quantity);
    console.log("currentCode in handleSearch", currentCode);
  
    setSavedProductCode(currentCode);
    setProductCode('');
    setNewQuantity(1);
    setSearchTrigger(prev => prev + 1); // Increment searchTrigger
  
    searchProduct({ variables: { code: currentCode } })
      .then(() => {
        console.log(`Searching for code: ${currentCode}, Quantity: ${quantity}`);
        setSavedQuantity(quantity);
      })
      .catch((error) => {
        console.error('Error during search:', error);
      });
  }, [productCode, newQuantity]);
  


  const getPriceForCode = (attributes: any[], searchCode: string) => {
    const excludedKeys = ["price", "stock", "images", "productCode", "barcode", "alphaNumericCode"];
    const otherKeyIndices: any[] = [];

    attributes.forEach((attr: any, index: number) => {
      if (!excludedKeys.includes(attr.keys)) {
        otherKeyIndices.push({ index, key: attr.keys, values: attr.values });
      }
    });

    const priceAttribute = attributes.find(attr => attr.keys === "price");
    const codeAttribute = attributes.find(attr => attr.keys === "productCode");
    const alphaCode = attributes.find(attr => attr.keys === "alphaNumericCode");

    if (priceAttribute) {
      const cleanedCode = searchCode.trim();
      let indexInCodeAttribute = -1;
      let indexInAlphaCode = -1;

      if (codeAttribute) {
        indexInCodeAttribute = codeAttribute.values.findIndex((val: any) => val.trim() === cleanedCode);
      }
      if (alphaCode) {
        indexInAlphaCode = alphaCode.values.findIndex((val: any) => val.trim() === cleanedCode);
      }

      let validIndex = -1;
      if (indexInCodeAttribute > -1 && indexInCodeAttribute < priceAttribute.values.length) {
        validIndex = indexInCodeAttribute;
      } else if (indexInAlphaCode > -1 && indexInAlphaCode < priceAttribute.values.length) {
        validIndex = indexInAlphaCode;
      }

      if (validIndex > -1) {
        return priceAttribute.values[validIndex];
      }
    }

    return "-";
  };

  const getOtherKeysForCode = (attributes: any[], searchCode: string) => {
    const excludedKeys = ["price", "stock", "images", "productCode", "barcode", "alphaNumericCode"];
    const otherKeyIndices: any[] = [];

    attributes?.forEach((attr: any, index: number) => {
      if (!excludedKeys.includes(attr.keys)) {
        otherKeyIndices.push({ index, key: attr.keys, values: attr.values });
      }
    });

    const codeAttribute = attributes?.find(attr => attr.keys === "productCode");
    const alphaCode = attributes?.find(attr => attr.keys === "alphaNumericCode");

    if (codeAttribute || alphaCode) {
      const cleanedCode = searchCode.trim();
      let indexInCodeAttribute = -1;
      let indexInAlphaCode = -1;

      if (codeAttribute) {
        indexInCodeAttribute = codeAttribute.values.findIndex((val: any) => val.trim() === cleanedCode);
      }
      if (alphaCode) {
        indexInAlphaCode = alphaCode.values.findIndex((val: any) => val.trim() === cleanedCode);
      }

      let validIndex = -1;
      if (indexInCodeAttribute > -1) {
        validIndex = indexInCodeAttribute;
      } else if (indexInAlphaCode > -1) {
        validIndex = indexInAlphaCode;
      }

      if (validIndex > -1) {
        return otherKeyIndices
          .map(attr => `${attr.values[validIndex]} ${attr.key}`)
          .join(", ") || "-";
      }
    }

    return "-";
  };

  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      const date = now.toLocaleDateString("en-GB");
      const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      setCurrentDateTime({ date, time });
    };

    updateDateTime();
    const intervalId = setInterval(updateDateTime, 60000);

    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    console.log("useEffect triggered");
    console.log("savedProductCode:", savedProductCode);
    console.log("data:", data);
    console.log(savedProductCode, "savedProductCode before resetting error"); 
    // Ensure error message is reset when product code changes
    if (!savedProductCode) return; // Exit early if no product code is present
   
    setErrorMessage(null); // Clear previous error
    console.log(savedProductCode, "savedProductCode after resetting error");

    // Only proceed if data is available
    if (data && data.mst_product.length > 0) {
        const newProducts: Product[] = data.mst_product.map((product: any) => {
            const price = product.price !== null ? product.price : getPriceForCode(product.attributes, savedProductCode);
            const quantity = savedQuantity; 

            return {
                id: product.id as string,
                productCode: savedProductCode,
                productName: product.name,
                quantity,
                unit: getOtherKeysForCode(product.attributes, savedProductCode),
                price,
                discount: product.offered_price !== null ? product.offered_price : null,
                total: price * quantity,
            };
        });

        const productMap: { [key: string]: Product } = {};
        const existingProducts: Product[] = JSON.parse(localStorage.getItem("displayedProducts") || "[]");

        existingProducts.forEach((existingProduct) => {
            const key = `${existingProduct.id}-${existingProduct.price}`;
            productMap[key] = existingProduct;
        });

        newProducts.forEach((newProduct) => {
            const key = `${newProduct.id}-${newProduct.price}`;
            if (productMap[key]) {
                setIsModalVisible(true); // Show modal if product exists
            } else {
                productMap[key] = newProduct; // Add new product
            }
        });

        const updatedProducts = Object.values(productMap);
        const calculatedTotalPrice = updatedProducts.reduce((sum, product) => sum + (product.total || 0), 0);
        
        setTotalPrice(calculatedTotalPrice);
        localStorage.setItem("displayedProducts", JSON.stringify(updatedProducts));
        setDisplayedProducts(updatedProducts);

        // Perform validation after processing the products
        const validProduct = newProducts.find(product => product.productCode === savedProductCode);

        // If no valid product is found in query result, proceed to check local storage
        if (!validProduct) {
            const productExistsInLocal = existingProducts.find(
                (existingProduct) => existingProduct.productCode === savedProductCode
            );

            // Show error only if the product doesn't exist in localStorage as well
            if (!productExistsInLocal) {
                console.log('Invalid product code: No related product found');
                setErrorMessage('No related product found');
            }
        }
    } else if (data && data.mst_product.length === 0) {
        // No products in query response and product code entered
        if (savedProductCode) {
            setErrorMessage('No related product found');
        }
    }
}, [data, savedProductCode,searchTrigger]);



  
  // Modal component to alert about existing product
  const handleOk = () => {
    setIsModalVisible(false);
  };
  
  const handleCancel = () => {
    setIsModalVisible(false);
  };


  const handlePrint = async (shouldInsert = false) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      const totalAmount = displayedProducts.reduce((acc, product) => acc + (product.total || 0), 0);
     
      printWindow.document.write(`
        <html>
          <head>
            <title>Print</title>
             <style>
              body {
                font-family: Arial, sans-serif;
                margin: 20px;
                padding: 0;
              }
              .bill-container {
                width: 100%;
                max-width: 400px; /* Adjust for your desired width */
                margin: auto;
                text-align: left;
              }
              .bill-header {
                text-align: center;
                margin-bottom: 20px;
              }
              .date-time {
                display: flex;
                justify-content: space-between;
                margin-top: 10px;
              }
              .product-list {
                margin-bottom: 20px;
                border-top: 1px solid #000;
                border-bottom: 1px solid #000;
              }
              .product-item {
                display: flex;
                justify-content: space-between;
                padding: 5px 0;
              }
              .total-amount {
                margin-top: 20px;
                font-weight: bold;
                display: flex;
                justify-content: space-between;
              }
              @media print {
                .no-print { display: none; }
              }
            </style>
          </head>
          <body>
            <div class="bill-container">
              <div class="bill-header">
                <h2>Shop Name</h2>
                <div class="date-time">
                  <span>Date: ${new Date().toLocaleDateString()}</span>
                  <span>Time: ${new Date().toLocaleTimeString()}</span>
                </div>
              </div>
              <div class="product-list">
                ${displayedProducts.map((product) => `
                  <div class="product-item">
                    <span>${product.productName}</span>
                    <span>${product.quantity} ${product.unit}</span>
                    <span>${product.price !== null ? `₹${product.price}` : '-'}</span>
                    <span>${product.total !== null ? `₹${product.total}` : '-'}</span>
                  </div>
                `).join('')}
              </div>
              <div class="total-amount">
                <span>Total Amount</span>
                <span>${`₹ ${totalAmount.toFixed(2)}`}</span>
              </div>
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
  
      // Insert booking if shouldInsert is true
      if (shouldInsert) {
        const billProductsJson = JSON.stringify(displayedProducts);
        try {
          const response = await insertBooking({
            variables: {
              bill_products: displayedProducts,
              total: totalAmount,
            },
          });
          console.log('Booking inserted:', response.data.insert_mst_bookings);
        } catch (error) {
          console.error('Error inserting booking:', error);
        }
      }
    }
  };
  
  const handleBillReprint = () => {
    handlePrint(); // Call print function only
  };
  
  const handlePrintAndInsert = () => {
    handlePrint(true); // Call print function with insertion
  };
  
  

useEffect(() => {
  const handleKeyPress = (event: KeyboardEvent) => {
    if (event.key === 'F12') {
      handlePrintAndInsert();
    }
  };

  window.addEventListener('keydown', handleKeyPress);
  return () => {
    window.removeEventListener('keydown', handleKeyPress);
  };
}, []);


  //remove td
  const handleRemoveProduct = () => {
    console.log('Initial displayedProducts:', displayedProducts);  // Check the initial state
    console.log('Selected Product Index:', selectedProductIndex);  // Confirm the index of the product to be removed
  
    if (selectedProductIndex !== null) {
      // Create a new array by filtering out the selected product
      const updatedProducts = displayedProducts.filter((_, index) => index !== selectedProductIndex);
      
      console.log('Updated Products after removal:', updatedProducts);  // Log updated product list
  
      // Update localStorage to keep it in sync
      localStorage.setItem('displayedProducts', JSON.stringify(updatedProducts));
      
      // Update state to trigger re-render
      setDisplayedProducts(updatedProducts);
      
      console.log('After setDisplayedProducts, displayedProducts:', updatedProducts);  // Log after state update
      
      setSelectedProductIndex(null); // Reset after removal
    } else {
      console.log('No product selected for removal.');  // If no product is selected for removal
    }
  };
  
  useEffect(() => {
    const handleKeyPress = (event: any) => {
      console.log('Key pressed:', event.keyCode);  // Log key code
      console.log('Event key:', event.key);        // Log key name
      console.log('Event code:', event.code);      // Log key code
      
      if (event.key === 'F4' || event.keyCode === 115 || event.code === 'F4') {  // Check for F4 using different properties
        event.preventDefault(); // Prevent the default F4 action
        console.log('F4 pressed - Default action prevented');
        handleRemoveProduct();   // Custom logic to remove the product
      }
    };
  
    // Add event listener for key press
    window.addEventListener('keydown', handleKeyPress);
  
    // Clean up the event listener on component unmount
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [selectedProductIndex]);
  
  
  

  const handleRowClick = (index: number) => {
    setSelectedProductIndex(index);
    setNewQuantity(displayedProducts[index]?.quantity || 1); // Prepare for editing, but do not set editing mode
  };
  
  
  

  
  //for quantity change

// Handler for editing quantity when clicking the div or pressing F2
const handleEditQuantity = () => {
  if (selectedProductIndex !== null) {
    setIsEditingQuantity(true); // Set editing mode
  }
};
  
const handleChangeQuantity = () => {
  if (selectedProductIndex !== null && displayedProducts) {
    const updatedProducts = [...displayedProducts];
    const currentProduct = updatedProducts[selectedProductIndex];
    if (currentProduct) {
      currentProduct.quantity = newQuantity;
      currentProduct.total = (currentProduct.price || 0) * newQuantity;

      // Recalculate the total price based on updated products
      const updatedTotalPrice = updatedProducts.reduce((sum, product) => {
        return sum + (product.total || 0);
      }, 0);

      // Save updated products to local storage and state
      localStorage.setItem("displayedProducts", JSON.stringify(updatedProducts));
      setDisplayedProducts(updatedProducts);
      setTotalPrice(updatedTotalPrice); // Update the total price state

      // Reset editing state
      setIsEditingQuantity(false);
      setNewQuantity(1);
      setSelectedProductIndex(null);
    }
  }
};

useEffect(() => {
  if (displayedProducts && displayedProducts.length > 0) {
    const calculatedTotalPrice = displayedProducts.reduce((sum, product) => {
      return sum + (product.total || 0);
    }, 0);
    
    setTotalPrice(calculatedTotalPrice);
    localStorage.setItem("displayedProducts", JSON.stringify(displayedProducts));
  }
}, [displayedProducts]);

  
 // UseEffect to handle F2 key press
useEffect(() => {
  const handleKeyPress = (event: KeyboardEvent) => {
    if (event.key === 'F2') {
      handleEditQuantity();
    }
  };

  window.addEventListener('keydown', handleKeyPress);

  return () => {
    window.removeEventListener('keydown', handleKeyPress);
  };
}, [selectedProductIndex]);


//Cancel Invoice

// Function to clear local storage
 const handleClearLocalStorage = () => {
    localStorage.clear();  // Clear local storage
    setDisplayedProducts([]);  // Clear state to remove products from the table
    // setIsAddingRow(false);
    setTotalPrice(0);
    console.log('Local storage cleared and displayed products updated');
    location.reload()
  };

// useEffect to listen for the F6 key
useEffect(() => {
  const handleKeyPress = (event: KeyboardEvent) => {
    if (event.key === 'F6') {
      handleClearLocalStorage(); // Clear local storage on F6 keypress
    }
  };

  window.addEventListener('keydown', handleKeyPress);

  return () => {
    window.removeEventListener('keydown', handleKeyPress); // Clean up listener on unmount
  };
}, []);


// Handle F3 key press or button click to add an empty row
useEffect(() => {
  const handleKeyPress = (event: KeyboardEvent) => {
    if (event.key === 'F3') {
      handleAddEmptyRow(); // Add empty row when F3 is pressed
    }
  };

  window.addEventListener('keydown', handleKeyPress);

  return () => {
    window.removeEventListener('keydown', handleKeyPress); // Cleanup listener
  };
}, []);

const handleAddEmptyRow = () => {
  setIsAddingRow(true); // Add an empty row for product search
};

// Capture the product code when user types
const handleProductCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  setProductCode(e.target.value.trim());
  setSelectedProductIndex(null);
  setNewQuantity(1);
  
  
  console.log('Selected Product Index after change:', null); // Log here to confirm
};

useEffect(() => {
  if (productCode) {
    setSelectedProductIndex(null);
  }
}, [productCode]);


// Handle the Enter key press to trigger search
const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
  if (event.key === 'Enter') {
    handleSearch(); // Trigger the search when Enter is pressed
    if (productCode) {
      console.log(`Product Code entered: ${productCode}`);
      // Implement your logic to handle the product code input
      // e.g., fetch product details, add to the list, etc.
    }
  }
  
};

  
    useEffect(() => {
      const handleKeyPress = (event:any) => {
        if (event.key === 'F9') {
          handlePrintAndInsert();
        }
      };
  
      // Add event listener for key press
      window.addEventListener('keydown', handleKeyPress);
  
      // Clean up the event listener on component unmount
      return () => {
        window.removeEventListener('keydown', handleKeyPress);
      };
    }, []);
  
 
  return (
    <>
      <div className="logo-container">Logo</div>
      <div className="POS-header">Point of Sale</div>
      <div className="pos-container">
        <div className="pos-product">
          {/* <div className="search-pos">
            <div className="search-product">Product code:</div>
            <div className="search-text">
              <input
                type="text"
                value={productCode}
                onChange={(e) => setProductCode(e.target.value)}
              />
            </div>
            <div className="search-button">
              <button onClick={handleSearch}>Search</button>
            </div>
          </div>
          {loading && <p>Loading...</p>}
          {error && <p>Error: {error.message}</p>} */}
          <div className="pos-tablecontainer"></div>
          <table className="pos-table">
            <thead>
              <tr>
                <th>SI.NO</th>
                <th>Product Code</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Unit</th>
                <th>Price</th>
                {/* <th>Discount</th> */}
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
          {displayedProducts.map((product, index) => (
            <tr
            key={`${product.id}-${product.productCode}`}
              style={{ backgroundColor: selectedProductIndex === index ? '#ddd' : '#EAEBF2' }}
              onClick={() => handleRowClick(index)}
            >
              <td>{index + 1}</td>
              <td>{product.productCode}</td>
              <td>{product.productName}</td>
              <td>
                {isEditingQuantity && selectedProductIndex === index ? (
                  <input
                    type="number"
                    value={newQuantity}
                    onChange={(e) => setNewQuantity(Number(e.target.value))}
                    min="1"
                    onBlur={handleChangeQuantity}
                  />
                ) : (
                  product.quantity
                )}
              </td>
              <td>{product.unit}</td>
              <td>{product.price !== null ? `₹${product.price}` : "-"}</td>
              <td>{product.total !== null ? `₹${product.total}` : "-"}</td>
            </tr>
          ))}

          {/* Render empty row for adding new product */}
          {isAddingRow && (
  <tr style={{ backgroundColor: '#ddd' }}>
    <td>{displayedProducts.length + 1}</td>
    <td>
    <input
        type="text"
        value={productCode}
        onChange={(e) => {
          handleProductCodeChange(e); // Update product code
          setErrorMessage(null); // Clear error message on change
        }}
        onFocus={() => setErrorMessage(null)} // Clear error on focus
        onKeyPress={handleKeyPress} // Listen for Enter key
        placeholder="Product Code"
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            e.preventDefault(); // Prevent form submission on Enter key
          }
        }}
      />
       {errorMessage && <div style={{ color: 'red' }}>{errorMessage}</div>}
    </td>
    <td>
      {productCode && ( // Show quantity input only if product code is entered
        <input
          type="number"
          value={newQuantity}
          onChange={(e) => setNewQuantity(Number(e.target.value))}
          // min="1"
          placeholder="Quantity"
          onKeyPress={handleKeyPress} 
          
        />
      )}
    </td>
    <td>{/* Empty placeholder for Unit */}</td>
    <td>{/* Empty placeholder for Price */}</td>
    <td>{/* Empty placeholder for Total */}</td>
    <td>{/* Empty placeholder for Total */}</td>
  </tr>
)}
        </tbody>



          </table>
        </div>
        <div className="pos-amount">
          <div className="timedatenow">
          <div className="Date">Date: {currentDateTime.date}</div>
          <div className="Time">Time: {currentDateTime.time}</div>
          </div>
          <div className="price-calculation">
            <div className="bill_details">
              <div className="Bill">Bill Details</div>
              <div className="bill_details_amount">
                <div>Total</div>
                <div>
                <input type="text" value={`₹ ${totalPrice.toFixed(2)}`} readOnly />
                </div>
              </div>
              <div className="bill_details_amount" style={{ opacity: 0.5, pointerEvents: 'none' }}>
  <div>Discount</div>
  <div>
    <input type="text" disabled style={{ backgroundColor: '#f0f0f0', border: '1px solid #ccc' }} />
  </div>
</div>

              <div className="bill_details_amount">
                <div>Sub Total</div>
                <div>
                <input type="text" value={`₹ ${totalPrice.toFixed(2)}`} readOnly />
                </div>
              </div>
              <hr className="hr-margin-bottom" />
              <div className="bill_details_amount">
                <div>Total Amount</div>
                <div>{`₹ ${totalPrice.toFixed(2)}`}</div>
              </div>
            </div>
          </div>
          <div className="short-cuts">
            <div className="shortcuts_column">
              <div className="row_column1" onClick={handlePrintAndInsert} style={{ cursor: 'pointer' }}>
      <div>Save+Print</div>
      <div>[F12]</div>
    </div>
    <div className="row_column2"
     onClick={handleEditQuantity}
     >
  <div>Change Qty</div>
  <div>[F2]</div>
</div>

            </div>
            <div className="shortcuts_column">
            <div className="row_column3"  onClick={handleRemoveProduct} style={{ cursor: 'pointer' }}>
                <div>Remove Item</div>
                <div>[F4]</div>
              </div>
              <div className="row_column4" onClick={handleAddEmptyRow}>
  <div>Add</div>
  <div>[F3]</div>
</div>

            </div>
            <div className="shortcuts_column">
            <div className="row_column5" onClick={handleBillReprint} style={{ cursor: 'pointer' }}>
                <div>Bill Reprint</div>
                <div>[F9]</div>
              </div>
              <div className="row_column6" onClick={handleClearLocalStorage}>
                <div>Cancel Invoice</div>
                <div>[F6]</div>
              </div>
            </div>
          </div>
        </div>
        <Modal
      // title="Product Already Exists"
      visible={isModalVisible}
      onOk={handleOk}
      onCancel={handleCancel}
    >
      <p>The product you are trying to add already exists in the list.</p>
    </Modal>
      </div>
    </>
  );
};

export default Pos;
