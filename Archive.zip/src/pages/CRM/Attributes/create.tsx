import { useMutation, useQuery } from "@apollo/client";
import { Button, Form, Input, Select, Space } from "antd";
import React, { useEffect, useRef, useState } from "react";
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { ColorPicker, useColor } from "react-color-palette";
import "react-color-palette/css";
import { GetColorName } from 'hex-color-to-color-name';
import { GET_SERVICE_ATTRIBUTES, CREATE_SERVICE_ATTRIBUTES, UPDATE_SERVICE_ATTRIBUTES, GET_CATEGORY, GET_SHOP } from "@/helpers";

interface SendPayload {
    id?: string;
    name: string;
    categories: any;
    options: any;
    shop_id: string;
}

const CreateAttributes: React.FC<any> = ({ ModalClose, editdraw, showModal }) => {
    const [form] = Form.useForm();
    const { data: shopData } = useQuery(GET_SHOP);
    const [category, setCategory] = useState([]);
    const [color, setColor] = useColor("#ffffff");
    const [nameValue, setNameValue] = useState("");
    const [colors, setColors] = useState([{ color: "#ffffff", name: "" }]);
    const [colorPickerVisible, setColorPickerVisible] = useState(true);

    const [createAttribute, { loading: createLoading, error: createError }] = useMutation(CREATE_SERVICE_ATTRIBUTES, { errorPolicy: 'all' });
    const [updateAttribute, { loading: updateLoading, error: updateError }] = useMutation(UPDATE_SERVICE_ATTRIBUTES, { errorPolicy: 'all' });
    const { refetch } = useQuery(GET_SERVICE_ATTRIBUTES);
    const { data: dataCat } = useQuery(GET_CATEGORY);

    useEffect(() => {
        if (dataCat) {
            setCategory(dataCat?.mst_category || []);
        }
    }, [dataCat]);

    useEffect(() => {
        if (editdraw) {
            form.setFieldsValue(editdraw);
            setNameValue(editdraw?.name || "");
            
            if (editdraw.name.toLowerCase() === "color" && Array.isArray(editdraw.options)) {
                const colorOptions = editdraw.options.map((colorOption: any) => {
                    const colorName = Object.keys(colorOption)[0];
                    const hexCode = colorOption[colorName];
                    const colorHex = `#${colorName.slice(4)}`;
                    return { color: colorHex, name: hexCode };
                });
                setColors(colorOptions);
            }
        }
    }, [editdraw]);

    const onFinish = async (values: any) => {
        const colorPairs = await Promise.all(colors.map(async color => {
            const colorName = await GetColorName(color.color);
            const hexCode = color.color.slice(1).toUpperCase();
            return { [`0xff${hexCode}`]: colorName };
        }));

        let sendPayload: SendPayload = {
            name: values?.name,
            categories: values?.categories,
            options: nameValue.toLowerCase() === "color" ? colorPairs : values?.options,
            shop_id: values?.shop_id
        };

        console.log("sendPayload:", sendPayload);

        if (editdraw) {
            sendPayload.id = editdraw.id;
            updateAttribute({
                variables: sendPayload,
                
            }).then(() => {
                console.log('Update Success:', sendPayload);
                refetch();
                ModalClose(null);
            }).catch(err => {
                console.error('Update Error:', err);
                console.error('Error Details:', err.graphQLErrors);
            });
        } else {
            createAttribute({
                variables: sendPayload,
            }).then(() => {
                console.log('Create Success:', sendPayload);
                refetch();
                ModalClose(null);
            }).catch(err => {
                console.error('Create Error:', err);
                console.error('Error Details:', err.graphQLErrors);
            });
        }
    };

    const onFinishFailed = (errorInfo: any) => {
        console.error('Failed:', errorInfo);
    };

    const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNameValue(e.target.value);
    };

    const handleColorChange = (newColor: any) => {
        setColor(newColor);
        const lastColor = colors[colors.length - 1];
        if (lastColor.name) {
            setColors([...colors, { color: newColor.hex, name: "" }]);
            setColorPickerVisible(false);
        } else {
            lastColor.color = newColor.hex;
            setColors([...colors]);
        }
    };

    const handleColorNameChange = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
        const newColors = [...colors];
        newColors[index].name = e.target.value;
        setColors(newColors);
    };

    const addColor = () => {
        setColors([...colors, { color: "#ffffff", name: "" }]);
        setColorPickerVisible(true);
    };

    return (
        <>
            <Form
                name="category"
                layout="vertical"
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                
                className="employee-details_form"
            >
                <Form.Item
                    label="Name"
                    name="name"
                    required={false}
                    rules={[{ required: true, message: 'Please Enter the Attribute' }]}
                >
                    <Input onChange={handleNameChange} />
                </Form.Item>
                {nameValue.toLowerCase() === "color" ? (
                    <>
                        {colors.map((item, index) => (
                            <div key={index} style={{ marginBottom: 8 }}>
                                <Form.Item label={`Color ${index + 1}`}>
                                    <Input
                                        placeholder={item.color}
                                        value={item.name}
                                        onChange={(e) => handleColorNameChange(e, index)}
                                    />
                                </Form.Item>
                                {colorPickerVisible && index === colors.length - 1 && (
                                    <ColorPicker color={color} onChange={handleColorChange} />
                                )}
                                <MinusCircleOutlined
                                    style={{ marginLeft: '10px' }}
                                    onClick={() => {
                                        const newColors = [...colors];
                                        newColors.splice(index, 1);
                                        setColors(newColors);
                                    }}
                                />
                            </div>
                        ))}
                        <Form.Item>
                            <Button
                                type="dashed"
                                onClick={addColor}
                                block
                                icon={<PlusOutlined />}
                            >
                                Add Color
                            </Button>
                        </Form.Item>
                    </>
                ) : (
                    <Form.List name="options">
                        {(fields, { add, remove }) => (
                            <>
                                {fields.map(({ key, name, ...restField }) => (
                                    <div key={key}>
                                        <Form.Item
                                            {...restField}
                                            name={name}
                                            label="Option"
                                            required={false}
                                            rules={[{ required: true, message: 'Missing option' }]}
                                        >
                                            <Input />
                                        </Form.Item>
                                        <MinusCircleOutlined
                                            style={{ marginLeft: '500px' }}
                                            onClick={() => remove(name)}
                                        />
                                    </div>
                                ))}
                                <Form.Item>
                                    <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />}>
                                        Add Option
                                    </Button>
                                </Form.Item>
                            </>
                        )}
                    </Form.List>
                )}
                {/* <Form.Item
                    label='Shop Name'
                    name='shop_id'
                    required={false}
                    rules={[{ required: true, message: 'Please Select the Shop' }]}
                >
                    <Select>
                        {shopData?.mst_shop.map((shop: any) => (
                            <Select.Option key={shop.id} value={shop.id}>{shop.shop_name}</Select.Option>
                        ))}
                    </Select>
                </Form.Item> */}
                <Form.Item>
                    <div className="employee-details_submit">
                        <Space>
                            <Button htmlType="button" onClick={() => ModalClose(null)} className="employee-details_cancel-btn">
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="employee-details_submit-btn">
                                Submit
                            </Button>
                        </Space>
                    </div>
                </Form.Item>
            </Form>
        </>
    );
};

export default CreateAttributes;
