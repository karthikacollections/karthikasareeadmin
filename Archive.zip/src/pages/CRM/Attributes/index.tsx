import { Button, Drawer, Popconfirm, Space, Table, Modal, Select } from "antd";
import React, { useEffect, useState } from "react";
import CreateAttributes from "./create";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@apollo/client";
import CRMnav from "../crmlayout";
import { useAuth } from "../../../components/auth";
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";
import {
  GET_SERVICE_ATTRIBUTES,
  DELETE_SERVICE_ATTRIBUTES,
  GET_SHOP,
} from "@/helpers";
import { useShopContext } from "@/context/shopContext";

export const Attributes: React.FC<any> = () => {
  const [open, setOpen] = useState<any>(null);
  const [attributes, setAttributes] = useState([]);
  
  const [filteredAttributes, setFilteredAttributes] = useState([]);
  const { check_button_permission, filteredColumns} = useAuth();
  const { error, loading, data, refetch } = useQuery(GET_SERVICE_ATTRIBUTES);
  const [editdraw, setEditdraw] = useState<any>(null);
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");
  const { selectedOrgValue, setSelectedOrgValue } = useShopContext();
  const [deleteCategory, { loading: deleteLoad, error: deleteError }] =
    useMutation(DELETE_SERVICE_ATTRIBUTES);
  const { data: shopData } = useQuery(GET_SHOP);

  useEffect(() => {
    if (data) {
      console.log('Fetched attributes:', data.mst_attributes);
      setAttributes(data.mst_attributes || []);
    }
  }, [data]);

  const OnOpen = () => {
    setOpen(true);
  };

  const ModalClose = () => {
    setOpen(false);
  };

  const handleChange = (record: any) => {
    setEditdraw(record);
    setOpen("Edit");
  };

  const handleDelete = (res: any) => {
    deleteCategory({
      variables: res,
      update: (cache: any) => {
        showModal("Deleted");
        refetch();
      },
    });
  };

  const search = (data: any[]) => {
    const filteredData = data?.filter((record: any) => {
      const shopName = record?.shop?.shop_name?.toLowerCase();
      const selectedShop = selectedOrgValue?.toLowerCase();
      const matchesShop = selectedShop ? shopName === selectedShop : true;
      return matchesShop;
    });
    return filteredData;
  };
  
  const handleSelectChangeOrganization = (value: any) => {
    console.log('Selected shop:', value);
    setSelectedOrgValue(value);
  };

  var count = 0;
  const columns = [
    {
      title: "S.No",
      render: () => ++count,
    },
    {
      title: "Name",
      key: "name",
      dataIndex: "name",
    },
    {
      title: "Options",
      dataIndex: "options",
      key: "options",
      render: (options: any[], record: any) => {
        if (record.name.toLowerCase() === "color") {
          // If it's a color attribute, render color names
          if (options && options.length > 0) {
            return options
              .map((option) => {
                const colorKey = Object.keys(option)[0];
                const colorName = option[colorKey];
                return colorName;
              })
              .join(", ");
          } else {
            return "--";
          }
        } else {
          // Otherwise, render normal options
          return options && options.length > 0 ? options.join(", ") : "--";
        }
      },
    },
    {
      title: "Action",
      key: "action",
      render: (record: any) => (
        <Space size="large">
          {check_button_permission("Category", "edit") ? (
            <EditOutlined
              onClick={() => handleChange(record)}
              className="employee-details_edit"
            />
          ) : null}
          {check_button_permission("Category", "delete") ? (
            <Popconfirm
              title="Delete the Attributes"
              description="Are you sure to delete this Attributes?"
              okText="Yes"
              cancelText="No"
              onConfirm={() => handleDelete(record)}
            >
              <DeleteOutlined className="employee-details_delete" />
            </Popconfirm>
          ) : null}
        </Space>
      ),
    },
  ];

  const showModal = (param: any) => {
    setPopOpen(true);
    setTitle(param);
  };

  const handleOk = () => {
    refetch();
    setPopOpen(false);
  };

  const handleCancel = () => {
    setPopOpen(false);
  };

  return (
    <CRMnav>
      <div className="employee-details">
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Attributes</h2>
          {/* <Select
            size={"large"}
            onChange={handleSelectChangeOrganization}
            allowClear
            showSearch
            filterOption={(input, option: any) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
            placeholder={"Search Shop"}
            className="Asset_selecter"
            style={{ width: "220px", marginRight: "10px" }}
            value={selectedOrgValue} // Set the default value
          >
            {shopData?.mst_shop?.map((shop: any, index: any) => (
              <Select.Option value={shop?.shop_name} key={index}>
                {shop?.shop_name}
              </Select.Option>
            ))}
          </Select> */}
          {check_button_permission("Category", "create") ? (
            <Button
              className="employee-details_head-create"
              onClick={() => setOpen("Create")}
            >
              + Add New Attributes
            </Button>
          ) : null}
        </div>

        <Table
  columns={filteredColumns(columns)}
  dataSource={search(attributes)} // Changed from filteredAttributes to attributes
  pagination={false}
  className="employee-details_table"
/>

        <Drawer
          title={`${open} Attributes`}
          width={570}
          placement="right"
          onClose={() => setOpen(false)}
          open={open}
          className="employee-details_drawer"
        >
          {open === "Edit" ? (
            <CreateAttributes
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={editdraw}
            />
          ) : null}
          {open === "Create" ? (
            <CreateAttributes
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={null}
            />
          ) : null}
        </Drawer>
      </div>
      <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{ display: "flex", justifyContent: "center" }}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}
            >
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}
      >
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}
          >
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
    </CRMnav>
  );
};

export default Attributes;
