
import withApollo from '../../../config'
import React, { useEffect, useState, useRef } from 'react';
import { Space, Table, Button, Form, Popconfirm, Drawer, Modal, Select } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { GET_PRODUCT, GET_CLIENT_NAME,GET_SHOP,GET_PRODUCT_BY_ID} from '../../../helpers/queries'
import { DELETE_PRODUCT, PRODUCT_SOFT_DELETE } from '../../../helpers/mutation'
import { useQuery, useMutation } from "@apollo/client";
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import CreateProduct from "./createProduct";
import CRMnav from '../crmlayout'
import moment from "moment";
import { useAuth } from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";
import { useShopContext } from '../../../context/shopContext';
import JsBarcode from 'jsbarcode';

export const Products: React.FC = () => {

  // const [count, setCount] = useState([])

  const [open, setOpen] = useState<any>(null);
  const [editdraw, setEditdraw] = useState("")
  const [product, setproduct] = useState([])
  const [products, setproducts] = useState([])
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");
  const { check_button_permission, filteredColumns, check_user_type, user } = useAuth();
  const [selectedValue, setSelectedValue] = useState("");
  const { selectedOrgValue, setSelectedOrgValue } = useShopContext();
  const handleSelectChange = (value: any) => { setSelectedValue(value); };
  const { data: shopData } = useQuery(GET_SHOP);
  const showModal = (param: any) => {
    setPopOpen(true);
    setTitle(param);
  };

  const handleOk = () => {
    refetProduct();
    setPopOpen(false);
  };

  const handleCancel = () => {
    setPopOpen(false);
  };

  const ModalClose = () => {
    setOpen(false)
    // refetProduct()

  }

  const handleChange = (record: any) => {
    setEditdraw(record)
    setOpen("Edit")
  }

  const [deleteProduct, { loading, error, data }] = useMutation(PRODUCT_SOFT_DELETE);
  const handleDelete = async (record: any) => {
    try {
      const [deleteResult] = await Promise.all([
        deleteProduct({
          variables: {
            id: record.id,
            check: false,
          },
          refetchQueries: [{ query: GET_PRODUCT }],
        }),
      ]);

      // Use deleteResult if needed
    } catch (error) {
    }
  };

  const search_user = (data: any) => {
    return selectedValue
      ? data.filter((u: any) =>
        u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
      )
      : data;
  };

  const search = (data: any) => {
    return selectedValue
      ? data.filter((u: any) =>
        u.name?.toLowerCase().includes(selectedValue?.toLowerCase())
      )
      : data;
  };

  const search1 = (data: any) => {
    const filteredData = data?.filter((record: any) => {
        const categoryShopName = record?.mst_category?.shop?.shop_name?.toLowerCase();
        const selectedShop = selectedOrgValue?.toLowerCase();
        const selectedProduct = selectedValue?.toLowerCase();

        if (selectedShop) {
          return (
            categoryShopName === selectedShop &&
            (!selectedProduct || record.name.toLowerCase().includes(selectedProduct))
          );
        }

         return !selectedProduct || record.name.toLowerCase().includes(selectedProduct);
    });

    return filteredData;
};

const handleSelectChangeOrganization = (value: any) => {
  setSelectedOrgValue(value);
  setSelectedValue("")
};

 
  const {
    error: assetError,
    loading: assetLoading,
    data: dataProduct,
    refetch: refetProduct,
  } = useQuery(GET_PRODUCT, {
    variables: {},
  });

  useEffect(() => {
    if (dataProduct) {
      let product = dataProduct?.mst_product
      setproduct(product)
    }
  }, [dataProduct])

 


  //for client name
  const {
    error: assetErrors,
    loading: assetLoadings,
    data: dataProducts,
    refetch: refetProducts,
  } = useQuery(GET_CLIENT_NAME, {
    variables: {},
  });

  useEffect(() => {
    if (dataProducts) {
      let products = dataProducts?.mst_clientmanagement
      setproducts(products)
    }
  }, [dataProducts])

  let empData = [...(dataProduct?.mst_product || [])];
  let sort = empData?.sort((a: any, b: any) => a?.name?.localeCompare(b?.name));

  interface DataType {

    employee: string;
  }

  var count = 0

  const columns: ColumnsType<DataType> = [
    {
      title: 'S.no',
      render: () => ++count
    },


    {
      title: 'Service Name',
      dataIndex: 'name',
      key: 'name'
    },



    // {
    //   title: 'Description',
    //   dataIndex: 'description',
    //   key: 'description'
    // },

    {
      title: 'Category',
      render: (value: any) => {
        let category = value?.mst_category?.category
        return (
          <p>{category}</p>
        )
      }
    },

    {
      title: 'Sub Category',
      
      render: (value: any) => {
        console.log(value,"subcategory value")
        let category = value?.mst_sub_category?.sub_name
        return (
          <p>{category}</p>
        )
      }
    },
                               
    {
      title: 'Price',
      dataIndex: 'offered_price',
      key: 'offered_price'
    },
    {
      title: 'Stock',
      dataIndex: 'stocks',
      key: 'stocks'
    },


    // {
    //   title: 'Expiry',
    //   render: (value) => {
    //     let x = value?.expiry;

    //     const isValidExpiry = typeof x === 'number' && !isNaN(x);

    //     return (
    //       <>
    //         {isValidExpiry ? (
    //           <p>{Math.abs(x)} days</p>
    //         ) : (
    //           <p>No Expiry</p>
    //         )}
    //       </>
    //     );
    //   },
    // },
    {
      title: 'Duration',
      render: (value) => {
        let x = value?.duration;

        const isValidExpiry = typeof x === 'number' && !isNaN(x);

        return (
          <>
            {isValidExpiry ? (
              <p>{Math.abs(x)} Mins</p>
            ) : (
              <p>No Duration</p>
            )}
          </>
        );
      },
    },


    {
      title: 'Action',
      key: 'action',
      render: (
        record: any) => (
        <Space size='large'>
          {
            check_button_permission("Products", "Edit")
              ?
              <EditOutlined
                onClick={() => handleChange(record)}
                className="assets_edit"
              /> : <></>
          }

          {
            check_button_permission("Products", "delete")
              ?
              <Popconfirm
                title="Delete the task"
                description="Are you sure to delete this Service?"
                okText="Yes"
                onConfirm={() => handleDelete(record)}
                cancelText="No"
              >
                <DeleteOutlined className="assets_delete" />
              </Popconfirm> : <></>
          }

        </Space>
      ),
    },
  ];
 
 

  return (
    <CRMnav>
      <div className="assets">
        <div className="assets_head">
          <h2 className="assets_head-text">Products</h2>
          <div>
      
      
    </div>
          {/* <Select
          size={"large"}
          onChange={handleSelectChangeOrganization}
          allowClear
          showSearch
          filterOption={(input, option: any) =>
            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
          }
          placeholder={"Search Shop"}
          className="Asset_selecter"
          style={{ width: "220px", marginRight: "10px" }}
          value={selectedOrgValue}
        >
          {shopData?.mst_shop?.map((shop: any, index: any) => (
            <Select.Option value={shop?.shop_name} key={index}>
              {shop?.shop_name}
            </Select.Option>
          ))}
        </Select> */}
       {/* {(user.email === "admin@gmail.com" || user.email === "")  && (
            <Select
              size={"large"}
              onChange={handleSelectChange}
              allowClear
              showSearch
              filterOption={(input, option: any) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >=
                0
              }
              placeholder={"Search Product"}
              className="Asset_selecter"
              style={{ width: "220px", marginRight: "10px" }}
            >
               {sort
           ?.filter(
             (emp: any) =>
               emp.mst_category &&
               emp.mst_category.shop &&
               (selectedOrgValue
                 ? emp.mst_category.shop.shop_name === selectedOrgValue
                 : true)
           )
           .map((emp: any, index: any) => (
             <Select.Option value={emp.name} key={index}>
               {emp?.name}
             </Select.Option>
           ))}
       </Select>
          )} */}
            <Select
              size={"large"}
              onChange={handleSelectChange}
              allowClear
              showSearch
              filterOption={(input, option: any) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >=
                0
              }
              placeholder={"Search Product"}
              className="Asset_selecter"
              style={{ width: "220px", marginRight: "10px" }}
            >
               {sort
           ?.filter(
             (emp: any) =>
               emp.mst_category &&
               emp.mst_category.shop &&
               (selectedOrgValue
                 ? emp.mst_category.shop.shop_name === selectedOrgValue
                 : true)
           )
           .map((emp: any, index: any) => (
             <Select.Option value={emp.name} key={index}>
               {emp?.name}
             </Select.Option>
           ))}
       </Select>
          {
            check_button_permission("Products", "create")
              ?
              <Button className="assets_head-create"
                onClick={() => setOpen("Create")}
              >Add Product</Button>
              : <></>
          }
         
        </div>
{/*       
        {user.email === "admin@gmail.com" ||user.email === "" ? (
          <Table
            columns={filteredColumns(columns, "Payroll")}
            dataSource={search1(product)}
            pagination={{ pageSize: 10 }}
            className="assets_table"
          />
        ) : (
          <Table
            columns={filteredColumns(columns, "Payroll")}
            dataSource={search_user(product)}
            pagination={{ pageSize: 10 }}
            className="assets_table"
          />
        )} */}
         <Table
            columns={filteredColumns(columns, "Payroll")}
            dataSource={search1(product)}
            pagination={{ pageSize: 10 }}
            className="assets_table"
          />

        <Drawer title={`${open} Product `} width={1200} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}>
          {
            open == "Edit" ? (<CreateProduct ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
          }
          {
            open == "Create" ? (<CreateProduct ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
          }
        </Drawer>

      </div>
      <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{ display: "flex", justifyContent: "center" }}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
    </CRMnav>
  )
}

export default Products