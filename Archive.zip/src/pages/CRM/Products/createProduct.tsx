//E:\employee_details\employee-details\src\pages\CRM\Products\createProduct.tsx

import React, { useRef, useEffect, useState, useMemo } from "react";
import JsBarcode from 'jsbarcode';


import {
  Form,
  Modal,
  Input,
  Button,
  Popconfirm,
  Select,
  Space,
  Checkbox,
  Upload,
  InputNumber,
  Dropdown,
  Col,
  Row,
  Menu,
  message,
  Table,
  Collapse,
  Radio,
} from "antd";
import {
  GET_PRODUCT,
  GET_SUB_CATEGORY,
  GET_CATEGORY,
  GET_SERVICE_ATTRIBUTES,
  GET_ATTRIBUTEID,
  GET_PRODUCT_BY_ID,
  CHECK_ALPHACODE,
  CHECK_PRODUCT_BY_CODE
} from "../../../helpers/queries";
import { useApolloClient, useLazyQuery, useMutation, useQuery } from "@apollo/client";
import { CREATE_PRODUCT, UPDATE_PRODUCT,GENERATE_BARCODE  } from "../../../helpers/mutation";
import {
  ExclamationCircleOutlined,
  DeleteOutlined,
  MinusCircleOutlined,
  PlusOutlined,
  RightOutlined,
} from "@ant-design/icons";
import UploadOutlined from "@ant-design/icons/UploadOutlined";
import { RichTextEditor } from "../../../components/ritchTextBox";
import { GetColorName } from "hex-color-to-color-name";
import colorNameList from "color-name-list";
import html2canvas from "html2canvas";


interface Attribute {
  id: string;
  name: string;
  options: string[];
}
interface TransformedAttribute {
  [key: string]: string;
}
interface Props {
  updatedTransformedData: any[];
}
type TransformedKeyValue = {
  keys: string;
  values: string[] | { [hexColor: string]: string }[];
};
interface FormData {
  price: string;
  stock: string;
 
  images: string | string[]; // Allow images to be either a string or an array of strings
}

interface Category {
  id: string;
  category: string;
  shop_id: string; // Define shop_id here
}

interface EditDrawProps {
  existingImages: string[]; // Ensure this is the correct type
}
const createEmp: React.FC<any> = ({
  ModalClose,
  editdraw,
  props,
  showModal,
}) => {
  const [form] = Form.useForm();
  const formRef = useRef(null);
  const [user, setUser] = useState([]);
  const [attribute, setAttribtes] = useState([]);
  const [subcat, setSub] = useState([]);
  const [category, setCategory] = useState<Category[]>([]); // Explicitly type the category array

  const { Dragger } = Upload;
  const [loadingMP, setLoading] = useState(false);
  const [showDragger, setShowDragger] = useState(false);
  const [initialLogo, setInitialLogo] = useState<string[]>([]);
  const [isSubCategoryDisabled, setIsSubCategoryDisabled] = useState(true);
  const [selectedAttributes, setSelectedAttributes] = useState<{
    [key: string]: string;
  }>({});
  const [selectedCategoryId, setSelectedCategoryId] = useState("");
  const [selectedShopId, setSelectedShopId] = useState<string | null>(null);
  // State to store array of combined data
  const [tempFormData, setTempFormData] = useState<{
    [key: number]: { price?: string; stock?: string; images?: string;productCode?: string };
  }>({});
  const [editedAttributes, setEditedAttributes] = useState<{
    [key: number]: { [attributeName: string]: string };
  }>({});
 
  const [combinedDataArray, setCombinedDataArray] = useState<any[]>([]);
  const [combinedData, setCombinedData] = useState({});
  const [transformedData, setTransformedData] = useState<
    TransformedAttribute[]
  >([]);
  const [transformedKeyValueData, setTransformedKeyValueData] = useState<any>(
    []
  );

  const [editorValue, setEditorValue] = useState<string>("");
  const [isCreating, setIsCreating] = useState(false);
  const [missingAttributes, setMissingAttributes] = useState<string[]>([]);

  const [createProduct, { data: contactDataAddress }] = useMutation(
    CREATE_PRODUCT,
    { errorPolicy: "all" }
  );
  const [generateBarcode, { data: BarcodeGenerator }] = useMutation(
    GENERATE_BARCODE,
    { errorPolicy: "all" }
  );
  const [updateProduct, { data: updateDataAddress }] = useMutation(
    UPDATE_PRODUCT,
    { errorPolicy: "all" }
  );
  const { data: dataAttri, refetch: refetAttri } = useQuery(
    GET_SERVICE_ATTRIBUTES,
    { variables: {} }
  );
  const [urlList, setUrlList] = useState<string[]>([]);
  const [modalImageOpen, setModalImageOpen] = useState<boolean>(false);
  const [modalAttriOpen, setModalAttriOpen] = useState<boolean>(false);
  const [modalImage, setModalImage] = useState<any>(null);
  const [deletedImageIndex, setDeletedImageIndex] = useState<number>(-1);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    price: "",
    stock: "",
    images: "", // Initially an empty string
   
  });
  const [checkProductByCode, { data, loading, error }] = useLazyQuery(CHECK_PRODUCT_BY_CODE);
  const [subName, setSubName] = useState('');
  const [selectedSubCategory, setSelectedSubCategory] = useState(subName); // Manage selected subcategory
  const [selectedSubCategoryId, setSelectedSubCategoryId] = useState(''); 
  
console.log(subName,"subname");
console.log(selectedSubCategory,"selectedSubCategory");
const handleSubCategoryChange = (subName: string, subId: string) => {
  setSubName(subName); // Update the selected subcategory name
  setSelectedSubCategory(subName); // Update the selected subcategory name
  setSelectedSubCategoryId(subId); // Update the selected subcategory ID
  console.log("Selected Subcategory Name:", subName);
  console.log("Selected Subcategory ID:", subId);
};



// Handle when the product code changes
const handleProductCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  const productCode = e.target.value;

  // Only check if there's a value entered
  if (productCode) {
    checkProductByCode({
      variables: { code: productCode },
      onCompleted: (result) => {
        if (result.mst_product.length > 0) {
          setIsModalVisible(true);
        }
      },
    });
  }
};

  const handleModalClose = () => {
    setIsModalVisible(false);
  };
  useEffect(() => {
    if (dataAttri) {
      const updatedcolor = dataAttri?.mst_attributes;
      console.log(dataAttri, "dataAttri in editdraw");
      console.log(updatedcolor, "updatedcolor in dataAtrri line");

      if (updatedcolor) {
        // Transform color attribute to match other options format
        const attributes = updatedcolor.map((attr: any) => {
          if (attr.name === "color") {
            return {
              ...attr,
              options: attr.options.map(
                (option: any) => Object.keys(option)[0]
              ),
            };
          }
          return attr;
        });

        console.log(attributes, "console in transformedAttributes");
        setAttribtes(attributes);
      }
    }
    console.log(dataAttri, "data Attri in editdraw");
  }, [dataAttri]);

  console.log(dataAttri, "dataAttri after useEffect");
  const handleEditorChange = (value: string) => {
    setEditorValue(value);
  };
  const ImageUploaderProp: any = {
    name: "file",
    multiple: true,
    action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
    onChange(info: any) {
      const { status } = info.file;
      if (status !== "uploading") {
      }
      if (status === "done") {
        message.success(`${info.file.name} file uploaded successfully.`);
      } else if (status === "error") {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
  };

  const ImageUploaderattributeProp: any = {
    name: "file",
    multiple: true,
    action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
    onChange(info: any) {
      const { status } = info.file;
      if (status !== "uploading") {
      }
      if (status === "done") {
        message.success(`${info.file.name} file uploaded successfully.`);
      } else if (status === "error") {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
  };

  const uploadImages = async (options: any) => {
    const { onSuccess, onError, file } = options;
    try {
      setLoading(true);
      const data = new FormData();
      data.append("upload_preset", "Employee");
      data.append("file", file);
      data.append("cloud_name", "dgcgmcaxb");
  
      fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
        method: "post",
        body: data,
      })
        .then((resp) => resp.json())
        .then((data) => {
          console.log(setUrlList,"setUrlist")
          setUrlList((prevUrlList) => {
            const newUrlList = [...prevUrlList, data.url];
            console.log("Current URL List after adding new image:", newUrlList); // Log the updated URL list
            return newUrlList;
          });
          setLoading(false);
        })
        .catch((err) => {
          setLoading(false);
        });
      onSuccess("Ok");
    } catch (err) {
      const error = new Error("Some error");
      onError({ err });
    }
  };
  
  const uploadImageattributes = async (options: any) => {
    const { onSuccess, onError, file } = options;
    try {
      setLoading(true);
      const data = new FormData();
      data.append("upload_preset", "Employee");
      data.append("file", file);
      data.append("cloud_name", "dgcgmcaxb");

      const response = await fetch(
        "https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload",
        {
          method: "POST",
          body: data,
        }
      );
      if (!response.ok) {
        throw new Error("Failed to upload image");
      }
      const responseData = await response.json();
      const imageUrl = responseData.url;

      setFormData((prevFormData) => {
        const updatedImages =
          typeof prevFormData.images === "string" && prevFormData.images
            ? [prevFormData.images, imageUrl]
            : [...(prevFormData.images as string[]), imageUrl];

        // Flatten the array to ensure no nested arrays and join into a comma-separated string
        const flattenedImages = updatedImages.flat().join(",");

        console.log("Updated Images:", flattenedImages); // Log the updated images

        return {
          ...prevFormData,
          images: flattenedImages,
        };
      });

      setLoading(false);
      onSuccess("Ok");
    } catch (err) {
      setLoading(false);
      onError(err);
    }
  };

  const handleRemove = async (image: string, newUrl?: string) => {
    // Find the index of the image to be removed
    const indexToRemove = urlList.findIndex((e) => e === image);
    console.log("Index to remove:", indexToRemove);
  
    if (indexToRemove !== -1) {
      // Create a copy of the current URL list
      const updatedUrlList = [...urlList];
  
      // Remove the image at the found index
      updatedUrlList.splice(indexToRemove, 1);
  
      console.log("URL List after deletion:", updatedUrlList);
      console.log("New URL to insert:", newUrl);
      // If there's a new URL to insert, add it at the same index
      if (newUrl) {
        updatedUrlList.splice(indexToRemove, 0, newUrl);
        console.log("URL List after insertion of new URL:", updatedUrlList);
      }
  
      // Update the state with the modified URL list
      setUrlList(updatedUrlList);
console.log("Final URL List after state update:", updatedUrlList);

    } else {
      console.error("Image not found in the list:", image);
    }
  };
  useEffect(() => {
    console.log("urlList updated:", urlList);
  }, [urlList]);
  
  const handleRemoveAttribute = (imageToRemove: string) => {
    setFormData((prevFormData) => {
      let updatedImages: string | string[];

      if (typeof prevFormData.images === "string") {
        // Handle case where images is a single string
        updatedImages =
          prevFormData.images === imageToRemove ? "" : prevFormData.images;
      } else {
        // Handle case where images is an array of strings
        updatedImages = prevFormData.images.filter(
          (image) => image !== imageToRemove
        );
      }

      console.log("Images after removal:", updatedImages); // Log the images after removal

      return {
        ...prevFormData,
        images: updatedImages,
      };
    });
  };

  const handleRemoveAttributeEdit = async (imageUrl: string) => {
    console.log(
      transformedData,
      "transformedData in first handleRemoveAttributeEdit"
    );

    try {
      // Find the item that contains the image URL and replace the URL with null
      const updatedData = transformedData.map((item: any, index: number) => {
        if (item.images === imageUrl) {
          console.log("Key:", "images");
          console.log("Value:", item.images);
          console.log("Index:", index);
          return { ...item, images: "null" };
        }
        return item;
      });
      // Find the index of the item with the deleted image
      const deletedImageIndex = transformedData.findIndex(
        (item) => item.images === imageUrl
      );
      // Update state
      setTransformedData(updatedData);
      setDeletedImageIndex(deletedImageIndex);
      // Clear the image source in the DOM
      const imgElements = document.querySelectorAll(`img[src="${imageUrl}"]`);
      imgElements.forEach((img: any) => {
        img.src = ""; // Clear src attribute
      });

      // Show Dragger for the deleted index only if images value is null
      //  if (updatedData[deletedImageIndex].images === null) {
      //   setShowDragger(true);
      // } else {
      //   setShowDragger(false); // Hide Dragger if images value is not null
      // }

      console.log("Deleted Image URL:", imageUrl);
      console.log("Updated Data:", updatedData);

      message.success("Image deleted successfully.");
      setShowDragger(true);
    } catch (error) {
      console.error("Error deleting image:", error);
      message.error("Failed to delete image.");
    }
  };

  const uploadImageattributesEdit = async (options: any) => {
    const { onSuccess, onError, file, index: uploadingImageIndex } = options;
    try {
      setLoading(true);
      const data = new FormData();
      data.append("upload_preset", "Employee");
      data.append("file", file);
      data.append("cloud_name", "dgcgmcaxb");

      console.log("Index of image being uploaded:", uploadingImageIndex); // Log the index of the image being uploaded

      const response = await fetch(
        "https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload",
        {
          method: "POST",
          body: data,
        }
      );
      if (!response.ok) {
        throw new Error("Failed to upload image");
      }
      const responseData = await response.json();
      const imageUrl = responseData.url;

      console.log("Updated Images:", imageUrl); // Log the updated images

      // Update transformedData with the new imageUrl
      const updatedData = transformedData.map((item: any, index: number) => {
        if (index === uploadingImageIndex) {
          return { ...item, images: imageUrl };
        }
        return item;
      });

      // Update state with the updatedData
      setTransformedData(updatedData);

      setLoading(false);
      onSuccess("Ok");
    } catch (err) {
      setLoading(false);
      onError(err);
    }
  };

  const handleBeforeUpload = (file: any) => {
    const fileSizeInMB = file.size / 1024 / 1024; // Convert bytes to megabytes
    const maxFileSizeInMB = 2;
  
    if (fileSizeInMB > maxFileSizeInMB) {
      message.error(`File size must be within ${maxFileSizeInMB}MB!`);
      return false;
    }
  
    // Resize image before upload
    const resizeImage = (imageFile: File) => {
      return new Promise<File>((resolve, reject) => {
        const img = new Image();
        const reader = new FileReader();
        
        reader.onload = () => {
          img.src = reader.result as string;
        };
        
        reader.onerror = (err) => reject(err);
        
        img.onload = () => {
          // Log the original image width and height
          console.log('Original Image Dimensions:', img.width, img.height);
  
          // Set the target height and calculate the new width to maintain aspect ratio
          const targetHeight = 428;
          const targetWidth = (img.width / img.height) * targetHeight;
  
          // Log the new calculated width and height
          console.log('Calculated Image Dimensions for resizing:', targetWidth, targetHeight);
          
          // Create a canvas element to resize the image
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          if (!ctx) {
            reject("Failed to get canvas context");
            return;
          }
          
          canvas.width = targetWidth;
          canvas.height = targetHeight;
          ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
          
          // Convert the canvas back to a file
          canvas.toBlob((blob) => {
            if (blob) {
              const resizedFile = new File([blob], imageFile.name, { type: imageFile.type });
              resolve(resizedFile);
            } else {
              reject("Failed to resize image");
            }
          }, imageFile.type);
        };
        
        reader.readAsDataURL(imageFile);
      });
    };
  
    // Resize the image before uploading
    const resizePromise = resizeImage(file);
    return resizePromise.then((resizedFile) => {
      // Now you can upload the resized file (resizedFile)
      return true; // Proceed with the upload after resizing
    }).catch((error) => {
      message.error("Image resizing failed");
      return false;
    });
  };
  
  
  const handleBeforeUploadAttribute = (file: any) => {
    const fileSizeInMB = file.size / 1024 / 1024; // Convert bytes to megabytes
    const maxFileSizeInMB = 2;
    if (fileSizeInMB > maxFileSizeInMB) {
      message.error(`File size must be within ${maxFileSizeInMB}MB!`);
      return false;
    }
    return true;
  };

  const modalImageView = (LinkBox: any) => {
    setModalImageOpen(!modalImageOpen);
    setModalImage(LinkBox);
  };
  const modalImageViewAttribute = (imageLink: string) => {
    // Check if the image to be deleted is currently displayed in the modal
    if (modalImage === imageLink) {
      // Clear the modal image if it matches the image to be deleted
      setModalImage("");
      setModalAttriOpen(false); // Close the modal
    } else {
      // Otherwise, just open the modal with the current image
      setModalImage(imageLink);
      setModalAttriOpen(true);
    }
  };

  const modalImageClose = () => {
    setModalImageOpen(!modalImageOpen);
    setModalImage(null);
  };
  const imageList =
    typeof formData.images === "string" ? [formData.images] : formData.images;

  const handleAttributeChange = (attributeName: string, option: string) => {
    console.log(attributeName,"attributeName in handleAttributeChange ")
    setSelectedAttributes((prevSelectedAttributes) => {
      let updatedAttributes = { ...prevSelectedAttributes };

      if (attributeName === "color") {
        const hexCode = option.replace(/^0xff/, "");
        const colorName = GetColorName(hexCode);
        console.log(`Hex code: ${hexCode}, Color name: ${colorName}`);
        updatedAttributes[attributeName] = colorName;
      } else {
        updatedAttributes[attributeName] = option;
      }
        

      console.log(updatedAttributes, "updatedAttributes");
      return updatedAttributes;
    });
  };

  const handleAttributeEdit = (
    index: number,
    attributeName: string,
    option: any
  ) => {
    setEditedAttributes((prevSelectedAttributes) => ({
      ...prevSelectedAttributes,
      [index]: {
        ...prevSelectedAttributes[index],
        [attributeName]: option,
      },
    }));
    console.log("editedattributes in handleAttributeEdit", setEditedAttributes);
  };
  const handleDelete = (index: number) => {
    const updatedTransformedData = transformedData.filter(
      (_, i) => i !== index
    );
    setTransformedData(updatedTransformedData);

    const transformedToKeysValues = Object.keys(
      updatedTransformedData[0] || {}
    ).map((key) => ({
      keys: key,
      values: updatedTransformedData.map((item) => item[key]).filter(Boolean),
    }));

    setTransformedKeyValueData(transformedToKeysValues);
    console.log("Updated Transformed Data:", updatedTransformedData);
    console.log(
      "Transformed to Keys and Values in delete:",
      transformedToKeysValues
    );
    message.success(`Attributes Deleted sucessfully.`);
  };

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      price: value, // Update price field in formData
    }));
    console.log("Price:", value); // Log the typed value
  };

  // Function to handle stock change
  const handleStockChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      stock: value, // Update stock field in formData
    }));
    console.log("Stock:", value); // Log the typed value
  };

  const handleProductChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
  
    // Update formData with the current product code input
    setFormData((prevData) => ({
      ...prevData,
      productCode: value,
    }));
  
    console.log("productCode:", value); // Log the typed value
  
    // Only check for product code if a value is entered
    if (value) {
      checkProductByCode({
        variables: { code: value },
        onCompleted: (result) => {
          if (result.mst_product.length > 0) {
            setIsModalVisible(true);
          }
        },
        // onError: (error) => {
        //   console.error("Error checking product code:", error);
        //   message.error("An error occurred while checking the product code.");
        // },
      });
    }
  };
  

  const handlePriceEdit =
    (index: number) => (e: React.ChangeEvent<HTMLInputElement>) => {
      const { value } = e.target;
      setTempFormData((prevData) => ({
        ...prevData,
        [index]: { ...prevData[index], price: value },
      }));
      console.log("Price:", value);
    };

  const handleStockEdit =
    (index: number) => (e: React.ChangeEvent<HTMLInputElement>) => {
      const { value } = e.target;
      setTempFormData((prevData) => ({
        ...prevData,
        [index]: { ...prevData[index], stock: value },
      }));
      console.log("Stock:", value);
    };

    const handleProductcodeEdit =
    (index: number) => (e: React.ChangeEvent<HTMLInputElement>) => {
      const { value } = e.target;
      setTempFormData((prevData) => ({
        ...prevData,
        [index]: { ...prevData[index], productCode: value },
      }));
      console.log("productCode:", value);
      if (value) {
        checkProductByCode({
          variables: { code: value },
          onCompleted: (result) => {
            if (result.mst_product.length > 0) {
              setIsModalVisible(true);
            }
          },
          // onError: (error) => {
          //   console.error("Error checking product code:", error);
          //   message.error("An error occurred while checking the product code.");
          // },
        });
      }
    };


    const handleEditSave = async () => {
      const updatedTransformedData = await Promise.all(transformedData.map(async (item, index) => {
        const updatedItem: TransformedAttribute = { ...item, price: item.price };
        const tempData = tempFormData[index] || {};
    
        if (tempData.price !== undefined) updatedItem.price = tempData.price;
        if (tempData.stock !== undefined) updatedItem.stock = tempData.stock;
        if (tempData.images !== undefined) updatedItem.images = tempData.images;
        if (tempData.productCode !== undefined) updatedItem.productCode = tempData.productCode;
    
        if (editedAttributes[index]) {
          Object.entries(editedAttributes[index]).forEach(([key, value]) => {
            updatedItem[key] = value;
            if (key === "color") {
              console.log("Color key:", key);
              console.log("Color value:", value);
            }
          });
        }
    
    
        // Log and set missing attributes
        const missingAttributes = attribute.filter((attr: any) => !updatedItem.hasOwnProperty(attr.name));
        if (missingAttributes.length > 0) {
          console.log("Missing attributes:", missingAttributes.map((attr: any) => attr.name));
        }
        setMissingAttributes(missingAttributes.map((attr: any) => attr.name));
    
        return updatedItem;
      }));
    
      // Transform the data to keys and values format
      const transformedToKeysValues = Object.keys(updatedTransformedData[0]).map(
        (key) => {
          const values = updatedTransformedData.map((item) => item[key]);
    
          if (key === "color") {
            const colorValues = values.map((colorName) => {
              if (typeof colorName === "object") {
                return colorName; // If value is already an object, return it unchanged
              } else if (typeof colorName === "string") {
                // Convert color name to hex code
                const hexCode = getColorHexCode(colorName);
                return hexCode ? { [hexCode]: colorName } : {};
              } else {
                return {}; // Return empty object if value is neither object nor string
              }
            });
    
            return {
              keys: key,
              values: colorValues.filter(
                (item) => Object.keys(item).length !== 0
              ), // Remove empty objects
            };
          }
    
          else if (key === "images") {
            const imageValues: any = values;
            const allImagesNull = imageValues[key]?.every((value: any) => value === "null");
            return {
              keys: key,
              values: allImagesNull ? [] : values,
            };
          }
    
          else {
            return {
              keys: key,
              values: values,
            };
          }
        }
      );
    
      console.log(
        transformedToKeysValues,
        "transformedToKeysValues in transformed keyvalue data"
      );
    
      setTransformedData(updatedTransformedData);
      const stockValues = updatedTransformedData.map((item) => item.stock);
      const ProductcodeValues = updatedTransformedData.map((item) => item.Productcode);
      console.log("Stock Values:", stockValues);
      console.log("Productcode Values:",ProductcodeValues );
      setTransformedKeyValueData(transformedToKeysValues);
      setTempFormData({}); // Reset temp form data after save
      setSelectedAttributes({}); // Reset selected attributes after save
      message.success(`Attributes Saved successfully.`);
    };
    

  const renderSelectedAttributes = () => {
    return (
      <Row gutter={16} style={{ marginTop: 20 }}>
        {/* Input fields for price, stock, and images */}
        <Col>
          <Input
            value={formData.price}
            onChange={handlePriceChange}
            placeholder="Price"
          />
        </Col>
        <Col>
          <Input
            value={formData.stock}
            onChange={handleStockChange}
            placeholder="Stock"
          />
        </Col>

        <Col>
        {/* <Input
          value={formData.productCode}
          onChange={handleProductChange} // Trigger query on input change
          placeholder="Product Code"
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault(); // Prevent form submission on Enter key
            }
          }}
        /> */}

        </Col>
        
    
        <Col>
          <Form.Item
            className="image_dragger"
            required={false}
            rules={[
              { required: true, message: "Please Upload your Photos / videos" },
            ]}
            label={<p className="create_post_lable">Upload Photos</p>}
          >
            {formData.images.length === 0 ? (
              <Dragger
                {...ImageUploaderattributeProp}
                maxCount={1}
                name="file"
                beforeUpload={handleBeforeUploadAttribute}
                showUploadList={true}
                customRequest={uploadImageattributes}
                className="dragger"
                style={{ width: "100%", border: "2px dashed #7FACD6" }}
              >
                <UploadOutlined className="employee-details_uploade-photo" />
                <p>Drag & drop or Browse</p>
                <p className="ant-upload-text">
                  {/* Photo formats: JPEG, PNG, (maximum image size 2 MB). */}
                </p>
              </Dragger>
            ) : (
              imageList.map((value, index) => {
                const filename = value?.split("/").pop();
                return (
                  <div key={index} className="employee-details_photodelete">
                    <img
                      src={value}
                      alt="profile"
                      width={25}
                      height={25}
                      onClick={() => modalImageViewAttribute(value)}
                    />
                    <p className="employee-details_photodelete-para">
                      {filename} {/* Display filename */}
                    </p>
                    <DeleteOutlined
                      onClick={() => handleRemoveAttribute(value)}
                      className="employee-details_delete_icon"
                    />
                  </div>
                );
              })
            )}
          </Form.Item>
        </Col>

        {/* Render selected attributes as checkboxes */}
        {Object.entries(selectedAttributes).map(([attributeName, option]) => (
          <Col key={attributeName + option}>
            <Checkbox checked={true}>{`${attributeName}: ${option}`}</Checkbox>
          </Col>
        ))}
      </Row>
    );
  };

  const handleSave = () => {
    console.log("Form Data:", formData);
    console.log("Selected Attributes:", selectedAttributes);

    const errorMessages: string[] = [];

    // Error checks for formData
    if (!formData.price) {
      errorMessages.push("Price is required.");
    }
    if (!formData.stock) {
      errorMessages.push("Stock is required.");
    }
    if (formData.images === "") {
      formData.images = "null";
    }

    if (errorMessages.length > 0) {
      message.error(errorMessages.join("\n"));
      return;
    }

    const combinedData = {
      ...formData,
      ...selectedAttributes,

    };

    console.log("Combined Data:", combinedData);

    const missingAttributes = attribute.filter(
      (attr: any) => !combinedData.hasOwnProperty(attr.name)
    );
    if (missingAttributes.length > 0) {
      console.log(
        "Missing attributes:",
        missingAttributes.map((attr: any) => attr.name)
      );
    }

    setCombinedData(combinedData);
    setCombinedDataArray((prevArray) => [...prevArray, combinedData]);

    setFormData({ price: "", stock: "", images: ""});
    setSelectedAttributes({});
    form.resetFields(["attributes"]);

    message.success(`Attributes saved successfully.`);
  };

  const handleAddNewAttributes = () => {
    setIsCreating(true);

    // Compare keys in editdraw?.attributes with names in dataAttri
    if (editdraw?.attributes) {
      const editAttributesKeys = editdraw?.attributes.map(
        (attr: any) => attr.keys
      );
      console.log(editAttributesKeys, "editAttributesKeys in create attribute");

      const dataAttriNames = dataAttri?.mst_attributes.map(
        (attr: any) => attr.name
      );

      // Combine keys from editAttributes and transformedData
      const transformedDataKeys =
        transformedData.length > 0 ? Object.keys(transformedData[0]) : [];

      const combinedKeys = Array.from(
        new Set([...editAttributesKeys, ...transformedDataKeys])
      );

      // Calculate missing attributes
      const missingAttrs = dataAttriNames.filter(
        (name: string) => !combinedKeys.includes(name)
       
      );
      console.log(missingAttrs,"missingAttrs in handleAddNewAttributes")

      if (transformedData.length === 0 && !editdraw?.attributes.length) {
        setMissingAttributes([]);
      } else {
        setMissingAttributes(missingAttrs);
      }

      console.log(missingAttrs, "handleAddNewAttributes in missingAttrs");

      // Log missing attributes
      console.log("Missing Attributes:", missingAttrs);

      // Log key-value pairs of transformedData
      transformedData.forEach((item, index) => {
        console.log(`Transformed Data Item ${index + 1}:`);
        Object.entries(item).forEach(([key, value]) => {
          console.log(`Key: ${key}, Value: ${value}`);
        });
      });
    }
  };

  const handleNewAttributeSave = async () => {
    const errorMessages: string[] = [];

    // Check if price is empty
    // if (!formData.price) {
    //   errorMessages.push("Price is required.");
    // }

    // // Check if stock is empty
    // if (!formData.stock) {
    //   errorMessages.push("Stock is required.");
    // }

    //     // Check if images are empty
    //     // Check if images are empty or null
    //    // Check if images are initially empty and should be set to an empty array
    if (!formData.images || formData.images.length === 0) {
      if (formData.images === null) {
        // If images were initially present and now removed, set to "null"
        formData.images = "null";
      } else {
        // Otherwise, set to an empty array
        formData.images = [];
      }
    }

    // If there are any error messages, show them and prevent saving
    if (errorMessages.length > 0) {
      const errorMessage = errorMessages.join("\n");
      message.error(errorMessage);
      return;
    }
console.log(formData,"formData in handleNewAttributeSave");
console.log(selectedAttributes,"selectedAttributes in handleNewAttributeSave");
   // Generate alphaNumericCode and barcode
  //  const alphaNumericCode = await generateAlphanumericCode();
  //  const barcode = generateBarcodeImage(alphaNumericCode);
 
  //  console.log(alphaNumericCode, "alphaNumericCode in handleNewAttributeSave");
  //  console.log(barcode, "barcode in handleNewAttributeSave");
 
   // Create the updatedTransformedData including the new alphaNumericCode and barcode
   const updatedTransformedData = {
     ...formData,
     ...selectedAttributes,
    //  alphaNumericCode,
    //  barcode,
   };
 
   console.log(updatedTransformedData, "updatedTransformedData in handleNewAttributeSave");
 
    setTransformedData((prevData: any) => {
      const validPrevData = prevData || [];
      return [...validPrevData, updatedTransformedData];
    });

    setIsCreating(false);
    setFormData({ price: "", stock: "", images: "" });
    message.success(`Click Save.`);
  };

  useEffect(() => {
    if (editdraw) {
      let data = JSON.parse(JSON.stringify(editdraw));
      form.setFieldsValue(editdraw);
      setUrlList(editdraw.images ? [editdraw.images] : []);
    }
    console.log(editdraw?.images,"editdrawimages");
    console.log(editdraw?.id);
    console.log(editdraw?.attributes, "editdraw attributes");
    console.log(transformedData, "editdraw attributes transformedData");
  }, [editdraw]);

  // Assuming editdraw.attributes is your original array
  useEffect(() => {
    const data = editdraw?.attributes?.reduce((acc: any, attribute: any) => {
      const { keys, values } = attribute;
      console.log(keys, values, "values in acc useEffect");

      // Check if the values array for images is empty and replace it with ["null"]
      if (keys === "images" && Array.isArray(values) && values.length === 0) {
        acc.forEach((item: any) => {
          if (!item[keys]) {
            item[keys] = "null";
          }
        });
        console.log('values set to ["null"] for key:', keys);
      }

      values?.forEach((value: any, index: any) => {
        if (!acc[index]) {
          acc[index] = {};
        }
        acc[index][keys] = value;
      });

      console.log(acc, "acc");
      return acc;
    }, []);

    console.log("transformedData in acc", data);
    // if(data){
      setTransformedData(data);
    // } else {
    //   setTransformedData([]);
    // }
  }, [editdraw]);

  const {
    error: userError,
    loading: userLoading,
    data: dataUser,
    refetch: refetProduct,
  } = useQuery(GET_PRODUCT, { variables: {} });

  useEffect(() => {
    if (dataUser) {
      let user = dataUser?.mst_product;
      setUser(user);
    }
  }, [dataUser]);

  const { data: dataSub, refetch: refetasset } = useQuery(GET_SUB_CATEGORY, {
    variables: {},
  });

  useEffect(() => {
    if (dataSub) {
      let subcat = dataSub?.mst_sub_category;
      setSub(subcat);
    }
  }, [dataSub]);

  const { data: dataCat, refetch: refetAsstManage } = useQuery(GET_CATEGORY, {
    variables: {},
  });

  useEffect(() => {
    if (dataCat) {
      let category = dataCat?.mst_category;
      setCategory(category);
    }
  }, [dataCat]);
  const getColorHexCode = (colorName: any) => {
    const color = colorNameList.find(
      (c) => c.name.toLowerCase() === colorName.toLowerCase()
    );
    return color ? `0xff${color.hex.replace(/^#/, "").toUpperCase()}` : null;
  };

  const generateBarcodeImage = (alpha_numeric: string): string => {
    const barcodeCanvas = document.createElement('canvas');
    // const formattedProductName = productName.substring(0, 2);
    console.log(alpha_numeric,"alpha_numeric");
  
    JsBarcode(barcodeCanvas, `${alpha_numeric}`, {
      format: "CODE128",
      displayValue: false,
      width: 1, 
      height: 30, 
    });
  
    // Convert canvas to data URL
    return barcodeCanvas.toDataURL();
  };

  const client = useApolloClient();
  
  const checkCodeExists = async (code: string): Promise<boolean> => {
    console.log(`Checking if code exists: ${code}`);
  
    try {
      const { data } = await client.query({
        query: CHECK_ALPHACODE,
      });
  
      console.log(`Query result for code "${code}":`, data);
  
      // Check if the code exists in the alpha_numeric field
      const existsInAlphaNumeric = data.mst_product.some((product: any) =>
        product.alpha_numeric === code
      );
  
      // Check if the code exists in the attributes where keys is 'alphaNumericCode'
      const existsInAttributes = data.mst_product.some((product: any) =>
        product.attributes?.some((attr: any) =>
          attr.keys === 'alphaNumericCode' && attr.values.includes(code)
        )
      );
  
      const exists = existsInAlphaNumeric || existsInAttributes;
      console.log(`Code "${code}" exists: ${exists}`);
      return exists;
    } catch (error) {
      console.error(`Error checking code "${code}":`, error);
      return true; // Return true to prevent using a potentially conflicting code
    }
  };
  
  const generateAlphanumericCode = async (): Promise<string> => {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
  
    do {
      code = '';
      for (let i = 0; i < 3; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        code += characters[randomIndex];
      }
      console.log(`Generated code: ${code}`);
    } while (await checkCodeExists(code)); // Regenerate if the code exists
  
    console.log(`Unique code generated: ${code}`);
    return code;
  };

  useEffect(() => {
    if (editdraw?.images && Array.isArray(editdraw?.images)) {
      setUrlList(editdraw?.images);
    }
  }, [editdraw?.images]);
    
  
  const onFinish = async (values: any) => {
    console.log("shopid",values.shop_id);
    console.log("Submitting selected subcategory ID:", selectedSubCategoryId);
    console.log(values)
    console.log("EditDraw urlList:", urlList);

    
    // handleNewAttributeSave();
      try {
        console.log(combinedDataArray, "combinedDataArray in onFinish");
    
        // Initialize attributes as an empty array if it is null or not an array
        if (!Array.isArray(values.attributes)) {
          values.attributes = [];
        }
    
        // Transform combinedDataArray into the desired format
        const attributesMap: { [key: string]: string[] } = {};
    
       for (const item of combinedDataArray) {
        // // Generate a barcode for each item in the array
        // const barcodeDataUrl = generateBarcodeImage(await generateAlphanumericCode());
        
        
        // item.barcode = barcodeDataUrl; // Add barcode to each item
         // Generate a unique alphanumeric code for each item
         const alphaNumericCode = await generateAlphanumericCode();
         console.log(`Generated code for item: ${alphaNumericCode}`);
         
         // Generate a barcode for each item in the array
         const barcodeDataUrl = generateBarcodeImage(alphaNumericCode);
         
        //  item.barcode = barcodeDataUrl; // Add barcode to each item
        //  item.alphaNumericCode = alphaNumericCode; // Add generated code to each item
  
        // Process other attributes
        for (const key of Object.keys(item)) {
          if (!attributesMap[key]) {
            attributesMap[key] = [];
          }
          attributesMap[key].push(item[key]);
        }
      }
  
      console.log(combinedDataArray, "Updated combinedDataArray with barcodes");
      console.log(attributesMap, "attributesMap");
      console.log(values.stocks, "values.stocks");
    
        Object.keys(attributesMap).forEach((key) => {
          if (key === "color" && Array.isArray(attributesMap[key])) {
            const colorValues = attributesMap[key].map((colorName) => {
              const hexCode = getColorHexCode(colorName);
              return hexCode ? { [hexCode]: colorName } : {};
            });
    
            values.attributes.push({
              keys: key,
              values: colorValues.filter((item) => Object.keys(item).length !== 0), // Remove empty objects
            });
          } else if (key === "images") {
            const imageValues = attributesMap[key];
            const allImagesNull = imageValues.every((value) => value === "null");
    
            values.attributes.push({
              keys: key,
              values: allImagesNull ? [] : imageValues,
            });
          } else {
            values.attributes.push({
              keys: key,
              values: attributesMap[key],
            });
          }
        });
    
        console.log("Formatted Attributes:", values.attributes);
    
        // Convert empty attributes array to null
        if (values.attributes.length === 0) {
          values.attributes = null;
        }

        console.log()
     // Assign `sub_name` instead of ID
     values.sub_category =  selectedSubCategoryId
     // Save `urlList` as an array in `images` field
     values.images = urlList.length > 0 ? urlList : [];  // directly assign the array


     console.log(values.sub_category,"subcategory while create")
        // Additional logic for setting image based on existing code
        values.image = urlList.length > 0 ? urlList[0] : initialLogo[0];
    
        // Logic to determine the value of show_stock
        if (values.stocks > 0) {
          values.show_stock = true;
        } else if (values.stocks === null || values.stocks === undefined) {
          const stockAttribute = values.attributes?.find(
            (attr: any) => attr.keys === "stock"
          );
          if (
            stockAttribute &&
            stockAttribute.values.some((val: any) => parseInt(val) > 0)
          ) {
            values.show_stock = true;
          } else {
            values.show_stock = false;
          }
        } else {
          values.show_stock = false;
        }
    
        // Handle default values for price and stocks
        values.price = values.price || null;
        values.offered_price= values.offered_price || null;
        values.stocks = values.stocks || null;
        values.product_code = values.product_code || null;
        values.selling_price
        = values.selling_price
        || null;
  
       
       // Generate a unique alphanumeric code for the product
       const alphaNumericCode = await generateAlphanumericCode();
      values.alpha_numeric = alphaNumericCode;
      console.log(alphaNumericCode, "alphaNumericCode");
    
      values.shop_id = selectedShopId;
      console.log(values, "Values before mutation editdraw");
      console.log("Initial urlList:", urlList);

   
  
      console.log("Updated images:", values.images);
      // Update images in values with editdraw.images or urlList if necessary
  values.images = urlList

console.log("Values to be saved:", values);
        if (editdraw) {
          console.log(values, "Values before mutation");
          console.log("Edit Mode",editdraw.id);
          console.log("Editdraw.images",editdraw.images);
          console.log("editdraw.category:", editdraw.category);
          console.log("editdraw.sub_category:", editdraw.sub_category);
          // Update logic for existing product
          values.id = editdraw?.id;
          values.shop_id = editdraw?.shop?.id 
 

  console.log("Updated images:", values.images);
          // values = editdraw?.shop_id;
          // values.shop_id = selectedShopId;
          // values.shop_id = editdraw?.shop_id || selectedShopId;
          console.log(values.shop_id,"values.shop_id");
         
          // Update attributes for editdraw
          values.attributes = transformedKeyValueData;
          if (values.attributes.length === 0) {
            values.attributes = null;
          }
          console.log("Final Values before Update Mutation:", values);
          console.log("transformedKeyValueData in editdraw", transformedKeyValueData);
          console.log("values in editdraw", values);
          console.log("values in subcat",values.sub_category);

          await updateProduct({ variables: { ...values, images: values.images } });

          showModal("Updated");
          refetProduct();
          refetasset();
          refetAsstManage();
          ModalClose(null);
        } else {
          // Create new product logic
          const response = await createProduct({ variables: values });
          console.log('Create Product Response:', response);
          const returning = response.data?.insert_mst_product?.returning;
    
          if (!returning || returning.length === 0) {
            throw new Error('No products returned from mutation.');
          }
    
          const createdProductId = returning[0].id;
        const createdProductName = returning[0].name;
        const alphanumeric =returning[0].alpha_numeric
  
        // Generate barcode image
        const barcodeImage = generateBarcodeImage(alphanumeric);
        console.log(barcodeImage, "barcodeImage");
  
        // Call barcode generation mutation
        await generateBarcode({
          variables: {
            id: createdProductId,
            bar_code: barcodeImage,
          },
        })
            .then(response => {
              if (response.data && response.data.generateBarcode) {
                console.log("Barcode generated successfully:", response.data.generateBarcode);
              } else {
                console.error("No data returned from barcode generation mutation:", response);
              }
            })
            .catch(error => {
              console.error("Error generating barcode:", error);
            });
    
          console.log("Barcode generated successfully");
          showModal("Created");
          refetProduct();
          refetAsstManage();
          refetasset();
          ModalClose(null);
        }
      } catch (error) {
        console.error('Error in onFinish:', error);
      }
    };
  
  
  
  
  
  
  const onFinishFailed = (errorInfo: any) => {};

  const handleCategoryChange = (value: string) => {
    setIsSubCategoryDisabled(false);
    setSelectedCategoryId(value);
    console.log(setSelectedCategoryId,"setSelectedCategoryId");
  
    const selectedCategory = category.find((cat: Category) => cat.id === value);
    console.log(selectedCategory,"selectedCategory");
    if (selectedCategory) {
      setSelectedShopId(selectedCategory.shop_id);  // Save shop_id to state
    }
  };
  // Call the function inside useEffect
useEffect(() => {
  handleCategoryChange
}, [selectedCategoryId, category]); // Dependencies: selectedCategoryId and category


  const subcategories = dataSub?.mst_sub_category ?? []; // Use the correct property name 'category'
  console.log(subcategories,"subcategories")
  // const attributes = dataAttri?.mst_attributes ?? []; // Use the correct property name 'category'
  useEffect(() => {
    if (dataAttri) {
      const updatedcolor = dataAttri?.mst_attributes;

      if (updatedcolor) {
        // Transform color attribute to match other options format
        const attributes = updatedcolor.map((attr: any) => {
          if (attr.name === "color") {
            return {
              ...attr,
              options: attr.options.map(
                (option: any) => Object.keys(option)[0]
              ),
            };
          }
          return attr;
        });

        console.log(attributes, "console in transformedAttributes");
        setAttribtes(attributes);
      }
    }
    console.log(dataAttri, "dataAttri in editdraw");
  }, [dataAttri]);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);


 
  const { error: queryError, loading: queryLoading, data: queryData } = useQuery(GET_PRODUCT_BY_ID, {
    variables: { id: editdraw?.id },
   
  });
  console.log(editdraw,"editdrawid")
  console.log(editdraw?.shop.id, "shop_id");


  
  useEffect(() => {
    if (queryData && queryData.mst_product && queryData.mst_product.length > 0) {
      const product = queryData.mst_product[0];

      const fetchedSubName = product?.mst_sub_category?.sub_name;
      const fetchedSubId = product?.mst_sub_category?.id;
  
      console.log("Fetched Subcategory Name:", fetchedSubName);
      console.log("Fetched Subcategory ID:", fetchedSubId);
  
      if (fetchedSubName && fetchedSubId) {
        setSubName(fetchedSubName); // Set the fetched subcategory name
        setSelectedSubCategory(fetchedSubName); // Set the selected subcategory
        setSelectedSubCategoryId(fetchedSubId); // Set the fetched subcategory ID
      }
      // Check if price is null before proceeding
      if (product.price === null) {
        console.error('Price is null, barcode will not be displayed');
        return; // Exit the useEffect if price is null
      }
  
      if (product.bar_code && canvasRef.current) {
        console.log(product.bar_code, "product.bar_code");
  
        // Create an image element to load the base64 data URL
        const img = new window.Image(); // Ensure to use the window.Image constructor
  
        img.onload = () => {
          const canvas = canvasRef.current;
          const ctx = canvas?.getContext('2d');
          if (ctx && canvas) {
            // Clear any previous content
            ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  // // Additional text to be drawn on top of the image
  const topText = `Code: ${product.alpha_numeric}`; // Custom text for the top
  const topX = 10;  // Starting 10px from the left
  const topY =  8;  // Position
     ctx.fillText(topText, topX, topY);
            // Draw the image
            ctx.drawImage(img, 0, 0);
  
            // Draw text below the image
            ctx.font = '10px Arial'; // Set font size and family
            ctx.fillStyle = 'black'; // Set text color
            ctx.textAlign = 'left';  // Align text to the left
  
            // Use the first 5 characters of the product name
            const shortName = product.name.substring(0, 5);
            console.log(product.price, "product.price");
            const text = `${shortName} Rs.${product.price}`;
            const x = 10;  // Start from 10px from the left
            const y = img.height + -2; // Position the text with more space below the image
  
            // Draw the text
            ctx.fillText(text, x, y);
            ctx.fillText(topText, topX, topY);
            // Convert canvas to a data URL
            const dataURL = canvas.toDataURL('image/png');
  
            // Create a link element for downloading the barcode image
            const link = document.createElement('a');
            link.href = dataURL; // Set the href to the canvas data URL
            link.download = `Product-${product.name}-barcode.png`; // Set the file name for download
            link.textContent = "Download Barcode";
  
            // Append the link to the designated container
            const linkContainer = document.getElementById('link-container');
            if (linkContainer) {
              linkContainer.innerHTML = ''; // Clear previous link if any
              linkContainer.appendChild(link); // Append the new link
            }
  
            console.log('Canvas data URL:', dataURL);
          } else {
            console.error('Canvas context is null');
          }
        };
  
        img.onerror = (error) => {
          console.error('Error loading image:', error);
        };
  
        img.src = product.bar_code; // Set the source to the base64 image data URL
      } else {
        console.error('Canvas reference is null or product.bar_code is missing');
      }
    }
  }, [queryData]);
  
  
  
  

  const handleTrendingChange = (isChecked: boolean) => {};
  const handleTopChange = (isChecked: boolean) => {};
  const handleFeaturedChange = (isChecked: boolean) => {};
  const handleStatusChange = (isChecked: boolean) => {};
  const { Panel } = Collapse;
  console.log(combinedDataArray, "combinedDataArray");
  return (
    <>
    
    <div>
      
      <Form
        name="basic"
        layout="vertical"
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            e.preventDefault(); // Prevent form submission on Enter globally
          }
        }}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        form={form}
        ref={formRef}
        className="assets_form"
      >
        <Form.Item
          label="Title"
          name="name"
          required={false}
          rules={[{ required: true, message: "Please enter product name!" }]}
          className="attendance_form_item"
        >
          <Input className="employee-details_form_item-input" />
        </Form.Item>
        
        <Row gutter={16}>
          <Col span={8}>
            <Form.Item
              label={<span className="purchased-label">Purchased</span>}
              name="price"
              required={false}
              rules={[{ required: false, message: "Please enter price" }]}
              className="attendance_form_item"
            >
              <Input className="employee-details_form_item-input" />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              label={<span className="selling-label">Selling</span>}
              name="selling_price"
              required={false}
              rules={[{ required: false, message: "Please enter price" }]}
              className="attendance_form_item"
            >
              <Input className="employee-details_form_item-input" />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              label={<span className="offered-label">Offered</span>}
              name="offered_price"
              required={false}
              rules={[{ required: false, message: "Please enter price" }]}
              className="attendance_form_item"
            >
              <Input className="employee-details_form_item-input" />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={16}>
          <Col span={8}>
            <Form.Item
              label="Category"
              name="category"
              required={false}
              rules={[{ required: true, message: "Please select type" }]}
              className="attendance_form_item"
            >
              <Select
                className="attendance_form_item-input"
                allowClear
                onChange={(value) => {
                  handleCategoryChange(value);

                  form.setFieldsValue({ sub_category: undefined });
                }}
              >
                {category.map((val: any) => (
                  <Select.Option value={val.id} key={val.id}>
                    {val?.category}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>
          </Col>
          <Col span={8}>
          <Form.Item
  label="Sub Category"
  // name="sub_category"
  required={false}
  rules={[{ required: false, message: "Please select type" }]}
  className="attendance_form_item"
>
<Select
  className="attendance_form_item-input"
  allowClear
  value={selectedSubCategory}
  onChange={(value, option: any) => {
    const selectedName = option.children; // Access the displayed name
    const selectedId = option.key; // Access the `key` for the subcategory ID
    handleSubCategoryChange(selectedName, selectedId);
  }}
>
  {subcategories
    .filter((subcat: { category: string }) => subcat.category === selectedCategoryId)
    .map((val: any) => (
      <Select.Option value={val.sub_name} key={val.id}>
        {val?.sub_name}
      </Select.Option>
    ))}
</Select>

</Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              label="Stocks"
              name="stocks"
              required={false}
              rules={[{ required: false, message: "Please enter price" }]}
              className="attendance_form_item"
            >
              <Input className="employee-details_form_item-input" />
            </Form.Item>
          </Col>
        </Row>
       
        {/* <div>
      <Row gutter={16} align="middle" justify="start">
        <Col>
          <p>Status</p>
        </Col>
        <Col>
          <Form.Item
            name="status"
            required={false}
            rules={[{ required: false, message: "Please select type" }]}
            valuePropName="checked"
            style={{ margin: 0 }} // Reset margin
          >
            <Checkbox onChange={(e) => handleStatusChange(e.target.checked)}>
              Active
            </Checkbox>
          </Form.Item>
        </Col>
        <Row>
          <div style={{  alignItems: 'top' }}>
            <div id="link-container"></div>
            <canvas ref={canvasRef} style={{position: 'relative' }} />
          </div>
        </Row>
      </Row>
    </div>
     */}
      
       
        <p>Product Collections</p>
        <Row gutter={16}>
          <Col span={8}>
            <Form.Item
              name="featured_products"
              required={false}
              rules={[{ required: false, message: "Please select type" }]}
              className="attendance_form_item"
              valuePropName="checked"
            >
              <Checkbox
                onChange={(e) => handleFeaturedChange(e.target.checked)}
              >
                Featured products
              </Checkbox>
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="trending_products"
              required={false}
              rules={[{ required: false, message: "Please select type" }]}
              className="attendance_form_item"
              valuePropName="checked"
            >
              <Checkbox
                onChange={(e) => handleTrendingChange(e.target.checked)}
              >
                Trending products
              </Checkbox>
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="top_selling"
              required={false}
              rules={[{ required: false, message: "Please select type" }]}
              className="attendance_form_item"
              valuePropName="checked"
            >
              <Checkbox onChange={(e) => handleTopChange(e.target.checked)}>
                Top selling products
              </Checkbox>
            </Form.Item>
          </Col>
        </Row>

        
        <Row gutter={16}>
          <Col span={8}>
          {/* <Form.Item
  label="Product code"
  name="product_code"
  required={false}
  className="attendance_form_item"
>
  <Input 
    className="employee-details_form_item-input" 
    onKeyDown={(e) => {
      if (e.key === 'Enter') {
        e.preventDefault(); // Prevent form submission on Enter key
      }
    }} 
    onChange={handleProductCodeChange}
  />
</Form.Item> */}
          </Col>
        
        </Row>
        <Modal
        title="Product Exists"
        visible={isModalVisible}
        onOk={handleModalClose}
        onCancel={handleModalClose}
      >
        <p>This Product already Exist</p>
      </Modal>
        <Form.Item
          label="Description"
          name="description"
          required={false}
          rules={[{ required: false, message: "Please enter description!" }]}
          className="attendance_form_item"
        >
          
          <RichTextEditor
            value={editorValue}
            onChange={handleEditorChange}
            className="description-productBox"
            placeholder="Write your Description"
          />
        </Form.Item>
        
        <Form.Item
  className="image_dragger"
  required={false}
  rules={[
    { required: true, message: "Please Upload your Photos / videos" },
  ]}
  label={<p className="create_post_lable">Upload Photos</p>}
>
  {/* Only show the dragger if there are fewer than 3 images */}
  {urlList.length < 3 && (
    <Dragger
      {...ImageUploaderProp}
      maxCount={3}
      name="file"
      beforeUpload={handleBeforeUpload}
      showUploadList={true}
      customRequest={uploadImages}
      className="dragger"
      style={{ width: "100%", border: "2px dashed #7FACD6" }}
    >
      <UploadOutlined className="employee-details_uploade-photo" />
      <p>Drag & drop or Browse</p>
      <p className="ant-upload-text">
        {/* Photo formats: JPEG, PNG, (maximum image size 2 MB). */}
      </p>
    </Dragger>
  )}

  <div className="danger_alert">
    <p>
      <ExclamationCircleOutlined className="employee-details_uploade-icon" />{" "}
      maximum 3 slides
    </p>
  </div>

  {/* Display uploaded images with delete button */}
  {urlList.length > 0 ? (
    urlList.map((url, index) => {
      if (typeof url !== "string") {
        return null; // Skip non-string values
      }

      const filename = url.split("/").pop(); // Extract the filename from the URL

      return (
        <div className="employee-details_photodelete" key={index}>
          <img
            src={url}
            alt="profile"
            width={45}
            height={45}
            onClick={() => modalImageView(url)} // Open the modal to view the image
          />
          <p className="employee-details_photodelete-para">{filename}</p>
          <DeleteOutlined
            onClick={() => handleRemove(url)} // Handle image removal
            className="employee-details_delete_icon"
          />
        </div>
      );
    })
  ) : (
    <p>No images uploaded yet.</p>
  )}
</Form.Item>



{/* Modal for viewing the image */}
{modalImage && (
  <Modal
    visible={true}
    footer={null}
    onCancel={() => setModalImage(null)} // Close modal
  >
    <img
      alt="uploaded"
      style={{ width: "100%" }}
      src={modalImage} // Display selected image
    />
  </Modal>
)}


        
        <Form.Item>
          <div className="assets_submit">
            <Space>
              <Button
                htmlType="button"
                className="assets_cancel-btn"
                onClick={() => ModalClose(null)}
              >
                Cancel
              </Button>
              <Button htmlType="submit" className="assets_submit-btn">
                Submit
              </Button>
            </Space>
          </div>
        </Form.Item>
      </Form>
      <Modal
        open={modalImageOpen}
        onCancel={modalImageClose}
        footer={null}
        className="modal_body"
      >
        <img src={modalImage} alt="modal view" style={{ width: "100%" }} />
      </Modal>
    </div>
    </>
  );
};
export default createEmp;
