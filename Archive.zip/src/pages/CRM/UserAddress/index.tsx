import React, { useEffect, useState, useRef } from 'react';
import { Space, Table, Button, Form, Popconfirm, Drawer, Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { GET_SERVICE_USERS_ADDRESS } from '../../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import CRMnav from '../crmlayout';
import { useAuth } from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";

export const User: React.FC = () => {
    const [open, setOpen] = useState<any>(null);
    const { check_button_permission, filteredColumns } = useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");
    const [useraddress, setUsersAdd] = useState([]);

    const { error, loading, data, refetch } = useQuery(GET_SERVICE_USERS_ADDRESS);

    useEffect(() => {
        if (data) {
            let useraddress = data?.user_address
            setUsersAdd(useraddress)
        }
    }, [data])

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
    };
    const handleOk = () => {
        refetch();
        setPopOpen(false);
    };

    const handleCancel = () => {
        setPopOpen(false);
    };

    const ModalClose = () => {
        setOpen(false)
        // refetProduct()
    }

    var count = 0
    interface DataType {
        employee: string;
    }

    const columns: ColumnsType<DataType> = [
        {
            title: 'S.no',
            render: () => ++count
        },
        {
            title: 'Name',
            dataIndex: 'user_name',
            key: 'user_name'
        },
        {
            title: 'Email',
            dataIndex: 'email',
            key: 'email'
        },
      
        {
            title: 'Mobile',
            dataIndex: 'phone_number',
            key: 'phone_number'
        },
        {
            title: 'Address',
            dataIndex: 'address',
            key: 'address'
        },
        {
            title: 'City',
            dataIndex: 'city',
            key: 'city'
        },
        {
            title: 'State',
            dataIndex: 'state',
            key: 'state'
        },
        {
            title: 'Pincode',
            dataIndex: 'pincode',
            key: 'pincode'
        },
    ]

    return (
        <CRMnav>
            <div className="assets">
                <div className="assets_head">
                    <h2 className="assets_head-text">User Addresss</h2>
                    {/* {
                        check_button_permission("Products", "create")
                            ?
                            <Button className="assets_head-create"
                                onClick={() => setOpen("Create")}
                            >Add Product</Button>
                            : <></>
                    } */}
                </div>
                <Table
                    columns={filteredColumns(columns, 'Products')} dataSource={useraddress} pagination={false} className="assets_table" />


                {/* <Drawer title={`${open} Product `} width={570} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}>
                    {
                        open == "Edit" ? (<CreateProduct ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        open == "Create" ? (<CreateProduct ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                    }
                </Drawer> */}

            </div>
            <Modal
                open={Popopen}
                title=""
                onOk={handleOk}
                onCancel={handleCancel}
                footer={[
                    <div style={{ display: "flex", justifyContent: "center" }}>
                        <Button
                            key="submit"
                            type="primary"
                            loading={loading}
                            onClick={handleOk}
                            style={{
                                display: "flex",
                                width: "206px",
                                padding: "15px 30px",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "10px",
                                borderRadius: "8px",
                                background: "#252947",
                            }}>
                            OK
                        </Button>
                    </div>,
                ]}
                width={"386px"}>
                <Space
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                    }}>
                    <Image
                        src={PopImage}
                        alt="image"
                        style={{
                            width: "150px",
                            height: "150px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    />
                    <p
                        style={{
                            color: "#101010",
                            textAlign: "center",
                            fontFamily: "revert",
                            fontSize: "32px",
                            fontStyle: "normal",
                            fontWeight: "700",
                            lineHeight: "normal",
                        }}>
                        {`${title}`} Successfully
                    </p>
                </Space>
            </Modal>
        </CRMnav>
    )
}

export default User