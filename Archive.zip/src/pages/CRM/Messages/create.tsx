import { useMutation, useQuery } from "@apollo/client";
import { Button, Form, Input, Space, message, Upload, Select, Modal } from "antd";
import React, { useEffect, useRef, useState } from "react";
import { CREATE_CATEGORY, GET_CATEGORY, UPDATE_CATEGORY, GET_SHOP } from "@/helpers";
import { UploadOutlined, ExclamationCircleOutlined, DeleteOutlined } from '@ant-design/icons';

const Createmessage: React.FC<any> = ({ ModalClose, editdraw, showModal }) => {
    const [form] = Form.useForm();
    const formRef = useRef(null);
    const { Dragger } = Upload;
    const [urlList, setUrlList] = useState<string[]>([]);
    const [modalImage, setModalImage] = useState<string | null>(null);
    const [modalImageOpen, setModalImageOpen] = useState<boolean>(false);
    const [loadingMP, setLoading] = useState(false);
    const [cat, setCat] = useState<any[]>([]);
    const [editforminitaldata, seteditforminitaldata] = useState<any>(false);
    const [initialLogo, setInitialLogo] = useState<string[]>([]);
    
    const [createCategory, { error, loading, data }] = useMutation(CREATE_CATEGORY, { errorPolicy: 'all' });
    const { data: categoryData, refetch: refetCategoryData } = useQuery(GET_CATEGORY);
    const { data: shopData } = useQuery(GET_SHOP);
    const [updateCategory, { error: updateError, loading: updateLoading, data: updateData }] = useMutation(UPDATE_CATEGORY, { errorPolicy: 'all' });

    useEffect(() => {
        if (categoryData) {
            let Cate = categoryData?.mst_category;
            setCat(Cate);
        }
    }, [categoryData]);

    useEffect(() => {
        if (editdraw && shopData?.mst_shop) {
            const selectedShop = shopData.mst_shop.find((shop: any) => shop.id === editdraw.id);
            console.log(shopData?.mst_shop)
            console.log(editdraw)
            form.setFieldsValue({
                category: editdraw.category,
                description: editdraw.description,
                image: editdraw.image,
                shop_id: editdraw.shop?.shop_name,
            });
            setInitialLogo(editdraw.image ? [editdraw.image] : []);
            setUrlList(editdraw.image ? [editdraw.image] : []);
        }
    }, [editdraw, form, shopData]);

    const ImageUploaderProp: any = {
        name: "file",
        multiple: true,
        action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
        onChange(info: any) {
            const { status } = info.file;
            if (status !== "uploading") {}
            if (status === "done") {
                message.success(`${info.file.name} file uploaded successfully.`);
            } else if (status === "error") {
                message.error(`${info.file.name} file upload failed.`);
            }
        },
    };

    const uploadImages = async (options: any) => {
        const { onSuccess, onError, file } = options;
        try {
            setLoading(true);
            const data = new FormData();
            data.append("upload_preset", "Employee");
            data.append("file", file);
            data.append("cloud_name", "dgcgmcaxb");
            fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
                method: "post",
                body: data,
            })
                .then((resp) => resp.json())
                .then((data) => {
                    setUrlList((urlList) => [...urlList, data.url]);
                    setLoading(false);
                })
                .catch((err) => {
                    setLoading(false);
                });
            onSuccess("Ok");
        } catch (err) {
            const error = new Error("Some error");
            onError({ err });
        }
    };

    const handleRemove = async (images: any) => {
        let filteredImage = urlList?.filter(e => e !== images);
        setUrlList(filteredImage);
    };

    const modalImageView = (LinkBox: any) => {
        setModalImageOpen(!modalImageOpen);
        setModalImage(LinkBox);
    };

    const modalImageClose = () => {
        setModalImageOpen(!modalImageOpen);
        setModalImage(null);
    };

const handleBeforeUpload = (file: any) => {
        const fileSizeInMB = file.size / 1024 / 1024;
        const maxFileSizeInMB = 2;
        if (fileSizeInMB > maxFileSizeInMB) {
            message.error(`File size must be within ${maxFileSizeInMB}MB!`);
            return false;
        }
        return true;
    };

    const getShopIdByName = (shopName: string) => {
        const shop = shopData?.mst_shop.find((shop: any) => shop.shop_name === shopName);
        return shop ? shop.id : null;
    };

    const onFinish = async (value: any) => {
        try {
            if (editdraw) {
                value.id = editdraw.id;
                value.image = urlList.toString();
                value.shop_id = getShopIdByName(value.shop_id); // Convert shop name to ID
                console.log("onFinish value for updateCategory:", value);
                await updateCategory({ variables: value });
                console.log(updateCategory, "updateCategory in onfinish");
                ModalClose(null);
                showModal('Updated');
                refetCategoryData();
                console.log('Update submitted successfully');
            } else {
                value.image = urlList.length > 0 ? urlList[0] : initialLogo[0];
                value.shop_id = getShopIdByName(value.shop_id); // Convert shop name to ID
                console.log("onFinish value for createCategory:", value);
                await createCategory({ variables: value });
                ModalClose(null);
                showModal('Created');
                refetCategoryData();
                form.resetFields();
                console.log('Create submitted successfully');
            }

             // Clear image state after successful submission
        setUrlList([]);
        setInitialLogo([]);

        }
        
        catch (error) {
            // console.error('Error:', error.message);
            message.error('An error occurred');
        }
    };

    const onFinishFailed = (errorInfo: any) => {
        message.error('Check the Failed');
    };

    return (
        <>
            <Form
                name="category"
                layout="vertical"
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                ref={formRef}
                className="employee-details_form"
            >
                <Form.Item
                    label="Name"
                    name="category"
                    required={false}
                    rules={[{ required: true, message: 'Please Enter the Category' }]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    label="Description"
                    name="description"
                    required={false}
                    rules={[{ required: true, message: 'Please Enter the Description' }]}
                >
                    <Input.TextArea rows={3} autoSize={false} style={{ resize: 'none', height: '100px' }} />
                </Form.Item>
                {/* <Form.Item
                    label='Shop Name'
                    name='shop_id'
                    required={false}
                    rules={[{ required: true, message: 'Please Select the Shop' }]}
                >
                    <Select>
                        {shopData?.mst_shop.map((shop: any) => (
                            <Select.Option value={shop.shop_name} key={shop.id}>
                                {shop.shop_name}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item> */}
                <Form.Item
                    className="image_dragger"
                    required={false} rules={[{ required: true, message: "Please Upload your Photos / videos" }]}
                    label={<p className="create_post_lable">Upload Photos</p>}
                >
                    {urlList.length === 0 && (
                        <Dragger
                            {...ImageUploaderProp}
                            maxCount={1}
                            name="file"
                            beforeUpload={handleBeforeUpload}
                            showUploadList={true}
                            customRequest={uploadImages}
                            className="dragger"
                            style={{ width: "100%", border: "2px dashed #7FACD6" }}
                        >
                            <UploadOutlined className="employee-details_uploade-photo" />
                            <p>Drag & drop or Browse</p>
                        </Dragger>
                    )}
                    {urlList.map((value) => {
                        const filename = value?.split('/').pop();
                        return (
                            <div className='employee-details_photodelete' key={value}>
                                <img src={value} alt="profile" width={45} height={45} onClick={() => modalImageView(value)} />
                                <DeleteOutlined onClick={() => handleRemove(value)} className='employee-details_delete_icon' />
                            </div>
                        );
                    })}
                    {modalImageOpen && (
                        <Modal open={modalImageOpen} onCancel={modalImageClose} footer={null}>
                            <img alt="Modal Image" style={{ width: '100%' }} src={modalImage!} />
                        </Modal>
                    )}
                </Form.Item>
                <Form.Item>
                    <div className="employee-details_submit">
                        <Space>
                            <Button htmlType="button" onClick={() => ModalClose(null)} className="employee-details_cancel-btn">
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="employee-details_submit-btn">
                                Submit
                            </Button>
                        </Space>
                    </div>
                </Form.Item>
            </Form>
        </>
    );
};

export default Createmessage;
