import React, { useEffect, useState } from "react";
import CRMnav from "../crmlayout";
import { useShopContext } from "../../../context/shopContext";
import { useMutation, useQuery } from "@apollo/client";
import { GET_MESSAGE, GET_SHOP, USER_MESSAGE } from "@/helpers";
import { Button, Drawer, message, Modal, Popconfirm, Select, Space, Table } from "antd";
import { useAuth } from "@/components/auth";
import { ArrowRightOutlined, ArrowUpOutlined, DeleteOutlined, EditOutlined, MessageOutlined } from "@ant-design/icons";
import Createmessage from "./create";
interface UserRecord {
  userId: string;
  name: string;
  messages: string[];
  // Add other properties based on your data structure
}

export const Messages: React.FC = () => {
  const [userClient, setUserClient] = useState([]);
  const { check_button_permission, filteredColumns } = useAuth();
  const [open, setOpen] = useState<any>(null);
  const [heading, setHeading] = useState<any>(null);
  const { data, refetch: refetchUserData } = useQuery(GET_MESSAGE);
  const { selectedOrgValue, setSelectedOrgValue } = useShopContext();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const { data: shopData } = useQuery(GET_SHOP);
  const [editdraw, setEditdraw] = useState<{ userId: string } | null>(null); // userId for the selected user
  const[createMessage]=useMutation(USER_MESSAGE);
  const [messageText, setMessageText] = useState(""); 
  const [drawerVisible, setDrawerVisible] = useState(false);
const [drawerMessages, setDrawerMessages] = useState<any[]>([]); // Messages for the drawer
const [drawerHeading, setDrawerHeading] = useState(""); // Name for the drawer heading


  useEffect(() => {
    if (data) {
      let result = data?.mst_users;
      setUserClient(result);
    }
  }, [data]);

 // useEffect to refetch when userId is updated or after sending a message
useEffect(() => {
  if (editdraw?.userId) {
    const fetchUserData = async () => {
      try {
        // Refetch user data here, maybe calling the API again
      
        console.log("User data refetched.");
      } catch (error) {
        console.error("Failed to refetch user data:", error);
      }
    };
    
    // Call fetchUserData only after a message is sent
    fetchUserData();
  }
}, [editdraw?.userId]); // Depend
  

   // Send message mutation
   const handleSendMessage = async () => {
    console.log(editdraw?.userId," console.log(editdraw?.userId)")
    if (!editdraw?.userId) {
      message.warning("Please select a user.");
      return;

     
    }
    if (!messageText.trim()) {
      message.warning("Please enter a message.");
      return;
    }
  
    try {
      await createMessage({
        variables: {
          user_id: editdraw.userId,
          message: messageText,
        },
      });
      message.success("Message sent successfully!");
      setMessageText(""); // Clear the message input
      await refetchUserData(); 
    } catch (error) {
      message.error("Failed to send message.");
    }
  };
  

  const search = (data: any) => {
    return data?.filter((record: any) => {
      const shopName = record?.shop?.shop_name?.toLowerCase();
      const selectedShop = selectedOrgValue?.toLowerCase();
      return selectedShop ? shopName === selectedShop : true;
    });
  };

  const handleResolve = (userId: string) => {
    console.log(`Resolving all messages for User ID: ${userId}`);
  
    // Add your logic to mark all messages as resolved for this user via a mutation or API call
    // Example API call:
    // resolveMessagesForUser(userId);
  
    // Optionally refetch or update the local state to reflect the changes
    refetchUserData();
  };
  
  

  const handleSelectChange = (value: any) => {
    setSelectedCategory(value);
  };


 

  const openMessageDrawer = (record: any) => {
    console.log(`Opening messages for User ID: ${record.userId}`);

    setDrawerMessages(record.messages); // Set messages for the selected user
    setDrawerHeading(record.name); // Set user name for the heading
    setDrawerVisible(true); // Open the drawer
    setEditdraw({ userId: record.userId });
    console.log(record.userId ,"record.userId ")
  };
  
  const closeMessageDrawer = () => {
    setDrawerVisible(false);
    setDrawerMessages([]);
    setDrawerHeading("");
    
  };
  let count = 0;
  const columns = [
    {
      title: "S.no",
      render: () => ++count,
    },
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Mobile",
      dataIndex: "mobile",
      key: "mobile",
    },
    // {
    //   title: "Status",
    //   render: (record: any) => {
    //     // Check if any message has resolved: false
    //     const hasUnresolved = record.messages.some((msg: any) => !msg.resolved);
  
    //     return (
    //       <Button
    //         type="primary"
    //         danger={hasUnresolved} // Red if any message is unresolved
    //         onClick={() => handleResolve(record.userId)}
    //       >
    //         {hasUnresolved ? "New Message" : "Resolved"}
    //       </Button>
    //     );
    //   },
    // },
    
    {
      title: "Messages",
      render: (record: any) => (
        <Button
          type="primary"
          onClick={() => openMessageDrawer(record)}
        >
          View Messages
        </Button>
      ),
    },
  ];

  // Filter the data to include only rows with messages
  const filteredDataWithMessages = userClient.filter(
    (user: any) => user.userchat && user.userchat.message
  );

  // Further filter the table data based on the selected category (name)
  const filteredData = selectedCategory
    ? filteredDataWithMessages.filter((user: any) => user.name === selectedCategory)
    : search(filteredDataWithMessages);

  // Group messages by userId, including created_at
  const groupMessagesByUserId = () => {
    const groupedMessages: { [key: string]: any } = {};

    filteredData.forEach((user: any) => {
      const userId = user?.userchat?.user_id; // Assuming user_id is the identifier for each user
      if (!groupedMessages[userId]) {
        groupedMessages[userId] = {
          userId,
          name: user?.name,
          mobile: user?.mobile,
          messages: [],
        };
      }
      // Log the user_id to the console
    console.log(`User ID: ${userId}`);  
      groupedMessages[userId].messages.push({
        message: user?.userchat?.message,
        createdAt: user?.userchat?.created_at, // Assuming created_at exists for each message
        is_admin: user?.userchat?.is_admin, 
      });
    });

    // Convert grouped messages to an array
    return Object.values(groupedMessages);
  };

  const groupedMessages = groupMessagesByUserId(); // Get grouped messages

  return (
    <CRMnav>
      <div className="employee-details">
        <h1 className="employee-details_head-text">{selectedOrgValue}</h1>
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Clients</h2>

          <Select
            size={"large"}
            onChange={handleSelectChange}
            allowClear
            showSearch
            filterOption={(input, option: any) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
            placeholder={"Search"}
            className="Asset_selecter"
            style={{ width: "220px", marginRight: "10px" }}
            value={selectedCategory}
          >
            {filteredDataWithMessages
              .filter((user: any) =>
                selectedOrgValue
                  ? user.shop && user.shop.shop_name === selectedOrgValue
                  : true
              )
              .map((user: any, index: any) => (
                <Select.Option value={user?.name} key={index}>
                  {user?.name}
                </Select.Option>
              ))}
          </Select>
        </div>
        <Table
          columns={filteredColumns(columns, Messages)}
          dataSource={groupedMessages} // Use the grouped messages as the data source
          pagination={{ pageSize: 10 }}
          className="employee-details_table"
        />
 <Drawer
  title={`Messages for ${drawerHeading}`}
  width={570}
  placement="right"
  onClose={closeMessageDrawer}
  visible={drawerVisible}
  style={{ height: '100%' }} // Ensure the Drawer takes the full height
>
  <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
    <div
      style={{
        flex: 1, // This ensures the messages section takes up remaining space
        overflowY: 'auto', // Enable scrolling for messages
        marginBottom: '20px', // Space for input box
      }}
    >
      {drawerMessages.length > 0 ? (
        Object.entries(
          drawerMessages.reduce((acc: Record<string, any[]>, msg: any) => {
            const date = new Date(msg.createdAt).toLocaleDateString(); // Group by date
            if (!acc[date]) acc[date] = [];
            acc[date].push(msg);
            return acc;
          }, {})
        ).map(([date, messages]) => (
          <div key={date} style={{ marginBottom: "20px" }}>
            {/* Date Header */}
            <h4 style={{ textAlign: "center", margin: "10px 0" }}>{date}</h4>

            {/* Messages for the Date */}
            {(messages as any[]).map((msg, index) => (
              <div
                key={index}
                style={{
                  display: "flex",
                  justifyContent: msg.is_admin ? "flex-end" : "flex-start",
                  marginBottom: "10px",
                }}
              >
                <div
                  style={{
                    backgroundColor: msg.is_admin ? "#fdecea" : "#f0f0f0", // Different background for admin
                    color: msg.is_admin ? "red" : "black", // Admin text in red
                    padding: "10px 15px",
                    borderRadius: "10px",
                    maxWidth: "70%",
                    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                  }}
                >
                  {/* Message Text */}
                  <p
                    style={{
                      margin: 0,
                      wordWrap: "break-word",
                      textAlign: msg.is_admin ? "right" : "left",
                    }}
                  >
                    {msg.message}
                  </p>

                  {/* Display createdAt time */}
                  <small
                    style={{
                      display: "block",
                      textAlign: msg.is_admin ? "right" : "left",
                      color: "gray",
                      marginTop: "5px",
                    }}
                  >
                    {new Date(msg.createdAt).toLocaleTimeString()}
                  </small>
                </div>
              </div>
            ))}
          </div>
        ))
      ) : (
        <p>No messages found.</p>
      )}
    </div>

    {/* Input box at the bottom */}
    <div
      style={{
        display: "flex",
        alignItems: "center",
        padding: "10px",
        // Optional: for visual separation
      }}
    >
      <input
        style={{
          width: "90%",
          padding: "10px",
          fontSize: "16px",
          marginRight: "10px",
        }}
        type="text"
        value={messageText} // Bind input value to state
        onChange={(e) => setMessageText(e.target.value)} // Handle input change
      />
      <ArrowUpOutlined
        style={{ fontSize: "20px", cursor: "pointer" }}
        onClick={handleSendMessage} // Call the send message function
      />
    </div>
  </div>
</Drawer>









      </div>
    </CRMnav>
  );
};

export default Messages;
