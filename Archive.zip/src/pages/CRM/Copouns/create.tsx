import { DeleteOutlined, UploadOutlined } from "@ant-design/icons";
import {
  Button,
  Checkbox,
  DatePicker,
  Form,
  Input,
  Modal,
  Select,
  Space,
  Switch,
} from "antd";
import moment from 'moment';
import Dragger from "antd/es/upload/Dragger";
import { useEffect, useRef, useState } from "react";
import { CREATE_COPOUNS, UPDATE_COUPONS,GET_COPOUNS,GET_CATEGORY, GET_PRODUCT, GET_SERVICE_USERS } from "@/helpers";
import { useMutation, useQuery } from "@apollo/client";

const CreateCoupons: React.FC<any> = ({ ModalClose, editdraw, showModal }) => {
  const [form] = Form.useForm();
  const formRef = useRef(null);
  const [isPublic, setIsPublic] = useState(true);
  const [category, setCategory] = useState<any[]>([]);
  const [userClient, setUserClient] = useState<any[]>([]);
  const [product, setProduct] = useState<any[]>([]);
  const [coupons, setCoupons] = useState([]);
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<string[]>([]);
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [createCoupon, { loading, error }] = useMutation(CREATE_COPOUNS);
  const [updateCoupon, { error: updateError, loading: updateLoading, data: updateData }] = useMutation(UPDATE_COUPONS, { errorPolicy: 'all' });
  const { data, refetch: refetchCategoryData } = useQuery(GET_CATEGORY);
  
  const { data: clientData, refetch: refetchClient } = useQuery(GET_SERVICE_USERS);
  const { data: dataProduct, refetch: refetchProduct } = useQuery(GET_PRODUCT);
console.log(editdraw?.id,"editdraw");

const {
 
  data:datas,
  refetch: refetchcoupons,
} = useQuery(GET_COPOUNS);

useEffect(() => {
  console.log(datas, "datas from GET_COPOUNS query");  // Inspect this to understand the structure
  if (datas && datas.mst_coupons) {
    setCoupons(datas.mst_coupons);
  }
}, [datas]);

  useEffect(() => {
    if (dataProduct) {
      const products = dataProduct?.mst_product || [];
      setProduct(products);
    }
  }, [dataProduct]);

  useEffect(() => {
    if (data) {
      const categories = data?.mst_category || [];
      setCategory(categories);
    }
  }, [data]);

  const onChangeToggle = (checked:any) => {
    setIsPublic(checked); // Update the toggle state
    form.setFieldsValue({ is_public: checked }); // Sync toggle state with the form
    console.log('Toggle state changed:', checked);
  };
  useEffect(() => {
    console.log(selectedCategoryIds, "Updated selectedCategoryIds");
  }, [selectedCategoryIds]);
  
  useEffect(() => {
    console.log(selectedProductIds, "Updated selectedProductIds");
  }, [selectedProductIds]);
  
  useEffect(() => {
    console.log(selectedUserIds, "Updated selectedUserIds");
  }, [selectedUserIds]);
  
  const handleCategoryChange = (selectedIds: string[]) => {
    setSelectedCategoryIds(selectedIds);
    console.log(selectedCategoryIds,"selectedCategoryIds")
  };

  const handleProductChange = (selectedIds: string[]) => {
    setSelectedProductIds(selectedIds);
    console.log(selectedProductIds,"selectedProductIds")
  };

  const handleUserChange = (selectedIds: string[]) => {
    setSelectedUserIds(selectedIds);
    console.log(selectedUserIds,"selectedUserIds")
  };

  useEffect(() => {
    if (editdraw) {

      if (editdraw.is_public == false) {
        onChangeToggle(false); 
      }
        // Log editdraw to see its structure
        console.log('Editdraw:', editdraw);
       form.setFieldsValue({
               code:editdraw.code,
               description: editdraw.description,
               discount_type: editdraw.discount_type,
          discount_value: editdraw.discount_value,
          start_date: editdraw.start_date ? moment(editdraw.start_date) : null, // Convert to moment
      end_date: editdraw.end_date ? moment(editdraw.end_date) : null, // Convert to moment
          min_order_value: editdraw.min_order_value,
          is_public: editdraw.is_public,
          status: editdraw.status,
          customer_id: editdraw.customer_id || [],
          category_id: editdraw.category_id || [],
          product_id: editdraw.product_id || [],
            });
        

      
    }
}, [editdraw, form]);


  // const handleSubmit = async (values: any) => {
  //   const { start_date, end_date, customer_id, product_id, category_id, ...rest } = values;

  //   // Format the dates
  //   const formattedStartDate = start_date ? start_date.format("YYYY-MM-DDTHH:mm:ss") : null;
  //   const formattedEndDate = end_date ? end_date.format("YYYY-MM-DDTHH:mm:ss") : null;

  //   // Prepare the variables for mutation
  //   const variables = {
  //     ...rest,
  //     start_date: formattedStartDate,
  //     end_date: formattedEndDate,
  //     customer_id: isPublic ? customer_id : [],
  //     product_id: isPublic ? product_id : [],
  //     category_id: isPublic ? category_id : [],
  //   };

  //   try {
  //     const { data } = await createCoupon({
  //       variables,
  //     });
  //     console.log(data, "Coupon Created Successfully");
  //     ModalClose(null);
  //     showModal('Created');
  //    form.resetFields();
                
  //   } catch (err) {
  //     console.error(err, "Error in Creating Coupon");
  //   }
  // };

  const handleSubmit = async (values: any) => {
    const { start_date, end_date, customer_id = [], product_id = [], category_id = [], ...rest } = values;
  
    // Format the dates
    const formattedStartDate = start_date ? start_date.format("YYYY-MM-DDTHH:mm:ss") : null;
    const formattedEndDate = end_date ? end_date.format("YYYY-MM-DDTHH:mm:ss") : null;
  
    // Prepare the variables for mutation
    const variables = {
      ...rest,
      start_date: formattedStartDate,
      end_date: formattedEndDate,
      is_public:isPublic,
      customer_id: !isPublic ? customer_id : [],
      product_id: !isPublic ? product_id : [],
      category_id: !isPublic ? category_id : [],
    };
  
    try {
      if (editdraw?.id) {
        // Update logic
        await updateCoupon({
          variables: { id: editdraw.id, ...variables },
        });
        console.log("Coupon Updated Successfully");
        showModal("Updated");
        refetchcoupons();
      } else {
        // Create logic
        await createCoupon({
          variables,
        });
        console.log("Coupon Created Successfully");
        showModal("Created");
      }
      ModalClose(null);
      form.resetFields();
      refetchcoupons();
    } catch (err) {
      console.error(err, `Error in ${editdraw?.id ? "Updating" : "Creating"} Coupon`);
    }
  };
  


  return (
    <div>
      <Form
        name="coupons"
        layout="vertical"
        autoComplete="off"
        form={form}
        ref={formRef}
        onFinish={handleSubmit}
        className="employee-details_form"
      >
        <Form.Item
          label="Coupon Code"
          name="code"
         
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Description"
          name="description"
         
        >
          <Input.TextArea rows={3} style={{ resize: "none", height: "100px" }} />
        </Form.Item>

        <Form.Item
          label="Discount Type"
          name="discount_type"
         
        >
          <Select placeholder="Select Discount Type">
            <Select.Option value="Percentage">Percentage</Select.Option>
            <Select.Option value="Price">Price</Select.Option>
          </Select>
        </Form.Item>

        <Form.Item
          label="Discount Value"
          name="discount_value"
          
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Start Date"
          name="start_date"
          
        >
          <DatePicker className="employee-details_form-datepic" />
        </Form.Item>
        <Form.Item
          label="End Date"
          name="end_date"
         
        >
          <DatePicker className="employee-details_form-datepic" />
        </Form.Item>

        <Form.Item
          label="Min Value"
          name="min_order_value"
          
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Status"
          name="status"
          
        >
          <Select placeholder="Select Status">
            <Select.Option value="Active">Active</Select.Option>
            <Select.Option value="Inactive">Inactive</Select.Option>
          </Select>
        </Form.Item>

        <div>
        <Form.Item label="Is Public" name="is_public">
        <Switch checked={isPublic} onChange={onChangeToggle}/>
        </Form.Item>


          {!isPublic && (
            <>
              <Form.Item label="Customer Name" name="customer_id">
                <Select
                  mode="multiple"
                  placeholder="Select Customer"
                  optionLabelProp="label"
                  onChange={handleUserChange}
                >
                  {clientData?.mst_users?.map((user: any) => (
                    <Select.Option value={user.id} label={user.name} key={user.id}>
                      <Checkbox checked={selectedUserIds.includes(user.id)}>
                        {user.name}
                      </Checkbox>
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item label="Category" name="category_id">
                <Select
                  mode="multiple"
                  placeholder="Select Category"
                  optionLabelProp="label"
                  onChange={handleCategoryChange}
                >
                  {category.map((cat: any) => (
                    <Select.Option value={cat.id} label={cat.category} key={cat.id}>
                      <Checkbox checked={selectedCategoryIds.includes(cat.id)}>
                        {cat.category}
                      </Checkbox>
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item label="Product" name="product_id">
                <Select
                  mode="multiple"
                  placeholder="Select Product"
                  optionLabelProp="label"
                  onChange={handleProductChange}
                >
                  {product.map((prod: any) => (
                    <Select.Option value={prod.id} label={prod.name} key={prod.id}>
                      <Checkbox checked={selectedProductIds.includes(prod.id)}>
                        {prod.name}
                      </Checkbox>
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </>
          )}
        </div>

        <Form.Item>
          <div className="employee-details_submit">
            <Space>
              <Button
                htmlType="button"
                onClick={() => ModalClose(null)}
                className="employee-details_cancel-btn"
              >
                Cancel
              </Button>
              <Button htmlType="submit" className="employee-details_submit-btn">
                Submit
              </Button>
            </Space>
          </div>
        </Form.Item>
      </Form>
    </div>
  );
};

export default CreateCoupons;
