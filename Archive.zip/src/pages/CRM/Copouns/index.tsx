import React, { useEffect, useState } from "react";
import CRMnav from "../crmlayout";
import {
    GET_COPOUNS,DELETE_COUPONS
  } from "@/helpers";
import { useMutation, useQuery } from "@apollo/client";
import { Button, Drawer, Popconfirm, Space, Table } from "antd";
import { useAuth } from "../../../components/auth";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import CreateCoupons from "./create";



export const Coupon: React.FC<any> = () => {
    const [coupons, setCoupons] = useState([]);
    const [open, setOpen] = useState<any>(null);
    const [heading, setHeading] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("");
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");
  const { check_button_permission, filteredColumns } = useAuth();
  const [
    deleteCoupons,
    { loading: delectLoad, error: delectError, data: deleteData },
  ] = useMutation(DELETE_COUPONS);
    const {
        error,
        loading,
        data,
        refetch: refetchcoupons,
      } = useQuery(GET_COPOUNS);

      useEffect(() => {
        if (data) {
          let res = data?.mst_coupons;
          setCoupons(res);
        }
      }, [data]);

      var count = 0;

      const columns = [
        {
          title: "S.no",
          render: () => ++count,
        },
       
        {
          title: "Code",
          dataIndex: "code",
          key: "code",
        },
        {
          title: "Expiry",
          dataIndex: "end_date",
          key: "end_date",
        },
        {
            title: "Discount Value",
            dataIndex: "discount_value",
            key: "discount_value",
          },

          {
            title: "Discount Type",
            dataIndex: "discount_type",
            key: "discount_type",
          },

          {
            title: "Status",
            dataIndex: "status",
            key: "status",
          },
          {
            title: "Action",
            key: "action",
            render: (record: any) => (
              <Space size="large">
                {check_button_permission("coupons", "edit") ? (
                  <EditOutlined
                    onClick={() => handleChange(record)}
                    className="employee-details_edit"
                  />
                ) : (
                  <></>
                )}
                {check_button_permission("coupons", "delete") ? (
                  <Popconfirm
                    title="Delete the Copouns"
                    description="Are you sure to delete this Copouns?"
                    okText="Yes"
                    cancelText="No"
                    onConfirm={() => handleDelete(record)}
                  >
                    <DeleteOutlined className="employee-details_delete" />
                  </Popconfirm>
                ) : (
                  <></>
                )}
              </Space>
            ),
          },
       
      ];

      const OnOpen = () => {
        setOpen(true);
        setHeading("Create");
      };
      const handleChange = (record: any) => {
        setEditdraw(record);
        setOpen("Edit");
        setHeading("Edit");
      };
    
      const handleDelete = (res: any) => {
        deleteCoupons({
          variables: res,
          update: (cache: any) => {
            showModal("Deleted");
            refetchcoupons();
          },
        });
      };

      const ModalClose = () => {
        setOpen(false);
      };

      const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
      };
    

  return (
    <CRMnav>
      <div className="employee-details">
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Coupons Details</h2>
         
            {check_button_permission("Category", "create") ? (
            <Button className="employee-details_head-create" onClick={OnOpen}>
            + Add New Coupon
          </Button>
          ) : (
            <></>
          )}
          </div>
          </div>
          <Table
          columns={columns}
          dataSource={coupons}
          pagination={{ pageSize: 10 }}
          className="employee-details_table"
        />
          <Drawer
          title={`${heading} Copouns`}
          width={570}
          placement="right"
          onClose={() => setOpen(false)}
          open={open}
          className="employee-details_drawer"
        >
          {heading == "Edit" ? (
            <CreateCoupons
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={editdraw}
            />
          ) : (
            <></>
          )}
          {heading == "Create" ? (
            <CreateCoupons
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={null}
            />
          ) : (
            <></>
          )}
        </Drawer>
       
    </CRMnav>
  );
};

export default Coupon;
