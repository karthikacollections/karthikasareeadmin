import { Button, Drawer, Popconfirm, Space, Table,Modal } from "antd";
import React, { useEffect, useState } from "react"
import  CreateShop  from "./create";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@apollo/client";
import { SOFT_DEL_SHOP, GET_SHOP } from "@/helpers";
import CRMnav from '../crmlayout'
import { useAuth } from '../../../components/auth'
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";

export const Shop:React.FC<any>=()=>{
    const[shop,setShop]=useState([])
    const [open, setOpen] = useState<any>(null);
    const { check_button_permission,filteredColumns } = useAuth()
    const [heading, setHeading] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("")
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");
 
    const{error, loading, data, refetch: refetShopData}=useQuery(GET_SHOP)
    
    const [deleteShop, { loading: delectLoad, error: delectError, data: deleteData }] = useMutation(SOFT_DEL_SHOP, {
        onCompleted: () => {
            showModal("Deleted");
            refetShopData();
        },
    });

    useEffect(()=>{
        if(data){
            let res=data?.mst_shop
            setShop(res)
        }
    },[data])
    
    const OnOpen=()=>{
        setOpen(true)
        setHeading('Create')
        refetShopData(); 
    }

    const ModalClose = () => {
        setOpen(false)
    }

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
        setHeading("Edit")
    }

    const handleDelete=(res:any)=>{
        deleteShop({
            variables:res,
            update:(cache:any)=>{
                showModal("Deleted");
                refetShopData()            
            }
        })
    }

    var count=0

    const columns=[
        {
            title:'S.no',
            render:()=>++count
        },
        {
            title: "Image",
            render: (urlList: any) => {
                if (urlList?.shop_logo){
              return (
                <img
                  src={urlList?.shop_logo}
                  alt="Image"
                  style={{ width: "100px" }}
                  className="employee-details_table-profile"
                />
              );
            }
            else {
                return "No Image";
              }
            }
          },

        {
            title:'Name',
            dataIndex:'shop_name',
            key:'shop_name'
        },
       
        
       
        {
            title:'Action',
            key:'action',
            render:(record:any)=>(
                <Space size='large'>
                    {
                        check_button_permission("Shop", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="employee-details_edit"
                            />:<></>
                    }
                    {
                        check_button_permission("Shop", "delete")
                            ?
                            <Popconfirm
                                title="Delete the Shop"
                                description="Are you sure to delete this Shop?"
                                okText="Yes"
                                cancelText="No"
                                onConfirm={()=>handleDelete(record)}
                            >
                                <DeleteOutlined className="employee-details_delete" />
                            </Popconfirm>:<></>
                    }
            </Space>   
            )   
        }
    ]

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
    };

    const handleOk = () => {
        refetShopData();
        setPopOpen(false);
    };

    const handleCancel = () => {
        setPopOpen(false);
    };

    return(
        <CRMnav>
        <div className="employee-details">
                <div className="employee-details_head">
                    <h2 className="employee-details_head-text">Shop Details</h2>
                    {
                        check_button_permission("Shop", "create")
                            ?
                        <Button className="employee-details_head-create" onClick={OnOpen}>+ Add New Shop</Button>
                        :<></>
                    }
                </div>

                <Table columns={filteredColumns(columns,Shop)} dataSource={shop} pagination={{pageSize: 10}} className="employee-details_table" />

                <Drawer title={`${heading} Shop`} width={570} placement="right" onClose={() => setOpen(false)} open={open} className="employee-details_drawer">
                    {
                        heading == "Edit" ? (<CreateShop ModalClose={ModalClose}  showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        heading == "Create" ? (<CreateShop ModalClose={ModalClose}  showModal={showModal} editdraw={null} />) : <></>
                    }
                </Drawer>

            </div>
            <Modal
                open={Popopen}
                title=""
                onOk={handleOk}
                onCancel={handleCancel}
                footer={[
                    <div style={{ display: "flex", justifyContent: "center" }}>
                        <Button
                            key="submit"
                            type="primary"
                            loading={loading}
                            onClick={handleOk}
                            style={{
                                display: "flex",
                                width: "206px",
                                padding: "15px 30px",
                                justifyContent: "center",
                                alignItems: "center",
                                gap: "10px",
                                borderRadius: "8px",
                                background: "#252947",
                            }}>
                            OK
                        </Button>
                    </div>,
                ]}
                width={"386px"}>
                <Space
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                    }}>
                    <Image
                        src={PopImage}
                        alt="image"
                        style={{
                            width: "150px",
                            height: "150px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    />
                    <p
                        style={{
                            color: "#101010",
                            textAlign: "center",
                            fontFamily: "revert",
                            fontSize: "32px",
                            fontStyle: "normal",
                            fontWeight: "700",
                            lineHeight: "normal",
                        }}>
                        {`${title}`} Successfully
                    </p>
                </Space>
            </Modal>
        </CRMnav>
    )
}

export default Shop