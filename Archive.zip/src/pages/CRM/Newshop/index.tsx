import React from 'react'

const newshop = () => {
  return (
    <div>index</div>
  )
}

export default newshop