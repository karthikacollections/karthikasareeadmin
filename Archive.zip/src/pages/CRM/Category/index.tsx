import { Button, Drawer, Popconfirm, Space, Table, Modal, Select } from "antd";
import React, { useEffect, useState } from "react";
import CreateCategory from "./create";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@apollo/client";
import {
  DELECT_CATEGORY,
  GET_CATEGORY,
  CATEGORY_SOFT_DELETE,
  GET_SHOP,
} from "@/helpers";
import CRMnav from "../crmlayout";
import { useAuth } from "../../../components/auth";
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";
import { useShopContext } from "../../../context/shopContext";

type ValueType = string | undefined; // Define a type for the values

export const Category: React.FC<any> = () => {
  //  const { selectedShop, setSelectedShop } = useShopContext();
  const [category, setCategory] = useState([]);
  const [open, setOpen] = useState<any>(null);
  const { check_button_permission, filteredColumns } = useAuth();
  const [heading, setHeading] = useState<any>(null);
  const [editdraw, setEditdraw] = useState("");
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");
  const { selectedOrgValue, setSelectedOrgValue } = useShopContext();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const {
    error,
    loading,
    data,
    refetch: refetCategoryData,
  } = useQuery(GET_CATEGORY);
  const handleSelectChange = (value: any) => {
    setSelectedCategory(value);
  };

  const { data: shopData } = useQuery(GET_SHOP);
  const [
    deleteCategory,
    { loading: delectLoad, error: delectError, data: deleteData },
  ] = useMutation(CATEGORY_SOFT_DELETE);

  useEffect(() => {
    if (data) {
      let res = data?.mst_category;
      setCategory(res);
    }
  }, [data]);

  const OnOpen = () => {
    setOpen(true);
    setHeading("Create");
  };

  const ModalClose = () => {
    setOpen(false);
  };

  const handleChange = (record: any) => {
    setEditdraw(record);
    setOpen("Edit");
    setHeading("Edit");
  };

  const handleDelete = (res: any) => {
    deleteCategory({
      variables: res,
      update: (cache: any) => {
        showModal("Deleted");
        refetCategoryData();
      },
    });
  };

  var count = 0;

  const columns = [
    {
      title: "S.no",
      render: () => ++count,
    },
    {
      title: "Image",
      render: (urlList: any) => {
        if (urlList?.image) {
          return (
            <img
              src={urlList?.image}
              alt="Image"
              style={{ width: "100px" }}
              className="employee-details_table-profile"
            />
          );
        } else {
          return "No Image";
        }
      },
    },
    {
      title: "Name",
      dataIndex: "category",
      key: "category",
    },
    {
      title: "Description",
      dataIndex: "description",
      key: "description",
    },
    // {
    //   title: "Shop",
    //   render: (value: any) => {
    //     console.log("value:", value);
    //     let shop = value?.shop?.shop_name;
    //     console.log(`shop ${shop}`);
    //     return <p>{shop}</p>;
    //   },
    // },
    {
      title: "Action",
      key: "action",
      render: (record: any) => (
        <Space size="large">
          {check_button_permission("Category", "edit") ? (
            <EditOutlined
              onClick={() => handleChange(record)}
              className="employee-details_edit"
            />
          ) : (
            <></>
          )}
          {check_button_permission("Category", "delete") ? (
            <Popconfirm
              title="Delete the Category"
              description="Are you sure to delete this Category?"
              okText="Yes"
              cancelText="No"
              onConfirm={() => handleDelete(record)}
            >
              <DeleteOutlined className="employee-details_delete" />
            </Popconfirm>
          ) : (
            <></>
          )}
        </Space>
      ),
    },
  ];

  const showModal = (param: any) => {
    setPopOpen(true);
    setTitle(param);
  };

  const handleOk = () => {
    refetCategoryData();
    setPopOpen(false);
  };

  const handleCancel = () => {
    setPopOpen(false);
  };

  const search = (data: any) => {
    const filteredData = data?.filter((record: any) => {
      const shopName = record?.shop?.shop_name?.toLowerCase();
      const selectedShop = selectedOrgValue?.toLowerCase();
      const selectedCategoryLowerCase = selectedCategory?.toLowerCase() || "";

      const matchesShop = selectedShop ? shopName === selectedShop : true;
      const matchesCategory = selectedCategoryLowerCase
        ? record?.category?.toLowerCase() === selectedCategoryLowerCase
        : true;

      return matchesShop && matchesCategory;
    });

    return filteredData;
  };

  const handleSelectChangeOrganization = (value: any) => {
    setSelectedOrgValue(value);
    setSelectedCategory(null);
  };

  return (
    <CRMnav>
      <div className="employee-details">
        <h1 className="employee-details_head-text">{selectedOrgValue}</h1>
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Category Details</h2>
          {/* <Select
            size={"large"}
            onChange={handleSelectChangeOrganization}
            allowClear
            showSearch
            filterOption={(input, option: any) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
            placeholder={"Search Shop"}
            className="Asset_selecter"
            style={{ width: "220px", marginRight: "10px" }}
            value={selectedOrgValue} // Set the default value
          >
            {shopData?.mst_shop?.map((shop: any, index: any) => (
              <Select.Option value={shop?.shop_name} key={index}>
                {shop?.shop_name}
              </Select.Option>
            ))}
          </Select> */}
          <Select
            size={"large"}
            onChange={handleSelectChange}
            allowClear
            showSearch
            filterOption={(input, option: any) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
            placeholder={"Search"}
            className="Asset_selecter"
            style={{ width: "220px", marginRight: "10px" }}
            value={selectedCategory} // Set the default value
          >
            {data?.mst_category
              ?.filter((cat: any) =>
                selectedOrgValue
                  ? cat.shop && cat.shop.shop_name === selectedOrgValue
                  : true
              )
              .sort((a: any, b: any) => {
                // Your sorting logic here, you may need to adjust this depending on your data structure
                return a.category.localeCompare(b.category);
              })
              .map((cat: any, index: any) => (
                <Select.Option value={cat?.category} key={index}>
                  {cat?.category}
                </Select.Option>
              ))}
          </Select>

          {check_button_permission("Category", "create") ? (
            <Button className="employee-details_head-create" onClick={OnOpen}>
              + Add New Category
            </Button>
          ) : (
            <></>
          )}
        </div>

        <Table
          columns={filteredColumns(columns, Category)}
          dataSource={search(category)}
          pagination={{ pageSize: 10 }}
          className="employee-details_table"
        />

        <Drawer
          title={`${heading} Category`}
          width={570}
          placement="right"
          onClose={() => setOpen(false)}
          open={open}
          className="employee-details_drawer"
        >
          {heading == "Edit" ? (
            <CreateCategory
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={editdraw}
            />
          ) : (
            <></>
          )}
          {heading == "Create" ? (
            <CreateCategory
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={null}
            />
          ) : (
            <></>
          )}
        </Drawer>
      </div>
      <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{ display: "flex", justifyContent: "center" }}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}
            >
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}
      >
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}
          >
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
    </CRMnav>
  );
};

export default Category;
