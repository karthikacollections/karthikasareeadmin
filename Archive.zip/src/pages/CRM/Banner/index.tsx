import React, { useEffect, useState } from "react";
import { useAuth } from "@/components/auth";
import { useMutation, useQuery } from "@apollo/client";
import { GET_BANNER, GET_SHOP, DELETE_BANNER } from "@/helpers";
import PopImage from "../../../assets/photos/tick-circle.jpg";
import {
  Button,
  Drawer,
  Modal,
  Popconfirm,
  Select,
  Space,
  Table,
  Image,
} from "antd";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useShopContext } from "@/context/shopContext";
import CreateBanner from "./create";
import CRMnav from "../crmlayout";

const Banner: React.FC = () => {
  const [banner, setBanner] = useState<any[]>([]);
  const { selectedOrgValue, setSelectedOrgValue } = useShopContext();
  const [heading, setHeading] = useState<any>(null);
  const [editdraw, setEditdraw] = useState("");
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [open, setOpen] = useState<any>(null);
  const { check_button_permission, filteredColumns } = useAuth();
  const { data: shopData } = useQuery(GET_SHOP);
  const {
    error,
    loading,
    data,
    refetch: refetBannerData,
  } = useQuery(GET_BANNER);

  useEffect(() => {
    if (data) {
      setBanner(data.mst_banner);
    }
  }, [data]);

  const OnOpen = () => {
    setOpen(true);
    setHeading("Create");
  };

  const ModalClose = () => {
    setOpen(false);
  };

  const handleChange = (record: any) => {
    setEditdraw(record);
    setOpen("Edit");
    setHeading("Edit");
  };

  const handleDelete = (res: any) => {
    deleteBanner({
      variables: res,
      update: (cache: any) => {
        showModal("Deleted");
        refetBannerData();
      },
    });
  };

  const [
    deleteBanner,
    { loading: delectLoad, error: delectError, data: deleteData },
  ] = useMutation(DELETE_BANNER);

  let count = 0;

  const columns = [
    {
      title: "S.No",
      render: () => ++count,
    },
    {
      title: "Shop",
      dataIndex: "bannershop",
      key: "shop",
      render: (bannershop: { shop_name?: string } | undefined) => {
        const shopName = bannershop?.shop_name ?? "N/A";
        return <p>{shopName}</p>;
      },
    },
    {
      title: "Image",
      render: (urlList: any) => {
        if (urlList?.image) {
          return (
            <img
              src={urlList.image}
              alt="Image"
              style={{ width: "100px" }}
              className="employee-details_table-profile"
            />
          );
        } else {
          return "No Image";
        }
      },
    },
    {
      title: "Action",
      key: "action",
      render: (record: any) => (
        <Space size="large">
          {check_button_permission("Banner", "edit") && (
            <EditOutlined
              className="employee-details_edit"
              onClick={() => handleChange(record)}
            />
          )}
          {check_button_permission("Banner", "delete") && (
            <Popconfirm
              title="Delete the Banner"
              description="Are you sure to delete this Banner?"
              okText="Yes"
              cancelText="No"
              onConfirm={() => handleDelete(record)}
            >
              <DeleteOutlined className="employee-details_delete" />
            </Popconfirm>
          )}
        </Space>
      ),
    },
  ];

  const filteredData = selectedOrgValue
    ? banner.filter((record) =>
        record.bannershop?.shop_name
          ?.toLowerCase()
          .includes(selectedOrgValue.toLowerCase())
      )
    : banner;

  const handleSelectChangeOrganization = (value: any) => {
    setSelectedOrgValue(value);
  };

  const showModal = (param: any) => {
    setPopOpen(true);
    setTitle(param);
  };

  const handleOk = () => {
    refetBannerData();
    setPopOpen(false);
  };

  const handleCancel = () => {
    setPopOpen(false);
  };

  return (
    <CRMnav>
      <div className="employee-details">
        <h1 className="employee-details_head-text">{selectedOrgValue}</h1>
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Banner Details</h2>
          {/* <Select
            size="large"
            onChange={handleSelectChangeOrganization}
            allowClear
            showSearch
            filterOption={(input, option: any) =>
              typeof option.children === "string" &&
              option.children.toLowerCase().includes(input.toLowerCase())
            }
            placeholder="Search Shop"
            className="Asset_selecter"
            style={{ width: "220px", marginRight: "10px" }}
            value={selectedOrgValue}
          >
            {shopData?.mst_shop?.map((shop: any, index: any) => (
              <Select.Option value={shop?.shop_name} key={index}>
                {shop?.shop_name}
              </Select.Option>
            ))}
          </Select> */}
          {check_button_permission("Banner", "create") ? (
            <Button className="employee-details_head-create" onClick={OnOpen}>
              + Add New Banner
            </Button>
          ) : (
            <></>
          )}
        </div>
        <Table
          columns={filteredColumns(columns, "Banner")}
          dataSource={filteredData}
          pagination={{ pageSize: 10 }}
          className="employee-details_table"
        />
        <Drawer
          title={`${heading} Banner`}
          width={570}
          placement="right"
          onClose={() => setOpen(false)}
          open={open}
          className="employee-details_drawer"
        >
          {heading === "Edit" ? (
            <CreateBanner
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={editdraw}
            />
          ) : null}
          {heading === "Create" ? (
            <CreateBanner
              ModalClose={ModalClose}
              showModal={showModal}
              editdraw={null}
            />
          ) : null}
        </Drawer>
      </div>
      <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div
            style={{ display: "flex", justifyContent: "center" }}
            key="footer"
          >
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}
            >
              OK
            </Button>
          </div>,
        ]}
        width="386px"
      >
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          <Image
            src={PopImage.src}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}
          >
            {title} Successfully
          </p>
        </Space>
      </Modal>
    </CRMnav>
  );
};

export default Banner;
