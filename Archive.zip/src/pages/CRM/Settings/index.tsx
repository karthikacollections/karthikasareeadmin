import React, { useEffect, useRef, useState } from "react";

import CRMnav from '../crmlayout';
import { useQuery,useMutation } from '@apollo/client';
import { GET_SHOP,UPDATE_SHOP_SETTINGS,UPDATE_SETTINGS,CHECK_SETTING_EXISTS,INSERT_SETTING,GET_SHOP_PRODUCTS,UPDATE_SELECTED_FEATURE_PRODUCT,UPDATE_ALL_FEATURE_PRODUCT} from '@/helpers';
import { Select, Form, Input, Button, Upload, message, Modal, List, Checkbox } from 'antd';
import { useShopContext } from '@/context/shopContext';
import { UploadChangeParam, RcFile } from 'antd/lib/upload/interface';
import upload from 'antd/es/upload/Dragger';
import { DeleteOutlined, ExclamationCircleOutlined, PlusOutlined, UploadOutlined } from '@ant-design/icons';

interface Shop {
  id: string;
  shop_name: string;
  shop_logo: string;
}
type Product = {
  id: string;
  name: string;
  // Add other fields as necessary
};
export const ServiceDashboard: React.FC = () => {
  const [shop, setShop] = useState<Shop[]>([]);
  const [form] = Form.useForm();
  const { selectedOrgValue, setSelectedOrgValue } = useShopContext();
  const { error, loading, data, refetch: refetchShopData } = useQuery(GET_SHOP);
  const [urlList, setUrlList] = useState<string[]>([]);
  const [loadings, setLoading] = useState(false);
  const [modalImageOpen, setModalImageOpen] = useState(false);
  const [modalImage, setModalImage] = useState<any>(null)
  const [updateSettings] = useMutation(UPDATE_SETTINGS);
  const [updateShopSetting] = useMutation(UPDATE_SHOP_SETTINGS);
  const [insertSetting] = useMutation(INSERT_SETTING);
  const [product, setProduct] = useState<any>(null);
  const [productData, setProductData] = useState<{ id: string; name: string }[]>([]);
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  const productids = productData.map(product => product.id);


  const [isModalVisible, setIsModalVisible] = useState(false);
const [productNames, setProductNames] = useState<string[]>([]);
  const selectedShop = shop.find((s) => s.shop_name === selectedOrgValue);
const selectedShopId = selectedShop?.id;

  
  // Query to check if settings exist
  const { data: settingsCheckData, refetch: refetchSettingsCheckData } = useQuery(CHECK_SETTING_EXISTS, {
    variables: { shop_id: form.getFieldValue('id') },
    skip: !form.getFieldValue('id'),
  });

  const { Dragger } = Upload;
   useEffect(() => {
    form.setFieldsValue({ shopName: selectedOrgValue });
  }, [selectedOrgValue, form]);


  useEffect(() => {
    if (settingsCheckData) {
      console.log('Settings Check Data:', settingsCheckData);
      const shopId = settingsCheckData.mst_settings[0]?.shop_id;
      console.log('Extracted Shop ID:', shopId);
    }
  }, [settingsCheckData]);


  useEffect(() => {
    if (data) {
      const res: Shop[] = data.mst_shop;
      setShop(res);
      console.log(shop, "shop");
    }
  }, [data]);


  useEffect(() => {
    const selectedShop = shop.find((s) => s.shop_name === selectedOrgValue);
    if (selectedShop) {
      form.setFieldsValue({
        shopName: selectedShop.shop_name,
        id: selectedShop.id,
        shop_logo: selectedShop.shop_logo
      });
      setUrlList([selectedShop.shop_logo]);
    } else {
      form.resetFields();
      setUrlList([]);
      
    }
  }, [selectedOrgValue, form, shop]);

  const handleSelectChangeOrganization = (value: string) => {
    setSelectedOrgValue(value);
  };

  const onFinish = (values: any) => {
    const selectedShop = shop.find((s) => s.shop_name === selectedOrgValue);
    if (selectedShop) {
      const shopIdFromSettings = settingsCheckData?.mst_settings[0]?.shop_id;
      const shopLogo = urlList.length > 0 ? urlList[0] : '';
      if (shopIdFromSettings) {
        // Update settings if they exist
        updateSettings({
          variables: {
            shop_name: values.shopName,
            shop_logo: shopLogo,
            id: selectedShop.id,
          },
        })
          .then(() => {
            message.success('Settings updated successfully');
          })
          .catch(() => {
            message.error('Failed to update settings');
          });
  
        // Update shop information
        updateShopSetting({
          variables: {
            shop_name: values.shopName,
            shop_logo: shopLogo,
            id: selectedShop.id,
          },
        })
          .then(() => {
            message.success('Shop updated successfully');
          })
          .catch(() => {
            message.error('Failed to update shop');
          });
  
      } else {
        // Insert new settings if they do not exist
        insertSetting({
          variables: {
            shop_id: selectedShop.id,
            shop_name: values.shopName,
            shop_logo: shopLogo,
          },
        })
          .then(() => {
            message.success('Shop and settings inserted successfully');
          })
          .catch(() => {
            message.error('Failed to insert shop and settings');
          });
  
        // Update shop information
        updateShopSetting({
          variables: {
            shop_name: values.shopName,
            shop_logo: shopLogo,
            id: selectedShop.id,
          },
        })
          .then(() => {
            message.success('Shop updated successfully');
          })
          .catch(() => {
            message.error('Failed to update shop');
          });
      }
    }
  };
   // Fetch products for the selected shop
   const { data: dataProductResponse, refetch: refetchProduct } = useQuery(GET_SHOP_PRODUCTS, {
    
    variables: { shopId: selectedShopId },
    skip: !selectedShopId, // Skip the query if selectedShopId is undefined
  });

  useEffect(() => {
    if (selectedShopId) {
      refetchProduct({ shopId: selectedShopId });
    }
  }, [selectedShopId, refetchProduct]);

  useEffect(() => {
    if (dataProductResponse && dataProductResponse.mst_product) {
      const products = dataProductResponse.mst_product.map((product: any) => ({
        id: product.id,
        name: product.name,
        featured: product.featured_products, // Capture whether the product is featured
      }));

      setProductData(products);

      // Automatically select products that are featured
      const featuredProductIds = products
        .filter((product:any) => product.featured)
        .map((product:any) => product.id);

      setSelectedProductIds(featuredProductIds);
    }
  }, [dataProductResponse]);

  const openModal = () => {
    if (selectedShopId) {
      refetchProduct({ shopId: selectedShopId }); // Ensure the latest data is fetched
      setIsModalVisible(true);
    } else {
      console.error("Selected shop ID is undefined.");
    }
  };

  const handleModalCancel = () => {
    setIsModalVisible(false);
    setSelectedProductIds([]); // Optionally clear selected products
  };

  const handleCheckboxChange = (productId: string, checked: boolean) => {
    setSelectedProductIds((prevSelected) =>
      checked ? [...prevSelected, productId] : prevSelected.filter((id) => id !== productId)
    );
  };

 

  const [UpdateNonFeaturedProducts, { data: updateAllProducts }] = useMutation(
    UPDATE_ALL_FEATURE_PRODUCT,
    { errorPolicy: "all" }
  );

  const [UpdateFeaturedProducts, { data: updateFeatureProduct }] = useMutation(
    UPDATE_SELECTED_FEATURE_PRODUCT,
    { errorPolicy: "all" }
  );

  const handleSubmit = async () => {
    console.log(selectedProductIds); // Log the selected product IDs
    console.log(productids);
    try {
     
  
      // First mutation: Set all featured products to false
      const { data: updateAllProductsData } = await UpdateNonFeaturedProducts({
        variables: { ids: productids }
      });
  
      // Second mutation: Set selected products to featured
      const { data: updateFeaturedProductsData } = await UpdateFeaturedProducts({
        variables: { ids: selectedProductIds }
      });
  
      // Optionally handle data from mutations
      // console.log('Update All Products Data:', updateAllProductsData);
      console.log('Update Featured Products Data:', updateFeaturedProductsData);
  
      // Close the modal and reset state
      setIsModalVisible(false);
      setSelectedProductIds([]);
    } catch (error) 
    {
      console.error('Error updating products:', error);
      // Handle the error if necessary
    }
  };


  

  const ImageUploaderProp: any = {
    name: "file",
    multiple: true,
    action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
    onChange(info: any) {

        const { status } = info.file;
        if (status !== "uploading") {
        }
        if (status === "done") {
            message.success(`${info.file.name} file uploaded successfully.`);
        } else if (status === "error") {
            message.error(`${info.file.name} file upload failed.`);
        }
    },
};

const uploadImages = async (options: any) => {
    const { onSuccess, onError, file } = options;
    try {
        setLoading(true);
        const data = new FormData();
        data.append("upload_preset", "Employee");
        data.append("file", file);
        data.append("cloud_name", "dgcgmcaxb");
        fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
            method: "post",
            body: data,
        })
            .then((resp) => resp.json())
            .then((data) => {
                setUrlList([data.url]); // Set the new image URL
                setLoading(false);
            })
            .catch((err) => {
                setLoading(false);
            });
        onSuccess("Ok");
    } catch (err) {
        const error = new Error("Some error");
        onError({ err });
    }
};


const handleRemove = async (shop_logo: any) => {
    let filteredImage = urlList?.filter(e => e !== shop_logo);
    setUrlList(filteredImage);
};


const modalImageView = (LinkBox: any) => {
    setModalImageOpen(!modalImageOpen)
    setModalImage(LinkBox)
}

const modalImageClose = () => {
    setModalImageOpen(!modalImageOpen)
    setModalImage(null)
}

const handleChange = (info: UploadChangeParam) => {
    if (info.file.status === 'done') {
        message.success(`${info.file.name} file uploaded successfully`);
        refetchShopData()  } else if (info.file.status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
    }
};

const handleBeforeUpload = (file: any) => {
    const fileSizeInMB = file.size / 1024 / 1024; // Convert bytes to megabytes
    const maxFileSizeInMB = 2;
    if (fileSizeInMB > maxFileSizeInMB) {
        message.error(`File size must be within ${maxFileSizeInMB}MB!`);
        return false;
    }
    return true;
};
  

  return (
    <CRMnav>
      <div className="employee-details">
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Settings</h2>
        
         </div>
         <Select
            size={"large"}
            onChange={handleSelectChangeOrganization}
            allowClear
            showSearch
            filterOption={(input, option: any) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
            placeholder={"Search Shop"}
            className="Asset_selecter"
            style={{ width: "220px", marginRight: "10px" }}
            value={selectedOrgValue} // Set the default value
          >
            {shop.map((shopItem) => (
              <Select.Option value={shopItem.shop_name} key={shopItem.id}>
                {shopItem.shop_name}
              </Select.Option>
            ))}
          </Select>
        
        
        {selectedOrgValue && (
            <div className="employee-details_body">
            <Form
              form={form}
              name="shopForm"
              onFinish={onFinish}
              layout="vertical"
              initialValues={{ shopName: selectedOrgValue }}
            >
              <Form.Item
                label="Shop Name"
                name="shopName"
                rules={[{ required: false, message: 'Please input the shop name!' }]}
              >
                <Input placeholder="Enter shop name" />
              </Form.Item>

              <a onClick={openModal}>Feature Products</a>

<Modal
  title="Select Products"
  visible={isModalVisible}
  onCancel={handleModalCancel}
  footer={[
    <Button htmlType="submit" className="employee-details_submit-btn" onClick={handleSubmit}>
      Submit
    </Button>,
  ]}
>
  {productData.length === 0 ? (
    <p>No products available.</p>
  ) : (
    <List
      dataSource={productData}
      renderItem={(item) => (
        <List.Item>
          <Checkbox
            checked={selectedProductIds.includes(item.id)}
            onChange={(e) => handleCheckboxChange(item.id, e.target.checked)}
          >
            {item.name}
          </Checkbox>
        </List.Item>
      )}
    />
  )}
</Modal>


              <Form.Item
                    className="image_dragger"
                    required={false} rules={[{ required: true, message: "Please Upload your Photos / videos" }]}
                    label={<p className="create_post_lable">Upload Photos</p>}
                >
                    {urlList.length === 0 && (
                        <Dragger
                            {...ImageUploaderProp}
                            maxCount={1}
                            name="file"
                            beforeUpload={handleBeforeUpload}
                            showUploadList={true}
                            customRequest={uploadImages}
                            className="dragger"
                            style={{ width: "100%", border: "2px dashed #7FACD6" }}
                            onChange={handleChange}
                        >
                            <UploadOutlined className="employee-details_uploade-photo" />
                            <p>Drag & drop or Browse</p>
                            
                            <p className="ant-upload-text">
                              
                            </p>
                        </Dragger>
                    )}

                    <div className="danger_alert">
                        <p> <ExclamationCircleOutlined className="employee-details_uploade-icon" /> maximum 1 slide</p>
                    </div>

                    {
                        urlList.map((value) => {
                            const filename = value?.split('/').pop();

                            return <>
                                <div className='employee-details_photodelete'>
                                    <img src={value} alt="profile" width={45} height={45}
                                        onClick={() => modalImageView(value)}
                                    />
                                    <p className='employee-details_photodelete-para' >{filename}</p>
                                    <DeleteOutlined onClick={() => handleRemove(value)} className='employee-details_delete_icon' />
                                </div>
                            </>
                        })
                    }
                </Form.Item>
              
              <Form.Item>
              <Button htmlType="submit" className="employee-details_submit-btn">
                  Submit
                </Button>
              </Form.Item>
            </Form>
          </div>
           )}
      </div>
      
    </CRMnav>
  );
};

export default ServiceDashboard;
