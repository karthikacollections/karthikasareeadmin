import CRMnav from '../crmlayout';
import { useAuth } from "@/components/auth";
import { CLIENT_SOFT_DELETE, } from "@/helpers/mutation";
import { GET_CLIENT } from "@/helpers/queries";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@apollo/client";
import { Button, Drawer, Modal, Popconfirm, Space, Table } from "antd";
import { useEffect, useState } from "react";
import CreateClient from "./create";
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";

export const ClientManagement: React.FC<any> = () => {

  const [client, setClient] = useState([]);
  const [open, setOpen] = useState<any>(null);
  const [editdraw, setEditdraw] = useState("");
  const { check_button_permission, filteredColumns } = useAuth()
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [clientDetail, setClientDetail] = useState<any | null>(null);

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  // const { error: userErrors, loading: userLoadings, data: clientDatas } = useQuery(
  //   GET_CLIENT_DETAIL,
  //   {
  //     variables: { client: clientDetail?.id || "" },
  //     skip: !isModalOpen,
  //     onCompleted: (data) => {
  //       setClientDetail(data?.mst_clientmanagement[0] || null);
  //     },
  //   }
  // );


  // useEffect(() => {
  //   if (clientDatas) {
  //     let datas = clientDatas?.mst_clientmanagement;
  //     setClientDetail(datas[0] || null);
  //   }
  // }, [clientDatas]);



  const {
    error: userError,
    loading: userLoading,
    data: clientData,
    refetch: refetClientData
  } = useQuery(GET_CLIENT)

  const [deleteClient, { error: delectError, loading: delectLoading, data: deleteData }] = useMutation(CLIENT_SOFT_DELETE, {
    errorPolicy: 'all'
  })

  useEffect(() => {
    if (clientData) {
      let data = clientData?.mst_clientmanagement
      setClient(data)
    }
  }, [clientData])

  const ModalClose = () => {
    setOpen(false)
    refetClientData()
  }


  const handleChange = (record: any) => {
    setEditdraw(record);
    setOpen("Edit");
  };



  const handleDelete = async (record: any) => {
    try {
      const [deleteResult] = await Promise.all([
        deleteClient({
          variables: {
            id: record.id,
            check: false,
          },
          refetchQueries: [{ query: GET_CLIENT }],
        }),
      ]);

      // Use deleteResult if needed
    } catch (error) {
    }
  };

  let count = 0

  // ani table data
  const columns = [
    {
      title: 'S.No',
      render: () => ++count
    },
    {
      title: 'Company',
      dataIndex: 'company_name',
      key: 'company_name'
    },
    {
      title: 'Contact Person',
      dataIndex: 'name',
      key: 'name'
    },
    {
      title: 'Company Email',
      dataIndex: 'email',
      key: 'email'
    },
    {
      title: 'Phone Number',
      dataIndex: 'phone_number',
      key: 'phone_number'
    },
    {
      title: 'Address',
      dataIndex: 'address',
      key: 'address'
    },
    {
      title: 'GST',
      dataIndex: 'gst',
      key: 'gst',
      render: (text: any) => text || 'Not Available',
    },
    //     {
    //   title: "Actions",
    //   render: (value: any) => (
    //     <>
    //       <Button
    //         type="primary"
    //         onClick={showModal}
    //       >
    //         View
    //       </Button>
    //     </>
    //   ),
    // },       
    {
      title: "Action",
      key: "action",
      render: (record: any) => (
        <Space size="large">
          {
            check_button_permission("ClientManagement", "edit")
              ?
              <EditOutlined
                onClick={() => handleChange(record)}
                className="role_edit"
              /> : <></>
          }

          {
            check_button_permission("ClientManagement", "delete")
              ?
              <Popconfirm
                title="Delete the task"
                description="Are you sure to delete this task?"
                okText="Yes"
                cancelText="No"
                onConfirm={() => handleDelete(record)}>
                <DeleteOutlined className="role_delete" />
              </Popconfirm> : <></>
          }
        </Space>
      ),
    },
  ]


  return (
    <CRMnav>
      <div className="employee-details">
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Client Management</h2>
          {
            check_button_permission("ClientManagement", "create")
              ?
              <Button className="employee-details_head-create" onClick={() => setOpen("Create")}>Add New Client</Button>
              : <></>
          }
        </div>

        <Table columns={columns} dataSource={client} pagination={false} className="employee-details_table" />

        <Drawer title={`${open} Client`} width={570} placement="right" onClose={() => setOpen(false)} open={open} className="employee-details_drawer">
          {
            open == "Edit" ? (<CreateClient ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
          }
          {
            open == "Create" ? (<CreateClient ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
          }
        </Drawer>

      </div>

      <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{ display: "flex", justifyContent: "center" }}>
            <Button
              key="submit"
              type="primary"
              loading={userLoading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
      <Modal
        title="Client Details"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        {/* {clientDetail && (
    <>
      <p>Name: {clientDetail.mst_bookings[0]?.mst_product?.name}</p>
      
    </>
  )} */}
      </Modal>
    </CRMnav>
  )
}

export default ClientManagement