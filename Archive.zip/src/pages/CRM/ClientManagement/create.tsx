import { CREATE_CLIENT, UPDATE_CLIENT } from "@/helpers/mutation";
import { useMutation, useQuery } from "@apollo/client";
import { Button, Form, Input, Space, message,  } from "antd";
import { GET_CLIENT } from "../../../helpers/queries"
import { useEffect, useRef, useState } from "react"

const CreateClient: React.FC<any> = ({ ModalClose, editdraw, showModal }) => {
    const [form] = Form.useForm()
    const formRef = useRef(null)
    const [category, setCategory] = useState([])

    const {
        error: userError,
        loading: userLoading,
        data: clientData,
        refetch: refetClient
    } = useQuery(GET_CLIENT)

    const [createClient, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_CLIENT, {
        errorPolicy: 'all',
    });

    const [updateClient, { error: updateError, loading: updateLoading, data: updateData }] = useMutation(UPDATE_CLIENT, {
        errorPolicy: 'all'
    })

    useEffect(() => {
        if (clientData) {
            let category = clientData?.mst_clientmanagement
            setCategory(category)
        }
    }, [clientData])

    useEffect(() => {
        form.setFieldsValue(editdraw)
    }, [editdraw])

        const onFinish = (values: any,) => {

            if (editdraw) {
                values.id = editdraw?.id
                updateClient({
                    variables: values,
                }).then((response) => {
                    showModal("Updated")
                    refetClient()
                    ModalClose(null)
                });
            }
            else {
                
                createClient({
                    variables: values,
                }).then((response) => {
                    showModal("Created")
                    refetClient()
                    ModalClose(null)
                });
            };
        }
    const onFinishFailed = (errorInfo: any) => {
        message.error('Check the Failed')
    };
    
    return (
        <>
            <Form
                name="newClient"
                //initialValues={{remember:true}}
                layout="vertical"
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                ref={formRef}
                className="employee-details_form"
            >
                <Form.Item
                    label="Company Name"
                    name="company_name"
                    required={false}
                    rules={[{ required: true, message: 'Please input Company Name!' }]}
                >
                    <Input />
                </Form.Item>

                <Form.Item
                    label="Contact Person Name"
                    name="name"
                    required={false}
                    rules={[{ required: true, message: 'Please Enter Contact Person Name!' }]}
                >
                    <Input />
                </Form.Item>

                <Form.Item
                    label="Company Email"
                    name="email"
                    required={false}
                    rules={[{ required: true, message: 'Please Enter Company Email!' }, { type: 'email' }]}
                >
                    <Input />
                </Form.Item>

                <Form.Item
                    label="Phone Number"
                    name="phone_number"
                    required={false}
                    rules={[
                        {
                            required: true,
                            message: 'Please enter Phone number',
                            pattern: /^\d{10}$/,
                        },
                    ]}
                >
                    <Input />
                </Form.Item>

                <Form.Item
                    label="Address"
                    name="address"
                    required={false}
                    rules={[{ required: true, message: 'Please Enter Company Address!' }]}
                >
                  <Input className="employee-details_form_item_input" />   
                </Form.Item>

              

                <Form.Item
                    label="GST"
                    name="gst"
                    className="employee-details_form_item"
                    required={false}
                    rules={[
                        {
                            required: false,
                            message: 'Please input your GST No',
                            min: 15,
                            max: 15
                        },
                    ]}
                >
                    <Input className="employee-details_form_item_input" />
                </Form.Item>

                <Form.Item>
                    <div className="employee-details_submit">
                        <Space>
                            <Button htmlType="button" className="employee-details_cancel-btn">
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="employee-details_submit-btn">
                                Submit
                            </Button>
                        </Space>

                    </div>
                </Form.Item>
            </Form>
        </>
    )
}

export default CreateClient