import React from 'react'; 
import CRMLayout from './crmlayout';

const HistoryPage = () => {
  return (
    <CRMLayout>
      <h1>History Page</h1>
      {/* Add your History page content here */}
    </CRMLayout>
  );
};

export default HistoryPage;