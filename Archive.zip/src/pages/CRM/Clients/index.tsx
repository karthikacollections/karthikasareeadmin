import React, { useEffect, useState } from "react";
import CRMnav from "../crmlayout";
import { useShopContext } from "../../../context/shopContext";
import { useQuery } from "@apollo/client";
import { GET_USER_CLIENT, GET_SHOP } from "@/helpers";
import { Button, Modal, Popconfirm, Select, Space, Table } from "antd";
import { useAuth } from "@/components/auth";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { title } from "process";

export const ServiceDashboard: React.FC = () => {
  const [userClient, setUserClient] = useState([]);
  const { check_button_permission, filteredColumns } = useAuth();
  const [open, setOpen] = useState<any>(null);
  const [heading, setHeading] = useState<any>(null);
  const { data, refetch: refetchUserData } = useQuery(GET_USER_CLIENT);
  const { selectedOrgValue, setSelectedOrgValue } = useShopContext();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const { data: shopData } = useQuery(GET_SHOP);
  const [modalVisible, setModalVisible] = useState(false);
    const [taskData, setTaskData] = useState<any>([]);
    const [viewingAddress, setViewingAddress] = useState(false); 

  useEffect(() => {
    if (data) {
      let result = data?.mst_users;
      setUserClient(result);
    }
  }, [data]);

  const search = (data: any) => {
    return data?.filter((record: any) => {
      const shopName = record?.shop?.shop_name?.toLowerCase();
      const selectedShop = selectedOrgValue?.toLowerCase();
      return selectedShop ? shopName === selectedShop : true;
    });
  };

  const handleSelectChangeOrganization = (value: any) => {
    setSelectedOrgValue(value);
    setSelectedCategory(null);
  };

  const handleSelectChange = (value: any) => {
    setSelectedCategory(value);
  };

  const OnOpen = () => {
    setOpen(true);
    setHeading("Create");
  };

  const showModal = (param: any ,isAddress: boolean = false) => {
    setModalVisible(true);
    setTaskData(param);
    setViewingAddress(isAddress);
};

  let count = 0;
  const columns = [
    {
      title: "S.no",
      render: () => ++count,
    },
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Mobile",
      dataIndex: "mobile",
      key: "mobile",
    },

    {
      title: "Address",
      key: "address",
      render: (record: any) => {
          // const address = record?.userAddress?.address;
          
          return (
              <Button className="employee-details_head-create"  onClick={() => showModal(record, true)}>
                  View
              </Button>
          );
      },
  },

   
  ];

  // Filter the table data based on the selected category (name)
  const filteredData = selectedCategory
    ? userClient.filter((user: any) => user.name === selectedCategory)
    : search(userClient);

  return (
    <CRMnav>
      <div className="employee-details">
        <h1 className="employee-details_head-text">{selectedOrgValue}</h1>
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Clients</h2>
         
          <Select
            size={"large"}
            onChange={handleSelectChange}
            allowClear
            showSearch
            filterOption={(input, option: any) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
            placeholder={"Search"}
            className="Asset_selecter"
            style={{ width: "220px", marginRight: "10px" }}
            value={selectedCategory} // Set the default value
          >
            {userClient
              ?.filter((user: any) =>
                selectedOrgValue
                  ? user.shop && user.shop.shop_name === selectedOrgValue
                  : true
              )
              .map((user: any, index: any) => (
                <Select.Option value={user?.name} key={index}>
                  {user?.name}
                </Select.Option>
              ))}
          </Select>
         
        </div>
        <Table
          columns={filteredColumns(columns, ServiceDashboard)}
          dataSource={filteredData}
          pagination={{ pageSize: 10 }}
          className="employee-details_table"
        />
         <Modal
    title={viewingAddress ? "Address Details" : "Products"}
    open={modalVisible}
    onCancel={() => setModalVisible(false)}
    footer={null}
    width={600}
  >
    {viewingAddress ? (
      taskData?.mst_user_address && taskData?.mst_user_address.length > 0 ? (
        <div>
          {taskData?.mst_user_address.map((address: any, index: number) => (
            <div key={index} style={{ marginBottom: "20px" }}>
              <p><strong>Name:</strong> {address.name}</p>
              <p><strong>Address:</strong> {address.address}</p>
              <p><strong>City:</strong> {address.city}</p>
              <p><strong>Landmark:</strong> {address.landmark}</p>
              <p><strong>State:</strong> {address.state}</p>
              <p><strong>Pincode:</strong> {address.pincode}</p>
              <p><strong>Mobile:</strong> {address.mobile}</p>
              <hr />
            </div>
          ))}
        </div>
      ) : (
        <p>No Address Available</p>
      )
    ) : (
      <p>No Products to Display</p>
    )}
  </Modal>
      </div>
    </CRMnav>
  );
};

export default ServiceDashboard;
