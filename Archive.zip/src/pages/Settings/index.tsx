import React, { ReactNode } from 'react';
import SettingsNav from '../../components/Side_Nav/Settingsnav';
import SettingsLayout from './settingslayout';
import withApollo from '../../config'

const SettingsPage: React.FC = () => {
  return (

    <SettingsLayout>
      {/* <h1>Settings Page</h1> */}
      {/* Add your Settings page content here */}
    </SettingsLayout>
  );
};

export default SettingsPage;