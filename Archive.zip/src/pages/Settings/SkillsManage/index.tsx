
import withApollo from '../../../config'
import React, { useEffect, useState, } from 'react';
import { Space, Table, Button, Popconfirm, Drawer,Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { GET_SKILLSMANAGE } from '../../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import { DELETE_SKILLSMANAGE } from "../../../helpers/mutation";
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import moment from "moment";
import CreateSkills from "./createSkills";
import SettingsLayout from '../settingslayout';
import {useAuth} from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";

interface DataType {
    key: string;
    name: String;
}



export const skills: React.FC = () => {

    const [dest, setDest] = useState([])
    const [open, setOpen] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("");
    const { check_button_permission,filteredColumns } = useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
      };
      
      const handleOk = () => {
        refetdestination();
        setPopOpen(false);
      };
    
      const handleCancel = () => {
        setPopOpen(false);
      };
    


    const ModalClose = () => {
        setOpen(false)
        refetdestination()
    }

    //get skills
    const {
        error: userError,
        loading: userLoading,
        data: dataskills,
        refetch: refetdestination,
    } = useQuery(GET_SKILLSMANAGE, {
        variables: {},
    });

    useEffect(() => {
        if (dataskills) {
            let des = dataskills?.mst_skillsmanage
            setDest(des)
        }
    }, [dataskills])

    // delete destination
    const [deleteSkills, { loading, error, data }] = useMutation(DELETE_SKILLSMANAGE);
    const handleDelete = (id: any) => {
        deleteSkills({
            variables: id,

            update: (cache: any) => {
                refetdestination()
            },
        });
    };


    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("edit")
    }

    const columns: ColumnsType<DataType> = [
        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: 'Type',
            dataIndex:"type",
            key:"type"
        },

        {
            title: 'Action',
            key: 'action',
            render: (_, record) => (
                <Space size='large'>
                    {
                        check_button_permission("SkillsManage", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="Skills_edit"
                            />:<></>
                    }


                    {
                        check_button_permission("SkillsManage", "delete")
                            ?
                            <Popconfirm
                                title="Delete the task"
                                description="Are you sure to delete this task?"
                                okText="Yes"
                                cancelText="No"
                                onConfirm={() => handleDelete(record)}
                            >
                                <DeleteOutlined className="Skills_delete" />
                            </Popconfirm>:<></>
                    }



                </Space>
            ),
        },
    ];


    return (
        <SettingsLayout>
            <div className="Skills">
                <div className="Skills_head">
                    <h2 className="Skills_head-text">Skills Manage</h2>
                    {
                        check_button_permission("SkillsManage", "create")
                            ?
                        <Button className="Skills_head-create" onClick={() => setOpen("create")}>+ Add new Skills</Button>
                        :<></>
                    }
                </div>
                <Table columns={filteredColumns(columns,"SkillsManage")} dataSource={dest} pagination={false} className="Skills_tale" />
                <Drawer title={`${open} Skills Manage`} width={570} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}>
                    {
                        open == "edit" ? (<CreateSkills ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        open == "create" ? (<CreateSkills ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                    }


                </Drawer>

            </div>
            <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{display: "flex", justifyContent: "center"}}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
        </SettingsLayout>
    )
}
export default skills;
