import { Button, Form, Input, Space, Select } from 'antd';
import React, { useEffect, useState, useRef } from 'react';
import { CREATE_SKILLSMANAGE, UPDATE_SKILLSMANAGE, } from "../../../helpers/mutation";
import { useMutation, useQuery } from "@apollo/client";
import { GET_SKILLSMANAGE } from '../../../helpers/queries'



interface DataType {
    key: string;
    name: String;
    type:String;
}

export const createSkills: React.FC<any> = ({ ModalClose, editdraw,showModal }) => {

    const [form] = Form.useForm();
    const formRef = useRef(null);
    const { Option } = Select;
    // create destination
    const [createSkills, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_SKILLSMANAGE, {
        errorPolicy: 'all',
    });

    // edit destination
    const [
        updateSkills,
        { loading: updateloading, error: updateerror, data: updatedataAddress },
    ] = useMutation(UPDATE_SKILLSMANAGE, {
        errorPolicy: "all",
    });



    //get skills
    const {
        error: userError,
        loading: userLoading,
        data: dataskills,
        refetch: refetdestination,
    } = useQuery(GET_SKILLSMANAGE, {
        variables: {},
    });
    useEffect(() => {
        form.setFieldsValue(editdraw)
    }, [editdraw])

    const onFinish = (values: any) => {
        if (editdraw) {
            values.id = editdraw?.id
            updateSkills({
                variables: values,
            }).then((response) => {
                showModal("Updated")
                refetdestination()
                ModalClose(null)
                // setOpen(false)
            });
        }
        else {
            createSkills({
                variables: values,
            }).then((response) => {
                showModal("Created")
                ModalClose(null)
                refetdestination()
                // setOpen(false)
            });
        };
    }

    const onFinishFailed = (errorInfo: any) => {
    };

    function handleChange(value: any) {
    }

    return (

        <>
            <Form
                name="basic"
                layout="vertical"
                initialValues={{ remember: true }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                ref={formRef}
                className="Skills_form"
            >
                <Form.Item
                    label="Name"
                    name="name"
                    required={false}
                    rules={[{ required: true, message: 'Please input your Name!' }]}
                    className="Skills_form_item"
                >
                    <Input className="Skills_form_item-input" />
                </Form.Item>
                <Form.Item
                    label="Type"
                    name="type"
                    required={false}
                    rules={[{ required: true, message: 'Please input your Name!' }]}
                    className="Skills_form_item"
                >
                    <Input className="Skills_form_item-input" />
                </Form.Item>
                {/* <Form.Item
                    label="Type"
                    name="type"
                    required={false}
                    rules={[{ required: true, message: 'Please input your SKills!' }]}
                    className="Destination_form_item"
                >
                    <Select
                        mode="multiple"                      
                        placeholder="select one country"                        
                        onChange={handleChange}
                        optionLabelProp="label"
                    >
                        <Option value="Database" label="Database">
                          Database
                        </Option>
                        <Option value="Tools" label="Tools">
                        Tools
                        </Option>
                        <Option value="Cloud" label="Cloud">
                        Cloud
                        </Option>
                        <Option value="OS" label="OS">
                         OS
                        </Option>
                        <Option value="Library/Framework" label="Library/Framework">
                         Library/Framework
                        </Option>
                        <Option value="Mobile" label="Mobile">
                         Mobile
                        </Option>
                    </Select>
                </Form.Item> */}
                <Form.Item >
                    <div className="Skills_submit">
                        <Space>
                            <Button htmlType="button" className="Skills_cancel-btn" onClick={() => ModalClose(null)}>
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="Skills_submit-btn">
                                Submit
                            </Button>

                        </Space>

                    </div>
                </Form.Item>
            </Form>
        </>
    )
}
export default createSkills