import {
  CREATE_LEAVE_LIST,
  GET_LEAVE_LIST,
  UPDATE_LEAVE_LIST,
} from "@/helpers";
import { useMutation, useQuery } from "@apollo/client";
import { Input } from "@mantine/core";
import { Button, Form, Select, Space, message } from "antd";
import React, { useEffect, useRef } from "react";

const CreateLeaveList: React.FC<any> = ({ ModalClose, editdraw, showModal }) => {
  const [form] = Form.useForm();
  const formRef = useRef(null);

  //  GET the Data
  const {
    loading,
    error,
    data: leaveListData,
    refetch: refetLeaveList,
  } = useQuery(GET_LEAVE_LIST);

  useEffect(() => {
    if (editdraw) {
      form.setFieldsValue(editdraw);
    }
  }, [editdraw]);

  // POST the Data
  const [
    CreateleaveList,
    { loading: contactLoading, error: contactError, data: contactDataAddress },
  ] = useMutation(CREATE_LEAVE_LIST, {
    errorPolicy: "all",
  });

  //  UPDATE the Data
  const [
    updateleaveList,
    { loading: upLoad, error: upError, data: updateData },
  ] = useMutation(UPDATE_LEAVE_LIST, {
    errorPolicy: "all",
  });

  const onFinishFailed = (error: any) => { };

  const onFinish = async (value: any) => {

    try {
      const variables = {

        type: value.type,
        days: value.days,
        reason: value.reason,
        piror_permission: value.piror_permission,
        day: { type: value.type, days: value.days, reason: value.reason, piror_permission: value.piror_permission },
      };

      if (editdraw) {
        value.id = editdraw.id;
        const res = await updateleaveList({ variables:value });
        showModal("Updated")
        ModalClose(null);
        refetLeaveList();
      } else {
        const res = await CreateleaveList({ variables });
        showModal("Created")
        ModalClose(null);
        refetLeaveList();
      }
    } catch (error) {
      message.error("An error occurred");
    }
  };

  const onCancel = () => {
    editdraw = null;
    ModalClose(null);
  };

  return (
    <>
      <Form
        name="LeaveList"
        layout="vertical"
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        form={form}
        ref={formRef}
        className="employee-details_form"
      >
        <Form.Item
          label="Reason"
          name="reason"
          required={false}
          rules={[{ required: true, message: "Enter the Reason" }]}
        >

          <Select className="attendance_form_item-input">
            <Select.Option value={"Sick Leave"}>Sick Leave</Select.Option>
            <Select.Option value={"Maternity Leave"}>Maternity Leave</Select.Option>
            <Select.Option value={"Casual Leave"}>Casual Leave</Select.Option>
            <Select.Option value={"Permission Leave"}>Permission Leave</Select.Option>
            <Select.Option value={"Un Paid Leave"}>Un Paid Leave</Select.Option>
          </Select>
        </Form.Item>
       
        <Form.Item
          label="Piror Permission"
          name="piror_permission"
          required={false}
          rules={[{ required: false, message: "Enter piror permission" }]}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Type"
          name="type"
          required={false}
          rules={[{ required: true, message: "Enter the type" }]}
          className="attendance_form_item"
        >
          <Select className="attendance_form_item-input">
            <Select.Option value={"paid"}>Paid</Select.Option>
            <Select.Option value={"unpaid"}>Un Paid</Select.Option>
          </Select>
        </Form.Item>

        <Form.Item>
          <div className="employee-details_submit">
            <Space>
              <Button
                htmlType="button"
                className="employee-details_cancel-btn"
                onClick={onCancel}
              >
                Cancel
              </Button>
              <Button htmlType="submit" className="employee-details_submit-btn">
                Submit
              </Button>
            </Space>
          </div>
        </Form.Item>
      </Form>
    </>
  );
};

export default CreateLeaveList;
