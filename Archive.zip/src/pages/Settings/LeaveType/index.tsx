// import { authProtected } from "@/components/protectedroute";
import { Button, Drawer, Popconfirm, Space, Table,Modal } from "antd";
import React, { useEffect, useState } from "react";
import  CreateLeaveList  from "./create";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@apollo/client";
import { DELETE_LEAVE_LIST, GET_LEAVE_LIST } from "@/helpers";
import SettingsLayout from '../settingslayout';
import {useAuth} from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";

export const LeaveList:React.FC<any>=()=>{

    const [open, setOpen] = useState<any>(false);
    const [heading, setHeading] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("");
    const [leaveList,setLeaveList]=useState([]);
    const { check_button_permission,filteredColumns } = useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
      };
      
      const handleOk = () => {
        refetLeaveList();
        setPopOpen(false);
      };
    
      const handleCancel = () => {
        setPopOpen(false);
      };
    

    const OnOpen=()=>{
        setOpen(true)
        setHeading('Create')
    }

    const ModalClose = () => {
        setOpen(false)
    }

    // GET Leave List Data
    const{loading,error,data:leaveListData,refetch: refetLeaveList}=useQuery(GET_LEAVE_LIST)
    
    // DELECT Leave List Data
    const [deleteLeaveList, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(DELETE_LEAVE_LIST, {
        errorPolicy: 'all',
     });


    useEffect(()=>{
        if(leaveListData){
            let data=leaveListData?.mst_leave_type
            setLeaveList(data)
        }
    })

    const handleDelect=(id:any)=>{
        deleteLeaveList({
            variables:id,
            update: (cache: any) => {
                refetLeaveList()
            },
        })
    }

    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen(true)
        setHeading("Edit")
    }

    var count=0
    const colums=[
        {
            title:'S.No',
            dataIndex: 's.no',
            render: () =>++count,
        },
        {
            title:"Reason",
            dataIndex:"reason",
            key:"reason"
        },
        
        {
            title:"Piror Permission",
            dataIndex:"piror_permission",
            key:"piror_permission"
        },
        {
            title:"Action",
            key:'action',
            render:(record:any)=>(
                <Space size='large'>
                    {
                        check_button_permission("LeaveType", "edit")
                            ?
                            <EditOutlined
                                onClick={() => handleChange(record)}
                                className="employee-details_edit"
                            />
                            :<></>
                    }

                    {
                        check_button_permission("LeaveType", "delete")
                            ?
                        <Popconfirm
                            title="Delete the Client"
                            description="Are you sure to delete this Client?"
                            okText="Yes"
                            cancelText="No"
                            onConfirm={()=>handleDelect(record)}
                        >
                            <DeleteOutlined className="employee-details_delete" />
                        </Popconfirm>
                        :<></>
                    }
            </Space>   
            )
        }
    ]

    return(
        <SettingsLayout>
            <div className="employee-details">
                <div className="employee-details_head">
                    <h2 className="employee-details_head-text">Leave Type</h2>
                    {
                        check_button_permission("LeaveType", "create")
                            ?
                        <Button className="employee-details_head-create" onClick={OnOpen}>+ Add Leave Type</Button>
                        :<></>
                    }
                </div>
                <Table columns={filteredColumns(colums,"LeaveType")} dataSource={leaveList} pagination={false} className="employee-details_table" />

                <Drawer title={`${heading} Leave Type`} width={570} placement="right" onClose={() => setOpen(false)} open={open} className="employee-details_drawer">
                    {
                        heading == "Edit" ? (<CreateLeaveList ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        heading == "Create" ? (<CreateLeaveList ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                    }
                </Drawer>

            </div>
            <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{display: "flex", justifyContent: "center"}}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
        </SettingsLayout>
    )
}

export default LeaveList