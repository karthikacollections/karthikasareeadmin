
import { Button, Form, Input,Space } from 'antd';
import React, { useEffect, useState, useRef } from 'react';
import { useQuery, useMutation } from "@apollo/client";
import { GET_ROLE } from '../../../helpers/queries';
import { CREATE_ROLE, UPDATE_ROLE } from "../../../helpers/mutation";


export const Role: React.FC<any> = ({ ModalClose, editdraw  }) => {


    const [form] = Form.useForm();
    const formRef = useRef(null);
    const [role, setRole] = useState([])
    const [open, setOpen] = useState(false);

    const [createRole,
        { loading: contactLoading, error: contactError, data: contactDataAddress }
    ] = useMutation(CREATE_ROLE, {
        errorPolicy: 'all',
    });



    const [
        updateRole,
        { loading: updateloading, error: updateerror, data: updatedataAddress },
    ] = useMutation(UPDATE_ROLE, {
        errorPolicy: "all",
    });

    const {
        error: userError,
        loading: userLoading,
        data: dataRole,
        refetch: refetrole,
    } = useQuery(GET_ROLE, {
        variables: {},
    });

    useEffect(() => {
        if (dataRole) {
            let role = dataRole?.mst_role
            setRole(role)
        }
    }, [dataRole])

    const onFinish = (values: any) => {

        if (editdraw) {
            values.id = editdraw?.id
            updateRole({
                variables: values,
            }).then((response) => {
                refetrole()
                ModalClose(null)

            });
        }
        else {
            createRole({
                variables: values,
            }).then((response) => {
                refetrole()
                ModalClose(null)
            });
        };
    }
    useEffect(() => {
        form.setFieldsValue(editdraw)
    }, [editdraw])


    const onFinishFailed = (errorInfo: any) => {
    };


    return (
        <>
            <div>
                <Form
                    name="basic"
                    layout="vertical"
                    initialValues={{ remember: true }}
                    onFinish={onFinish}
                    onFinishFailed={onFinishFailed}
                    autoComplete="off"
                    form={form}
                    ref={formRef}
                    className="role_form"
                >
                    <Form.Item
                        label="Name"
                        name="name"
                        required={false}
                        rules={[{ required: true, message: 'Please input your Name!' }]}
                        className="role_form_item"
                    >
                        <Input className="role_form_item-input"/>
                    </Form.Item>

                    <Form.Item >
                        <div className="role_submit">
                            <Space>
                                <Button htmlType="button" className="role_cancel-btn" onClick={() => ModalClose(null)}>
                                    Cancel
                                </Button>
                                <Button htmlType="submit" className="role_submit-btn">
                                    Submit
                                </Button>
                            </Space>
                        </div>
                    </Form.Item>
                </Form>


            </div>

        </>
    )
}
export default Role