
import withApollo from '../../../config'
import React, { useEffect, useState, useRef } from 'react';
import { Space, Table, Button, Form, Modal, Popconfirm, Drawer,Tag } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { GET_ROLE } from '../../../helpers/queries';
import { useQuery, useMutation } from "@apollo/client";
import { DELETE_ROLE } from "../../../helpers/mutation";
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import CreateRole from './CreateRole';
import moment from "moment";
import {useAuth} from '../../../components/auth'
import SettingsLayout from '../settingslayout'
interface DataType {
    key: string;
    name: String;
}



export const Role: React.FC = () => {
    const [editRole, setEditRole] = useState<any>();
    const [role, setRole] = useState([]);
    const[rolePermission,setRolePermission]=useState([])
    const [form] = Form.useForm();
    const formRef = useRef(null);
    const [open, setOpen] = useState<any>(false);
    const { check_button_permission,filteredColumns } = useAuth()
    const [editdraw, setEditdraw] = useState("");
  
    const ModalClose = () => {
      setOpen(false);
      refetrole();
    };
  
    const {
      error: userError,
      loading: userLoading,
      data: dataRole,
      refetch: refetrole,
    } = useQuery(GET_ROLE, {
      variables: {},
    });
  
    const handleChange = (record: any) => {
      setEditdraw(record);
      setOpen("edit");
    };
  
    useEffect(() => {
      if (dataRole) {
        let role = dataRole?.mst_role;
        setRole(role);
      }
    }, [dataRole]);
      
    const [deleteRole, {loading, error, data}] = useMutation(DELETE_ROLE);
    const handleDelete = (id: any) => {
      
      deleteRole({
        variables: id,
  
        update: (cache) => {
          refetrole();
        },
      });
    };
  
    const columnsModle: ColumnsType<DataType>=[
          {
              title: "Page Name",
              dataIndex: "pageName",
              key: "pageName",
              width:'30%',
              align:'center'
            },
            {
              title: "Allow",
              render:(value:any)=>{
                let allowData=value?.allow
                
                return(
                 <>
                 {allowData.map((value:any)=>{
                 return <Tag color="magenta">{value}</Tag>
                 })}
                  </>
                  
                )
              },
            }
    ]
  
    const columns: ColumnsType<DataType> = [
      {
        title: "Type",
        dataIndex: "type",
        key: "type",
      },
      {
        title: "Created At",
        render: (value: any) => {
          let passWordFormat = moment(value?.createdat).format("DD MMMM YYYY");
  
          return (
            <>
              <p>{passWordFormat}</p>
            </>
          );
        },
      },
  
      {
        title: "Permission",
        key: "Permission",
        render: (_, record:any) => (
          <Space size={"large"}>
            <Button type="primary" onClick={()=>showModal(record?.permission)}>View</Button>
          </Space>
        ),
      },
      {
        title: "Action",
        key: "action",
        render: (_, record) => (
          <Space size="large">
            {
                check_button_permission("Role", "edit")
                  ?
                  <EditOutlined
                    onClick={() => handleChange(record)}
                    className="role_edit"
                  />:<></>
            }
            
            {
              check_button_permission("Role", "delete")
                ?
                <Popconfirm
                  title="Delete the task"
                  description="Are you sure to delete this task?"
                  okText="Yes"
                  cancelText="No"
                  onConfirm={() => handleDelete(record)}>
                  <DeleteOutlined className="role_delete" />
                </Popconfirm>:<></>
            }
          </Space>
        ),
      },
    ];
  
  
    const [isModalOpen, setIsModalOpen] = useState(false);
  
    const showModal = (param:any) => {
      setRolePermission(param)
      setIsModalOpen(true);
    };
  
    const handleOk = () => {
      setIsModalOpen(false);
    };
  
    const handleCancel = () => {
      setIsModalOpen(false);
    };


    return (
        <SettingsLayout>
             <div className="role">
        <div className="role_head">
          <h2 className="role_head-text">Role</h2>
          <Button
            className="role_head-create"
            onClick={() => setOpen("create")}>
            + Add New Role
          </Button>
        </div>
        <Table
          columns={columns}
          dataSource={role}
          pagination={false}
          className="role_table"
        />
        <Drawer
          title={`${open} Role`}
          width={570}
          placement="right"
          onClose={() => setOpen(false)}
          open={open?.length > 1 ? true : false}>
          {open == "edit" ? (
            <CreateRole ModalClose={ModalClose} editdraw={editdraw} />
          ) : (
            <></>
          )}
          {open == "create" ? (
            <CreateRole ModalClose={ModalClose} editdraw={null} />
          ) : (
            <></>
          )}
        </Drawer>
        <Modal
          open={isModalOpen}
          onOk={handleOk}
          onCancel={handleCancel}
          footer={[]}
          width={1000}
          >
            
          <Table
          columns={columnsModle}
          dataSource={rolePermission}
          pagination={false}
          className="role_table"
        />
        </Modal>
      </div>
        </SettingsLayout>
    )
}
export default Role 