import React from "react";
import SettingsLayout from "../settingslayout";
import { useEffect, useState } from "react";
import { useMutation, useQuery } from "@apollo/client";
import { GET_REMINDER_NOTIFICATION, DELETE_REMINDER_DAYS } from "@/helpers";
import { useAuth } from "../../../components/auth";
import { Button, Drawer, Modal, Popconfirm, Space, Table } from "antd";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import moment from "moment";
import CreateReminderadd from "./createReminder";
import Image from "next/image";
import PopImage from "../../../assets/photos/tick-circle.jpg";

export const ReminderNotificationManagement: React.FC<any> = () => {
  const [isCreatingReminder, setCreatingReminder] = useState(false);
  const [reminder, setreminder] = useState<any>([]);
  const [heading, setHeading] = useState("");
  const [editdraw, setEditdraw] = useState("");
  const [Popopen, setPopOpen] = useState(false);
  const [title, setTitle] = useState("");

  const { check_button_permission, filteredColumns } = useAuth(); // Use a more descriptive variable name

  // const handleShowModal = (message: string) => {
  //   // You can customize this part based on your modal implementation
  //   console.log(`Modal: ${message}`);
  //   // Add your logic to show the modal here
  // };
  const OnReminder = () => {
    setCreatingReminder(true); // Set it to true when creating a reminder
    setHeading("Create");
  };

  const ModalClose = () => {
    setCreatingReminder(false);
    // refetClientData()
  };
  //for the last 2 icons

  const handleChange = (record: any) => {
    setEditdraw(record);
    setCreatingReminder(true);
    setHeading("Edit");
  };

  //get data
  const {
    error,
    loading,
    data: GetReminderData,
    refetch: refetchTask,
  } = useQuery(GET_REMINDER_NOTIFICATION);

  //Getting Data
  useEffect(() => {
    if (GetReminderData) {
      console.log(GetReminderData, "GetReminderData");

      let res = GetReminderData?.mst_company_details;
      setreminder(res);
    }
  }, [GetReminderData]);

  //Delete Data
  const [deleteReminder, { error: delectError, loading: delectLoading, data }] =
    useMutation(DELETE_REMINDER_DAYS);

  //deleting Data
  const handledelete = (id: any) => {
    deleteReminder({
      variables: id,
      update: (cache: any) => {
        showModal("Deleted");
        refetchTask();
      },
    });
  };
  const showModal = (param: any) => {
    setPopOpen(true);
    setTitle(param);
  };

  const handleOk = () => {
    refetchTask();
    setPopOpen(false);
  };

  const handleCancel = () => {
    setPopOpen(false);
  };


  var count = 0;
  const colums = [
    {
      title: "S.no",
      dataIndex: "s.no",
      render: () => ++count,
    },
    {
      title: "Company Name",
      dataIndex: "company_name",
      key: "company_name",
    },

    {
      title: "Address",
      dataIndex: "company_address",
      key: "company_address",
    },
    {
      title: "GST.No",
      dataIndex: "gst_no",
      key: "gst_no",
    },
    {
      title: "Phone Number",
      dataIndex: "phone_number",
      key: "phone_number",
    },
    {
      title: "Bank Name",
      dataIndex: "bank_name",
      key: "bank_name",
    },
    {
      title: "Account Number",
      dataIndex: "account_number",
      key: "account_number",
    },

    {
      title: "Days",
      dataIndex: "days",
      key: "days",
    },
    {
      title: "Remind",
      dataIndex: "remind",
      key: "remind",
    },
    {
      title: "GST%",
      dataIndex: "gst_percent",
      key: "gst_percent",
    },

    {
      title: "action",
      key: "action",
      render: (record: any) => (
        <Space size="large">
          {check_button_permission("Reminder", "edit") ? (
            <EditOutlined
              onClick={() => handleChange(record)}
              className="employee-details_edit"
            />
          ) : (
            <></>
          )}

          {check_button_permission("Reminder", "delete") ? (
            <Popconfirm
              title="Delete the Reminder Days"
              description="Are you sure to delete this Reminder?"
              okText="Yes"
              cancelText="No"
              onConfirm={() => handledelete(record)}
            >
              <DeleteOutlined className="employee-details_delete" />
            </Popconfirm>
          ) : (
            <></>
          )}
        </Space>
      ),
    },
  ];
  return (
    <SettingsLayout>
      <div className="employee-details">
        <div className="employee-details_head">
          <h2 className="employee-details_head-text">Reminder Notification</h2>
          {check_button_permission("Reminder", "create") && (
            <Button
              className="employee-details_head-create"
              onClick={OnReminder}
            >
              + Add New Reminder Notification
            </Button>
          )}
        </div>

        <Table
          columns={filteredColumns(colums, "Reminder Notification")}
          dataSource={reminder}
          pagination={false}
          className="employee-details_table"
        />

        <Drawer
          title={`${heading} Reminder`}
          width={570}
          placement="right"
          onClose={() => setCreatingReminder(false)}
          open={isCreatingReminder}
          className="employee-details_drawer"
        >
          {heading === "Edit" ? (
            <CreateReminderadd
              ModalClose={ModalClose}
              editdraw={editdraw}
              showModal={showModal}
            />
          ) : (
            <></>
          )}
          {heading === "Create" ? (
            <CreateReminderadd
              ModalClose={ModalClose}
              editdraw={null}
              showModal={showModal}
            />
          ) : (
            <></>
          )}
        </Drawer>
        <Modal
          open={Popopen}
          title=""
          onOk={handleOk}
          onCancel={handleCancel}
          footer={[
            <div style={{ display: "flex", justifyContent: "center" }}>
              <Button
                key="submit"
                type="primary"
                loading={loading}
                onClick={handleOk}
                style={{
                  display: "flex",
                  width: "206px",
                  padding: "15px 30px",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: "10px",
                  borderRadius: "8px",
                  background: "#252947",
                }}>
                OK
              </Button>
            </div>,
          ]}
          width={"386px"}>
          <Space
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            }}>
            <Image
              src={PopImage}
              alt="image"
              style={{
                width: "150px",
                height: "150px",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            />
            <p
              style={{
                color: "#101010",
                textAlign: "center",
                fontFamily: "revert",
                fontSize: "32px",
                fontStyle: "normal",
                fontWeight: "700",
                lineHeight: "normal",
              }}>
              {`${title}`} Successfully
            </p>
          </Space>
        </Modal>

      </div>
    </SettingsLayout>
  );
};

export default ReminderNotificationManagement;
