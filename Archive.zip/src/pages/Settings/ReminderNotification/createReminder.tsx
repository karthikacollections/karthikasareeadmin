import React, { useState, useRef, useEffect } from "react";
import { Form,  Input, Button,  Space, message, Row,Upload, Col } from 'antd';
import { useMutation, useQuery } from "@apollo/client";
import { GET_REMINDER_NOTIFICATION,INSERT_REMINDER_DAYS,UPDATE_REMINDER_DAYS,
} from "@/helpers";
import dayjs from "dayjs";
import { DeleteOutlined, UploadOutlined } from "@ant-design/icons";
const { Dragger } = Upload;




// interface CreateReminderaddProps {
//   ModalClose: (arg: any) => void;
//   editdraw: any;
//   showModal: (message: string) => void; // Add showModal to the interface
// }

const CreateReminderadd: React.FC<any> = ({ ModalClose, editdraw,showModal}) => {
  const [user, setUser] = useState<any[]>([]);
  const formRef = useRef<any>(null);
  const [form] = Form.useForm();
  const [editforminitaldata, seteditforminitaldata] = useState<any>(false);
  const [formtype, setformtype] = useState<string>("create");
  const [urlLogo, seturllogo] = useState<string[]>([]);
  const [loadingMP, setLoading] = useState(false);
  const [urlQrcode, seturlQrcode] = useState<string[]>([]);
  const [loadingMPs, setLoadings] = useState(false);
  const [modalImageOpen, setModalImageOpen] = useState<boolean>(false);
  const [modalImage, setModalImage] = useState<any>(null);
  const [initialLogo, setInitialLogo] = useState<string[]>([]);
  const [initialQrcode, setInitialQrcode] = useState<string[]>([]);

  const [updateReminder,{ loading: updateloade, error: updateError, data: updateData },] = useMutation(UPDATE_REMINDER_DAYS, { errorPolicy: "all",});

  const {error,loading,data: announData, refetch: refetchReminder, } = useQuery(GET_REMINDER_NOTIFICATION);

  useEffect(() => {
    if (announData) {
      let add = announData?.mst_company_details;
      setUser(add);
    }
  }, [announData]);

  const [
    createReminder,
    { loading: AnnounceLoading, error: AnnounceError, data: AnnounceData },
  ] = useMutation(INSERT_REMINDER_DAYS, {
    errorPolicy: "all",
  });
  const ImageUploaderProp: any = {
    
    name: "file",
    multiple: true,
    action: "https://www.mocky.io/v2/5cc8019d300000980a055e76",
    onChange(info: any) {
      const { status } = info.file;
      if (status !== "uploading") {
      }
      if (status === "done") {
        message.success(`${info.file.name} file uploaded successfully.`);
      } else if (status === "error") {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
  };
  
  const uploadLogo = async (options: any) => {
    const { onSuccess, onError, file } = options;
    try {
      setLoading(true);
      const data = new FormData();
      data.append("upload_preset", "Employee");
      data.append("file", file);
      data.append("cloud_name", "dgcgmcaxb");
  
      fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
        method: "post",
        body: data,
        redirect: 'follow',
      })
        .then((resp) => resp.json())
        .then((data) => {
          seturllogo((urlLogo) => [...urlLogo, data.url]);
          setLoading(false);
          onSuccess("Ok");
          
        })
        .catch((err) => {
          setLoading(false);
          onError(err);
        });
      onSuccess("Ok");
    } catch (err) {
      const error = new Error("Some error");
      onError({ err });
    }
  };
  
  const uploadQrcode = async (options: any) => {
    const { onSuccess, onError, file } = options;
    try {
      setLoadings(true);
      const data = new FormData();
      data.append("upload_preset", "Employee");
      data.append("file", file);
      data.append("cloud_name", "dgcgmcaxb");
  
      fetch("https://api.cloudinary.com/v1_1/dgcgmcaxb/image/upload", {
        method: "post",
        body: data,
        redirect: 'follow',
      })
        .then((resp) => resp.json())
        .then((data) => {
          seturlQrcode((urlQrcode) => [...urlQrcode, data.url]);
          setLoadings(false);
        })
        .catch((err) => {
          setLoadings(false);
          onError(err);
        });
      onSuccess("Ok");
    } catch (err) {
      const error = new Error("Some error");
      onError({ err });
    }
  };
  
  const handleBeforeUpload = (file: any) => {
    const fileSizeInMB = file.size / 1024 / 1024;
    const maxFileSizeInMB = 2;
    if (fileSizeInMB > maxFileSizeInMB) {
      message.error(`File size must be within ${maxFileSizeInMB}MB!`);
      return false;
    }
    return true;
  };
  
  const modalImageView = (LinkBox: any) => {
    setModalImageOpen(!modalImageOpen);
    setModalImage(LinkBox);
  };
  
  const modalImageClose = () => {
    setModalImageOpen(!modalImageOpen);
    setModalImage(null);
  };
  
  const deleteRes = async (images: any) => {
    let filteredImage = urlLogo?.filter((e) => e !== images);
    seturllogo(filteredImage);
  };
  
  const deleteRess = async (images: any) => {
    let filteredImage = urlQrcode?.filter((e) => e !== images);
    seturlQrcode(filteredImage);
  };

  const onFinishFailed = (error: any) => {
  };

  useEffect(() => {
    if (editdraw) {
      let data = JSON.parse(JSON.stringify(editdraw));
      setInitialLogo(data?.company_logo ? [data.company_logo] : []);
      setInitialQrcode(data?.qr_code ? [data.qr_code] : []);
      seturllogo(data?.company_logo ? [data.company_logo] : []);
    seturlQrcode(data?.qr_code ? [data.qr_code] : []);
      form.setFieldsValue({
        company_name: data.company_name,
      company_address: data.company_address,
      gst_no: data.gst_no,
      phone_number: data.phone_number,
      bank_name: data.bank_name,
      account_number: data.account_number,
      days: data.days,
      gst_percent: data.gst_percent,
        company_logo: data.company_logo,
        qr_code: data.qr_code,
      });
      setformtype("edit");
      seteditforminitaldata(data);
    }
  }, [editdraw]);

  const onFinish = (values: any,) => {

    if (editdraw) {
        values.id = editdraw?.id
        values.company_logo = urlLogo[0];
        values.qr_code = urlQrcode[0];

        updateReminder({
            variables: values,
        }).then((response) => {
        showModal("Updated")
            refetchReminder();
            ModalClose(null);
            message.success(`Update Company Details`);
            
        })
        .catch((error) => {
          // Handle error if needed
          message.error("Check the Fileds");
        });
    }
    else {
      values.company_logo = urlLogo.length > 0 ? urlLogo[0] : initialLogo[0];
      values.qr_code = urlQrcode.length > 0 ? urlQrcode[0] : initialQrcode[0];
      createReminder({
            variables: values,
        }).then((response) => {
        
            showModal("Created")
            refetchReminder();
            message.success(`Add New Details`);
            ModalClose(null)
          })
          .catch((error) => {
            // Handle error if needed
        });
    };
}


  return (
    <div>
      <Form
        name="basic"
        layout="vertical"
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        form={form}
        ref={formRef}
        className="assets_form"
      >
        <Form.Item
          label="Company Name"
          name="company_name"
          required={false}
          rules={[{ required: true, message: "Please enter Company Name" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>
        <Form.Item
          label="Address"
          name="company_address"
          required={false}
          rules={[{ required: true, message: "Please enter Address" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>
        <Form.Item
          label="GST No."
          name="gst_no"
          required={false}
          rules={[{ required: true, message: "Please enter GST Number" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>
        <Form.Item
          label="Phone Number"
          name="phone_number"
          required={false}
          rules={[{ required: true, message: "Please enter Phone Number" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>
        <Form.Item
          label="Bank Name"
          name="bank_name"
          required={false}
          rules={[{ required: true, message: "Please enter Bank Name" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>
        <Form.Item
          label="Account Number"
          name="account_number"
          required={false}
          rules={[{ required: true, message: "Please enter Account Number" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>

        <Form.Item
          label="Bookings Reminder Notification (In Days)"
          name="days"
          required={false}
          rules={[{ required: true, message: "Please enter Reminder Days" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>
        <Form.Item
          label="Remind"
          name="remind"
          required={false}
          rules={[{ required: true, message: "Please enter Remind Days" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>
        <Form.Item
          label="GST(in %)"
          name="gst_percent"
          required={false}
          rules={[{ required: true, message: "Please enter GST(in %)" }]}
          className="assets_form_item"
        >
          <Input className="assets_form_item-input" />
        </Form.Item>
          <Row gutter={16}>
          <Col span={12}>
          <Form.Item
                            label="Logo"
                            name="company_logo"
                        > 
                        {urlLogo.length === 0 && (
                            <Dragger
                                {...ImageUploaderProp}
                                name="file"
                                beforeUpload={handleBeforeUpload}
                                showUploadList={false}
                                customRequest={uploadLogo}
                                className="dragger"
                                style={{ width: "100%", border: "2px dashed #7FACD6" }}
                                maxCount={1}
                            >
                                <UploadOutlined className="employee-details_uploade-photo" />
                                <p>Drag & drop or Browse</p>
                            </Dragger>
                        )}
                            {
                                urlLogo?.map((values) => {
                                    const filename = values?.split('/').pop();

                                    return <>
                                        <div className='employee-details_photodelete' >
                                            <img src={values} alt="profile" width={45} height={45} onClick={() => modalImageView(values)}/>
                                            <p className='employee-details_photodelete-para' >{filename}</p>
                                            <DeleteOutlined onClick={() => deleteRes(values)} className='employee-details_delete_icon' />
                                        </div>
                                    </>
                                })
                            }
                        </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item label="QR Code" name="qr_code">
            {urlQrcode.length === 0 && (
                            <Dragger
                                {...ImageUploaderProp}
                                name="file"
                                beforeUpload={handleBeforeUpload}
                                showUploadList={false}
                                customRequest={uploadQrcode}
                                className="dragger"
                                style={{ width: "100%", border: "2px dashed #7FACD6" }}
                                maxCount={1}
                            >
                                <UploadOutlined className="employee-details_uploade-photo" />
                                <p>Drag & drop or Browse</p>
                            </Dragger>
                        )}
                            {
                                urlQrcode?.map((values) => {
                                    const filename = values?.split('/').pop();

                                    return <>
                                        <div className='employee-details_photodelete' >
                                            <img src={values} alt="profile" width={45} height={45} onClick={() => modalImageView(values)}/>
                                            <p className='employee-details_photodelete-para' >{filename}</p>
                                            <DeleteOutlined onClick={() => deleteRess(values)} className='employee-details_delete_icon' />
                                        </div>
                                    </>
                                })
                            }
                        </Form.Item>
      
          </Col>
        </Row>

        <Form.Item>
          <div className="assets_submit">
            <Space>
              <Button
                htmlType="button"
                className="assets_cancel-btn"
                onClick={() => ModalClose(null)}
              >
                Cancel
              </Button>
              <Button htmlType="submit" className="assets_submit-btn">
                Submit
              </Button>
            </Space>
          </div>
        </Form.Item>
      </Form>
    </div>
  );
};

export default CreateReminderadd;
