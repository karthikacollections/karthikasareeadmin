import React, { ReactNode } from 'react';
import SettingsNav from '../../components/Side_Nav/Settingsnav';

type SettingsLayoutProps = {
  children: ReactNode;
};

const SettingsLayout: React.FC<SettingsLayoutProps> = ({ children }) => {
  return (
    <div className='setting_nav '>
      {/* <div>
        <SettingsNav />
      </div> */}
      <div className='settings_style'>
        {children}
      </div>
    </div>
  );
};

export default SettingsLayout