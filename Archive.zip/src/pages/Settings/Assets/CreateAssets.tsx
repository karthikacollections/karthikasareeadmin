import { Button, Form, Select, message, DatePickerProps, TimePickerProps, DatePicker, TimePicker, Space, Input, } from 'antd';
import React, { useEffect, useState, useRef } from 'react';
import { GET_ASSET } from '../../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import { CREATE_ASSET, UPDATE_ASSET } from "../../../helpers/mutation"

import dayjs from "dayjs";
import moment from 'moment';

export const Employee: React.FC<any> = ({ ModalClose, editdraw, login,showModal }) => {
    const [form] = Form.useForm();
    const formRef = useRef(null);

    const { TextArea } = Input;
    const [createAsset, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_ASSET, {
        errorPolicy: 'all',
    });

    const [updateAsset, { loading: updateLoading, error: updateError, data: updateDataAddress }] = useMutation(UPDATE_ASSET, {
        errorPolicy: 'all',
    });

    
    const {
        error: countError,
        loading: countLoading,
        data: dataCount,
        refetch: refetasset,
    } = useQuery(GET_ASSET, {
        variables: {},
    });

    const onFinish = (values: any,) => {

        if (editdraw) {
            values.id = editdraw?.id
        

            updateAsset({
                variables: values,
            }).then((response) => {
                showModal("Updated")
                refetasset()
                ModalClose(null)
            });
        }
        else {
            
            createAsset({
                variables: values,
            }).then((response) => {
                showModal("Created")
                refetasset()
                ModalClose(null)
            });
        };
    }

    useEffect(() => {
        form.setFieldsValue(editdraw)
    }, [editdraw])
    
    const onFinishFailed = (errorInfo: any) => {
    };

    return (
        <div>
            <Form
                name="basic"
                layout="vertical"
                initialValues={{ remember: true }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                ref={formRef}
                className="assets_form"

            >

                <Form.Item label="Property Type" 
                name="property_type"
                required={false}
                rules={[{ required: true, message: 'Please select type' }]}
                className="assets_form_item"
                >
                    <Select className="assets_form_item-input">
                        <Select.Option value="Laptop">Laptop</Select.Option>
                        <Select.Option value="CPU">CPU</Select.Option>
                        <Select.Option value="Mobile">Mobile</Select.Option>
                        <Select.Option value="Monitor">Monitor</Select.Option>
                        <Select.Option value="Keyboard">Keyboard</Select.Option>
                        <Select.Option value="Mouse">Mouse</Select.Option>
                        <Select.Option value="Headphone">Headphone</Select.Option>
                        <Select.Option value="Others">Others</Select.Option>
                    </Select>
                </Form.Item>

                <Form.Item 
                label="Serial Number"
                name="serialno"
                required={false}
                rules={[{ required: true, message: 'Please enter Serial Number' }]}
                className="assets_form_item"
                >
                    <Input className="assets_form_item-input"/>
                </Form.Item>

                <Form.Item label="Brand" 
                name="brand"
                required={false}
                rules={[{ required: true, message: 'Please select brand' }]}
                className="assets_form_item">
                    <Select className="assets_form_item-input">
                        <Select.Option value="Apple">Apple</Select.Option>
                        <Select.Option value="Dell">Dell</Select.Option>
                        <Select.Option value="HP">HP</Select.Option>
                        <Select.Option value="Lenevo">Lenevo</Select.Option>
                        <Select.Option value="Samsung">Samsung</Select.Option>
                        <Select.Option value="others">Others</Select.Option>
                    </Select>
                </Form.Item>

                <Form.Item label="Model"
                name="model"
                required={false}
                rules={[{ required: true, message: 'Please enter model no' }]}
                className="assets_form_item"
                >
                    <Input className="assets_form_item-input" />
                </Form.Item>

                <Form.Item label="Color"
                name="color"
                required={false}
                rules={[{ required: true, message: 'Please select color' }]}
                className="assets_form_item">
                    <Select className="assets_form_item-input">
                        <Select.Option value="Black">Black</Select.Option>
                        <Select.Option value="Silver">Silver</Select.Option>
                        <Select.Option value="White">White</Select.Option>
                        <Select.Option value="Others">Others</Select.Option>


                    </Select>
                </Form.Item>

                <Form.Item label="Description"
                name="description"
                required={false}
                rules={[{ required: true, message: 'Please enter description' }]}
                className="assets_form_item">
                    <TextArea rows={4}
                    className="assets_form_item-input"
                    />
                </Form.Item>

                <Form.Item >
                        <div className="assets_submit">
                            <Space>
                                <Button htmlType="button" className="assets_cancel-btn" onClick={() => ModalClose(null)}>
                                    Cancel
                                </Button>
                                <Button htmlType="submit" className="assets_submit-btn">
                                    Submit
                                </Button>
                            </Space>
                        </div>
                    </Form.Item>

            </Form>
        </div>
    )
}

export default Employee