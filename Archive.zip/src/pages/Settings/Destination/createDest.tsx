import { Button, Form, Input,Space } from 'antd';
import React, { useEffect, useState, useRef } from 'react';
import { CREATE_DESTNATION, UPDATE_DESTINATION, } from "../../../helpers/mutation";
import { useMutation, useQuery } from "@apollo/client";
import { GET_DESTINATION } from '../../../helpers/queries'



interface DataType {
    key: string;
    name: String;
}

export const creatDest: React.FC<any> = ({ ModalClose, editdraw,showModal }) => {

    const [form] = Form.useForm();
    const formRef = useRef(null);
    // create destination
    const [createDestination, { loading: contactLoading, error: contactError, data: contactDataAddress }] = useMutation(CREATE_DESTNATION, {
        errorPolicy: 'all',
    });

    // edit destination
    const [
        updateDestination,
        { loading: updateloading, error: updateerror, data: updatedataAddress },
    ] = useMutation(UPDATE_DESTINATION, {
        errorPolicy: "all",
    });


    // get destination
    const {
        error: userError,
        loading: userLoading,
        data: datadestination,
        refetch: refetdestination,
    } = useQuery(GET_DESTINATION, {
        variables: {},
    });

    useEffect(() => {
        form.setFieldsValue(editdraw)
    }, [editdraw])

    const onFinish = (values: any) => {
        if (editdraw) {
            values.id = editdraw?.id
            updateDestination({
                variables: values,
            }).then((response) => {
               showModal("Updated")
                refetdestination()
                ModalClose(null)
                // setOpen(false)
            });
        }
        else {
            createDestination({
                variables: values,
            }).then((response) => {
                showModal("Created")
                ModalClose(null)
                refetdestination()
                // setOpen(false)
            });
        };
    }




    const onFinishFailed = (errorInfo: any) => {
    };

    return (

        <>
            <Form
                name="basic"
                layout="vertical"
                initialValues={{ remember: true }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                form={form}
                ref={formRef}
                className="Destination_form"
            >
                <Form.Item
                    label="Designation"
                    name="name"
                    required={false}
                    rules={[{ required: true, message: 'Please enter Designation' }]}
                    className="Destination_form_item"
                >
                    <Input className="Destination_form_item-input"/>
                </Form.Item>

                <Form.Item >
                    <div className="Destination_submit">
                        <Space>
                            <Button htmlType="button" className="Destination_cancel-btn" onClick={() => ModalClose(null)}>
                                Cancel
                            </Button>
                            <Button htmlType="submit" className="Destination_submit-btn">
                                Submit
                            </Button>

                        </Space>

                    </div>
                </Form.Item>
            </Form>
        </>
    )
}
export default creatDest