
import withApollo from '../../../config'
import React, { useEffect, useState, } from 'react';
import { Space, Table, Button, Popconfirm, Drawer,Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import { GET_DESTINATION } from '../../../helpers/queries'
import { useQuery, useMutation } from "@apollo/client";
import { DELETE_DESTINATION } from "../../../helpers/mutation";
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import CreateDest from "./createDest";
import moment from "moment";
import SettingsLayout from '../settingslayout';
import {useAuth} from '../../../components/auth'
import PopImage from "../../../assets/photos/tick-circle.jpg";
import Image from "next/image";
import { message } from 'antd';

interface DataType {
    key: string;
    name: String;
}



export const Destination: React.FC = () => {

    
    const [dest, setDest] = useState([])
    const [open, setOpen] = useState<any>(null);
    const [editdraw, setEditdraw] = useState("");
    const { check_button_permission,filteredColumns } = useAuth()
    const [Popopen, setPopOpen] = useState(false);
    const [title, setTitle] = useState("");

    const showModal = (param: any) => {
        setPopOpen(true);
        setTitle(param);
      };
      
      const handleOk = () => {
        refetdestination();
        setPopOpen(false);
      };
    
      const handleCancel = () => {
        setPopOpen(false);
      };
    

    const ModalClose = () => {
        setOpen(false)
        refetdestination()
    }

    //get destination
    const {
        error: userError,
        loading: userLoading,
        data: datadestination,
        refetch: refetdestination,
    } = useQuery(GET_DESTINATION, {
        variables: {},
    });

    useEffect(() => {
        if (datadestination) {
            console.log(datadestination);
            
            let des = datadestination?.mst_destination
            setDest(des)
        }
    }, [datadestination])

    // delete destination
    const [deleteDestination, { loading, error, data }] = useMutation(DELETE_DESTINATION);
    const handleDelete = (id: any) => {
        deleteDestination({
            variables: id,

            update: (cache: any) => {
                refetdestination()
            },
        }).then((res:any)=>{

        }).catch((err:any) => message.error("This Designation linked with some other data's, We can't delete this designation right now!"))
    };


    const handleChange = (record: any) => {
        setEditdraw(record)
        setOpen("Edit")
    }

    var count=0
    const columns: ColumnsType<DataType> = [
        {
            title:'S.no',
            dataIndex: 's.no',
            render: () =>++count,
        },
        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: 'Created At',
            render: (value: any) =>{
                let passWordFormat=  moment(value?.createdat).format("DD MMMM YYYY");

                return(
                <>
                    <p>{passWordFormat}</p>
                </>
              )  }

        },

        {
            title: 'Action',
            key: 'action',
            render: (_, record) => (
                <Space size='large'>
                    {
                        check_button_permission("Destination", "edit")
                            ?
                        <EditOutlined
                            onClick={() => handleChange(record)}
                            className="Destination_edit"
                        />:<></>
                    }


                    {
                        check_button_permission("Destination", "delete")
                            ?
                        <Popconfirm
                            title="Delete the task"
                            description="Are you sure to delete this task?"
                            okText="Yes"
                            cancelText="No"
                            onConfirm={() => handleDelete(record)}
                        >
                            <DeleteOutlined className="Destination_delete" />
                        </Popconfirm>:<></>
                    }



                </Space>
            ),
        },
    ];


    return (
        <SettingsLayout>
            <div className="Destination">
                <div className="Destination_head">
                    <h2 className="Destination_head-text">Designation</h2>
                    {
                        check_button_permission("Destination", "create")
                            ?
                        <Button className="Destination_head-create" onClick={() => setOpen("Create")}>+ Add new Designation</Button>
                        :<></>
                    }
                </div>
                <Table columns={filteredColumns(columns,"Destination")} dataSource={dest} pagination={{pageSize: 10}} className="Destination_tale" />
                <Drawer title={`${open} Designation`} width={570} placement="right" onClose={() => setOpen(false)} open={open?.length > 1 ? true : false}>
                    {
                        open == "Edit" ? (<CreateDest ModalClose={ModalClose} showModal={showModal} editdraw={editdraw} />) : <></>
                    }
                    {
                        open == "Create" ? (<CreateDest ModalClose={ModalClose} showModal={showModal} editdraw={null} />) : <></>
                    }
                </Drawer>
            </div>
            <Modal
        open={Popopen}
        title=""
        onOk={handleOk}
        onCancel={handleCancel}
        footer={[
          <div style={{display: "flex", justifyContent: "center"}}>
            <Button
              key="submit"
              type="primary"
              loading={loading}
              onClick={handleOk}
              style={{
                display: "flex",
                width: "206px",
                padding: "15px 30px",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                borderRadius: "8px",
                background: "#252947",
              }}>
              OK
            </Button>
          </div>,
        ]}
        width={"386px"}>
        <Space
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}>
          <Image
            src={PopImage}
            alt="image"
            style={{
              width: "150px",
              height: "150px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          />
          <p
            style={{
              color: "#101010",
              textAlign: "center",
              fontFamily: "revert",
              fontSize: "32px",
              fontStyle: "normal",
              fontWeight: "700",
              lineHeight: "normal",
            }}>
            {`${title}`} Successfully
          </p>
        </Space>
      </Modal>
        </SettingsLayout>
    )
}
export default Destination
