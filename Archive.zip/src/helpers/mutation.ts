import { gql } from '@apollo/client'
import { SHOP_ID } from "../utils/constants";


export const CREATE_EMPLOYDETAILS = gql`
  mutation MyMutation(
    $name: String,
    $email: String,
    $destination: uuid,
    $pan_photos: String,
    $experience_letter: String,
    $resume: String,
    $education_photo: String,
    $doj: String,
    $adhar: String,
    $pan: String,
    $education: String,
    $role: uuid,
    $image: String,
    $referral: String,
    $organization: uuid,
    $department: uuid,
    $adhaar_photo: String,
    $phone:String,
    $gender:String,
    $dob: String,
    $employeeid: String,
    $marital_status: String,
    $blood_group: String
  ) {
    insert_mst_employeedetails(
      objects: {
        name: $name,
        email: $email,
        destination: $destination,
        doj: $doj,
        pan_photos: $pan_photos,
        education_photo: $education_photo,
        experience_letter: $experience_letter,
        adhar: $adhar,
        pan: $pan,
        education: $education,
        organization: $organization
        department: $department
        role: $role,
        image: $image,
        referral: $referral,
        resume: $resume,
        adhaar_photo: $adhaar_photo,
        phone:$phone,
        dob:$dob,
        gender:$gender
        employeeid:$employeeid
        marital_status:$marital_status
        blood_group:$blood_group

      }
    ) {
      affected_rows
    }
  }
`;



export const UPDATE_EMPLOYDETAILS = gql`
  mutation MyMutation(
    $name: String,
    $id: uuid,
    $destination: uuid,
    $doj: String,
    $department:uuid
    $adhar: String,
    $pan: String,
    $pan_photos: String,
    $education_photo: String,
    $organization:uuid,
    $experience_letter: String,
    $resume: String,
    $education: String,
    $role: uuid,
    $image: String,
    $referral: String,
    $email:String,
    $phone:String,
    $adhaar_photo: String,
    $gender:String,
    $dob: String,
    $employeeid: String,
    $marital_status: String,
    $blood_group: String
  ) {
    update_mst_employeedetails(
      where: { id: { _eq: $id } }
      _set: {
        name: $name,
        destination: $destination,
        doj: $doj,
        adhar: $adhar,
        email:$email
        pan: $pan,
        department: $department,
        organization: $organization,
        education: $education,
        role: $role,
        image: $image,
        referral: $referral,
        adhaar_photo: $adhaar_photo,
        pan_photos: $pan_photos,
        education_photo: $education_photo,
        experience_letter: $experience_letter,
        resume: $resume,
        phone:$phone,
        dob:$dob,
        gender:$gender,
        employeeid:$employeeid
        marital_status:$marital_status
        blood_group:$blood_group
      }
    ) {
      affected_rows
    }
  }
`;



export const DELETE_EMPLOYDETAILS = gql`
mutation MyMutation ($id:uuid)  {
  delete_mst_employeedetails(where: {id: {_eq: $id}}) {
    affected_rows
  }
}

`;

export const UPDATE_DELETE_EMPLOYEEDETAILS = gql`
mutation MyMutation ($id:uuid, $isdeleteat:Boolean){
  update_mst_employeedetails(where: {id: {_eq: $id}}, _set: {isdeleteat: $isdeleteat}) {
    affected_rows
  }
}
`
export const UPDATE_STATUS_EMPLOYEEDETAILS = gql`
mutation MyMutation ($id:uuid, $status:Boolean){
  update_mst_employeedetails(where: {id: {_eq: $id}}, _set: {status: $status}) {
    affected_rows
  }
}
`
export const UPDATE_EMPLOYEE_DOR = gql`
mutation MyMutation ($id:uuid, $dor:timestamptz){
  update_mst_employeedetails(where: {id: {_eq: $id}}, _set: {dor: $dor}) {
    affected_rows
  }
}
`



export const CREATE_EMPLOYEE = gql`
mutation MyMutation($name: String,  $age: Int, $experience: Int) {
  insert_mst_employee(objects: {name: $name,  age: $age, experience: $experience}) {
    affected_rows
    returning {
      age
      name
      experience
    }
  }
}
`;

export const CREATE_DESTNATION = gql`
mutation MyMutation($name: String) {
  insert_mst_destination(objects: {name: $name}) {
    affected_rows
  }
}
`
export const CREATE_ROLE = gql`
mutation MyMutation($name:String) {
  insert_mst_role(objects: {name:$name}) {
    affected_rows
  }
}
`

export const UPDATE_EMPLOYEE = gql`
  mutation MyMutation($name: String, $sno: Int, $age: Int, $experience: Int, $id: uuid) {
    update_mst_employee(
      where: { id: { _eq: $id } }
      _set: { name: $name, age: $age, experience: $experience }
    ) {
      affected_rows
    }
  }
`;

export const UPDATE_DESTINATION = gql`
mutation MyMutation($name: String, $id: uuid) {
  update_mst_destination(where: {id: {_eq: $id},}, _set: {type:$type}) {
    affected_rows
  }
}
`

export const UPDATE_ROLE = gql`
mutation MyMutation($type: String, $permission: jsonb, $id: uuid) {
  update_mst_role(where: {id: {_eq: $id}}, _set: {type: $type, permission: $permission}) {
    affected_rows
  }
}
`


export const DELETE_DESTINATION = gql`
mutation MyMutation($id:uuid) {
  delete_mst_destination(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`
export const DELETE_ROLE = gql`
mutation MyMutation($id:uuid) {
  delete_mst_role(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`

export const DELETE_EMPLOYEE = gql`
mutation MyMutation($id:uuid) {
  delete_mst_employee(where: {id: {_eq:$id}}) {
    affected_rows
  }
}

`

export const CREATE_ATTENDANCE = gql`

mutation MyMutation($logintime: String, $logouttime: String, $date: String, $employee:uuid) {
  insert_mst_attendance(objects: {logintime: $logintime, logouttime: $logouttime, date: $date, employee: $employee}) {
    affected_rows
  }
}

`
export const UPDATE_ATTENDANCE = gql`

mutation MyMutation($id: uuid, $logintime: String, $logouttime: String, $date: String, $employee: uuid) {
  update_mst_attendance(where: {id: {_eq: $id}}, _set: {logintime: $logintime, logouttime: $logouttime, date: $date, employee: $employee}) {
    affected_rows
  }
}
`

export const DELETE_ATTENDANCE = gql`
mutation MyMutation($id:uuid) {
  delete_mst_attendance(where: {id: {_eq:$id}}) {
    affected_rows
  }
}
`
export const SIGNUP_MUTATION = gql`
mutation MyMutation ($email:String , $password:String) {
  insert_mst_user(objects: {email:$email, password:$password}) {
    affected_rows
  }
}
`


export const LOGIN_MUTATION = gql`
  mutation Login($email: String, $password: String) {
    mst_user(where: { email: { _eq: $email }, password: { _eq: $password } }) {
      id
      email
    }
  }
`;

export const CREATE_USER = gql`mutation MyMutation($email: String!, $password: String!) {
  insert_mst_user(objects: {email: $email, password: $password}) {
    returning {
      id
    }
  }
}
`




// export const GETUSER_QUERY = gql`
// query MyQuery($email: String!) {
//   mst_employeedetails(where: { email: { _eq: $email } }) {
//     id
//     name
//     mst_role {
//       id
//       permission
//       type
//       createdat
//     }
//   }
// }
// `;
// ;



export const GETUSER_QUERY = gql`
query MyQuery($email: String!) {
  mst_employeedetails(where: { email: { _eq: $email } }) {
    name
    email
    referral
    destination
    adhaar_photo
    pan_photos
    education_photo
    experience_letter
    resume
    isdeleteat
    mst_destination {
      name
    }
    doj
    id
    dob
    adhar
    pan
    education
    role
    image
    organization
    department
    gender
    status
    mst_role {
      id
      permission
      type
      createdat
    }
    mst_employeedetails_mst_timesheets {
      date
      seconds
      id
      in_time
      out_time
      checkin_location
    }
    mst_employeedetails_mst_salarymanagements {
      final_pay
      id
      employee
      salary
    }
    mst_employeedetails_mst_salary_payments {
      emp
      emp_working_days
      id
      paid_on
      payment
      status
      working_days
    }
    mst_organization {
      name
      description
      longitude
      latitude
    }
    mst_department {
      department_name
      id
    }
  }
}
`;
;

// Assets

export const CREATE_ASSET = gql`
mutation MyMutation ($property_type: String, $brand: String, $model: String, $color: String, $description:String, $serialno: String ) {
  insert_mst_assets(objects: {property_type: $property_type, brand:$brand, model: $model, color: $color, description:$description, serialno:$serialno}) {
    affected_rows
  }
}
`
export const DELETE_ASSET = gql`
mutation MyMutation($id: uuid) {
  delete_mst_assets(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`

export const UPDATE_ASSET = gql`
mutation MyMutation ($id:uuid, $property_type:String, $brand: String,  $model: String,$color: String,$description:String, $serialno: String) {
  update_mst_assets(where: {id: {_eq: $id}}, _set: {property_type: $property_type, brand: $brand, model: $model, color: $color, description: $description, serialno:$serialno}) {
    affected_rows
  }
}
`

// Assets Management

export const CREATE_ASSTMANAGE = gql`
mutation MyMutation($employee: uuid, $property_type: uuid) {
  insert_mst_asstmanage(objects: {employee: $employee, property_type: $property_type}) {
    affected_rows
  }
}
`
export const UPDATE_ASSTMANAGE = gql`
mutation MyMutation ($id: uuid, $employee: uuid, $property_type: uuid) {
  update_mst_asstmanage(where: {id: {_eq: $id}}, _set: {employee: $employee, property_type:$property_type}){
    affected_rows
  }
}

`
export const DELETE_ASSTMANAGE = gql`
mutation MyMutation ($id: uuid) {
  delete_mst_asstmanage(where: {id: {_eq: $id}}){
    affected_rows
  }
  
}

`

// Expense

export const CREATE_EXPENSE = gql`
mutation MyMutation ($date: timestamp, $expense: Int,  $reason: String){
  insert_mst_expense(objects: {date:$date , expense:$expense ,  reason: $reason}) {
    affected_rows
  }
}
`
export const CREATE_HOLIDAY = gql`
mutation MyMutation ($reason: String, $date: date) {
  insert_mst_holidaymanagement(objects: { date: $date, reason: $reason }) {
    affected_rows
  }
}
`;

export const UPDATE_EXPENSE = gql`
mutation MyMutation ($id:uuid, $reason: String, $expense: Int , $date: timestamp){
  update_mst_expense(where: {id:{_eq: $id}}, _set: {reason: $reason,  expense: $expense, date:$date }) {
    affected_rows
  }
}
`
export const UPDATE_HOLIDAY = gql`
mutation MyMutation($id: uuid, $date: date, $reason: String) {
  update_mst_holidaymanagement(where: {id: {_eq: $id}}, _set: {date: $date, reason: $reason} ) {
    affected_rows
  }
}
`

export const DELETE_HOLIDAY = gql`
mutation MyMutation ($id: uuid) {
  delete_mst_holidaymanagement(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`

export const DELETE_EXPENSE = gql`
mutation MyMutation ($id:uuid) {
  delete_mst_expense(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`

export const UPDATE_DELETE_EXPENSE = gql`
mutation MyMutation($id:uuid, $isdeleteat:Boolean) {
  update_mst_expense(where: {id: {_eq: $id}}, _set: {isdeleteat: $isdeleteat}) {
    affected_rows
  }
}
`

export const DELETE_ORGANIZATION = gql`
  mutation MyMutation($id: uuid) {
    delete_mst_organization(where: { id: { _eq: $id } }) {
      affected_rows
    }
  }
`;

export const CREATE_ORGANIZATION = gql`
mutation MyMutation ($description: String,$name:String,$latitude:String,$longitude:String){
  insert_mst_organization(objects: {name:$name, description: $description,longitude:$longitude,latitude:$latitude}) {
    affected_rows
  }
}
`

export const UPDATE_ORGANIZATION = gql`
mutation MyMutation($description: String, $name: String, $id:uuid,$latitude:String,$longitude:String) {
  update_mst_organization(where: {id: {_eq: $id}}, _set: {name: $name, description: $description,longitude:$longitude,latitude:$latitude}) {
    affected_rows
  }
}
`


export const CREATE_SALARYMANAGEMENT = gql`
mutation MyMutation ($basic_salary: Int, $conveyance_allowance: Int, $employee: uuid,
  $esi: Int, $medical_allowance: Int, $rent_allowance: Int, $special_allowance: Int,  $final_pay:Int, $salary: Int
  ) {
  insert_mst_salarymanagement(objects: {
    salary:$salary,
    rent_allowance: $rent_allowance , special_allowance: $special_allowance
    basic_salary: $basic_salary, 
    conveyance_allowance:$conveyance_allowance, 
    employee: $employee, 
    esi: $esi, medical_allowance: $medical_allowance, final_pay: $final_pay, }) {
    affected_rows
  }
}
`
export const DELETE_DEPARTMENT = gql`
mutation MyMutation($id:uuid) {
  delete_mst_department(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`


export const DELETE_SALARYMANAGEMENT = gql`
mutation MyMutation($id: uuid) {
  delete_mst_salarymanagement(where: {id: {_eq: $id}}) {
    affected_rows
  }
}

`

export const UPDATE_SALARYMANAGEMENT = gql`
  mutation MyMutation(
    $id: uuid,
    $salary: Int,
    $conveyance_allowance: Int,
    $basic_salary: Int,
    $esi: Int,
    $final_pay: Int,
    $medical_allowance: Int,
    $rent_allowance: Int,
    $special_allowance: Int,
    $employee: uuid
  ) {
    update_mst_salarymanagement(
      _set: {
        salary:$salary
        basic_salary: $basic_salary,
        conveyance_allowance: $conveyance_allowance,
        esi: $esi,
        final_pay: $final_pay,
        medical_allowance: $medical_allowance,
        rent_allowance: $rent_allowance,
        special_allowance: $special_allowance,
        employee: $employee
      },
      where: { id: { _eq: $id } }
    ) {
      affected_rows
    }
  }
`

export const CREATE_SKILLSMANAGE = gql`
mutation MyMutation ($name:String,$type:String){
  insert_mst_skillsmanage(objects: {name:$name, type: $type}) {
    affected_rows
  }
}
`

export const UPDATE_SKILLSMANAGE = gql`


mutation MyMutation($id: uuid, $name: String, $type: String) {
  update_mst_skillsmanage(where: {id: {_eq: $id}}, _set: {name: $name, type: $type}) {
    affected_rows
  }
}

`

export const DELETE_SKILLSMANAGE = gql`
mutation MyMutation($id:uuid) {
  delete_mst_skillsmanage(where: {id: {_eq:$id}}) {
    affected_rows
  }
}
`
export const CREATE_SALARY_PAYMENT = gql`
mutation MyMutation($emp: uuid, $emp_working_days:Int, $paid_on: date, $paid_for: date,$payment: Int, $working_days: Int, $status: Boolean) {
  insert_mst_salary_payment(objects: {emp: $emp, emp_working_days: $emp_working_days, paid_on: $paid_on,  paid_for: $paid_for, payment: $payment, working_days: $working_days, status: $status}) {
    affected_rows
  }
}
`

export const UPDATE_SALARY_PAYMENT = gql`
mutation MyMutation($id:uuid,$status: Boolean)
{update_mst_salary_payment (where: { id: { _eq: $id } }  _set: {status:$status}){
  affected_rows
}}`

export const CREATE_CLIENT = gql`
mutation MyMutation($address: String, $company_name:String,$email:String,$gst:String,$phone_number:String,$name:String) {
  insert_mst_clientmanagement(objects: {address:$address, company_name:$company_name,
    email:$email, gst:$gst, name:$name, phone_number: $phone_number}) {
    affected_rows
  }
}`

export const UPDATE_CLIENT = gql`
mutation MyMutation(
  $id: uuid,
  $address: String,
  $company_name: String,
  $email: String,
  $gst: String,
  $name: String,
  $phone_number: String
) {
  update_mst_clientmanagement(
    where: { id: { _eq: $id } }
    _set: {
      address: $address
      company_name: $company_name
      email: $email
      gst: $gst
      name: $name
      phone_number: $phone_number
    }
  ) {
    affected_rows
  }
}
`

export const DELETE_CLIENT = gql`
mutation MyMutation ($id:uuid) {
  delete_mst_clientmanagement(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`

export const DELETE_SALARY_PAYMENT = gql`
mutation MyMutation($id: uuid) {
   delete_mst_salary_payment(where: {id: {_eq: $id}}) {
   affected_rows
    
  }
 }
`
// Project Mangament

export const CREATE_PROJECT_DATA = gql`
mutation MyMutation ( $company_name:uuid, $created_at: timestamptz, $description: String  $budget: Int, $duration_from: String, $duration_to:String, $project_name: String ){
  insert_mst_project(objects: { company_name: $company_name, created_at: $created_at , description: $description,  budget: $budget, project_name: $project_name , duration_to:$duration_to ,duration_from :$duration_from}) {
    affected_rows
  }
}`

export const UPDATE_PROJECT_DATA = gql`
mutation MyMutation($id: uuid,$budget: Int,  $company_name:uuid ,  $duration_from:String,$duration_to:String,$project_name: String  ) {
  update_mst_project(where: {id: {_eq:$id}}, _set: { budget:$budget ,company_name: $company_name,duration_to: $duration_to,duration_from:$duration_from ,project_name: $project_name}) {
    affected_rows
  }
}`

export const DELECT_PPROJECT = gql`
mutation MyMutation($id:uuid) {
  delete_mst_project(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`
export const CREATE_PROJECT = gql`
mutation MyMutation($project_name:String,$description:String) {
  insert_mst_project(objects: {project_name: $project_name,description:$description}) {
    affected_rows
  }
}`

export const UPDATE_PROJECT = gql`
mutation MyMutation($id:uuid,$project_name:String,$description: String) {
  update_mst_project(where: {id: {_eq: $id}}, _set: {project_name: $project_name, description:$description}) {
    affected_rows
  }
}`

export const UPDATE_PAGE_NAME = gql`
mutation MyMutation($pagename: String, $id: uuid, $parentpage : String) {
  update_mst_page_list(_set: {pagename: $pagename, parentpage:$parentpage}, where: {id: {_eq:  $id}}) {  
      returning {
      id
    }
  }
}`


export const DELETE_PROJECT = gql`
mutation MyMutation($id:uuid) {
  delete_mst_project(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`

export const CREATE_RESUME_PROJECTS = gql`
mutation MyMutation ( $employee:uuid, $name:String, $experience:String,
  $project:jsonb,  $skill:String, $summary:String){
    insert_mst_resume_creation(objects: 
      {
        employee: $employee, 
        experience:$experience, 
        project: $project
        skill: $skill, 
        summary: $summary,
        name:$name,
        }) {
      affected_rows
    }
  }
  
`


export const CREATE_PAGE = gql`
mutation InsertMstPageList($pagename: String, $parentpage : String) {
  insert_mst_page_list(objects: {pagename: $pagename ,parentpage:$parentpage}) {
    affected_rows
    returning {
			id
    }
  }
}
`


export const CREATE_Role = gql`mutation InsertMstRole($type: String, $permission: jsonb) {
  insert_mst_role(objects: {type: $type, permission: $permission}) {
    affected_rows
    returning {
			id
    }
  }
}`

export const UPDATE_RESUME_PROJECTS = gql`

mutation MyMutation ($id:uuid, $employee:uuid, $experience: String, $project:jsonb, $skill:String, $summary:String){
  update_mst_resume_creation(where: {id: {_eq: $id}}, _set: {employee: $employee, experience:$experience, project: $project, skill:$skill, summary: $summary}) {
    affected_rows
  }
}  
 `
export const DELETE_RESUME_PROJECTS = gql`

mutation MyMutation($id:uuid) {
  delete_mst_resume_creation(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
 
`

export const DELETE_PAGE = gql`

mutation MyMutation($id:uuid) {
  delete_mst_page_list(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
 
`

export const CREATE_LEAVE_LIST = gql`
mutation MyMutation ($type: String, $days: Int, $day: jsonb, $reason:String,$piror_permission: Int){
  insert_mst_leave_type(objects: {type: $type, days:$days, day: $day, reason:$reason,piror_permission:$piror_permission}) {
    affected_rows
  }
}`

export const UPDATE_LEAVE_LIST = gql`
mutation MyMutation($id:uuid,$type:String, $days: Int, $day: jsonb, $reason: String,$piror_permission: Int) {
  update_mst_leave_type(where: {id: {_eq:$id}},_set: {type: $type, days:$days, day:$day, reason:$reason,piror_permission:$piror_permission}) {
    affected_rows
  }
}`

export const DELETE_LEAVE_LIST = gql`
mutation MyMutation ($id:uuid){
  delete_mst_leave_type(where: {id: {_eq: $id}}) {
    affected_rows
  }
}`

// Leave Management
export const CREATE_LEAVE = gql`
  mutation CreateLeave(
    $emp_name: uuid
    $from_date: String
    $to_date: String
    $reason: uuid
    $comments: String
    $count: Int
    $leave_period: jsonb
    $casual_leave: Int
  ) {
    insert_mst_leave_management(
      objects: {
        emp_name: $emp_name
        reason: $reason
        from_date: $from_date
        to_date: $to_date
        comments: $comments
        count: $count
        leave_period: $leave_period
        casual_leave: $casual_leave
      }
    ) {
      affected_rows
    }
  }
`;


export const COUNT_LEAVE = gql`
mutation MyMutation ($casual_leave: Int){
  insert_mst_leave_management(objects: {casual_leave: $casual_leave}) {
    affected_rows
  }
}`

export const UPDATE_LEAVE = gql`
mutation MyMutation($id:uuid,$emp_name:uuid,$from_date: String,$to_date: String,$reason:uuid, $comments:String,  $count: Int, $leave_period: jsonb) {
  update_mst_leave_management(where: {id: {_eq:$id}},_set: {emp_name:$emp_name, reason:$reason , from_date: $from_date,to_date:$to_date,comments:$comments,count:$count, leave_period: $leave_period}) {
    affected_rows
  }
}`

// export const COUNT_LEAVE_UPDATE = gql`
// mutation MyMutation($id:uuid,$casual_leave: Int) {
//   update_mst_leave_management(where: {id: {_eq:$id}},_set: {casual_leave: $casual_leave}) {
//     affected_rows
//   }
// }`

export const DELETE_LEAVE = gql`
mutation MyMutation ($id:uuid){
  delete_mst_leave_management(where: {id: {_eq: $id}}) {
    affected_rows
  }
}`

// Category

export const CREATE_CATEGORY = gql`
mutation MyMutation($id: uuid, $category: String, $description: String, $image: String) {
  insert_mst_category(objects: {category: $category, description: $description, image: $image, shop_id: "${SHOP_ID}"}) {
    affected_rows
  }
}
`;



export const UPDATE_CATEGORY = gql`
mutation MyMutation($id: uuid, $category: String, $description: String, $image:String,$shop_id: uuid) {
  update_mst_category(where: {id: {_eq: $id}}, _set: {category: $category, description: $description,image :$image,shop_id: "${SHOP_ID}"}) {
    affected_rows
  }
}
`


export const DELECT_CATEGORY = gql`
mutation MyMutation($id:uuid) {
  delete_mst_category(where: {id: {_eq:$id}}) {
    affected_rows
  }
}`

// Sub Category

export const CREATE_SUB_CATEGORY = gql`
mutation MyMutation($id: uuid, $category: uuid, $description: String, $sub_name: String, $image:String,$shop_id: uuid) {
  insert_mst_sub_category(objects: {category: $category, description: $description, sub_name: $sub_name, image:$image,shop_id: "${SHOP_ID}"}) {
    affected_rows
  }
}`

export const UPDATE_SUB_CATEGORY = gql`
mutation MyMutation($id: uuid, $category: uuid, $description: String, $sub_name: String, $image:String, $shop_id: uuid) {
  update_mst_sub_category(where: {id: {_eq: $id}}, _set: {category: $category, description: $description, sub_name: $sub_name, image:$image,shop_id: "${SHOP_ID}"}) {
    affected_rows
  }
}
`

export const DELETE_SUB_CATEGORY = gql`
mutation MyMutation($id: uuid) {
  delete_mst_sub_category(where: {id: {_eq: $id}}) {
    affected_rows
  }
}`

export const CREATE_PRODUCT = gql`
mutation MyMutation(
  $name: String, 
  $price: Int, 
  $offered_price: Int, 
  $selling_price: Int, 
  $expiry: Int, 
  $stocks: Int, 
  $description: String, 
  
  $product_code: String,
  $category: uuid, 
  $sub_category: uuid, 
  $duration: Int, 
  $shop_id: uuid,
  $attributes: jsonb, 
  $images: jsonb,
  $status: Boolean, 
  $featured_products: Boolean, 
  $trending_products: Boolean, 
  $top_selling: Boolean, 
  $show_stock: Boolean, 
  $alpha_numeric: String) {
  
  insert_mst_product(
    objects: {
      name: $name, 
      price: $price, 
      images:$images
      shop_id:$shop_id,
      offered_price: $offered_price, 
      selling_price: $selling_price, 
      product_code: $product_code,
      expiry: $expiry, 
      stocks: $stocks, 
      
      description: $description, 
      category: $category, 
      sub_category: $sub_category, 
      duration: $duration, 
      attributes: $attributes, 
      status: $status, 
      featured_products: $featured_products, 
      trending_products: $trending_products, 
      top_selling: $top_selling, 
      show_stock: $show_stock, 
      alpha_numeric: $alpha_numeric
    }) {
    affected_rows
    returning {
      id
      name
      alpha_numeric
    }
  }
}

`;

export const GENERATE_BARCODE = gql `mutation MyMutation($id: uuid!, $bar_code: String!) {
  update_mst_product(
    where: { id: { _eq: $id } },
    _set: { bar_code: $bar_code }
  ) {
    affected_rows
    returning {
      id
      bar_code
    }
  }
}

`;

export const UPDATE_PRODUCT = gql`
 mutation MyMutation(
    $name: String,
    $price: Int,
    $expiry: Int,
    $shop_id: uuid,
    $offered_price: Int,
    $selling_price: Int,
    $description: String,
    $category: uuid,
    $images: jsonb,
    $product_code: String,
    $sub_category: uuid,
    $id: uuid,
    $duration: Int,
    $attributes: jsonb,
    $status: Boolean,
    $featured_products: Boolean,
    $trending_products: Boolean,
    $top_selling: Boolean
     $show_stock: Boolean
  ) {
    update_mst_product(
      where: { id: { _eq: $id } },
      _set: {
        name: $name,
        offered_price: $offered_price,
        price: $price,
        shop_id:$shop_id,
        selling_price: $selling_price,
        product_code: $product_code,
        expiry: $expiry,
        images: $images,
        description: $description,
        category: $category,
        sub_category: $sub_category,
        duration: $duration,
        attributes: $attributes,
        status: $status,
        featured_products: $featured_products,
        trending_products: $trending_products,
        top_selling: $top_selling,
        show_stock: $show_stock
      }
    ) {
      affected_rows
    }
  }
`;


export const DELETE_PRODUCT = gql`
mutation MyMutation($id: uuid) {
  delete_mst_product(where: {id: {_eq: $id} _set: {isdeleteatd: true}}) {
    affected_rows
  }
}
`
export const UPDATE_ALL_FEATURE_PRODUCT=gql`mutation UpdateNonFeaturedProducts($ids: [uuid!]!) {
  update_mst_product(
    where: {
      id: { _in: $ids }
    },
    _set: { featured_products: false }
  ) {
    affected_rows
  }
}`

export const UPDATE_SELECTED_FEATURE_PRODUCT=gql`mutation UpdateFeaturedProducts($ids: [uuid!]!) {
  update_mst_product(
    where: {
      id: { _in: $ids }
    },
    _set: { featured_products: true }
  ) {
    affected_rows
  }
}`

export const INSERT_BOOKING = gql
  `mutation MyMutation($client: uuid,   $quantity: Int, $total: float8, ) {
  insert_mst_bookings(objects: {client: $client, quantity: $quantity, total: $total}) {
    affected_rows
    returning {
      id}
    }
}
`
export const insertBookingMutation = gql`
  mutation MyMutation($bill_products: jsonb, $total: float8) {
    insert_mst_bookings(objects: { bill_products: $bill_products, total: $total }) {
      affected_rows
      returning {
        id
        created_at
      total
        
      }
    }
  }`;

  export const UPDATE_TRACKING= gql`mutation MyMutation($id: uuid, $trackingId: String, $trackingImage: String) {
  update_mst_bookings(
    where: { id: { _eq: $id } },
    _set: { tracking_id: $trackingId, tracking_image: $trackingImage }
  ) {
    affected_rows
    returning {
      tracking_image
      tracking_id
      id
    }
  }
}
`;



  export const UPDATE_BOOKING_STATUS = gql`
  mutation MyMutation(
    $id: uuid,
    $status: String,
    $rejected_at: timestamp,
    $accepted_at: timestamp,
    $dispatched_at: timestamp,
    $inTransit_at: timestamp,
    $delivered_at: timestamp
  ) {
    update_mst_bookings(
      where: { id: { _eq: $id } }
      _set: { 
        status: $status,
        rejected_at: $rejected_at,
        accepted_at: $accepted_at,
        dispatched_at: $dispatched_at,
        inTransit_at: $inTransit_at,
        delivered_at: $delivered_at
      }
    ) {
      affected_rows
    }
  }
`;

export const CREATE_BANNER= gql`
mutation MyMutation($image: String, $visibility: Boolean = true) {
  insert_mst_banner(objects: {image: $image, shop_id: "${SHOP_ID}", visibility: $visibility}) {
    affected_rows
    returning {
      id
      image
      isdeleted
      shop_id
      visibility
    }
  }
}
`;

export const UPDATE_BANNER = gql`mutation MyMutation($id: uuid!, $image: String, $shop_id: uuid, $visibility: Boolean) {
  update_mst_banner(
    where: { id: { _eq: $id } } 
    _set: { image: $image, shop_id: "${SHOP_ID}", visibility: $visibility }
  ) {
    affected_rows
    returning {
      id
      image
      isdeleted
      shop_id
      visibility
    }
  }
}
`
;

export const DELETE_BANNER = gql `mutation MyMutation($id: uuid) {
  delete_mst_banner(where: {id: {_eq: $id}}) {
    affected_rows
    returning {
      created_at
      id
      image
      isdeleted
      shop_id
      visibility
    }
  }
}
`
;

export const CREATE_COPOUNS= gql`

mutation MyMutation($code: String, $description: String, $discount_type: String, $discount_value: numeric, $start_date: timestamp, $end_date: timestamp, $min_order_value: Int, $is_public: Boolean, $status: String, $customer_id: jsonb, $product_id: jsonb, $category_id: jsonb) {
  insert_mst_coupons(objects: {code: $code, description: $description, discount_type: $discount_type, discount_value: $discount_value, start_date: $start_date, end_date: $end_date, min_order_value: $min_order_value, is_public: $is_public, status: $status, customer_id: $customer_id, product_id: $product_id, category_id: $category_id, shop_id: "${SHOP_ID}"}) {
    affected_rows
    returning {
      id
      code
      description
      discount_type
      discount_value
      start_date
      end_date
      min_order_value
      is_public
      status
      customer_id
      category_id
      product_id
    }
  }
}
`
export const DELETE_COUPONS=gql`

mutation MyMutation ($id: uuid){
  update_mst_coupons(where: {id: {_eq: $id}, shop_id: {_eq:"${SHOP_ID}"}}, _set: {isdeleted: true}) {
    affected_rows
  }
}
`
export const UPDATE_COUPONS= gql`
mutation MyMutation(
  $id: uuid, 
  $code: String, 
  $description: String, 
  $discount_type: String, 
  $discount_value: numeric, 
  $start_date: timestamp, 
  $end_date: timestamp, 
  $min_order_value: Int, 
  $status: String, 
  $is_public: Boolean, 
  $customer_id: jsonb, 
  $category_id: jsonb, 
  $product_id: jsonb
) {
  update_mst_coupons(
    where: { id: { _eq: $id } }, 
    _set: { 
      code: $code, 
      description: $description, 
      discount_type: $discount_type, 
      discount_value: $discount_value, 
      start_date: $start_date, 
      end_date: $end_date, 
      min_order_value: $min_order_value, 
      status: $status, 
      is_public: $is_public, 
      customer_id: $customer_id, 
      category_id: $category_id, 
      product_id: $product_id,
      shop_id: "${SHOP_ID}"
    }
  ) {
    affected_rows
  }
}
`

export const UPDATE_MYORDER = gql
  `mutation MyMutation($id: uuid, $client: uuid, $price: float8, $product: uuid, $quantity: float8, $total: float8) {
  update_mst_bookings(where: {id: {_eq: $id}}, _set: {client: $client, price: $price, product: $product, quantity: $quantity, total: $total}) {
    affected_rows
  }
}
`
export const DELETE_MYORDER = gql
  `mutation MyMutation($id: uuid) {
  delete_mst_bookings(where: {id: {_eq: $id}}) {
    affected_rows
  }
}`

export const UPDATE_DELETE_REMINDER = gql
  `mutation MyMutation($id: uuid, $check: Boolean) {
  update_mst_subscription(where: {id: {_eq: $id}}, _set: {check: $check}) {
    affected_rows
  }
}
`
export const USER_MESSAGE = gql`mutation MyMutation($user_id: uuid!, $message: String!) {
  insert_mst_chats(objects: {
    is_admin: true, 
    resolved: false, 
    shop_id: "c0554ffb-8e3a-4ce4-bb3b-d345873e061a",  
    user_id: $user_id, 
    message: $message
  }) {
    affected_rows
    returning {
      created_at
      id
      is_admin
      message
      resolved
      shop_id
      user_id
    }
  }
}
`;

export const CREATE_SUB_INVOICE = gql`
mutation MyMutation($total_price: Int, $client_name: uuid, $price: Int, $product_name: uuid, $quantity: Int, $subscription_id: uuid, $updated_at: timestamptz) {
  insert_mst_invoice(objects: {client_name: $client_name, price: $price, product_name: $product_name, quantity: $quantity, total_price: $total_price, subscription_id: $subscription_id, updated_at: $updated_at}) {
    affected_rows
  }
}
`

export const CREATE_INVOICE = gql`
  mutation MyMutation(
    $additional_charges: Int,
    $client: uuid,
    $date: String,
    $due_date: String,
    $invoice: String,
    $notes: String,
    $product: jsonb,
    $reduction: Int,
    $sales: String,
    $terms: String,
    $total_amount: Int,
    $type: String
  ) {
    insert_mst_invoice(
      objects: {
        additional_charges: $additional_charges,
        client: $client,
        date: $date,
        due_date: $due_date,
        invoice: $invoice,
        notes: $notes,
        product: $product,
        reduction: $reduction,
        sales: $sales,
        terms: $terms,
        total_amount: $total_amount,
        type: $type
      }
    ) {
      affected_rows
    }
  }
`;

export const DELETE_INVOICE = gql`
mutation MyMutation ($id:uuid) {
  delete_mst_invoice(where: {id: {_eq: $id}}) {
    affected_rows
  }
}

`

export const UPDATE_INVOICE = gql`

  mutation MyMutation(
    $additional_charges: Int,
    $client: uuid,
    $date: String,
    $due_date: String,
    $invoice: String,
    $notes: String,
    $product: jsonb,
    $reduction: Int,
    $sales: String,
    $terms: String,
    $total_amount: Int,
    $type: String,
    $id: uuid
  ) {
    update_mst_invoice(
      where: {id: {_eq: $id}},
      _set: {
        additional_charges: $additional_charges,
        client: $client,
        date: $date,
        due_date: $due_date,
        invoice: $invoice,
        notes: $notes,
        product: $product,
        reduction: $reduction,
        sales: $sales,
        terms: $terms,
        total_amount: $total_amount,
        type: $type
      }
    ) {
      affected_rows
    }
  }

`

export const CREATE_ANNOUNCEMENT = gql`
mutation MyMutation($id: uuid,$date:date,$message:String,$file:String) {
  insert_mst_announcement(objects:{date:$date,message:$message,file:$file}) {
    affected_rows
  }
}
`
export const UPDATE_ANNOUNCEMENT = gql`
mutation MyMutation($id: uuid,$date:date,$message:String,$file:String,$isdeleteat: Boolean) {
  update_mst_announcement(where: {id: {_eq: $id}}, _set: {date:$date,message:$message,file:$file, isdeleteat: $isdeleteat}) {
    affected_rows
  }
}
`
export const UPDATE_ANNOUNCEMENT_VIEW = gql`
mutation MyMutation($id: uuid, $isdelete: Boolean) {
  update_mst_announcement(where: {id: {_eq: $id}}, _set: {isdelete: $isdelete}) {
    affected_rows
  }
}
`

export const DELECT_ANNOUNCEMENT = gql`
mutation MyMutation($id: uuid) {
  delete_mst_announcement(where: {id: {_eq: $id}}) {
    affected_rows
  }
}`


export const CREATE_TIMESHEET = gql`
mutation MyMutation($employee: uuid, $date: date, $in_time: time, $checkin_location: jsonb, $intime: timetz) {
  insert_mst_timesheet(objects: {
    date: $date,
    employee: $employee,
    in_time: $in_time,
    checkin_location: $checkin_location,
    intime: $intime
  }) {
    affected_rows
  }
}`

export const UPDATE_TIMESHEET = gql`
mutation MyMutation($id: uuid, $out_time: time, $seconds: Int, $task: String, $outtime: timetz, $checkout_location: jsonb) {
  update_mst_timesheet(
    where: { id: { _eq: $id } },
    _set: {
      out_time: $out_time,
      seconds: $seconds,
      task: $task,
      outtime: $outtime,
      checkout_location: $checkout_location
    }
  ) {
    affected_rows
  }
}`
export const CREATE_DEPARTMENT = gql`
mutation MyMutation($department_name: String, $description: String) {
  insert_mst_department(objects: {description: $description, department_name: $department_name}) {
    affected_rows
  }
}
`

export const UPDATE_DEPARTMENT = gql`
mutation MyMutation ($department_name: String, $description: String, $id: uuid){
  update_mst_department(where: {id: {_eq: $id}}, _set: {description: $description, department_name: $department_name}) {
    affected_rows
  }
}
`

// SERVICE MUTATIONS

export const DELETE_SERVICE_PRODUCT_CATEGORY = gql
  `
mutation MyMutation($id:uuid) {
  delete_product_categories(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`

export const CREATE_SERVICE_PRODUCT_CATEGORY = gql`
mutation MyMutation($name: String, $image: String, $parent_name: uuid) {
  insert_product_categories(objects: {image: $image, name:$name,parent_name:$parent_name}) {
    affected_rows
  }
}
`

export const UPDATE_SERVICE_PRODUCT_CATEGORY = gql`
mutation MyMutation ($id: uuid, $image: String, $name: String,$parent_name: uuid) {
  update_product_categories(where: {id: {_eq: $id}}, _set: {image: $image, name: $name,parent_name:$parent_name}) {
    affected_rows
  }
}
`

// SERVICE MUTATIONS

export const CREATE_SERVICE_PRODUCT = gql`
mutation MyMutation($category_id:uuid, $description: String, $discount: Int, $image: String, $name: String, $price: Int, $sale_price: float8 ,$type:jsonb, $stocks: Int,$attributes:jsonb) {
  insert_product(objects: {
    category_id: $category_id,
    description: $description, 
    discount: $discount,
    image: $image,
    name: $name,
    price:$price,
    sale_price: $sale_price,
    type: $type,
    attributes:$attributes
    stocks: $stocks}) {
    affected_rows
  }
}
`

export const UPDATE_SERVICE_PRODUCT = gql`
mutation MyMutation(
  $id: uuid,
  $category_id: uuid,
  $description: String,
  $discount: Int,
  $name: String,
  $image: String,
  $price: Int,
  $sale_price: float8,
  $stocks: Int,
  $type: jsonb,
  $attributes: jsonb
) {
  update_product(
    where: { id: { _eq: $id } },
    _set: {
      category_id: $category_id,
      description: $description,
      discount: $discount,
      image: $image,
      name: $name,
      price: $price,
      sale_price: $sale_price,
      stocks: $stocks,
      type: $type,
      product_code: $product_code,
      attributes: $attributes
    }
  ) {
    affected_rows
  }
}


`

export const DELETE_SERVICE_PRODUCT = gql
  `
mutation MyMutation($id: uuid) {
  delete_product(where: {id: {_eq: $id}}) {
    affected_rows
  }
}

`
export const CREATE_SERVICE_ATTRIBUTES = gql
  `
mutation MyMutation ($options:jsonb,$name:String,$categories:uuid,$shop_id: uuid){
  insert_mst_attributes(objects: {options: $options, name: $name,categories:$categories,shop_id: "${SHOP_ID}"}) {
    affected_rows
  }
}`

export const UPDATE_SERVICE_ATTRIBUTES = gql
  `
mutation MyMutation ($id:uuid, $name: String,$options: jsonb,$shop_id: uuid){
  update_mst_attributes(where: {id: {_eq: $id}}, _set: {name: $name, options: $options,shop_id: "${SHOP_ID}"}) {
    affected_rows
  }
}
`
export const DELETE_SERVICE_ATTRIBUTES = gql
  `
mutation MyMutation($id:uuid) {
  delete_mst_attributes(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`

export const CREATE_WORK_TIMESHEET = gql`
mutation MyMutation($employee: uuid, $timesheet: jsonb,$startDate: timestamptz,$endDate: timestamptz, $status:Boolean  )  {
  insert_mst_work_timesheet(objects: {employee: $employee, endDate: $endDate,startDate: $startDate, status : $status ,timesheet: $timesheet }) {
    affected_rows
  }
}
`
export const DELETE_TIME_SHEET = gql
  `mutation MyMutation($id: uuid) {
    delete_mst_work_timesheet(where: {id: {_eq: $id}}) {
    affected_rows
  } 
}
`
export const DELETE_MYTASK = gql
  `mutation MyMutation($id: uuid) {
  delete_mst_task(where: {id: {_eq: $id}}) {
    affected_rows
  } 
}
`
export const INSERT_MYTASK = gql
  `mutation MyMutation($issue_type: String, $title: String, $assignee_userid: uuid, $description: String, $reporter_userid: uuid, $status: String, $priority: String, $start_date: date, $target_date: date, $sprint_associationid: uuid, $comment: String ) {
  insert_mst_task(objects: {issue_type: $issue_type, title: $title, assignee_userid: $assignee_userid, description: $description, reporter_userid: $reporter_userid, status: $status, priority: $priority, start_date: $start_date, target_date: $target_date, sprint_associationid: $sprint_associationid, comment: $comment}) {
    affected_rows
  }
}
`

export const UPDATE_MYTASK = gql`mutation MyMutation($id: uuid, $issue_type: String, $title: String, $assignee_userid: uuid, $description: String, $reporter_userid: uuid, $status: String, $priority: String, $start_date: date, $target_date: date, $sprint_associationid: uuid, $comment: String) {
  update_mst_task(where: {id: {_eq: $id}}, _set: {assignee_userid: $assignee_userid, description: $description, id: $id, issue_type: $issue_type, priority: $priority, reporter_userid: $reporter_userid, sprint_associationid: $sprint_associationid, start_date: $start_date, status: $status, target_date: $target_date, title: $title, comment: $comment}) {
    affected_rows
  }
}
`
export const UPDATE_TASK_DESCRIPTION = gql`mutation MyMutation($id: uuid, $description: String,) {
  update_mst_task(where: {id: {_eq: $id}}, _set: {description: $description}) {
    affected_rows
  }
}
`

export const INSERT_SPRINT = gql
  `mutation MyMutation($end_date:date, $project_associationid: uuid, $goal: String, $sprint_name: String, $start_date: date, $status: String) {
  insert_mst_sprints(objects: {end_date: $end_date, goal: $goal, project_associationid: $project_associationid, sprint_name: $sprint_name, start_date: $start_date, status: $status}) {
    affected_rows
    
  }
}
`
export const UPDATE_SPRINT = gql
  `mutation MyMutation($id:uuid,$end_date: date, $project_associationid: uuid, $goal: String, $sprint_name: String, $start_date: date, $status: String) {
  update_mst_sprints(where:{id: {_eq: $id }}, _set: {end_date: $end_date, goal: $goal, project_associationid: $project_associationid, sprint_name: $sprint_name, start_date: $start_date, status: $status}) {
    affected_rows
   
  }
}
`
export const DELETE_SPRINT = gql
  `mutation MyMutation($id: uuid) {
  delete_mst_sprints(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`

export const STATUS_UPDATE = gql
  `mutation MyMutation($status: String, $id: uuid) {
  update_mst_task(where: {id: {_eq: $id}}, _set: {status: $status}) {
    returning {
      description
      id
      issue_type
      priority
      assignee_userid
      sprint_associationid
      reporterrelation {
        name
      }
      status
      title
    }
  }
}`

export const UPDATE_WORK_TIMESHEET = gql
  `mutation MyMutation($id: uuid, $employee: uuid, $timesheet: jsonb) {
  update_mst_work_timesheet(where: {id: {_eq: $id}}, _set: {employee: $employee, timesheet: $timesheet}) {
    affected_rows
  }
}
`
export const UPDATE_WORK_TIMESHEET_STATES = gql
  `mutation MyMutation($id: uuid, $status: Boolean) {
  update_mst_work_timesheet(where: {id: {_eq: $id}}, _set: {status: $status}) {
    affected_rows
  }
}
`
export const INSERT_WEEKDATA_TIMESHEET = gql
  `mutation MyMutation($objects: [mst_weeklydate_timesheet_insert_input!]!) {
  insert_mst_weeklydate_timesheet(objects: $objects) {
    affected_rows
  }
}
`
export const DELETE_REMINDER_DAYS = gql
  `mutation MyMutation($id: uuid) {
  delete_mst_company_details(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`
export const INSERT_REMINDER_DAYS = gql
  `mutation MyMutation($account_number: String, $bank_name: String, $company_address: String, $company_logo: String, $company_name: String, $days: Int, $gst_no: String, $gst_percent: String, $phone_number: String, $qr_code: String, $remind: Int) {
  insert_mst_company_details(objects: {account_number: $account_number, bank_name: $bank_name, company_address: $company_address, company_logo: $company_logo, company_name: $company_name, days: $days, gst_no: $gst_no, gst_percent: $gst_percent, phone_number: $phone_number, qr_code: $qr_code, remind: $remind}) {
    affected_rows
  }
}
`
export const UPDATE_REMINDER_DAYS = gql
  `mutation MyMutation($id: uuid, $account_number: String, $bank_name: String, $company_address: String, $company_logo: String, $company_name: String, $days: Int, $gst_no: String, $gst_percent: String, $phone_number: String, $qr_code: String, $remind: Int) {
  update_mst_company_details(where: {id: {_eq: $id}}, _set: {account_number: $account_number, bank_name: $bank_name, company_address: $company_address, company_logo: $company_logo, company_name: $company_name, days: $days, gst_no: $gst_no, gst_percent: $gst_percent, phone_number: $phone_number, qr_code: $qr_code, remind: $remind}) {
    affected_rows
    returning {
      account_number
      bank_name
      company_address
      company_logo
      company_name
      days
      gst_no
      gst_percent
      phone_number
      qr_code
    }
  }
}
`

export const DELETE_REMINDER_TRUE = gql
  `mutation MyMutation($id: uuid) {
  update_mst_subscription(where: {id: {_eq: $id}}, _set: {check: true}) {
    affected_rows
   
  }
}
`

export const DELETE_REMINDER = gql
  `mutation MyMutation($id:uuid) {
  delete_mst_reminder(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`

export const UPDATE_REMINDER = gql`
mutation MyMutation($snooze: date, $_eq: uuid) {
  update_mst_reminder(where: {id: {_eq: $_eq}}, _set: {snooze: $snooze}) {
    affected_rows
  }
}
`

export const CREATE_COMMENT = gql
  `
mutation MyMutation($comments: String, $employee: uuid, $task_id: uuid) {
  insert_mst_comments(objects: {task_id: $task_id, employee: $employee, comments: $comments}) {
    affected_rows
  }
}
`
export const PRODUCT_SOFT_DELETE = gql
  `mutation MyMutation($id: uuid) {
  update_mst_product(where: {id: {_eq: $id}}, _set: {isdeleted: true}) {
    affected_rows
    returning {
      id
      isdeleted
    }
  }
}
`
export const CLIENT_SOFT_DELETE = gql
  `mutation MyMutation($id: uuid) {
  update_mst_clientmanagement(where: {id: {_eq: $id}}, _set: {isdeleted: true}) {
    affected_rows
    returning {
      address
      company_name
      created_at
      email
      gst
      isdeleted
      name
      phone_number
      id
    }
  }
}
`

export const DELETE_COMMENT = gql`
mutation MyMutation($id: uuid) {
  delete_mst_comments(where: {id: {_eq: $id}}) {
    affected_rows
  }
}
`
export const CATEGORY_SOFT_DELETE = gql`mutation MyMutation($id: uuid) {
  update_mst_category(where: {id: {_eq: $id}}, _set: {isdeleted: true}) {
    affected_rows
    returning {
      id
      isdeleted
    }
  }
}`

export const SUB_CATEGORY_SOFT_DELETE = gql`mutation MyMutation($id: uuid) {
  update_mst_sub_category(where: {id: {_eq: $id}}, _set: {isdeleted: true}) {
    affected_rows
    returning {
      id
      isdeleted
    }
  }
}`

export const INSERT_PRODUCT = gql`
mutation MyMutation(
  $booking_id: uuid,
  $price: float8,
  $product: uuid,
  $quantity: Int,
  $sub_total: float8
  $expiry: Int
) {
  insert_mst_booked_products(
    objects: {
      booking_id: $booking_id,
      price: $price,
      quantity: $quantity,
      product: $product,
      sub_total: $sub_total
      expiry: $expiry 
    }
  ) {
    affected_rows
  }
}

`

export const INSERT_REMINDER = gql`
mutation MyMutation( $snooze: date, $renewal: date, $product: uuid, $expiry: Int, $client: uuid, $booking_id: uuid) {
  insert_mst_reminder(objects: {client: $client, expiry: $expiry, product: $product, snooze: $snooze, renewal: $renewal, booking_id: $booking_id}) {
    affected_rows
  }
}`

export const UPDATE_YEARLY_LEAVE = gql`
mutation MyMutation($employee_id : uuid, $casual_leave: Int) {
  update_mst_yearly_leave(where: {employee_id : {_eq: $employee_id }}, _set: {casual_leave: $casual_leave }) {
    affected_rows
  }
}
`
export const INSERT_SHOP = gql`mutation MyMutation($shop_logo: String, $shop_name: String) {
  insert_mst_shop(objects: {shop_logo: $shop_logo, shop_name: $shop_name}) {
    affected_rows
    returning {
      created_at
      id
      isDeleted
      shop_logo
      shop_name
    }
  }
}
`

export const UPDATE_SHOP = gql `mutation MyMutation($id: uuid, $shop_logo: String, $shop_name: String ) {
  update_mst_shop(where: {id: {_eq: $id}}, _set: {shop_logo: $shop_logo, shop_name: $shop_name}) {
    affected_rows
    returning {
      created_at
      id
      isDeleted
      shop_logo
      shop_name
    }
  }
}`

export const SOFT_DEL_SHOP = gql`mutation MyMutation($id: uuid) {
  update_mst_shop(where: {id: {_eq: $id}}, _set: {isDeleted: true}) {
    affected_rows
    returning {
      created_at
      id
      isDeleted
      shop_logo
      shop_name
    }
  }
}
`

// export const UPDATE_SHOP_AND_SETTINGS = gql`
//   mutation UpdateShopAndSettings($shop_name: String!, $shop_logo: String!, $id: uuid!) {
//     update_mst_settings(
//       where: { shop_id: { _eq: $id } }
//       _set: { shop_name: $shop_name, shop_logo: $shop_logo }
//     ) {
//       affected_rows
//     }

//     update_mst_shop(
//       where: { id: { _eq: $id } }
//       _set: { shop_name: $shop_name, shop_logo: $shop_logo }
//     ) {
//       affected_rows
//     }
//   }
// `;

export const UPDATE_SHOP_SETTINGS = gql`
  mutation UpdateShop($shop_name: String!, $shop_logo: String!, $id: uuid!) {
    update_mst_shop(
      where: { id: { _eq: $id } }
      _set: { shop_name: $shop_name, shop_logo: $shop_logo }
    ) {
      affected_rows
    }
  }
`;
export const UPDATE_SETTINGS = gql`
  mutation UpdateSettings($shop_name: String!, $shop_logo: String!, $id: uuid!) {
    update_mst_settings(
      where: { shop_id: { _eq: $id } }
      _set: { shop_name: $shop_name, shop_logo: $shop_logo }
    ) {
      affected_rows
    }
  }
`;


export const INSERT_SETTING = gql`
  mutation InsertSetting($shop_id: uuid!, $shop_name: String!, $shop_logo: String!) {
    insert_mst_settings(objects: { shop_id: $shop_id, shop_name: $shop_name, shop_logo: $shop_logo }) {
      affected_rows
    }
  }
`;
