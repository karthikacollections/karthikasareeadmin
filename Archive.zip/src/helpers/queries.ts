///Users/ksuryadodi/Development/reactjs/crm-saree/src/helpers/queries.ts

import { gql } from "@apollo/client";
import { SHOP_ID } from "../utils/constants";

export const GET_NGO = gql`
  query NgoQuery {
    mst__ngos(order_by: { created_at: desc_nulls_last }) {
      id
      ngo_id
      name
      charity_type
      created_at
      charity_id
      email_id
      phone_number
      location
      logo
      country
      preferred_currency
      mst_posts {
        id
      }
      mst__projects {
        id
        name
        ngo_id
        is_active
        active_status
      }
      mst__transactions {
        total_amount
      }
    }
  }
`;

export const GET_USERS = gql`
  query GetUsers {
    mst_employee {
      id
      name
      sno
      age
      experience
    }
  }
`;

export const GET_EMPLOYDETAILS = gql`
  query employeeQuery {
   mst_employeedetails(where: { isdeleteat: { _eq: false } }) {
      sno
      name
      email
      referral
      destination
      adhaar_photo
      blood_group
      marital_status
    employeeid
      pan_photos
      education_photo
      experience_letter
      resume
      dob
      gender
      isdeleteat
      dor
      mst_destination {
        name
      }
      doj
      id
      phone
      adhar
      pan
      education
      role
      image
      organization
      department
      status
      mst_role {
        type
      }
      mst_employeedetails_mst_timesheets {
        date
        seconds
        employee
        id
        in_time
        out_time
        checkin_location
      }
      mst_employeedetails_mst_salarymanagements {
        final_pay
        id
        employee
        salary
      }
      mst_employeedetails_mst_leave_management {
        emp_name
        id
        count
        created_at
        from_date
        to_date
        reason                                                                                      
      }
       mst_leave_employee {
       emp_name
      id
      comments
      count
      casual_leave
      created_at
    } 
  
      mst_leavemanage_mst_leavetype {
        type
        reason
        id
        days
        day
      }
    mst_employeedetails_mst_salary_payments {
        emp
        emp_working_days
        id
        paid_on
        payment
        status
        working_days
      }
      mst_organization {
        name
      }
      
      createdat
    }
  }
`;

export const GET_EMPLOYDETAILS_TEST = gql`
query MyQuery {
  mst_employeedetails {
    image
    id
    gender
    email
    education
    department
    isdeleteat
    marital_status
    face_descriptor
    experience_letter
    employeeid
    education_photo
    dor
    doj
    dob
    destination
    createdat
    blood_group
    adhar
    adhaar_photo
  }
}

`;

export const GET_CHECK_IN_DETAILS = gql`
  query MyQuery($employee: uuid) {
    mst_timesheet(
      where: { employee: { _eq: $employee } }
      order_by: { createdat: desc }
      limit: 5
    ) {
      date
      employee
      id
      checkoutcurrent_time
      createdat
      in_time
      out_time
    }
  }
`;

export const GET_EMPLOYDETAILS_DATA = gql`
  query employeeQuery($date: date, $id: uuid) {
    mst_employeedetails(where: {mstTimesheetsByEmployee: {date: {_eq: $date}}, id: {_eq: $id}}) {
      sno
      name
      email
      id
      image
      organization
      department
      mstTimesheetsByEmployee (where: {date: {_eq: $date}}){
        date
        seconds
        employee
        id
        in_time
        out_time
        checkin_location
        checkoutcurrent_time
        createdat
        time_difference_seconds
      }
      mst_organization {
        name
      }
      mst_department {
        department_name
        id
      }
      createdat
    }
  }
`;

export const GET_ONE_EMPLOYDETAILS = gql`
  query employeeQuery($id: uuid) {
    mst_employeedetails(where: { id: { _eq: $id } }) {
      sno
      name
      email
      id
      image
      phone
      organization
      department
      status
      mst_employeedetails_mst_timesheets {
        date
        seconds
        employee
        id
        in_time
        out_time
        checkin_location
        checkoutcurrent_time
        createdat
        time_difference_seconds
      }
      mst_organization {
        name
      }
      mst_department {
        department_name
        id
      }
      createdat
    }
  }
`;

export const GET_EMPLOYDETAILS_DOB = gql`
  query employeeQuery {
    mst_employeedetails {
      name
      image
      dob
      id
    }
  }
`;

export const GET_ATTENDANCE = gql`
  query MyQuery2($date: date) {
    mst_employeedetails  {
      id
      name
      organization
      status
       isdeleteat
      mstTimesheetsByEmployee (where: {date: {_eq: $date}}){
        date
        employee
        id
        in_time
        out_time
        seconds
        intime
        outtime
       status
        task
        checkoutcurrent_time
        createdat
        time_difference_seconds
      }
      mst_organization {
        id
        name
      }
    }
  }
`;

export const GET_DESTINATION = gql`
  query destinationQuery {
    mst_destination {
      name
      createdat
      id
    }
  }
`;
export const GET_ROLE = gql`
  query RoleQuery {
    mst_role {
      id
      type
      permission
      createdat
    }
  }
`;

export const GET_LOGIN = gql`
  query MyQuery {
    mst_attendance {
      logintime
      logouttime
      id
      date
      employee
      mst_employeedetails {
        name
      }
    }
  }
`;

export const GET_ASSET = gql`
  query MyQuery {
    mst_assets {
      property_type
      brand
      model
      color
      serialno
      description
      id
    }
  }
`;

// export const GET_MANAGE = gql`
// query MyQuery {
//   mst_manage {
//     asset_id
//     employee_id
//     id
//   }
// }
// `

export const GET_ASSTMANAGE = gql`
  query MyQuery {
    mst_asstmanage {
      id
      employee
      property_type
      mst_asstmanage_mst_employee {
        name
      }
      mst_asstmanage_mst_assets {
        serialno
        property_type
      }
    }
  }
`;
export const GET_EXPENSE = gql`
  query MyQuery {
    mst_expense {
      date
      expense
      reason
      isdeleteat
      id
    }
  }
`;

// Payroll

export const GET_PAYROLL = gql`
  query MyQuery {
    mst_payroll {
      id
      mst_employeedetails {
        name
        mst_employeedetails_mst_timesheets {
          date
          seconds
        }
        mst_employeedetails_mst_salarymanagements {
          final_pay
        }
      }
    }
  }
`;

export const GET_PRESENCE = gql`
  query MyQuery($employee: uuid) {
    mst_timesheet(where: { employee: { _eq: $employee } }) {
      id
      date
      employee
      mst_employeedetails {
        id
        name
      }
    }
  }
`;

export const GET_PAYROLL_DATA = gql`
  query employeeQuery {
    mst_employeedetails (where: {status: {_eq: true}}) {
      name
      id
      organization
      isdeleteat
      mst_organization {
        id
        name
      }
      mstTimesheetsByEmployee {
        date
        seconds
        employee
        id
        in_time
        out_time
      }
      mst_employeedetails_mst_salarymanagements {
        final_pay
        id
        employee
        salary
      }
      mst_leave_employee {
        emp_name
        id
        count
        created_at
        from_date
        to_date
        reason
      }
      mst_employeedetails_mst_salary_payments {
        emp
        emp_working_days
        id
        paid_on
        paid_for
        payment
        status
        working_days
      }
      createdat
    }
  }
`;

// mst_timesheet_work {
//   date
//   employee_name
//   hours
//   id
//   project_name
//   timesheet
//   mst_project {
//     project_name
//   }
// }
export const GET_ANNOUNCEMENT_DOB = gql`
  query MyQuery {
    mst_employeedetails {
      dob
      id
      name
    }
  }
`;

export const GET_SALARYMANAGEMENT = gql`
  query MyQuery {
    mst_salarymanagement {
      id
      salary
      basic_salary
      conveyance_allowance
      final_pay
      medical_allowance
      esi
      employee
      rent_allowance
      special_allowance
      mst_salarymanagement_mst_employeedetail {
        name
      }
    }
  }
`;

export const GET_HOLIDAYMANAGEMENT = gql`
  query MyQuery {
    mst_holidaymanagement {
      date
      reason
      id
    }
  }
`;

export const GET_SKILLSMANAGE = gql`
  query MyQuery {
    mst_skillsmanage {
      id
      name
      type
    }
  }
`;

export const GET_CLIENT = gql`
  query MyQuery {
    mst_clientmanagement(where: { isdeleted: { _eq: false } }) {
      id
      name
      address
      company_name
      created_at
      email
      gst
      phone_number
      isdeleted
      mst_bookings {
        id
      }
    }
  }
`;

export const SEARCH_CLIENT = gql`
  query MyQuery {
    mst_clientmanagement {
      id
      name
    }
  }
`;
export const SEARCH_CATEGORY = gql`
  query MyQuery {
    mst_categoryData {
      id
      name
    }
  }
`;

export const GET_SALARY = gql`
  query MyQuery {
    mst_salary_payment {
      emp
      emp_working_days
      id
      paid_on
      payment
      status
      working_days
    }
  }
`;
export const GET_ORGANIZATION = gql`
  query MyQuery {
    mst_organization {
      name
      description
      id
      longitude
      latitude
    }
  }
`;
export const GET_DEPARTMENT = gql`
  query MyQuery {
    mst_department {
      department_name
      id
      description
      created_at
    }
  }
`;
// Project Managament
// export const GET_PROJECT = gql`
// query MyQuery {
//   mst_project_management {
//     mst_client_management {
//       company_name
//     }
//     project_name
//     duration_from
//     duration_to
//     budget
//     id
//     Client
//   }
// }`

export const GET_RESUME_MANAGEMENT = gql`
  query MyQuery {
    mst_resume_creation {
      employee
      id
      experience
      summary
      project
      skill
      name
     
    }
  }
`;
// Leave List
export const GET_LEAVE_LIST = gql`
  query MyQuery {
    mst_leave_type {
      type
      id
      days
      day
      piror_permission
      reason
    }
  }
`;

export const GET_LEAVE = gql`
query MyQuery {
  mst_leave_management {
    id
    from_date
    to_date
    emp_name
    leave_period
    created_at
    count
    comments
    casual_leave
    reason
    mst_leave_type {
      reason
      id
    }
    mst_employee_leave {
      name
    }
  }
}
`;

export const GET_YEARLY_LEAVE = gql`
  query MyQuery($employee_id: uuid) {
    mst_yearly_leave(where: { employee_id: { _eq: $employee_id } }) {
      id
      created_at
      casual_leave
      unpaid_leave
      employee_id
      year
    }
  }
`;

export const GET_YEARLY_LEAVE_ADMIN = gql`
  query MyQuery {
    mst_yearly_leave {
      id
      casual_leave
      created_at
      casual_leave
      unpaid_leave
      employee_id
    }
  }
`;

export const GET_LEAVE_EMP = gql`
  query MyQuery($id: uuid) {
    mst_leave_management(
      where: { mst_employee_leave: { id: { _eq: $id } } }
    ) {
      id
    from_date
    to_date
    emp_name
    leave_period
    created_at
    count
    comments
    casual_leave
    reason
    mst_leave_type {
      reason
      id
    }
    mst_employee_leave {
      name
    }
    }
  }
`;

export const GET_EMPLOYDETAILS_LEAVE = gql`
  query employeeQuery($id: uuid) {
    mst_employeedetails(where: { id: { _eq: $id } }) {
      name
      id
      role
      gender
      mst_employeedetails_mst_leave {
        emp_name
        id
        count
        created_at
        from_date
        to_date
        reason
      }
      createdat
      destination
      mst_destination {
        name
        id
      }
    }
  }
`;

// export const GET_LEAVES = gql`
//   query GetLeaves {
//     mst_leave_management {
//       id
//       from_date
//       emp_name
//       created_at
//       count
//       comments
//     }
//   }
// `;

export const GET_TODAY_LEAVE = gql`
  query MyQuery($from_date: String) {
    mst_leave_management(where: { from_date: { _eq: $from_date } }) {
      id
      emp_name
      reason
      mst_employeedetails_mst_leave {
        name
        id
      }
      mst_leavemanage_mst_leavetype {
        id
        reason
      }
      mst_yearly {
        id
        employee_id
        casual_leave
      }
    }
  }
`;

// Category

export const GET_CATEGORY = gql`
query MyQuery {
  mst_category(where: {isdeleted: {_eq: false}, shop_id: {_eq: "${SHOP_ID}"}}) {
    id
    description
    category
    image
    isdeleted
    shop_id
    shop {
      id
      shop_name
    }
  }
}
`;



// Sub Category

export const GET_SUB_CATEGORY = gql`
  query MyQuery {
  mst_sub_category(where: {isdeleted: {_eq: false}, shop_id: {_eq: "${SHOP_ID}"}}) {
    id
    description
    category
    sub_name
    image
    isdeleted
    mst_category_sub_category {
      category
      shop {
        id
        shop_name
      }
      shop_id
    }
  }
}
`;

export const GET_COPOUNS = gql`query MyQuery {
  mst_coupons(where: {isdeleted: {_eq: false}, shop_id: {_eq: "${SHOP_ID}"}}) {
    id
    code
    description
    discount_type
    discount_value
    start_date
    end_date
    min_order_value
    status
    is_public
    customer_id
    category_id
    product_id
    shop_id
  }
}
`

export const GET_PRODUCT = gql`
 query MyQuery($name: order_by = asc) {
  mst_product(order_by: {name: $name}, where: {isdeleted: {_eq: false},shop_id: {_eq: "${SHOP_ID}"}}) {
    id
    name
    description
    category
    images
    sub_category
    price
    expiry
    isdeleted
    duration
    attributes
    product_code
bar_code
alpha_numeric
    mst_category {
      category
      id
      created_at
      shop {
        shop_logo
        shop_name
        id
      }
    }
   
    mst_sub_category {
      sub_name
      id
      category
      shop_id
      mst_category_sub_category {
        category
        shop {
          id
          shop_name
          shop_logo
        }
      }
    }
    created_at
    image
    featured_products
    quantity
    selling_price
    status
    top_selling
    trending_products
    offered_price
    stocks
     shop {
      id
      shop_name
    }
  }
}


`;

export const GET_PRODUCT_BY_ID = gql`
 query GetProductById($id: uuid!) {
  mst_product(where: {id: {_eq: $id}, isdeleted: {_eq: false}}) {
    id
    name
    bar_code
    product_code
    price
    images
    alpha_numeric
    mst_sub_category {
      sub_name
      id
    }
  }
}

`;

export const CHECK_ALPHACODE= gql`query CheckAlphanumericCode {
  mst_product {
    id
    name
    alpha_numeric
    attributes
  }
}

`;

export const CHECK_PRODUCT_BY_CODE = gql`
  query CheckProductByCode($code: String!) {
    mst_product(
      where: {
        _or: [
          { alpha_numeric: { _eq: $code } },
          { product_code: { _eq: $code } },
          { attributes: { _contains: [{ keys: "alphaNumericCode", values: [$code] }] } },
          { attributes: { _contains: [{ keys: "productCode", values: [$code] }] } }
        ]
      }
    ) {
      id
      name
      price
      alpha_numeric
      attributes
      offered_price
      product_code
    }
  }
`;

export const GET_ATTRIBUTEID=gql`query MyQuery($nameOrder: order_by = asc, $id: uuid!) {
  mst_product(order_by: {name: $nameOrder}, where: {id: {_eq: $id}}) {
    attributes
    id
  }
}`

export const GET_CLIENT_NAME = gql`
  query MyQuery {
    mst_clientmanagement {
      id
      name
    }
  }
`;


export const GET_SUBSCRIPTION = gql`
query MyQuery {
  mst_bookings(order_by: {created_at: desc}, where: {shop_id: {_eq: "c0554ffb-8e3a-4ce4-bb3b-d345873e061a"}, customer: {}}) {
    id
    created_at
    total
    status
    payment_type
    customer
    shop_id
    coupon_code
    mst_booked_products {
      id
      booking_id
      product
      quantity
      sub_total
      attributes
      mst_products {
        image
        name
        price
        stocks
        selling_price
        offered_price
        price
        description
        attributes
      }
    }
    userAddress {
      address
      city
      email
      pincode
      state
      mobile
      mst_user {
        name
        id
        mobile
        email
        shop_id
        shop {
          shop_name
          id
        }
      }
    }
    time
    inTransit_at
    dispatched_at
    rejected_at
    accepted_at
    delivered_at
    delivery
    tracking_id
tracking_image
    date
  }
}


`;
///Bookings mutation
// export const INSERT_BOOKING = gql`
//   mutation MyMutation($client: uuid, $quantity: Int, $total: float8) {
//     insert_mst_bookings(objects: { client: $client, quantity: $quantity, total: $total }) {
//       affected_rows
//       returning {
//         id
//       }
//     }
//   }
// `
export const GET_REMINDER_DETAILS = gql`
  query MyQuery {
    mst_bookings(where: { check: { _eq: false } }) {
      check
      id
      client
      price
      quantity
      total
      bill_date
      mst_client {
        name
        company_name
        created_at
      }
      mst_product {
        expiry
        name
        created_at
      }
      product
      created_at
      updated_at
    }
  }
`;

export const GET_SUB_INVOICE = gql`
  query MyQuery {
    mst_invoice {
      client_name
      subscription_id
      mst_client {
        id
        name
        phone_number
        gst
        email
        company_name
        address
      }
      mst_product {
        id
        name
        created_at
        description
      }
      price
      product_name
      quantity
      total_price
      id
      created_at
    }
  }
`;

export const GET_INVOICE = gql`
  query MyQuery {
    mst_invoice {
      total_amount
      date
      due_date
      client
      id
      product
      mst_client_management {
        id
        name
      }
    }
  }
`;
// helpers/queries.js

export const GET_SUBCATEGORY = gql`
  query GetCategories {
    mst_category {
      id
      category
    }
  }
`;

export const GET_ANNOUNCEMENT = gql`
  query MyQuery {
    mst_announcement {
      date
      id
      message
      file
      isdeleteat
    }
  }
`;
export const GET_ANNOUNCEMENT_WIDGET = gql`
  query MyQuery {
    mst_announcement(where: { isdelete: { _eq: false } }) {
      date
      id
      message
      file
      isdelete
    }
  }
`;

export const GET_PAGE_LIST = gql`
  query GetMstPageList {
    mst_page_list {
      pagename
      parentpage
      id
    }
  }
`;

export const CHECK_PAGE_PARENT_EXISTS = gql`
  query MyQuery($pagename: String) {
    mst_page_list(where: { pagename: { _eq: $pagename } }) {
      id
    }
  }
`;

export const CHECK_PAGE_CHILD_EXISTS = gql`
  query MyQuery($parentpage: String) {
    mst_page_list(where: { parentpage: { _eq: $parentpage } }) {
      id
    }
  }
`;

export const GET_EMPLOYEE_DATA = gql`
  query MyQuery {
    mst_employeedetails {
      id
      adhaar_photo
      adhar
      department
      createdat
      destination
      dob
      doj
      education
      education_photo
      email
      experience_letter
      gender
      image
      name
      organization
      pan
      pan_photos
      phone
      referral
      role
      sno
      resume
    }
  }
`;

export const GET_EMPLOYEE_SALARY = gql`
  query MyQuery {
    mst_employeedetails {
      id
      name
      organization
      isdeleteat
      status
     mst_organization {
        id
        name
      }
      mst_employeedetails_mst_salarymanagements {
        final_pay
        esi
        employee
        basic_salary
        id
        medical_allowance
        rent_allowance
        salary
        special_allowance
        conveyance_allowance
      }
    }
  }
`;

export const GET_EMPLOYEE_TIMESHEET = gql`
  query MyQuery {
    mst_employeedetails {
      id
      image
      name
      organization
      mst_employeedetails_mst_timesheets {
        date
        id
        employee
        seconds
        time_difference_seconds
      }
      mst_organization {
        id
        name
      }
    }
  }
`;

export const GET_SERVICE_PRODUCT_CATEGORY = gql`
  query MyQuery {
    product_categories {
      id
      image
      name
      parent_name
      categorey_parent_name {
        id
        name
      }
    }
  }
`;

export const GET_SERVICE_PRODUCT = gql`
  query MyQuery {
    product {
      category_id

      description
      discount
      display_name
      id
      image
      name
      price
      sale_price
      attributes
      stocks
      type
      category_name {
        id
        name
      }
    }
  }
`;

export const GET_SERVICE_PRODUCT_VARIANT = gql`
  query MyQuery($product_id: uuid) {
    product_variants(where: { product_id: { _eq: $product_id } }) {
      id
      image
      color
      name
      price
      sale_price
      stocks
      discount
      type
    }
  }
`;

export const GET_SERVICE_USERS = gql`
  query MyQuery {
    mst_users(where: { isdeleted: { _eq: false }, shop_id: { _eq: "${SHOP_ID}" } }) {
      email
      id
      image
      isdeleted
      mobile
      name
      shop {
        shop_name
        id
      }
      shop_id
    }
  }
`;

export const GET_BOOKINGS_SEARCH_USER = gql`query MyQuery {
  mst_bookings {
    isdeleted
    payment_type
    quantity
    status
    time
    total
    updated_at
    userAddress {
      email
      name
      mst_user {
        name
        id
        shop {
          shop_name
        }
        shop_id
      }
    }
  }
}
`

export const GET_SERVICE_USERS_ADDRESS = gql`
  query MyQuery {
    user_address {
      id
      phone_number
      pincode
      state
      sub_name
      user_name
      email
      city
      address
      address_id
    }
  }
`;

export const GET_SERVICE_ORDERS = gql`
  query MyQuery {
    orders {
      id
      cus_name
      created_at
      updated_at
      total_amount
      status
      payment_type
      userdetails {
        id
        name
      }
      orders_ordered_products {
        id
        subscription_id
        product_id
        quantity
        sub_total
        mst_products {
          id
          name
          image
        }
      }
    }
  }
`;
export const GET_SERVICE_ATTRIBUTES = gql`
query MyQuery {
  mst_attributes(where: {isdeleted: {_eq: false},shop_id: {_eq: "${SHOP_ID}"}}) {
    id
    name
    options
    shop {
      shop_name
      id
    }
    shop_id
  }
}


`;

export const GET_PROJECT = gql`
  query MyQuery {
    mst_project {
      id
      project_name
      description
    }
  }
`;

export const GETTASK = gql`
  query MyQuery {
    mst_task {
      id
      issue_type
      title
      description
      reporter_userid
      assignee_userid
      status
      priority
      start_date
      target_date
      sprint_associationid
      mast_employee_assign {
        image
        id
        name
       }
     mst_task_mst_sprints {
        mst_sprint_mst_project {
          project_name
          id
        }
        sprint_name
        id
      }
    }
  }
`;
export const GET_TASK_MODAL = gql`
  query MyQuery($id: uuid) {
    mst_task(where: { id: { _eq: $id } }) {
      id
      issue_type
      title
      description
      reporter_userid
      assignee_userid
      status
      priority
      start_date
      target_date
      sprint_associationid
      mast_employee_assign {
        id
        name
        image
      }
      reporterrelation {
        id
        name
      }
      mst_task_mst_sprints {
        mst_sprint_mst_project {
          project_name
          id
        }
        sprint_name
        id
      }
    }
  }
`;
export const GET_EMPLOYEE_TASK = gql`
  query MyQuery {
    mst_employeedetails {
      id
      name
      status
    }
  }
`;

export const GET_SPRINT_TASK = gql`
  query MyQuery {
    mst_sprints {
      sprint_name
      id
    }
  }
`;
export const GET_SPRINT_QUERY = gql`
  query MyQuery {
    mst_sprints {
      end_date
      sprint_name
      project_associationid
      start_date
      status
      goal
      id
      mst_sprint_mst_project {
        id
        project_name
      }
    }
  }
`;
export const GET_PROJECT_NAME = gql`
  query MyQuery {
    mst_project {
      id
      project_name
    }
  }
`;
export const GET_ASSIGN_TONAME = gql`
  query MyQuery {
    mst_task {
      assignee_userid
      mast_employee_assign {
        name
      }
    }
  }
`;

export const GET_ASSIGNED_TITLE_DES = gql`
  query MyQuery {
    mst_task {
      description
      title
      status
      id
      issue_type
      assigneerelation {
        name
        image
      }
      priority
    }
  }
`;

export const GET_WORK_TIMESHEET = gql`
  query MyQuery {
    mst_work_timesheet {
      employee
      endDate
      id
      mst_employee {
        name
        mst_organization {
          name
        }
      }
      timesheet
      status
      startDate
      endDate
    }
  }
`;

export const GET_WORK_TIMESHEET_USER = gql`
  query MyQuery($employee: uuid) {
    mst_work_timesheet(where: { employee: { _eq: $employee } }) {
      employee
      endDate
      id
      mst_employee {
        name
        mst_organization {
          name
        }
      }
      timesheet
      status
      startDate
    }
  }
`;
export const GET_REMINDER_NOTIFICATION = gql`
  query MyQuery {
    mst_company_details {
      account_number
      bank_name
      company_address
      company_logo
      company_name
      created_at
      days
      gst_no
      gst_percent
      id
      phone_number
      qr_code
      remind
    }
  }
`;
export const CREATE_INVOICE_DETAILS = gql`
  query MyQuery {
    mst_company_details {
      account_number
      bank_name
      company_address
      company_logo
      company_name
      created_at
      days
      gst_no
      gst_percent
      id
      phone_number
      qr_code
    }
  }
`;
export const GET_INVOICE_DETAILS = gql`
  query MyQuery {
    mst_bookings {
      id
      mst_client {
        name
      }
      mst_product {
        name
        expiry
      }
      created_at
      price
      quantity
      total
    }
  }
`;

export const GET_COMMENTS = gql`
  query MyQuery($task_id: uuid) {
    mst_comments(where: { task_id: { _eq: $task_id } }) {
      comments
      created_at
      employee
      id
      mst_comments_mst_empolyee {
        name
        image
      }
      task_id
      updated_at
      created_at
    }
  }
`;
export const GET_CATEGORY_ID = gql`
  query MyQuery($id: uuid) {
    mst_product(where: { isdeleted: { _eq: false }, category: { _eq: $id } }) {
      id
      name
      description
      category
      sub_category
      price
      expiry
      isdeleted
      duration
      attributes
      mst_category {
        category
        created_at
        id
      }
      mst_sub_category {
        sub_name
      }
      created_at
      image
    }
  }
`;
export const ATTRIBUTE_ID_CATEGORY = gql`
  query MyQuery($categories: uuid) {
    mst_attributes(where: { categories: { _eq: $categories } }) {
      id
      name
      categories
      options
      mst_category {
        id
        category
      }
    }
  }
`;
export const GET_SUB_CATEGORY_ID = gql`
  query MyQuery($id: uuid) {
    mst_sub_category(
      where: { isdeleted: { _eq: false }, category: { _eq: $id } }
    ) {
      id
      description
      category
      sub_name
      image
      mst_category_sub_category {
        category
        id
        description
        image

      }
      isdeleted
    }
  }
`;
export const GET_PRODUCT_ATTRIBUTE = gql`
  query MyQuery($id: uuid) {
    mst_product(where: { isdeleted: { _eq: false }, id: { _eq: $id } }) {
      attributes
    }
  }
`;
export const GET_SUBCATEGORY_PRODUCTS = gql`
  query MyQuery($sub_category: uuid) {
  mst_product(where: {mst_sub_category: {id: {_eq: $sub_category}}}) {
    category
    image
    id
    description
    price
    sub_category
    name
  }
}

`;

// export const GET_CLIENT_DETAIL = gql`query MyQuery($client: uuid) {
//   mst_clientmanagement(where: {id: {_eq: $client}}) {
//     mst_bookings {
//       id
//       product
//       mst_product {
//         id
//         name
//       }
//       client
//     }
//     id
//   }
// }
// `

export const GET_TIMESHEET = gql`
  query MyQuery($employee: uuid, $date: date) {
    mst_timesheet(
      where: { date: { _eq: $date }, employee: { _eq: $employee } }
    ) {
      id
      in_time
      employee
      date
      out_time
      task
      seconds
      checkin_location
      mst_employeedetails {
        name
      }
    }
  }
`;

export const GET_REMINDER = gql`
  query MyQuery {
  mst_reminder {
    id
    expiry
    client
    product
    renewal
    booking_id
    snooze
    date
    created_at
    updated_at
 
    product_relation {
      name
    }
    clientmanage_relation {
      name
      company_name
    }
  }
}

`;

export const GET_BOOKED_PRODUCTS = gql`
 query MyQuery {
  mst_booked_products {
    booking_id
    id
    created_at
    price
    product
    quantity
    sub_total
    mst_products {
      image
      name
      attributes
    }
  }
}

`;

export const GET_SHOP = gql`query MyQuery {
  mst_shop(where: {isDeleted: {_eq: false}}) {
    created_at
    id
    shop_logo
    shop_name
  }
}

`
;

export const GET_SHOP_PRODUCTS = gql`query MyQuery($shopId: uuid!) {
  mst_product(order_by: {name: asc}, where: {mst_category: {shop_id: {_eq: $shopId}}}) {
    id
    image
    category
    description
    name
    sub_category
    attributes
    show_stock
    price
    stocks
    mst_sub_category {
      sub_name
    }
    mst_category {
      id
      category
      shop_id
    }
    featured_products
  }
}

`;



export const CHECK_SETTING_EXISTS = gql`
 query CheckSettingExists($shop_id: uuid!) {
  mst_settings(where: {shop_id: {_eq: $shop_id}}) {
    id
    shop_id
    shop_logo
    shop_name
  }
}

`;
export const GET_USER_CLIENT = gql `query MyQuery {
  mst_users (where: {isdeleted: {_eq: false},shop_id: {_eq: "${SHOP_ID}"}}) {
    email
    image
    mobile
    name
     shop {
      id
      shop_name
    }
    mst_user_address {
      address
      city
      landmark
      mobile
      pincode
      save_address_as
      state
      name
    }
  }
}
`;
export const GET_BANNER = gql`
query MyQuery {
  mst_banner(where: {shop_id: {_eq: "${SHOP_ID}"}, isdeleted: {_eq: false}}) {
    id
    created_at
    image
    isdeleted
    shop_id
    visibility
    bannershop {
      shop_name
    }
  }
}

`;

export const GET_MESSAGE = gql`query MyQuery {
  mst_users(where: {isdeleted: {_eq: false}}) {
    email
    image
    mobile
    name
    shop {
      id
      shop_name
    }
    mst_user_address {
      address
      city
      landmark
      mobile
      pincode
      save_address_as
      state
      name
    }
    shop_id
    userchat {
      message
      resolved
      created_at
      id
      is_admin
      user_id
    }
  }
}
`;
