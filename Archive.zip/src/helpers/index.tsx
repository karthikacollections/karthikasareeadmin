export * from './queries'
export * from './mutation'
export const BACKEND_URL = 'https://sycxxvjxcsvdbviafbvc.nhost.run'
