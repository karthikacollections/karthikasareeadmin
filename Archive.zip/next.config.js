/** @type {import('next').NextConfig} */
const nextConfig = {}

module.exports = nextConfig
module.exports = {
    images: {
      domains: ['res.cloudinary.com'],
    },
  };
  